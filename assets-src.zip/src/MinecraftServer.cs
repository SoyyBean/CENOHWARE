// Minecraft Server: manage a Minecraft Java server that runs on another PC, from this one. Works with vanilla, Paper, Spigot, Fabric
// and Forge servers on any operating system, because it only uses what the game itself offers over the network:
//   - the "server list ping" (what the multiplayer menu uses): online or offline, version, MOTD, players, latency. No setup needed.
//   - RCON, the game's remote console (turn it on in server.properties on the server PC: enable-rcon=true, rcon.port=25575,
//     rcon.password=<something>, then restart the server once): run any command, see who is online, kick, ban, op, whitelist, save, stop.
// Optional: a path to the server's logs\latest.log (a shared folder such as \\SERVER-PC\minecraft\logs\latest.log) shows the live log.
// The RCON password is stored on this PC only, encrypted for your Windows account. Never port-forward the RCON port to the internet.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

class McStatus
{
    public bool Online; public string Version = "", Motd = "", Error = ""; public int Online_, Max, Latency; public List<string> Sample = new List<string>();
}

static class McNet
{
    static void WriteVarInt(Stream s, int v) { uint u = (uint)v; while (true) { if ((u & ~0x7Fu) == 0) { s.WriteByte((byte)u); return; } s.WriteByte((byte)((u & 0x7F) | 0x80)); u >>= 7; } }
    static int ReadVarInt(Stream s) { int n = 0, shift = 0; while (true) { int b = s.ReadByte(); if (b < 0) throw new EndOfStreamException(); n |= (b & 0x7F) << shift; if ((b & 0x80) == 0) return n; shift += 7; if (shift > 35) throw new IOException("bad length"); } }
    static byte[] ReadExact(Stream s, int n) { var b = new byte[n]; int got = 0; while (got < n) { int r = s.Read(b, got, n - got); if (r <= 0) throw new EndOfStreamException(); got += r; } return b; }

    // the "server list ping": what the multiplayer menu does
    public static McStatus Ping(string host, int port, int timeoutMs)
    {
        var st = new McStatus();
        try
        {
            using (var c = new TcpClient())
            {
                var ar = c.BeginConnect(host, port, null, null); if (!ar.AsyncWaitHandle.WaitOne(timeoutMs)) { st.Error = "no answer (is the server on, and is the address and port right?)"; return st; } c.EndConnect(ar);
                c.ReceiveTimeout = c.SendTimeout = timeoutMs; var ns = c.GetStream();
                var hs = new MemoryStream(); WriteVarInt(hs, 0); WriteVarInt(hs, 765); var hb = Encoding.UTF8.GetBytes(host); WriteVarInt(hs, hb.Length); hs.Write(hb, 0, hb.Length); hs.WriteByte((byte)(port >> 8)); hs.WriteByte((byte)(port & 255)); WriteVarInt(hs, 1);
                var pk = new MemoryStream(); WriteVarInt(pk, (int)hs.Length); var hbytes = hs.ToArray(); pk.Write(hbytes, 0, hbytes.Length); pk.WriteByte(1); pk.WriteByte(0);           // handshake, then the status request (length 1, id 0)
                var o = pk.ToArray(); ns.Write(o, 0, o.Length);
                int len = ReadVarInt(ns); int id = ReadVarInt(ns); int jl = ReadVarInt(ns); var jb = ReadExact(ns, jl); string json = Encoding.UTF8.GetString(jb);
                var t0 = DateTime.UtcNow; var ping = new MemoryStream(); ping.WriteByte(9); ping.WriteByte(1); for (int i = 0; i < 8; i++) ping.WriteByte((byte)i); var pb = ping.ToArray(); ns.Write(pb, 0, pb.Length);
                try { ReadVarInt(ns); ReadVarInt(ns); ReadExact(ns, 8); st.Latency = (int)(DateTime.UtcNow - t0).TotalMilliseconds; } catch { }
                var d = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.DeserializeObject(json) as Dictionary<string, object>;
                if (d != null)
                {
                    st.Online = true; var v = d.ContainsKey("version") ? d["version"] as Dictionary<string, object> : null; if (v != null && v.ContainsKey("name")) st.Version = Convert.ToString(v["name"]);
                    var p = d.ContainsKey("players") ? d["players"] as Dictionary<string, object> : null;
                    if (p != null) { if (p.ContainsKey("online")) st.Online_ = Convert.ToInt32(p["online"]); if (p.ContainsKey("max")) st.Max = Convert.ToInt32(p["max"]); var sm = p.ContainsKey("sample") ? p["sample"] as System.Collections.IEnumerable : null; if (sm != null) foreach (object x in sm) { var xd = x as Dictionary<string, object>; if (xd != null && xd.ContainsKey("name")) st.Sample.Add(Convert.ToString(xd["name"])); } }
                    st.Motd = d.ContainsKey("description") ? Plain(d["description"]) : "";
                }
            }
        }
        catch (Exception ex) { st.Online = false; st.Error = ex is SocketException ? "the connection was refused (is the server running?)" : ex.Message; }
        return st;
    }
    // the MOTD can be a plain string or chat components (text plus extra parts)
    static string Plain(object o)
    {
        var s = o as string; if (s != null) return Strip(s); var d = o as Dictionary<string, object>; if (d == null) return "";
        var sb = new StringBuilder(); if (d.ContainsKey("text")) sb.Append(Convert.ToString(d["text"])); var ex = d.ContainsKey("extra") ? d["extra"] as System.Collections.IEnumerable : null; if (ex != null) foreach (object x in ex) sb.Append(Plain(x)); return Strip(sb.ToString());
    }
    public static string Strip(string s) { return Regex.Replace(s ?? "", "\u00a7.", "").Replace("\r", "").Replace("\n", "  "); }

    // RCON, the game's remote console (one connection, commands one at a time)
    public class Rcon : IDisposable
    {
        TcpClient c; NetworkStream ns; int nextId = 1; readonly object gate = new object();
        public bool Connected { get { return c != null && c.Connected; } }
        public string Connect(string host, int port, string password, int timeoutMs)
        {
            try
            {
                c = new TcpClient(); var ar = c.BeginConnect(host, port, null, null); if (!ar.AsyncWaitHandle.WaitOne(timeoutMs)) { c.Close(); c = null; return "no answer on the RCON port (is RCON on, and is the firewall open on the server PC?)"; }
                c.EndConnect(ar); c.ReceiveTimeout = c.SendTimeout = timeoutMs; ns = c.GetStream();
                int id = Send(3, password); Packet r = Read(); if (r.Type == 0) r = Read();                // some servers send an empty response first
                if (r.Id == -1 || r.Id != id) { Dispose(); return "wrong RCON password"; }
                return "";
            }
            catch (Exception ex) { Dispose(); return ex is SocketException ? "the RCON connection was refused" : ex.Message; }
        }
        class Packet { public int Id, Type; public string Body; }
        int Send(int type, string body)
        {
            int id = nextId++; var b = Encoding.UTF8.GetBytes(body ?? ""); var ms = new MemoryStream(); var w = new BinaryWriter(ms);
            w.Write(10 + b.Length); w.Write(id); w.Write(type); w.Write(b); w.Write((byte)0); w.Write((byte)0); var o = ms.ToArray(); ns.Write(o, 0, o.Length); return id;
        }
        Packet Read()
        {
            var lb = ReadExact(ns, 4); int len = BitConverter.ToInt32(lb, 0); if (len < 10 || len > 1 << 20) throw new IOException("bad RCON packet"); var b = ReadExact(ns, len);
            return new Packet { Id = BitConverter.ToInt32(b, 0), Type = BitConverter.ToInt32(b, 4), Body = Encoding.UTF8.GetString(b, 8, Math.Max(0, len - 10)) };
        }
        public string Command(string cmd)
        {
            lock (gate)
            {
                if (ns == null) throw new IOException("not connected"); Send(2, cmd); var sb = new StringBuilder(); var p = Read(); sb.Append(p.Body);
                while (p.Body.Length >= 4000) { c.ReceiveTimeout = 400; try { p = Read(); sb.Append(p.Body); } catch { break; } finally { c.ReceiveTimeout = 5000; } }      // long answers arrive in 4096 byte pieces
                return sb.ToString();
            }
        }
        public void Dispose() { try { if (ns != null) ns.Close(); } catch { } try { if (c != null) c.Close(); } catch { } ns = null; c = null; }
    }
}

// the zipped copy of the world: read from the server's (shared) folder while the server is running, so the world is first told to
// save and to stop writing (save-off), and every file is opened in a way that lets the server keep its own handle on it.
static class McBackup
{
    public static string LevelName(string serverDir)
    {
        try { foreach (string line in File.ReadAllLines(Path.Combine(serverDir, "server.properties"))) if (line.StartsWith("level-name=")) { string n = line.Substring(11).Trim(); if (n.Length > 0) return n; } } catch { }
        return "world";
    }
    public static string Zip(string serverDir, string destDir, Action<string> say)
    {
        string level = LevelName(serverDir); var dirs = new List<string>(); foreach (string suffix in new[] { "", "_nether", "_the_end" }) { string d = Path.Combine(serverDir, level + suffix); if (Directory.Exists(d)) dirs.Add(d); }
        if (dirs.Count == 0) throw new IOException("No world folder called '" + level + "' in " + serverDir + " (check the server folder path)");
        Directory.CreateDirectory(destDir); string zip = Path.Combine(destDir, level + "_" + DateTime.Now.ToString("yyyy-MM-dd_HHmmss", CultureInfo.InvariantCulture) + ".zip"); int files = 0, skipped = 0; long bytes = 0;
        using (var fs = new FileStream(zip, FileMode.Create)) using (var za = new System.IO.Compression.ZipArchive(fs, System.IO.Compression.ZipArchiveMode.Create))
        {
            foreach (string d in dirs)
                foreach (string f in Directory.GetFiles(d, "*", SearchOption.AllDirectories))
                {
                    if (f.EndsWith("session.lock", StringComparison.OrdinalIgnoreCase)) continue;
                    try
                    {
                        using (var src = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                        {
                            var e = za.CreateEntry(f.Substring(serverDir.TrimEnd('\\', '/').Length + 1).Replace('\\', '/'), System.IO.Compression.CompressionLevel.Fastest);
                            using (var o = e.Open()) src.CopyTo(o); bytes += src.Length; files++; if (files % 300 == 0 && say != null) say("  zipped " + files.ToString("N0", CultureInfo.InvariantCulture) + " files (" + (bytes >> 20) + " MB)…");
                        }
                    }
                    catch (IOException) { skipped++; }
                }
        }
        if (say != null) say("Backup written: " + zip + "  (" + files.ToString("N0", CultureInfo.InvariantCulture) + " files, " + (new FileInfo(zip).Length >> 20) + " MB" + (skipped > 0 ? ", " + skipped + " in use and skipped" : "") + ")");
        return zip;
    }
    // keep only the newest `keep` backups of this world (the older ones go to the Recycle Bin)
    public static void Prune(string destDir, string level, int keep, Action<string> say)
    {
        try
        {
            var fi = new List<FileInfo>(new DirectoryInfo(destDir).GetFiles(level + "_*.zip")); fi.Sort((a, b) => b.LastWriteTime.CompareTo(a.LastWriteTime)); int n = 0;
            for (int i = Math.Max(1, keep); i < fi.Count; i++) { try { Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(fi[i].FullName, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin); n++; } catch { } }
            if (n > 0 && say != null) say("Removed " + n + " old backup" + (n == 1 ? "" : "s") + " (keeping the newest " + keep + "; they are in the Recycle Bin).");
        }
        catch { }
    }
    // put a backup back: the current world folders are renamed (kept), the zip is unpacked in their place; the server must be stopped
    public static void Restore(string zip, string serverDir, Action<string> say)
    {
        using (var za = System.IO.Compression.ZipFile.OpenRead(zip)) foreach (var e in za.Entries) if (e.FullName.Contains("..") || Path.IsPathRooted(e.FullName)) throw new IOException("the backup contains an unsafe path: " + e.FullName);
        string level = LevelName(serverDir), stamp = DateTime.Now.ToString("yyyyMMdd-HHmm", CultureInfo.InvariantCulture); var moved = new List<KeyValuePair<string, string>>();
        try
        {
            foreach (string suffix in new[] { "", "_nether", "_the_end" }) { string d = Path.Combine(serverDir, level + suffix); if (Directory.Exists(d)) { string to = d + ".before-restore-" + stamp; Directory.Move(d, to); moved.Add(new KeyValuePair<string, string>(d, to)); if (say != null) say("Kept the current " + level + suffix + " as " + Path.GetFileName(to)); } }
            if (say != null) say("Unpacking the backup…"); System.IO.Compression.ZipFile.ExtractToDirectory(zip, serverDir); if (say != null) say("Restored. Start the server again.");
        }
        catch
        {
            foreach (var kv in moved) { try { if (Directory.Exists(kv.Key)) Directory.Delete(kv.Key, true); Directory.Move(kv.Value, kv.Key); } catch { } }
            throw;
        }
    }
}

// fake servers on this PC, so the real client code can be run without a real server (check switch --mc)
static class McTest
{
    public static bool Stop;
    public static void StartAll(int gp, int rp, int hp)
    {
        var gl = new TcpListener(IPAddress.Loopback, gp); var rl = new TcpListener(IPAddress.Loopback, rp); var hl = new TcpListener(IPAddress.Loopback, hp); gl.Start(); rl.Start(); hl.Start(); Stop = false;
        new Thread(delegate () { try { while (!Stop) { var c = gl.AcceptTcpClient(); ThreadPool.QueueUserWorkItem(delegate { try { FakePing(c); } catch { } }); } } catch { } }) { IsBackground = true }.Start();
        new Thread(delegate () { try { while (!Stop) { var c = rl.AcceptTcpClient(); ThreadPool.QueueUserWorkItem(delegate { try { FakeRcon(c); } catch { } }); } } catch { } }) { IsBackground = true }.Start();
        new Thread(delegate () { try { while (!Stop) { var c = hl.AcceptTcpClient(); ThreadPool.QueueUserWorkItem(delegate { try { FakeHelper(c); } catch { } }); } } catch { } }) { IsBackground = true }.Start();
    }
    static int ReadVar(Stream s) { int n = 0, sh = 0; while (true) { int b = s.ReadByte(); if (b < 0) throw new EndOfStreamException(); n |= (b & 0x7F) << sh; if ((b & 0x80) == 0) return n; sh += 7; } }
    static void WriteVar(Stream s, int v) { uint u = (uint)v; while (true) { if ((u & ~0x7Fu) == 0) { s.WriteByte((byte)u); return; } s.WriteByte((byte)((u & 0x7F) | 0x80)); u >>= 7; } }
    static void FakePing(TcpClient c)
    {
        using (c)
        {
            var ns = c.GetStream(); ReadVar(ns); ReadVar(ns); ReadVar(ns); int l = ReadVar(ns); for (int i = 0; i < l; i++) ns.ReadByte(); ns.ReadByte(); ns.ReadByte(); ReadVar(ns); ReadVar(ns); ReadVar(ns);
            string json = "{\"version\":{\"name\":\"Paper 1.20.4\",\"protocol\":765},\"players\":{\"max\":20,\"online\":2,\"sample\":[{\"name\":\"Steve\",\"id\":\"1\"},{\"name\":\"Alex\",\"id\":\"2\"}]},\"description\":{\"text\":\"\",\"extra\":[{\"text\":\"\\u00a7aMy \"},{\"text\":\"survival world\"}]}}";
            var jb = Encoding.UTF8.GetBytes(json); var body = new MemoryStream(); body.WriteByte(0); WriteVar(body, jb.Length); body.Write(jb, 0, jb.Length); var o = new MemoryStream(); WriteVar(o, (int)body.Length); var bb = body.ToArray(); o.Write(bb, 0, bb.Length); var ob = o.ToArray(); ns.Write(ob, 0, ob.Length);
            ReadVar(ns); ReadVar(ns); var pl = new byte[8]; int got = 0; while (got < 8) got += ns.Read(pl, got, 8 - got); var pong = new MemoryStream(); pong.WriteByte(9); pong.WriteByte(1); pong.Write(pl, 0, 8); var pb = pong.ToArray(); ns.Write(pb, 0, pb.Length);
        }
    }
    static void FakeRcon(TcpClient c)
    {
        using (c)
        {
            var ns = c.GetStream(); var br = new BinaryReader(ns);
            Action<int, int, string> send = (id, type, body) => { var b = Encoding.UTF8.GetBytes(body); var ms = new MemoryStream(); var w = new BinaryWriter(ms); w.Write(10 + b.Length); w.Write(id); w.Write(type); w.Write(b); w.Write((byte)0); w.Write((byte)0); var o = ms.ToArray(); ns.Write(o, 0, o.Length); };
            bool authed = false;
            while (true)
            {
                int len = br.ReadInt32(); int id = br.ReadInt32(); int type = br.ReadInt32(); var rest = br.ReadBytes(len - 8); string body = Encoding.UTF8.GetString(rest, 0, Math.Max(0, rest.Length - 2));
                if (type == 3) { authed = body == "secret"; send(authed ? id : -1, 2, ""); }
                else if (type == 2 && authed)
                {
                    if (body == "list") send(id, 0, "There are 2 of a max of 20 players online: Steve, Alex");
                    else if (body == "biglist") { send(id, 0, new string('a', 4096)); send(id, 0, new string('b', 4096)); send(id, 0, new string('c', 808)); }
                    else if (body == "tps") send(id, 0, "TPS from last 1m, 5m, 15m: 19.8, 20.0, 20.0");
                    else if (body == "whitelist list") send(id, 0, "There are 3 whitelisted players: Steve, Alex, Notch");
                    else if (body == "banlist players") send(id, 0, "There are 1 bans:\nGriefer was banned by Rcon: Banned by an operator.");
                    else if (body.StartsWith("gamerule ")) { string nm = body.Substring(9); if (nm == "keepInventory") send(id, 0, "Gamerule keepInventory is currently set to: false"); else if (nm == "advance_time") send(id, 0, "Gamerule advance_time is currently set to: true"); else if (nm == "mobGriefing") send(id, 0, "Gamerule mobGriefing is currently set to: true"); else if (nm == "doMobSpawning") send(id, 0, "Gamerule doMobSpawning is currently set to: true"); else send(id, 0, "Incorrect argument for command"); }
                    else if (body.StartsWith("gamemode ")) send(id, 0, "Set Alex's game mode to Creative Mode");
                    else if (body.StartsWith("give ")) send(id, 0, "Gave 16 [Diamond] to Alex");
                    else if (body.StartsWith("tp ")) send(id, 0, "Teleported Alex to Steve");
                    else send(id, 0, "Said it");
                }
            }
        }
    }
    static void FakeHelper(TcpClient c)
    {
        using (c)
        {
            var ns = c.GetStream(); var rd = new StreamReader(ns, Encoding.UTF8); var wr = new StreamWriter(ns, new UTF8Encoding(false)) { NewLine = "\n", AutoFlush = true };
            string auth = rd.ReadLine(); if (auth != "AUTH tok123") { wr.WriteLine("error=wrong token"); wr.WriteLine("END"); return; }
            string cmd = rd.ReadLine();
            if (cmd == "STATUS") { wr.WriteLine("running=1"); wr.WriteLine("autorestart=0"); wr.WriteLine("crashes=1"); wr.WriteLine("pid=4242"); wr.WriteLine("cpu=23.5"); wr.WriteLine("ramMB=3120"); wr.WriteLine("uptimeSec=93784"); wr.WriteLine("diskFreeGB=210"); wr.WriteLine("diskTotalGB=465"); }
            else wr.WriteLine("ok " + cmd);
            wr.WriteLine("END");
        }
    }
}
