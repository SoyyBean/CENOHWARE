// Draws CENOHWARE.ico: a deep violet tile with the placeholder neon C logo (same C as the intro). This is a stand-in: to use your own icon later, put a CENOHWARE.ico in the assets folder (see build.ps1 -Assets)
// or pass -Icon to the build, and this one is ignored.
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;

class MakeIcon
{
    static GraphicsPath Round(RectangleF r, float d)
    {
        var p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure(); return p;
    }
    static bool UseChip;
    static byte[] Render(int s)
    {
        using (var bmp = new Bitmap(s, s))
        using (var g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias; g.PixelOffsetMode = PixelOffsetMode.HighQuality; g.Clear(Color.Transparent);
            g.ScaleTransform(s / 256f, s / 256f);
            if (UseChip) { CasinoLogo.Chip(g, new RectangleF(0, 0, 256, 256)); using (var zs = new MemoryStream()) { bmp.Save(zs, System.Drawing.Imaging.ImageFormat.Png); return zs.ToArray(); } }
            var tile = new RectangleF(8, 8, 240, 240);
            using (var path = Round(tile, 84))
            {
                using (var b = new LinearGradientBrush(tile, Color.FromArgb(46, 24, 96), Color.FromArgb(12, 10, 28), 60f)) g.FillPath(b, path);
                var st = g.Save(); g.SetClip(path);
                using (var gp = new GraphicsPath())
                {
                    gp.AddEllipse(28, 28, 200, 200);
                    using (var pg = new PathGradientBrush(gp) { CenterColor = Color.FromArgb(150, 139, 92, 246), SurroundColors = new[] { Color.FromArgb(0, 139, 92, 246) } }) g.FillPath(pg, gp);
                }
                g.Restore(st);
                using (var p = new Pen(Color.FromArgb(70, 170, 130, 255), 3f)) g.DrawPath(p, path);
            }
            // the C: a thick open ring (opening to the right) in violet to cyan with a white-hot core and a node in the opening
            float cx = 120, cy = 128, r = 66, th = 34; var rect = new RectangleF(cx - r, cy - r, r * 2, r * 2);
            var violet = Color.FromArgb(150, 110, 255); var cyan = Color.FromArgb(56, 189, 248);
            using (var p = new Pen(Color.FromArgb(60, violet), th * 1.9f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(p, rect, 40, 280);
            using (var lb = new LinearGradientBrush(rect, cyan, violet, 90f)) using (var p = new Pen(lb, th)) g.DrawArc(p, rect, 40, 280);
            double sa = 40 * Math.PI / 180.0, ea = 320 * Math.PI / 180.0;
            foreach (var ang in new[] { sa, ea }) { var col = ang == sa ? violet : cyan; using (var br = new SolidBrush(col)) g.FillEllipse(br, cx + r * (float)Math.Cos(ang) - th / 2, cy + r * (float)Math.Sin(ang) - th / 2, th, th); }
            using (var p = new Pen(Color.FromArgb(235, 255, 255, 255), th * 0.34f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(p, rect, 46, 268);
            using (var b2 = new SolidBrush(Color.White)) g.FillEllipse(b2, cx + r * 0.46f - 15, cy - 15, 30, 30);
            using (var p = new Pen(cyan, 5f)) g.DrawEllipse(p, cx + r * 0.46f - 15, cy - 15, 30, 30);
            using (var ms = new MemoryStream()) { bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Png); return ms.ToArray(); }
        }
    }
    static void Main(string[] args)
    {
        UseChip = args.Length > 1 && args[1] == "chip";
        int[] sizes = { 16, 24, 32, 48, 64, 128, 256 };
        var imgs = new byte[sizes.Length][];
        for (int i = 0; i < sizes.Length; i++) imgs[i] = Render(sizes[i]);
        using (var w = new BinaryWriter(File.Create(args[0])))
        {
            w.Write((short)0); w.Write((short)1); w.Write((short)sizes.Length);
            int offset = 6 + 16 * sizes.Length;
            for (int i = 0; i < sizes.Length; i++)
            {
                byte dim = (byte)(sizes[i] == 256 ? 0 : sizes[i]);
                w.Write(dim); w.Write(dim); w.Write((byte)0); w.Write((byte)0); w.Write((short)1); w.Write((short)32);
                w.Write(imgs[i].Length); w.Write(offset); offset += imgs[i].Length;
            }
            foreach (var b in imgs) w.Write(b);
        }
        File.WriteAllBytes(Path.ChangeExtension(args[0], ".256.png"), imgs[imgs.Length - 1]);
    }
}
