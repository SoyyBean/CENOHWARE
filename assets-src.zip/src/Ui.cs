// Shared look and feel: one accent colour in, a whole theme out (dark, light, Frutiger Aero, Dragon Ball, Janemba, Zachery), plus the custom buttons and cards.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

// ---- theme: one accent colour in, a whole dark palette out ---------------------------------------------------------------
static class Theme
{
    public static Color Bg, Panel, Card, CardHover, Border, Text, Dim, Accent, AccentSoft, OnAccent, ConsoleBg;
    public static Color Green = Color.FromArgb(52, 211, 153), Red = Color.FromArgb(248, 113, 113), Amber = Color.FromArgb(251, 191, 36);
    public static string NativeStyle { get { return Light ? "Explorer" : "DarkMode_Explorer"; } }      // the style Windows gives scrollbars and list boxes
    public static bool Zach;                                                      // the Zachery theme: his green striped turtleneck, zebra print pants and pink boots
    public static readonly Color ZachKey = Color.FromArgb(254, 94, 172);
    public static bool Jnb;                                                       // the Janemba theme: the red Other World sky, purple demon gloss, floating jelly orbs
    public static readonly Color JnbKey = Color.FromArgb(232, 44, 98);
    public static bool Dbz;                                                       // the Dragon Ball theme: a dark night sky, orange ki, gold and dragon balls
    public static readonly Color DbzKey = Color.FromArgb(254, 140, 2);
    public static bool Light, Aero;                                                  // Aero = the Frutiger Aero theme (a light, glossy palette); it is chosen with the special accent colour AeroKey
    public static readonly Color AeroKey = Color.FromArgb(12, 160, 232);
    public static readonly string[] PresetNames = { "Violet", "Ocean", "Sky", "Teal", "Emerald", "Lime", "Gold", "Sunset", "Rose", "Pink" };
    public static readonly Color[] PresetColors =
    {
        Color.FromArgb(139, 92, 246), Color.FromArgb(59, 130, 246), Color.FromArgb(56, 189, 248), Color.FromArgb(20, 184, 166), Color.FromArgb(52, 211, 153),
        Color.FromArgb(163, 230, 53), Color.FromArgb(251, 191, 36), Color.FromArgb(249, 115, 22), Color.FromArgb(244, 63, 94), Color.FromArgb(236, 72, 153)
    };
    public static readonly Font UI = new Font("Segoe UI", 9f), UIB = new Font("Segoe UI Semibold", 9.5f), UIL = new Font("Segoe UI Semibold", 11f),
        Small = new Font("Segoe UI", 8.5f), SmallB = new Font("Segoe UI Semibold", 8f), Mono = new Font("Consolas", 9f), Title = new Font("Segoe UI Black", 19f),
        Head = new Font("Segoe UI Semibold", 8.5f), Tab = new Font("Segoe UI Semibold", 10.5f), Glyph = new Font("Segoe UI Symbol", 11f);

    static Theme() { Apply(PresetColors[0]); }

    /// <summary>Text / lines that must stand out from a card: lighter on the dark themes, darker on the light one.</summary>
    public static Color Emph(Color c, float k) { return Lerp(c, Light ? Color.Black : Color.White, k); }

    // Frutiger Aero: sky blue, white glass, fresh green, deep navy text (the colours of Windows Vista/7 and the mid-2000s web)
    static void ApplyJnb()
    {
        Aero = false; Light = false; Dbz = false; Zach = false; Jnb = true; Accent = JnbKey; AccentSoft = Color.FromArgb(255, 218, 70);
        Bg = Color.FromArgb(44, 5, 20); Panel = Color.FromArgb(66, 9, 30); Card = Color.FromArgb(92, 14, 44); CardHover = Color.FromArgb(128, 24, 66);
        Border = Color.FromArgb(188, 70, 138); Text = Color.FromArgb(255, 238, 244); Dim = Color.FromArgb(232, 160, 196); OnAccent = Color.White; ConsoleBg = Color.FromArgb(30, 3, 14);
        Green = Color.FromArgb(120, 232, 150); Red = Color.FromArgb(255, 120, 110); Amber = Color.FromArgb(255, 214, 64);
    }
    static void ApplyZach()
    {
        Jnb = false; Dbz = false; Aero = false; Light = false; Zach = true; Accent = ZachKey; AccentSoft = Color.FromArgb(255, 176, 214);
        Bg = Color.FromArgb(6, 24, 13); Panel = Color.FromArgb(10, 36, 21); Card = Color.FromArgb(15, 50, 30); CardHover = Color.FromArgb(24, 76, 46);
        Border = Color.FromArgb(64, 150, 94); Text = Color.FromArgb(238, 255, 242); Dim = Color.FromArgb(150, 204, 168); OnAccent = Color.FromArgb(52, 0, 28); ConsoleBg = Color.FromArgb(4, 17, 10);
        Green = Color.FromArgb(100, 238, 142); Red = Color.FromArgb(255, 112, 112); Amber = Color.FromArgb(255, 212, 72);
    }
    static void ApplyDbz()
    {
        Jnb = false; Zach = false; Aero = false; Light = false; Dbz = true; Accent = DbzKey; AccentSoft = Color.FromArgb(255, 208, 72);
        Bg = Color.FromArgb(9, 13, 42); Panel = Color.FromArgb(15, 21, 62); Card = Color.FromArgb(23, 31, 82); CardHover = Color.FromArgb(36, 48, 114);
        Border = Color.FromArgb(78, 94, 176); Text = Color.FromArgb(255, 246, 224); Dim = Color.FromArgb(158, 172, 218); OnAccent = Color.FromArgb(44, 16, 0); ConsoleBg = Color.FromArgb(6, 9, 30);
        Green = Color.FromArgb(84, 224, 124); Red = Color.FromArgb(255, 88, 72); Amber = Color.FromArgb(255, 204, 48);
    }
    static void ApplyAero()
    {
        Dbz = false; Jnb = false; Zach = false; Aero = true; Light = true; Accent = AeroKey; AccentSoft = Color.FromArgb(0, 112, 196);
        Bg = Color.FromArgb(205, 234, 250); Panel = Color.FromArgb(226, 243, 253); Card = Color.FromArgb(244, 250, 255); CardHover = Color.White;
        Border = Color.FromArgb(128, 184, 218); Text = Color.FromArgb(10, 48, 82); Dim = Color.FromArgb(62, 100, 130); OnAccent = Color.White; ConsoleBg = Color.FromArgb(238, 248, 255);
        Green = Color.FromArgb(22, 142, 62); Red = Color.FromArgb(204, 46, 46); Amber = Color.FromArgb(188, 116, 0);
    }
    /// <summary>The white "glass" highlight across the top half of a shape: the signature of Aero.</summary>
    // Aero glass: a bright curved sheen over the top half (its lower edge sags like a lens reflection and has a crisp rim), then a soft tinted light gathering at the bottom
    public static void Gloss(Graphics g, GraphicsPath path, RectangleF r, int alphaTop, int alphaBottom)
    {
        if (r.Height < 4 || r.Width < 4) return;
        var st = g.Save(); g.SetClip(path, CombineMode.Intersect);
        float w = r.Width, h = r.Height, yb = r.Y + h * 0.52f, sag = Math.Min(h * 0.12f, 16f);
        using (var sheen = new GraphicsPath())
        {
            sheen.AddLine(r.X - 2, r.Y - 2, r.Right + 2, r.Y - 2);
            sheen.AddLine(r.Right + 2, r.Y - 2, r.Right + 2, yb - sag);
            sheen.AddBezier(new PointF(r.Right + 2, yb - sag), new PointF(r.X + w * 0.66f, yb + sag * 0.9f), new PointF(r.X + w * 0.34f, yb + sag * 1.5f), new PointF(r.X - 2, yb - sag * 0.2f));
            sheen.CloseFigure();
            using (var b = new LinearGradientBrush(new RectangleF(r.X, r.Y - 2, w, h * 0.62f + 4), Color.FromArgb(Math.Min(255, alphaTop + 40), 255, 255, 255), Color.FromArgb(Math.Min(255, alphaBottom + 14), 255, 255, 255), 90f)) g.FillPath(b, sheen);
            using (var p = new Pen(Color.FromArgb(Math.Min(255, alphaTop / 2 + 20), 255, 255, 255), 1.2f)) g.DrawBezier(p, new PointF(r.Right + 2, yb - sag), new PointF(r.X + w * 0.66f, yb + sag * 0.9f), new PointF(r.X + w * 0.34f, yb + sag * 1.5f), new PointF(r.X - 2, yb - sag * 0.2f));
        }
        var low = new RectangleF(r.X, r.Y + h * 0.58f, w, h * 0.42f + 1);
        using (var b = new LinearGradientBrush(new RectangleF(low.X, low.Y - 1, low.Width, low.Height + 2), Color.FromArgb(0, 120, 232, 255), Color.FromArgb(Math.Min(255, alphaTop / 2), 150, 240, 255), 90f)) g.FillRectangle(b, low);
        g.Restore(st);
    }

    public static event Action<Color> BeforeApply;                                   // lets the hub grab the old look so it can cross-fade to the new one
    public static void Apply(Color accent)
    {
        if (BeforeApply != null) BeforeApply(accent);
        if (accent.ToArgb() == AeroKey.ToArgb()) { ApplyAero(); return; }
        if (accent.ToArgb() == DbzKey.ToArgb()) { ApplyDbz(); return; }
        if (accent.ToArgb() == JnbKey.ToArgb()) { ApplyJnb(); return; }
        if (accent.ToArgb() == ZachKey.ToArgb()) { ApplyZach(); return; }
        Dbz = false; Jnb = false; Zach = false; Aero = false; Light = false; Green = Color.FromArgb(52, 211, 153); Red = Color.FromArgb(248, 113, 113); Amber = Color.FromArgb(251, 191, 36);
        float h, s, l; ToHsl(accent, out h, out s, out l);
        Accent = accent; AccentSoft = Lerp(accent, Color.White, 0.40f);
        Bg = Hsl(h, 0.30f, 0.075f); Panel = Hsl(h, 0.28f, 0.105f); Card = Hsl(h, 0.24f, 0.140f); CardHover = Hsl(h, 0.28f, 0.185f);
        Border = Hsl(h, 0.22f, 0.27f); Text = Hsl(h, 0.30f, 0.93f); Dim = Hsl(h, 0.14f, 0.66f); ConsoleBg = Hsl(h, 0.30f, 0.055f);
        OnAccent = (0.299 * accent.R + 0.587 * accent.G + 0.114 * accent.B) > 150 ? Hsl(h, 0.45f, 0.08f) : Color.White;
    }
    public static string Hex(Color c) { return c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2"); }
    public static bool TryHex(string s, out Color c)
    {
        c = Color.Empty; s = (s ?? "").Trim().TrimStart('#');
        int v; if (s.Length != 6 || !int.TryParse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out v)) return false;
        c = Color.FromArgb((v >> 16) & 255, (v >> 8) & 255, v & 255); return true;
    }
    public static Color Lerp(Color a, Color b, float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }
    static void ToHsl(Color c, out float h, out float s, out float l)
    {
        float r = c.R / 255f, g = c.G / 255f, b = c.B / 255f, max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
        l = (max + min) / 2f; float d = max - min;
        if (d < 1e-5f) { h = 0; s = 0; return; }
        s = l > 0.5f ? d / (2f - max - min) : d / (max + min);
        if (max == r) h = (g - b) / d + (g < b ? 6 : 0); else if (max == g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h *= 60f;
    }
    static Color Hsl(float h, float s, float l)
    {
        float c = (1 - Math.Abs(2 * l - 1)) * s, hp = (h % 360f) / 60f, x = c * (1 - Math.Abs(hp % 2 - 1)), r = 0, g = 0, b = 0;
        if (hp < 1) { r = c; g = x; } else if (hp < 2) { r = x; g = c; } else if (hp < 3) { g = c; b = x; } else if (hp < 4) { g = x; b = c; } else if (hp < 5) { r = x; b = c; } else { r = c; b = x; }
        float m = l - c / 2f;
        return Color.FromArgb((int)Math.Round((r + m) * 255), (int)Math.Round((g + m) * 255), (int)Math.Round((b + m) * 255));
    }
    // Dragon Ball: chamfered, comic-panel corners. Janemba: shard corners (two long cuts, two short ones). Everything else: rounded.
    public static GraphicsPath Cut(Rectangle r, int d, bool dbz)
    {
        float m = Math.Min(r.Width, r.Height) / 2f, a, b, c, e;
        if (dbz) { a = b = c = e = Math.Min(m, d * 0.62f + 1f); } else { float big = Math.Min(m, d * 1.0f), sm = Math.Min(m, d * 0.3f); a = big; b = sm; c = big; e = sm; }
        var p = new GraphicsPath();
        p.AddPolygon(new[] { new PointF(r.X + a, r.Y), new PointF(r.Right - b, r.Y), new PointF(r.Right, r.Y + b), new PointF(r.Right, r.Bottom - c), new PointF(r.Right - c, r.Bottom), new PointF(r.X + e, r.Bottom), new PointF(r.X, r.Bottom - e), new PointF(r.X, r.Y + a) });
        return p;
    }
    /// <summary>The Dragon Ball (cel-shaded: hard light/dark split, speed stripes, thick ink outline) and Janemba (a faceted shard: diagonal light/dark halves, thin bright edge) button looks.</summary>
    public static void PaintToon(Graphics g, GraphicsPath path, Rectangle r, Color hi, Color lo, Color edge, bool dbz, float hv)
    {
        var st = g.Save(); g.SetClip(path, CombineMode.Intersect);
        using (var b = new SolidBrush(lo)) g.FillPath(b, path);
        if (dbz)
        {
            using (var b = new SolidBrush(hi)) g.FillRectangle(b, r.X, r.Y, r.Width, (int)(r.Height * 0.56f));
            using (var p = new Pen(Color.FromArgb(34, 255, 255, 255), 2f)) for (int x = -r.Height; x < r.Width; x += 10) g.DrawLine(p, r.X + x, r.Bottom, r.X + x + r.Height, r.Y);
        }
        else
        {
            using (var b = new SolidBrush(hi)) g.FillPolygon(b, new[] { new PointF(r.X, r.Y), new PointF(r.Right, r.Y), new PointF(r.X, r.Bottom) });
            using (var b = new SolidBrush(Color.FromArgb(24, 255, 255, 255))) g.FillPolygon(b, new[] { new PointF(r.X + r.Width * 0.5f, r.Y), new PointF(r.X + r.Width * 0.62f, r.Y), new PointF(r.X + r.Width * 0.12f, r.Bottom), new PointF(r.X, r.Bottom) });
        }
        g.Restore(st);
        if (hv > 0.02f) using (var p = new Pen(Color.FromArgb((int)((dbz ? 150 : 130) * hv), dbz ? Color.FromArgb(255, 222, 90) : Color.FromArgb(255, 80, 200)), 5f)) g.DrawPath(p, path);
        using (var p = new Pen(edge, dbz ? 2.4f : 1.6f)) g.DrawPath(p, path);
        if (dbz) using (var inner = Cut(Rectangle.Inflate(r, -2, -2), 10, true)) using (var p = new Pen(Color.FromArgb(120, 255, 255, 255), 1f)) g.DrawPath(p, inner);
    }
    public static GraphicsPath Round(Rectangle r, int d)
    {
        if (Dbz || Jnb) return Cut(r, d, Dbz);
        var p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure(); return p;
    }
    public const TextFormatFlags Wrap = TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix | TextFormatFlags.Left | TextFormatFlags.Top;
    public static int Measure(string s, Font f, int width)
    {
        if (string.IsNullOrEmpty(s)) return 0;
        return TextRenderer.MeasureText(s, f, new Size(Math.Max(20, width), 0), Wrap).Height;
    }
}

// ---- one shared animation clock: runs only while something is moving, and is paced to the monitor ----------------------------
// A background thread waits for the display's next refresh (DwmFlush) and asks the UI thread for one frame, never queueing more than
// one, so animations run at 60 / 120 / 144 Hz exactly like the screen. (Without a UI context it falls back to a 15 ms timer.)
static class Ticker
{
    [DllImport("dwmapi.dll")] static extern int DwmFlush();
    static Action<float> frame; static long last; static SynchronizationContext ctx; static int gen, pending; static bool running;
    static readonly System.Windows.Forms.Timer Fallback = new System.Windows.Forms.Timer { Interval = 15 };
    static Ticker() { Fallback.Tick += delegate { Pump(); }; }
    public static event Action<float> Frame
    {
        add { frame += value; Sync(); }
        remove { frame -= value; Sync(); }
    }
    static void Sync()
    {
        if (frame != null && !running) Start();
        else if (frame == null && running) { running = false; gen++; Fallback.Stop(); }
    }
    static void Start()
    {
        running = true; last = Stopwatch.GetTimestamp(); ctx = SynchronizationContext.Current;
        if (ctx == null) { Fallback.Start(); return; }
        int my = ++gen;
        var th = new Thread(delegate ()
        {
            long lastPost = 0;
            while (running && my == gen)
            {
                try { DwmFlush(); } catch { Thread.Sleep(8); }
                long n = Stopwatch.GetTimestamp();
                if ((n - lastPost) * 1000 / Stopwatch.Frequency < 3) Thread.Sleep(3);       // a screen that is off must not make this spin
                lastPost = Stopwatch.GetTimestamp();
                if (Interlocked.Exchange(ref pending, 1) == 0)
                {
                    try { ctx.Post(delegate { Interlocked.Exchange(ref pending, 0); Pump(); }, null); }
                    catch { Interlocked.Exchange(ref pending, 0); Thread.Sleep(10); }          // the window is not ready yet (start-up) or is closing: try again next frame
                }
            }
        }) { IsBackground = true, Name = "ticker" };
        th.Start();
    }
    static void Pump()
    {
        long n = Stopwatch.GetTimestamp(); float dt = (float)((n - last) / (double)Stopwatch.Frequency); last = n; if (dt > 0.05f) dt = 0.05f;
        var f = frame; if (f != null) f(dt);
    }
    public static float Ease(float cur, float target, float k, float dt)
    {
        cur += (target - cur) * (1f - (float)Math.Exp(-k * dt));
        return Math.Abs(target - cur) < 0.004f ? target : cur;
    }
}

static class Js
{
    static readonly JavaScriptSerializer Ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
    public static Dictionary<string, object> Parse(string s) { return Ser.Deserialize<Dictionary<string, object>>(s); }
    public static string S(Dictionary<string, object> d, string k) { object o; return d != null && d.TryGetValue(k, out o) && o != null ? Convert.ToString(o) : ""; }
    public static bool B(Dictionary<string, object> d, string k) { object o; return d != null && d.TryGetValue(k, out o) && o is bool && (bool)o; }
    public static int I(Dictionary<string, object> d, string k, int def) { object o; return d != null && d.TryGetValue(k, out o) && o != null ? Convert.ToInt32(o) : def; }
    public static List<object> L(Dictionary<string, object> d, string k)
    {
        var r = new List<object>(); object o;
        if (d != null && d.TryGetValue(k, out o) && o is IEnumerable && !(o is string)) foreach (object x in (IEnumerable)o) r.Add(x);
        return r;
    }
    public static List<string> Strs(Dictionary<string, object> d, string k) { var r = new List<string>(); foreach (object x in L(d, k)) r.Add(Convert.ToString(x)); return r; }
    public static Dictionary<string, object> O(object o) { return o as Dictionary<string, object>; }
    public static string Quote(string s) { return "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""; }
}

// ---- controls -------------------------------------------------------------------------------------------------------------------------
class Btn : Control
{
    public bool Primary, Selected, Big;
    public bool Danger; public float Pulse;          // Danger = red "recording" look; Pulse 0..1 makes it breathe (set by the owner)
    bool hover, down; float hoverT; bool hooked;
    public Btn(string text)
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        Text = text; Font = Theme.UIB; Height = 32; Cursor = Cursors.Hand;
    }
    void OnFrame(float dt)
    {
        float t = hover ? 1f : 0f; hoverT = Ticker.Ease(hoverT, t, 16f, dt); Invalidate();
        if (hoverT == t && hooked) { Ticker.Frame -= OnFrame; hooked = false; }
    }
    void Kick() { if (!hooked) { hooked = true; Ticker.Frame += OnFrame; } }
    // the glossy Aero button: a bright upper half, a deeper lower half, a white gloss, a white inner edge, a glow on hover
    void PaintToonHover(Graphics g, GraphicsPath path, Rectangle r, Color hi, Color lo, Color edge, bool d)
    {
        if (down) { hi = Theme.Lerp(hi, Color.Black, 0.18f); lo = Theme.Lerp(lo, Color.Black, 0.2f); }
        Theme.PaintToon(g, path, r, Theme.Lerp(hi, Color.White, hoverT * 0.18f), lo, edge, d, hoverT);
    }
    void PaintAero(Graphics g, Rectangle r)
    {
        bool prim = Primary || Selected; var rr = new Rectangle(0, 0, Width - 2, Height - 3); float hv = hoverT;
        Color top, bot, border, txt;
        if (!Enabled) { top = Color.FromArgb(240, 246, 250); bot = Color.FromArgb(216, 228, 238); border = Color.FromArgb(188, 204, 218); txt = Color.FromArgb(138, 158, 176); }
        else if (Danger) { top = Theme.Lerp(Color.FromArgb(255, 176, 166), Color.FromArgb(255, 126, 114), Pulse); bot = Theme.Lerp(Color.FromArgb(196, 40, 36), Color.FromArgb(232, 72, 60), Pulse); border = Color.FromArgb(140, 24, 20); txt = Color.White; }
        else if (prim) { top = Theme.Lerp(Color.FromArgb(52, 156, 236), Color.FromArgb(110, 204, 252), hv); bot = Theme.Lerp(Color.FromArgb(0, 92, 190), Color.FromArgb(10, 130, 224), hv); border = Color.FromArgb(0, 84, 150); txt = Color.White; }
        else { top = Theme.Lerp(Color.FromArgb(250, 253, 255), Color.White, hv); bot = Theme.Lerp(Color.FromArgb(206, 232, 248), Color.FromArgb(172, 222, 250), hv); border = Theme.Lerp(Color.FromArgb(122, 172, 206), Color.FromArgb(36, 148, 220), hv); txt = Theme.Text; }
        if (down) { top = Theme.Lerp(top, Color.Black, 0.12f); bot = Theme.Lerp(bot, Color.Black, 0.14f); }
        int rad = Big ? 14 : 11;
        using (var path = Theme.Round(rr, rad))
        {
            using (var sp = Theme.Round(new Rectangle(rr.X + 1, rr.Y + 2, rr.Width, rr.Height), rad)) using (var sb = new SolidBrush(Color.FromArgb(40, 20, 70, 120))) g.FillPath(sb, sp);
            using (var b = new LinearGradientBrush(rr, top, bot, 90f))
            {
                b.InterpolationColors = new ColorBlend(4) { Colors = new[] { top, Theme.Lerp(top, bot, 0.42f), Theme.Lerp(top, bot, 0.66f), bot }, Positions = new[] { 0f, 0.48f, 0.52f, 1f } };
                g.FillPath(b, path);
            }
            Theme.Gloss(g, path, rr, 150, 36);
            using (var p = new Pen(border)) g.DrawPath(p, path);
            using (var inner = Theme.Round(Rectangle.Inflate(rr, -1, -1), Math.Max(2, rad - 2))) using (var p = new Pen(Color.FromArgb(150, 255, 255, 255))) g.DrawPath(p, inner);
            if (hv > 0.02f && Enabled) using (var p = new Pen(Color.FromArgb((int)(110 * hv), 90, 210, 255), 3f)) g.DrawPath(p, path);
        }
        var fnt = Big ? Theme.Tab : Font; var flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix;
        if (Enabled && (prim || Danger)) TextRenderer.DrawText(g, Text, fnt, new Rectangle(rr.X, rr.Y + 1, rr.Width, rr.Height), Color.FromArgb(Danger ? 120 : 0, Danger ? 20 : 70, Danger ? 16 : 130), flags);
        TextRenderer.DrawText(g, Text, fnt, rr, txt, flags);
    }
    protected override void Dispose(bool d) { if (d && hooked) { Ticker.Frame -= OnFrame; hooked = false; } base.Dispose(d); }
    protected override void OnMouseEnter(EventArgs e) { hover = true; Kick(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hover = false; down = false; Kick(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { down = true; Invalidate(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { down = false; Invalidate(); base.OnMouseUp(e); }
    protected override void OnEnabledChanged(EventArgs e) { Cursor = Enabled ? Cursors.Hand : Cursors.Default; Invalidate(); base.OnEnabledChanged(e); }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        var hp = Parent as IBackdropHost;
        if (hp != null) hp.PaintBackdropFor(g, this); else if ((Theme.Dbz || Theme.Jnb) && Parent != null)
        {
            // the cut corners show what is really behind the button (a card the parent drew), not just the form colour: let the parent paint that bit
            var st0 = g.Save(); g.TranslateTransform(-Left, -Top); g.SetClip(new Rectangle(Left, Top, Width, Height));
            using (var pe = new PaintEventArgs(g, new Rectangle(Left, Top, Width, Height))) { InvokePaintBackground(Parent, pe); InvokePaint(Parent, pe); }
            g.Restore(st0);
        }
        else g.Clear(Parent != null ? Parent.BackColor : Theme.Bg);
        var r = new Rectangle(0, 0, Width - 1, Height - 1);
        if (Theme.Aero) { PaintAero(g, r); return; }
        Color fill, border, txt;
        if (!Enabled) { fill = Theme.Lerp(Theme.Card, Theme.Bg, 0.4f); border = Theme.Lerp(Theme.Border, Theme.Bg, 0.5f); txt = Theme.Lerp(Theme.Dim, Theme.Bg, 0.5f); }
        else if (Danger)
        {
            fill = Theme.Lerp(Theme.Lerp(Theme.Red, Color.Black, 0.25f), Theme.Red, Pulse * 0.8f + hoverT * 0.2f);
            if (down) fill = Theme.Lerp(fill, Color.Black, 0.2f);
            border = Theme.Lerp(fill, Color.White, 0.3f); txt = Color.White;
        }
        else if (Primary || Selected)
        {
            fill = Theme.Lerp(Theme.Accent, Theme.AccentSoft, hoverT * 0.45f);
            if (down) fill = Theme.Lerp(fill, Color.Black, 0.2f);
            border = Theme.Lerp(fill, Color.White, 0.22f); txt = Theme.OnAccent;
        }
        else
        {
            fill = Theme.Lerp(Theme.Card, Theme.CardHover, hoverT); if (down) fill = Theme.Lerp(fill, Color.Black, 0.2f);
            border = Theme.Lerp(Theme.Border, Theme.Accent, hoverT * 0.7f); txt = Theme.Text;
        }
        using (var path = Theme.Round(r, Big ? 14 : 10))
        {
            if (Theme.Zach && Enabled)                       // green knit cards, pink boots for the main buttons
            {
                bool strong = Primary || Selected || Danger; Color hi, lo, edge;
                if (Danger) { hi = Color.FromArgb(255, 126, 110); lo = Color.FromArgb(166, 24, 34); edge = Color.FromArgb(255, 214, 200); }
                else if (strong) { hi = Theme.Lerp(Color.FromArgb(255, 150, 206), Color.FromArgb(255, 196, 226), hoverT); lo = Color.FromArgb(212, 44, 128); edge = Color.FromArgb(255, 230, 242); }
                else { hi = Theme.Lerp(Theme.CardHover, Theme.Card, 0.25f); lo = Theme.Card; edge = Theme.Lerp(Theme.Border, Color.FromArgb(255, 110, 184), hoverT); }
                if (down) { hi = Theme.Lerp(hi, Color.Black, 0.18f); lo = Theme.Lerp(lo, Color.Black, 0.2f); }
                using (var b = new LinearGradientBrush(r, Theme.Lerp(hi, Color.White, hoverT * 0.12f), lo, 90f)) g.FillPath(b, path);
                if (!strong) { var st = g.Save(); g.SetClip(path); using (var b = new SolidBrush(Color.FromArgb(34, 0, 0, 0))) for (int yy = 4; yy < r.Height; yy += 8) g.FillRectangle(b, 0, yy, r.Width, 3); g.Restore(st); }
                using (var b = new LinearGradientBrush(new Rectangle(0, 0, r.Width, Math.Max(2, r.Height / 2)), Color.FromArgb(strong ? 90 : 34, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f)) { var st = g.Save(); g.SetClip(path); g.FillRectangle(b, 0, 0, r.Width, Math.Max(2, r.Height / 2)); g.Restore(st); }
                using (var p = new Pen(edge, strong ? 1.8f : 1.4f)) g.DrawPath(p, path);
                if (hoverT > 0.02f) using (var p = new Pen(Color.FromArgb((int)(110 * hoverT), 255, 110, 184), 4f)) g.DrawPath(p, path);
            }
            else if ((Theme.Dbz || Theme.Jnb) && Enabled)
            {
                bool strong = Primary || Selected || Danger, d = Theme.Dbz; Color hi, lo, edge;
                if (Danger) { hi = Color.FromArgb(255, 112, 92); lo = Color.FromArgb(150, 18, 24); edge = d ? Color.FromArgb(70, 6, 6) : Color.FromArgb(255, 214, 70); }
                else if (strong) { hi = d ? Color.FromArgb(255, 196, 56) : Color.FromArgb(176, 58, 196); lo = d ? Color.FromArgb(226, 96, 0) : Color.FromArgb(82, 16, 128); edge = d ? Color.FromArgb(70, 26, 0) : Color.FromArgb(255, 220, 72); }
                else { hi = Theme.Lerp(Theme.CardHover, Theme.Card, 0.2f); lo = Theme.Card; edge = d ? Theme.Lerp(Color.FromArgb(255, 170, 30), Color.FromArgb(255, 226, 110), hoverT) : Theme.Lerp(Theme.Border, Color.FromArgb(255, 220, 72), hoverT); }
                PaintToonHover(g, path, r, hi, lo, edge, d);
            }
            else
            {
                using (var b = new SolidBrush(fill)) g.FillPath(b, path);
                using (var p = new Pen(border)) g.DrawPath(p, path);
            }
        }
        TextRenderer.DrawText(g, Text, Big ? Theme.Tab : Font, r, txt, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
    }
}

// the top bar: soft colour glow, slow sparkles, a moving shimmer along the bottom edge, title and status painted straight on
class HeaderPanel : Panel, IBackdropHost
{
    public string Title = "CENOHWARE", StatusText = "", SubText = "";
    public Color StatusTone = Theme.Dim;
    bool hooked;
    readonly float[] sx = new float[26], sy = new float[26], sv = new float[26], ss = new float[26], sp = new float[26];
    float t;
    public HeaderPanel()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        var r = new Random(7);
        for (int i = 0; i < sx.Length; i++) { sx[i] = (float)r.NextDouble(); sy[i] = (float)r.NextDouble(); sv[i] = 0.01f + (float)r.NextDouble() * 0.03f; ss[i] = 0.8f + (float)r.NextDouble() * 1.6f; sp[i] = (float)r.NextDouble() * 6.28f; }
        VisibleChanged += delegate { Hook(); }; HandleCreated += delegate { Hook(); };
    }
    void Hook()
    {
        bool want = Visible && IsHandleCreated;
        if (want && !hooked) { hooked = true; Ticker.Frame += OnFrame; } else if (!want && hooked) { hooked = false; Ticker.Frame -= OnFrame; }
    }
    void OnFrame(float dt) { var f = FindForm(); if (f == null || f.WindowState == FormWindowState.Minimized || HubState.IntroPlaying) return; t += dt; Invalidate(); }
    protected override void Dispose(bool d) { if (d && hooked) { hooked = false; Ticker.Frame -= OnFrame; } base.Dispose(d); }
    public void SetStatus(string text, Color tone) { StatusText = text; StatusTone = tone; Invalidate(); }

    public void PaintBackdropFor(Graphics g, Control c)
    {
        var st = g.Save(); g.TranslateTransform(-c.Left, -c.Top); g.SetClip(new Rectangle(c.Left, c.Top, c.Width, c.Height));
        DrawBackdrop(g); g.Restore(st);
    }
    void DrawBackdrop(Graphics g)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var rc = new Rectangle(0, 0, Width, Height);
        if (Theme.Aero)
        {
            using (var b = new LinearGradientBrush(rc, Color.FromArgb(138, 206, 248), Color.FromArgb(230, 245, 254), 90f)) g.FillRectangle(b, rc);
            using (var path = new GraphicsPath()) { path.AddRectangle(rc); Theme.Gloss(g, path, rc, 120, 18); }
            for (int i = 0; i < sx.Length; i++)                                   // bubbles drifting up
            {
                float y = (sy[i] - sv[i] * t * 0.35f) % 1f; if (y < 0) y += 1f;
                float rad = ss[i] * 5f + 3f, x = sx[i] * Width + (float)Math.Sin(t * 0.8f + sp[i]) * 6f, yy = y * Height, tw = 0.55f + 0.45f * (float)Math.Abs(Math.Sin(t * 1.1f + sp[i]));
                using (var br = new SolidBrush(Color.FromArgb((int)(46 * tw), 255, 255, 255))) g.FillEllipse(br, x - rad, yy - rad, rad * 2, rad * 2);
                using (var p = new Pen(Color.FromArgb((int)(150 * tw), 255, 255, 255), 1f)) g.DrawEllipse(p, x - rad, yy - rad, rad * 2, rad * 2);
                using (var br = new SolidBrush(Color.FromArgb((int)(170 * tw), 255, 255, 255))) g.FillEllipse(br, x - rad * 0.55f, yy - rad * 0.65f, rad * 0.55f, rad * 0.4f);
            }
            using (var p = new Pen(Color.FromArgb(120, 70, 140, 190))) g.DrawLine(p, 0, Height - 1, Width, Height - 1);
            using (var p = new Pen(Color.FromArgb(200, 255, 255, 255))) g.DrawLine(p, 0, Height - 2, Width, Height - 2);
            float sw = ((t * 0.18f) % 1.4f - 0.2f) * Width; var sg = new Rectangle((int)sw - 140, 0, 280, Height);
            using (var lb = new LinearGradientBrush(sg, Color.Transparent, Color.Transparent, 0f))
            {
                lb.InterpolationColors = new ColorBlend(3) { Colors = new[] { Color.FromArgb(0, 255, 255, 255), Color.FromArgb(54, 255, 255, 255), Color.FromArgb(0, 255, 255, 255) }, Positions = new[] { 0f, 0.5f, 1f } };
                g.FillRectangle(lb, sg);
            }
            return;
        }
        using (var b = new LinearGradientBrush(rc, Theme.Lerp(Theme.Panel, Theme.Accent, 0.30f), Theme.Panel, 0f))
        { b.SetBlendTriangularShape(0.0f, 1f); b.Blend = new Blend { Positions = new[] { 0f, 0.55f, 1f }, Factors = new[] { 0f, 0.85f, 1f } }; g.FillRectangle(b, rc); }
        for (int i = 0; i < sx.Length; i++)
        {
            float y = (sy[i] - sv[i] * t * 0.35f) % 1f; if (y < 0) y += 1f;
            float x = sx[i] * Width + (float)Math.Sin(t * 0.8f + sp[i]) * 6f, yy = y * Height;
            float tw = 0.3f + 0.7f * (float)Math.Abs(Math.Sin(t * 1.4f + sp[i]));
            using (var br = new SolidBrush(Color.FromArgb((int)(150 * tw), Theme.AccentSoft))) g.FillEllipse(br, x - ss[i], yy - ss[i], ss[i] * 2, ss[i] * 2);
        }
        float sh = ((t * 0.18f) % 1.4f - 0.2f) * Width;     // shimmer along the bottom edge
        using (var p = new Pen(Theme.Lerp(Theme.Border, Theme.Panel, 0.4f))) g.DrawLine(p, 0, Height - 1, Width, Height - 1);
        var seg = new Rectangle((int)sh - 120, Height - 3, 240, 2);
        using (var lb = new LinearGradientBrush(seg, Color.Transparent, Color.Transparent, 0f))
        {
            lb.InterpolationColors = new ColorBlend(3) { Colors = new[] { Color.FromArgb(0, Theme.Accent), Color.FromArgb(230, Theme.AccentSoft), Color.FromArgb(0, Theme.Accent) }, Positions = new[] { 0f, 0.5f, 1f } };
            g.FillRectangle(lb, seg);
        }
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        DrawBackdrop(g);
        if (Theme.Aero) TextRenderer.DrawText(g, Title, Theme.Title, new Point(23, 14), Color.FromArgb(255, 255, 255));        // white "glass" shadow under navy letters
        TextRenderer.DrawText(g, Title, Theme.Title, new Point(22, 12), Theme.Aero ? Color.FromArgb(8, 66, 118) : Color.White);
        TextRenderer.DrawText(g, SubText, Theme.Small, new Point(24, 50), Theme.Aero ? Color.FromArgb(30, 78, 112) : Theme.Lerp(Theme.Dim, Color.White, 0.2f));
        if (StatusText.Length > 0)
            TextRenderer.DrawText(g, StatusText, Theme.Small, new Rectangle(Width - 560, 20, 540 - 0, 22), StatusTone, TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
    }
}

class HeaderLabel : Control
{
    public Color Tone;
    public HeaderLabel(string text, Color tone)
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        Text = text; Tone = tone; Height = 28;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.Clear(Parent.BackColor);
        TextRenderer.DrawText(g, Text, Theme.Head, new Rectangle(0, 0, Width, Height - 5), Tone, TextFormatFlags.Left | TextFormatFlags.Bottom | TextFormatFlags.NoPrefix);
        using (var p = new Pen(Theme.Lerp(Theme.Border, Theme.Bg, 0.35f))) g.DrawLine(p, 0, Height - 2, Width, Height - 2);
    }
}

interface IFlowRow { int PreferredHeight(int width); }

// a parent that paints something fancy behind its buttons (so their rounded corners match it)
interface IBackdropHost { void PaintBackdropFor(Graphics g, Control c); }

static class Draw
{
    public static int Chip(Graphics g, int x, int y, string text, Color tone, bool filled)
    {
        Size sz = TextRenderer.MeasureText(text, Theme.SmallB, Size.Empty, TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        var r = new Rectangle(x, y, sz.Width + 14, 19);
        using (var path = Theme.Round(r, 10))
        {
            using (var b = new SolidBrush(filled ? Theme.Lerp(Theme.Card, tone, 0.28f) : Theme.Lerp(Theme.Card, tone, 0.1f))) g.FillPath(b, path);
            using (var p = new Pen(Theme.Lerp(Theme.Card, tone, 0.55f))) g.DrawPath(p, path);
        }
        TextRenderer.DrawText(g, text, Theme.SmallB, r, filled ? Theme.Emph(tone, 0.35f) : tone, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        return r.Width + 6;
    }
    public static void IconDisc(Graphics g, Rectangle r, Color tone, string glyph)
    {
        using (var b = new SolidBrush(Theme.Lerp(Theme.Card, tone, 0.22f))) g.FillEllipse(b, r);
        using (var p = new Pen(Theme.Lerp(Theme.Card, tone, 0.6f), 1.2f)) g.DrawEllipse(p, r);
        TextRenderer.DrawText(g, glyph, Theme.Glyph, r, Theme.Emph(tone, 0.3f), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
    }
}

class Banner : Control, IFlowRow
{
    public Color Tone; public string Glyph;
    public Banner(string text, Color tone, string glyph) { Text = text; Tone = tone; Glyph = glyph; SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true); }
    public int PreferredHeight(int width) { return Math.Max(56, Theme.Measure(Text, Theme.UI, width - 74) + 26); }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit; g.Clear(Parent.BackColor);
        var r = new Rectangle(0, 0, Width - 1, Height - 1);
        using (var path = Theme.Round(r, 14))
        {
            using (var b = new LinearGradientBrush(r, Theme.Lerp(Theme.Card, Tone, 0.20f), Theme.Lerp(Theme.Card, Tone, 0.05f), 0f)) g.FillPath(b, path);
            using (var p = new Pen(Theme.Lerp(Theme.Border, Tone, 0.65f))) g.DrawPath(p, path);
        }
        Draw.IconDisc(g, new Rectangle(14, (Height - 34) / 2, 34, 34), Tone, Glyph);
        TextRenderer.DrawText(g, Text, Theme.UI, new Rectangle(62, 12, Width - 78, 900), Theme.Text, Theme.Wrap);
    }
}

class InfoText : Control, IFlowRow
{
    public Color Tone;
    public InfoText(string text, Color tone) { Text = text; Tone = tone; SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true); }
    public int PreferredHeight(int width) { return Theme.Measure(Text, Theme.UI, width) + 6; }
    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.Clear(Parent.BackColor); e.Graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        TextRenderer.DrawText(e.Graphics, Text, Theme.UI, new Rectangle(0, 2, Width, 900), Tone, Theme.Wrap);
    }
}

// swatches for the theme picker
class ThemePopup : Control
{
    public event Action<Color> Picked; public event Action CustomClicked;
    int hot = -2;
    readonly float[] sc = new float[14];
    bool hooked;
    public ThemePopup()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        Size = new Size(316, PopH); Visible = false; Cursor = Cursors.Hand;
    }
    Rectangle Swatch(int i) { return new Rectangle(18 + (i % 5) * 58, 40 + (i / 5) * 46, 40, 40); }
    Rectangle AeroRect() { return new Rectangle(18, 134, 136, 34); }
    Rectangle JnbRect() { return new Rectangle(18, 176, 280, 34); }
    Rectangle ZachRect() { return new Rectangle(18, 218, 280, 34); }
    const int PopH = 292, CustomY = 262;
    Rectangle DbzRect() { return new Rectangle(162, 134, 136, 34); }
    Rectangle CustomRect() { return new Rectangle(18, 126 - 4, 280, 0); }
    int HitTest(Point p)
    {
        for (int i = 0; i < 10; i++) if (Rectangle.Inflate(Swatch(i), 6, 6).Contains(p)) return i;
        if (AeroRect().Contains(p)) return 10;
        if (DbzRect().Contains(p)) return 11;
        if (JnbRect().Contains(p)) return 12;
        if (ZachRect().Contains(p)) return 13;
        return -1;
    }
    void OnFrame(float dt)
    {
        bool moving = false;
        for (int i = 0; i < 14; i++) { float t = hot == i ? 1f : 0f; float n = Ticker.Ease(sc[i], t, 18f, dt); if (n != t) moving = true; sc[i] = n; }
        Invalidate();
        if (!moving && hooked) { Ticker.Frame -= OnFrame; hooked = false; }
    }
    void Kick() { if (!hooked) { hooked = true; Ticker.Frame += OnFrame; } }
    protected override void Dispose(bool d) { if (d && hooked) { Ticker.Frame -= OnFrame; hooked = false; } base.Dispose(d); }
    protected override void OnMouseMove(MouseEventArgs e) { int h = HitTest(e.Location); if (h != hot) { hot = h; Kick(); } base.OnMouseMove(e); }
    protected override void OnMouseLeave(EventArgs e) { hot = -2; Kick(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        int h = HitTest(e.Location);
        if (h == 10 && Picked != null) Picked(Theme.AeroKey);
        else if (h == 11 && Picked != null) Picked(Theme.DbzKey);
        else if (h == 12 && Picked != null) Picked(Theme.JnbKey);
        else if (h == 13 && Picked != null) Picked(Theme.ZachKey);
        else if (h >= 0 && Picked != null) Picked(Theme.PresetColors[h]);
        else if (e.Y > CustomY - 4 && CustomClicked != null) CustomClicked();
        base.OnMouseDown(e);
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit; g.Clear(Theme.Bg);
        var r = new Rectangle(0, 0, Width - 1, Height - 1);
        using (var path = Theme.Round(r, 16))
        {
            using (var b = new SolidBrush(Theme.Panel)) g.FillPath(b, path);
            using (var p = new Pen(Theme.Lerp(Theme.Border, Theme.Accent, 0.5f))) g.DrawPath(p, path);
        }
        string title = hot == 10 ? "Theme: Frutiger Aero" : hot == 11 ? "Theme: Dragon Ball" : hot == 12 ? "Theme: Janemba" : hot == 13 ? "Theme: Zachery" : hot >= 0 ? "Theme: " + Theme.PresetNames[hot] : "Pick a theme colour";
        TextRenderer.DrawText(g, title, Theme.UIB, new Rectangle(18, 10, Width - 36, 22), Theme.Text, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        for (int i = 0; i < 10; i++)
        {
            var s = Swatch(i); float k = sc[i];
            var rr = Rectangle.Round(new RectangleF(s.X - 4 * k, s.Y - 4 * k, s.Width + 8 * k, s.Height + 8 * k));
            bool current = Theme.PresetColors[i].ToArgb() == Theme.Accent.ToArgb();
            using (var b = new SolidBrush(Theme.PresetColors[i])) g.FillEllipse(b, rr);
            if (current) using (var p = new Pen(Color.White, 2.4f)) g.DrawEllipse(p, Rectangle.Inflate(rr, 4, 4));
            else if (k > 0.05f) using (var p = new Pen(Color.FromArgb((int)(200 * k), Color.White), 1.6f)) g.DrawEllipse(p, Rectangle.Inflate(rr, 3, 3));
        }
        {   // the Frutiger Aero button: sky, glass and a gloss
            var ar = AeroRect(); float k = sc[10]; bool cur = Theme.Aero;
            using (var path = Theme.Round(ar, 16))
            {
                using (var b = new LinearGradientBrush(ar, Color.FromArgb(150, 214, 250), Color.FromArgb(24, 150, 230), 90f)) g.FillPath(b, path);
                Theme.Gloss(g, path, ar, 170, 30);
                using (var p = new Pen(cur ? Color.White : Color.FromArgb(120 + (int)(100 * k), 255, 255, 255), cur ? 2.4f : 1.4f)) g.DrawPath(p, path);
            }
            TextRenderer.DrawText(g, "Frutiger Aero", Theme.UIB, new Rectangle(ar.X, ar.Y + 1, ar.Width, ar.Height), Color.FromArgb(0, 70, 130), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            TextRenderer.DrawText(g, "Frutiger Aero", Theme.UIB, ar, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
        {   // the Janemba button: a faceted shard
            var jr = JnbRect(); float k = sc[12]; bool cur = Theme.Jnb;
            using (var path = Theme.Cut(jr, 16, false)) Theme.PaintToon(g, path, jr, Color.FromArgb(236, 120, 240), Color.FromArgb(120, 20, 110), cur ? Color.White : Color.FromArgb(255, 220, 72), false, k);
            TextRenderer.DrawText(g, "Janemba", Theme.UIB, new Rectangle(jr.X, jr.Y + 1, jr.Width, jr.Height), Color.FromArgb(70, 0, 40), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            TextRenderer.DrawText(g, "Janemba", Theme.UIB, jr, Color.FromArgb(255, 226, 90), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
        {   // the Zachery button: green turtleneck stripes, a zebra tab and a pink edge
            var zr = ZachRect(); float k = sc[13]; bool cur = Theme.Zach;
            using (var path = Theme.Round(zr, 14))
            {
                using (var b = new LinearGradientBrush(zr, Color.FromArgb(52, 168, 92), Color.FromArgb(18, 92, 50), 90f)) g.FillPath(b, path);
                var st = g.Save(); g.SetClip(path);
                using (var b = new SolidBrush(Color.FromArgb(60, 0, 40, 16))) for (int yy = zr.Y + 4; yy < zr.Bottom; yy += 8) g.FillRectangle(b, zr.X, yy, zr.Width, 3);
                using (var b = new SolidBrush(Color.White)) g.FillRectangle(b, zr.X, zr.Bottom - 6, zr.Width, 6);
                using (var b = new SolidBrush(Color.Black)) for (int xx = zr.X - 6; xx < zr.Right; xx += 12) g.FillPolygon(b, new[] { new Point(xx, zr.Bottom), new Point(xx + 5, zr.Bottom), new Point(xx + 8, zr.Bottom - 6), new Point(xx + 3, zr.Bottom - 6) });
                g.Restore(st);
                using (var p = new Pen(cur ? Color.White : Color.FromArgb(255, 110 + (int)(60 * k), 184), cur ? 2.4f : 1.8f)) g.DrawPath(p, path);
            }
            TextRenderer.DrawText(g, "Zachery", Theme.UIB, new Rectangle(zr.X, zr.Y - 2, zr.Width, zr.Height), Color.FromArgb(255, 150, 206), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
        {   // the Dragon Ball button: cel-shaded orange with ink outline
            var dr = DbzRect(); float k = sc[11]; bool cur = Theme.Dbz;
            using (var path = Theme.Cut(dr, 16, true)) Theme.PaintToon(g, path, dr, Color.FromArgb(255, 196, 56), Color.FromArgb(226, 96, 0), cur ? Color.White : Color.FromArgb(70, 26, 0), true, k);
            TextRenderer.DrawText(g, "Dragon Ball", Theme.UIB, dr, Color.FromArgb(60, 20, 0), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
        var cr = new Rectangle(18, 122, Width - 36, 0);
        TextRenderer.DrawText(g, "or choose any colour\u2026", Theme.Small, new Rectangle(18, CustomY, Width - 36, 20), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
    }
}

class PopupCloser : IMessageFilter
{
    public Control Popup; public Control[] KeepOpenOn;
    public bool PreFilterMessage(ref Message m)
    {
        if (m.Msg != 0x201 || Popup == null || !Popup.Visible) return false;
        Control c = Control.FromHandle(m.HWnd);
        for (Control x = c; x != null; x = x.Parent) { if (x == Popup) return false; if (KeepOpenOn != null) foreach (Control k in KeepOpenOn) if (x == k) return false; }
        Popup.Visible = false; return false;
    }
}

// one scrolling page per tab; kept alive and just shown / hidden
class ListHost : Panel
{
    public readonly List<Control> Rows = new List<Control>();
    public string Signature = "";            // what the page currently shows (so an unchanged answer doesn't rebuild it)
    public bool NeedsLayout;
    public ListHost()
    {
        SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
        AutoScroll = true; Dock = DockStyle.Fill; BackColor = Theme.Bg;
    }
    protected override CreateParams CreateParams { get { var cp = base.CreateParams; cp.ExStyle |= 0x02000000; return cp; } }   // WS_EX_COMPOSITED: no flicker while scrolling or swapping
}

// ---- how the CENOHWARE hub talks to a tool that lives inside it as a page ----
interface IHubPage
{
    void HubShown();          // the page was just brought to the front
    void HubHidden();         // another page took over (stop anything that should not run in the background)
    void HubTheme();          // the accent colour changed somewhere: repaint in the new colours
    void HubPrewarm();        // the hub built this page in the background: do any slow first-time work now, so the first click is instant
}

// set by the CENOHWARE hub while its intro plays, so everything else holds still and the intro gets the whole UI thread
static class HubState { public static volatile bool IntroPlaying, Transitioning; }

// The accent colour picker, in the app's own look: slide the bar for the colour, click the square for the shade, or type a hex code.
// It only repaints when something changes, so it costs nothing while idle.
class ColorPicker : Form
{
    const int SqX = 24, SqY = 106, SqS = 232, BarX = 272, BarW = 26;
    float hue, sat, val; Color start; bool dragSq, dragBar, typing;
    Bitmap sq, bar; float sqHue = -1f; TextBox hex; Btn ok, cancel; int hotSwatch = -1;
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int v, int size);
    public Color Result { get { return FromHsv(hue, sat, val); } }

    public static bool Show(IWin32Window owner, Color startColor, out Color picked)
    {
        using (var f = new ColorPicker(startColor)) { bool yes = f.ShowDialog(owner) == DialogResult.OK; picked = yes ? f.Result : startColor; return yes; }
    }
    // check switch: draws the dialog (its own window only) to a PNG
    public static void TestShot(string path) { using (var f = new ColorPicker(Color.FromArgb(249, 115, 22))) { f.StartPosition = FormStartPosition.CenterScreen; f.Show(); for (int i = 0; i < 20; i++) { Application.DoEvents(); Thread.Sleep(20); } using (var bmp = new Bitmap(f.ClientSize.Width, f.ClientSize.Height)) { f.DrawToBitmap(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height)); bmp.Save(path, System.Drawing.Imaging.ImageFormat.Png); } } }
    static Color FromHsv(float h, float s, float v)
    {
        h = (h % 360f + 360f) % 360f; float c = v * s, x = c * (1f - Math.Abs((h / 60f) % 2f - 1f)), m = v - c, r = 0, g = 0, b = 0;
        if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
        return Color.FromArgb((int)Math.Round((r + m) * 255f), (int)Math.Round((g + m) * 255f), (int)Math.Round((b + m) * 255f));
    }
    static void ToHsv(Color c, out float h, out float s, out float v)
    {
        float r = c.R / 255f, g = c.G / 255f, b = c.B / 255f, mx = Math.Max(r, Math.Max(g, b)), mn = Math.Min(r, Math.Min(g, b)), d = mx - mn;
        h = d < 1e-5f ? 0f : mx == r ? 60f * (((g - b) / d + 6f) % 6f) : mx == g ? 60f * ((b - r) / d + 2f) : 60f * ((r - g) / d + 4f);
        s = mx < 1e-5f ? 0f : d / mx; v = mx;
    }
    static Color Readable(Color c) { return (0.299 * c.R + 0.587 * c.G + 0.114 * c.B) < 150 ? Color.White : Color.Black; }

    ColorPicker(Color startColor)
    {
        start = startColor; ToHsv(startColor, out hue, out sat, out val); if (sat < 0.02f && val < 0.02f) val = 0.5f;
        Text = "Pick a colour"; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false; StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(560, 442); BackColor = Theme.Bg; ForeColor = Theme.Text; Font = Theme.UI;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        hex = new TextBox { BorderStyle = BorderStyle.None, BackColor = Theme.Card, ForeColor = Theme.Text, Font = new Font("Consolas", 12f), Width = 112, MaxLength = 7, CharacterCasing = CharacterCasing.Upper };
        hex.TextChanged += delegate { if (typing) return; Color c; if (Theme.TryHex(hex.Text, out c)) { ToHsv(c, out hue, out sat, out val); Invalidate(); } };
        hex.GotFocus += delegate { Invalidate(); }; hex.LostFocus += delegate { Invalidate(); };
        ok = new Btn("Use this colour") { Primary = true, Width = 150, Height = 36, Location = new Point(ClientSize.Width - 24 - 150, ClientSize.Height - 56) };
        cancel = new Btn("Cancel") { Width = 96, Height = 36, Location = new Point(ClientSize.Width - 24 - 150 - 10 - 96, ClientSize.Height - 56) };
        ok.Click += delegate { DialogResult = DialogResult.OK; }; cancel.Click += delegate { DialogResult = DialogResult.Cancel; };
        Controls.Add(hex); Controls.Add(ok); Controls.Add(cancel);
        hex.Location = new Point(336 + 14, 238 + 9);
        SyncHex();
        HandleCreated += delegate { try { int dark = Theme.Light ? 0 : 1; DwmSetWindowAttribute(Handle, 20, ref dark, 4); } catch { } };
        KeyPreview = true; KeyDown += delegate (object s, KeyEventArgs e) { if (e.KeyCode == Keys.Escape) DialogResult = DialogResult.Cancel; else if (e.KeyCode == Keys.Enter) DialogResult = DialogResult.OK; };
    }
    void SyncHex() { typing = true; hex.Text = "#" + Theme.Hex(Result); typing = false; }
    Rectangle PresetRect(int i) { return new Rectangle(336 + (i % 5) * 38, 318 + (i / 5) * 34, 30, 30); }
    Rectangle BarRect { get { return new Rectangle(BarX, SqY, BarW, SqS); } }
    Rectangle SqRect { get { return new Rectangle(SqX, SqY, SqS, SqS); } }

    void BuildSquare()
    {
        if (sq == null) sq = new Bitmap(SqS, SqS, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
        var bd = sq.LockBits(new Rectangle(0, 0, SqS, SqS), System.Drawing.Imaging.ImageLockMode.WriteOnly, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
        try
        {
            var px = new int[SqS * SqS];
            for (int y = 0; y < SqS; y++) for (int x = 0; x < SqS; x++) px[y * SqS + x] = FromHsv(hue, x / (float)(SqS - 1), 1f - y / (float)(SqS - 1)).ToArgb();
            Marshal.Copy(px, 0, bd.Scan0, px.Length);
        }
        finally { sq.UnlockBits(bd); }
        sqHue = hue;
    }
    void BuildBar()
    {
        bar = new Bitmap(BarW, SqS, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
        using (var g = Graphics.FromImage(bar)) for (int y = 0; y < SqS; y++) using (var p = new Pen(FromHsv(y / (float)(SqS - 1) * 360f, 1f, 1f))) g.DrawLine(p, 0, y, BarW, y);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit; g.CompositingQuality = CompositingQuality.HighSpeed;
        if (Theme.Aero) using (var b = new LinearGradientBrush(ClientRectangle, Color.FromArgb(206, 234, 252), Color.FromArgb(240, 250, 255), 90f)) g.FillRectangle(b, ClientRectangle); else g.Clear(Theme.Bg);
        if (sq == null || sqHue != hue) BuildSquare(); if (bar == null) BuildBar();
        var lf = TextFormatFlags.Left | TextFormatFlags.NoPrefix;
        TextRenderer.DrawText(g, "Pick a colour", Theme.UIL, new Rectangle(24, 16, 400, 26), Theme.Text, lf);
        TextRenderer.DrawText(g, "Slide the bar to choose a colour, then click the square to make it lighter, darker or stronger. The big swatch shows how it will look.", Theme.Small, new Rectangle(24, 44, 512, 32), Theme.Dim, lf | TextFormatFlags.WordBreak);
        TextRenderer.DrawText(g, "SHADE", Theme.Small, new Rectangle(SqX, SqY - 20, 100, 16), Theme.AccentSoft, lf);
        TextRenderer.DrawText(g, "COLOUR", Theme.Small, new Rectangle(BarX - 6, SqY - 20, 70, 16), Theme.AccentSoft, lf);
        g.InterpolationMode = InterpolationMode.NearestNeighbor; g.PixelOffsetMode = PixelOffsetMode.Half;
        g.DrawImage(sq, SqRect, 0, 0, SqS, SqS, GraphicsUnit.Pixel); g.DrawImage(bar, BarRect, 0, 0, BarW, SqS, GraphicsUnit.Pixel);
        using (var p = new Pen(Theme.Border)) { g.DrawRectangle(p, SqX - 1, SqY - 1, SqS + 1, SqS + 1); g.DrawRectangle(p, BarX - 1, SqY - 1, BarW + 1, SqS + 1); }
        float mx = SqX + sat * (SqS - 1), my = SqY + (1f - val) * (SqS - 1);
        using (var p = new Pen(Color.Black, 3f)) g.DrawEllipse(p, mx - 7, my - 7, 14, 14);
        using (var p = new Pen(Color.White, 1.8f)) g.DrawEllipse(p, mx - 7, my - 7, 14, 14);
        float by = SqY + hue / 360f * (SqS - 1);
        using (var p = new Pen(Color.Black, 3.4f)) g.DrawRectangle(p, BarX - 3, by - 3, BarW + 5, 6);
        using (var p = new Pen(Color.White, 1.6f)) g.DrawRectangle(p, BarX - 3, by - 3, BarW + 5, 6);
        // the new colour over the one in use now
        var cur = Result;
        TextRenderer.DrawText(g, "PREVIEW", Theme.Small, new Rectangle(336, SqY - 20, 120, 16), Theme.AccentSoft, lf);
        var newR = new Rectangle(336, SqY, 190, 48); var oldR = new Rectangle(336, SqY + 48, 190, 28);
        using (var path = Theme.Round(new Rectangle(336, SqY, 190, 76), 12))
        {
            var st = g.Save(); g.SetClip(path);
            using (var b = new SolidBrush(cur)) g.FillRectangle(b, newR);
            using (var b = new SolidBrush(start)) g.FillRectangle(b, oldR);
            g.Restore(st); using (var p = new Pen(Theme.Border)) g.DrawPath(p, path);
        }
        var cf = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix;
        TextRenderer.DrawText(g, "New colour", Theme.UIB, newR, Readable(cur), cf);
        TextRenderer.DrawText(g, "Colour now", Theme.Small, oldR, Readable(start), cf);
        // hex
        TextRenderer.DrawText(g, "OR TYPE A HEX CODE", Theme.Small, new Rectangle(336, 208, 190, 16), Theme.AccentSoft, lf);
        var hr = new Rectangle(336, 238, 140, 36);
        using (var path = Theme.Round(hr, 10)) { using (var b = new SolidBrush(Theme.Card)) g.FillPath(b, path); using (var p = new Pen(hex.Focused ? Theme.Accent : Theme.Border)) g.DrawPath(p, path); }
        // suggestions
        TextRenderer.DrawText(g, "OR START FROM ONE OF THESE", Theme.Small, new Rectangle(336, 296, 200, 16), Theme.AccentSoft, lf);
        for (int i = 0; i < Theme.PresetColors.Length; i++)
        {
            var r = PresetRect(i); if (hotSwatch == i) r.Inflate(2, 2);
            using (var b = new SolidBrush(Theme.PresetColors[i])) g.FillEllipse(b, r);
            using (var p = new Pen(hotSwatch == i ? Theme.Text : Color.FromArgb(120, 255, 255, 255), hotSwatch == i ? 2f : 1f)) g.DrawEllipse(p, r);
        }
    }
    void SetSquare(Point p) { sat = Math.Max(0f, Math.Min(1f, (p.X - SqX) / (float)(SqS - 1))); val = 1f - Math.Max(0f, Math.Min(1f, (p.Y - SqY) / (float)(SqS - 1))); SyncHex(); Invalidate(); }
    void SetBar(Point p) { hue = Math.Max(0f, Math.Min(359.9f, (p.Y - SqY) / (float)(SqS - 1) * 360f)); SyncHex(); Invalidate(); }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (SqRect.Contains(e.Location)) { dragSq = true; Capture = true; SetSquare(e.Location); }
        else if (Rectangle.Inflate(BarRect, 6, 4).Contains(e.Location)) { dragBar = true; Capture = true; SetBar(e.Location); }
        else for (int i = 0; i < Theme.PresetColors.Length; i++) if (PresetRect(i).Contains(e.Location)) { ToHsv(Theme.PresetColors[i], out hue, out sat, out val); SyncHex(); Invalidate(); }
        base.OnMouseDown(e);
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (dragSq) SetSquare(e.Location);
        else if (dragBar) SetBar(e.Location);
        else
        {
            int h = -1; for (int i = 0; i < Theme.PresetColors.Length; i++) if (PresetRect(i).Contains(e.Location)) h = i;
            if (h != hotSwatch) { hotSwatch = h; Invalidate(); }
            Cursor = h >= 0 ? Cursors.Hand : (SqRect.Contains(e.Location) || BarRect.Contains(e.Location)) ? Cursors.Cross : Cursors.Default;
        }
        base.OnMouseMove(e);
    }
    protected override void OnMouseUp(MouseEventArgs e) { dragSq = dragBar = false; Capture = false; base.OnMouseUp(e); }
    protected override void Dispose(bool d) { if (d) { if (sq != null) sq.Dispose(); if (bar != null) bar.Dispose(); } base.Dispose(d); }
}
