// CENOHWARE: one window that holds all the tools. A rail on the left switches between Home and the tools.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("CENOHWARE")]
[assembly: AssemblyCompany("Cenoh")]
[assembly: AssemblyProduct("CENOHWARE")]
[assembly: AssemblyCopyright("Made by Cenoh")]
[assembly: AssemblyDescription("CENOHWARE: tools and games in one app. Made by Cenoh.")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]

// ---- the picture behind Home and Hold Click -----------------------------------------------------------------------------------
static class Backdrop
{
    public static Bitmap Source;
    public static event Action Changed;
    static string FilePath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CENOHWARE", "background.png"); } }

    public static void Load(string overridePath)
    {
        try
        {
            string p = overridePath ?? FilePath;
            if (File.Exists(p)) using (var fs = File.OpenRead(p)) using (var tmp = new Bitmap(fs)) Source = new Bitmap(tmp);
        }
        catch { Source = null; }
    }
    /// <summary>Scales the picture to fill w x h and crops the overflow evenly (nothing stretched).</summary>
    public static Bitmap Cover(Image src, int w, int h)
    {
        var bmp = new Bitmap(Math.Max(1, w), Math.Max(1, h), PixelFormat.Format32bppPArgb);
        float k = Math.Max(w / (float)src.Width, h / (float)src.Height), sw = w / k, sh = h / k;
        using (var g = Graphics.FromImage(bmp))
        {
            g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.DrawImage(src, new Rectangle(0, 0, w, h), (src.Width - sw) / 2f, (src.Height - sh) / 2f, sw, sh, GraphicsUnit.Pixel);
        }
        return bmp;
    }
    public static string Choose(IWin32Window owner)
    {
        using (var d = new OpenFileDialog { Title = "Pick a background picture", Filter = "Pictures|*.jpg;*.jpeg;*.png;*.bmp;*.gif|All files|*.*" })
        {
            if (d.ShowDialog(owner) != DialogResult.OK) return "";
            try
            {
                Bitmap loaded;
                using (var fs = File.OpenRead(d.FileName)) using (var img = Image.FromStream(fs)) loaded = img.Width > 2560 || img.Height > 1440 ? Cover(img, Math.Min(img.Width, 2560), Math.Min(img.Height, 1440)) : new Bitmap(img);
                if (!Program.Testing) { Directory.CreateDirectory(Path.GetDirectoryName(FilePath)); loaded.Save(FilePath, ImageFormat.Png); }
                Source = loaded; if (Changed != null) Changed(); return "";
            }
            catch (Exception ex) { return "Could not use that picture: " + ex.Message; }
        }
    }
    public static void Reset() { Source = null; try { if (!Program.Testing) File.Delete(FilePath); } catch { } if (Changed != null) Changed(); }
}

// a page with an animated backdrop: your picture (dimmed so text stays readable) or the built-in drifting glow + sparkles.
// Built to hold the monitor's refresh rate: the whole backdrop is baked once (a little bigger than the page, so it can drift), the
// cards are cached pictures, and only the drift, sparkles and light streak are drawn per frame.
class BackdropPage : Panel, IBackdropHost
{
    protected float t;
    public static int PaintedFrames; public static double PaintMs; public static System.Collections.Generic.List<double> FrameLog; public static string Breakdown = ""; public static double[] BDs = new double[3]; protected bool SkipBackdrop;                  // for the --pagefps check
    const int M = 36;                                                                // how much bigger the baked picture is on every side
    static readonly float[] sx = new float[44], sy = new float[44], sv = new float[44], ss = new float[44], sp = new float[44];
    Bitmap cache; Size cacheSize; int cacheKey; static int ver; bool hooked;
    Dictionary<string, Bitmap> sprites = new Dictionary<string, Bitmap>(); readonly Dictionary<int, Dictionary<string, Bitmap>> spriteSets = new Dictionary<int, Dictionary<string, Bitmap>>(); int spriteKey;       // sprites are kept for the last few themes, so switching back to one is free
    protected const int Pad = 26;
    static BackdropPage()
    {
        var r = new Random(23);
        for (int i = 0; i < sx.Length; i++) { sx[i] = (float)r.NextDouble(); sy[i] = (float)r.NextDouble(); sv[i] = 0.01f + (float)r.NextDouble() * 0.035f; ss[i] = 0.7f + (float)r.NextDouble() * 1.8f; sp[i] = (float)r.NextDouble() * 6.28f; }
        Backdrop.Changed += delegate { ver++; };
    }
    public BackdropPage()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        BackColor = Theme.Bg;
        VisibleChanged += delegate { Hook(); }; HandleCreated += delegate { Hook(); };
        Backdrop.Changed += delegate { Invalidate(true); };
    }
    void Hook()
    {
        bool want = Visible && IsHandleCreated;
        if (want && !hooked) { hooked = true; Ticker.Frame += OnFrame; } else if (!want && hooked) { hooked = false; Ticker.Frame -= OnFrame; }
    }
    void OnFrame(float dt)
    {
        if (HubState.IntroPlaying) return;
        var f = FindForm(); if (f == null || f.WindowState == FormWindowState.Minimized || !f.Visible) return;
        if (HubState.Transitioning) return;                       // a cross-fade is playing over everything: hold still and leave the CPU to it
        t += dt; OnTick(dt); if (NeedsFrame()) Invalidate();
    }
    protected virtual bool NeedsFrame() { return true; }
    protected override void Dispose(bool d)
    {
        if (d) { if (hooked) { hooked = false; Ticker.Frame -= OnFrame; } cache = null; foreach (var set in spriteSets.Values) foreach (var b in set.Values) b.Dispose(); spriteSets.Clear(); sprites.Clear(); }
        base.Dispose(d);
    }
    protected virtual void OnTick(float dt) { }
    /// <summary>Builds the baked backdrop and card pictures for the current size now, instead of during the first paint.</summary>
    public void Warm() { EnsureCache(); using (var b = new Bitmap(2, 2)) using (var g = Graphics.FromImage(b)) DrawCards(g); }
    protected virtual void DrawCards(Graphics g) { }
    protected virtual void DrawContent(Graphics g) { }

    /// <summary>A cached picture of something that only changes when `key` does (size, hover level, colour, backdrop). Pad pixels of room on every side for shadows.</summary>
    protected Bitmap Sprite(string key, int w, int h, Action<Graphics, Rectangle> draw)
    {
        int k = Theme.Accent.ToArgb() * 31 + ver;
        if (k != spriteKey || sprites == null)
        {
            spriteKey = k;
            if (!spriteSets.TryGetValue(k, out sprites)) { sprites = new Dictionary<string, Bitmap>(); spriteSets[k] = sprites; }
            if (spriteSets.Count > 4) { int drop = 0; bool found = false; foreach (int kk in spriteSets.Keys) if (kk != k) { drop = kk; found = true; break; } if (found) { foreach (var b in spriteSets[drop].Values) b.Dispose(); spriteSets.Remove(drop); } }
        }
        Bitmap bmp;
        if (sprites.TryGetValue(key, out bmp)) return bmp;
        if (sprites.Count > 90) { foreach (var b in sprites.Values) b.Dispose(); sprites.Clear(); }
        bmp = new Bitmap(w + Pad * 2, h + Pad * 2, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(bmp)) { g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit; draw(g, new Rectangle(Pad, Pad, w, h)); }
        sprites[key] = bmp; return bmp;
    }
    // a glossy soap bubble: a thin tinted film, a bright rim with a rainbow edge, and two window-like highlights (cached per size)
    Bitmap BubbleSprite(int rad)
    {
        return Sprite("bub" + rad, rad * 2, rad * 2, delegate (Graphics g, Rectangle r)
        {
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(r);
                using (var pg = new PathGradientBrush(path) { CenterColor = Color.FromArgb(10, 255, 255, 255), SurroundColors = new[] { Color.FromArgb(92, 190, 236, 255) } }) { pg.SetBlendTriangularShape(0.9f, 1f); g.FillPath(pg, path); }
            }
            var ri = Rectangle.Inflate(r, -1, -1);
            using (var p = new Pen(Color.FromArgb(205, 255, 255, 255), 1.3f)) g.DrawEllipse(p, ri);
            using (var p = new Pen(Color.FromArgb(120, 255, 150, 214), 1.3f)) g.DrawArc(p, Rectangle.Inflate(ri, -2, -2), 20, 70);
            using (var p = new Pen(Color.FromArgb(120, 120, 232, 255), 1.3f)) g.DrawArc(p, Rectangle.Inflate(ri, -2, -2), 200, 70);
            using (var p = new Pen(Color.FromArgb(70, 255, 238, 150), 1.1f)) g.DrawArc(p, Rectangle.Inflate(ri, -3, -3), 95, 50);
            var hl = new RectangleF(r.X + r.Width * 0.18f, r.Y + r.Height * 0.12f, r.Width * 0.46f, r.Height * 0.30f);
            using (var b = new LinearGradientBrush(new RectangleF(hl.X, hl.Y - 1, hl.Width, hl.Height + 2), Color.FromArgb(235, 255, 255, 255), Color.FromArgb(40, 255, 255, 255), 90f)) g.FillEllipse(b, hl);
            using (var b = new SolidBrush(Color.FromArgb(110, 255, 255, 255))) g.FillEllipse(b, r.X + r.Width * 0.62f, r.Y + r.Height * 0.70f, r.Width * 0.20f, r.Height * 0.11f);
        });
    }
    protected void Blit(Graphics g, Bitmap b, int x, int y) { g.DrawImage(b, new Rectangle(x, y, b.Width, b.Height), 0, 0, b.Width, b.Height, GraphicsUnit.Pixel); }

    class SharedEntry { public int Key; public Size Size; public Bitmap Bmp; }
    static readonly List<SharedEntry> sharedList = new List<SharedEntry>();         // the last few backdrops, newest last: switching back to a theme just used costs nothing
    public static double CacheMs;
    // a picture with rounded corners and a border, made once: clipping a picture to a rounded path on every frame is very slow in GDI+ (it stalled the UI thread)
    protected static Bitmap RoundedCopy(Bitmap src, int w, int h, int d, Color border)
    {
        var t = new Bitmap(w, h, PixelFormat.Format32bppPArgb); using (var tg = Graphics.FromImage(t)) { tg.InterpolationMode = InterpolationMode.HighQualityBicubic; tg.PixelOffsetMode = PixelOffsetMode.Half; tg.DrawImage(src, new Rectangle(0, 0, w, h)); }
        var b = new Bitmap(w, h, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(b)) using (var path = Theme.Round(new Rectangle(0, 0, w - 1, h - 1), d)) using (var tb = new TextureBrush(t)) { g.SmoothingMode = SmoothingMode.AntiAlias; g.FillPath(tb, path); using (var p = new Pen(border, 1.5f)) g.DrawPath(p, path); }
        t.Dispose(); return b;
    }
    static readonly sbyte[] NoiseTable = MakeNoise();
    static sbyte[] MakeNoise() { var rn = new Random(41); var t = new sbyte[65536]; for (int i = 0; i < t.Length; i++) t[i] = (sbyte)rn.Next(-2, 3); return t; }
    void EnsureCache()
    {
        int key = ver * 7919 + Theme.Accent.ToArgb();
        if (cache != null && cacheSize == ClientSize && cacheKey == key && sharedList.Exists(se0 => se0.Bmp == cache)) return;
        // every page shows the same backdrop at the same size, so one picture is shared: switching page after a theme change finds it ready
        for (int si = sharedList.Count - 1; si >= 0; si--) { var se = sharedList[si]; if (se.Key == key && se.Size == ClientSize) { sharedList.RemoveAt(si); sharedList.Add(se); cache = se.Bmp; cacheSize = se.Size; cacheKey = key; return; } }
        long cq = Stopwatch.GetTimestamp(); try { BuildCache(); } finally { CacheMs += (Stopwatch.GetTimestamp() - cq) * 1000.0 / Stopwatch.Frequency; }
    }
    public static double PartA, PartB;
    void BuildCache()
    {
        long bq0 = Stopwatch.GetTimestamp();
        int key = ver * 7919 + Theme.Accent.ToArgb();
        if (ClientSize.Width < 2 || ClientSize.Height < 2) return;
        cacheSize = ClientSize; cacheKey = key; int w = ClientSize.Width + M * 2, h = ClientSize.Height + M * 2;
        cache = new Bitmap(w, h, PixelFormat.Format32bppPArgb);
        // the painted themes are soft shapes: draw them at half size (a quarter of the pixels) and scale up; a user picture is drawn at full size
        bool half = Backdrop.Source == null; Bitmap small = half ? new Bitmap((w + 1) / 2, (h + 1) / 2, PixelFormat.Format32bppPArgb) : null;
        using (var g = Graphics.FromImage(half ? small : cache))
        {
            if (half) g.ScaleTransform(small.Width / (float)w, small.Height / (float)h);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rc = new Rectangle(0, 0, w, h);
            if (Backdrop.Source != null)
            {
                using (var cov = Backdrop.Cover(Backdrop.Source, w, h)) g.DrawImageUnscaled(cov, 0, 0);
                using (var b = new SolidBrush(Color.FromArgb(118, Theme.Bg))) g.FillRectangle(b, rc);
                // one gradient over the whole height (two separate ones left a hairline seam where they met the picture)
                using (var b = new LinearGradientBrush(rc, Color.Black, Color.Black, 90f))
                {
                    b.InterpolationColors = new ColorBlend(4) { Colors = new[] { Color.FromArgb(150, Theme.Bg), Color.FromArgb(0, Theme.Bg), Color.FromArgb(0, Theme.Bg), Color.FromArgb(170, Theme.Bg) }, Positions = new[] { 0f, Math.Min(0.4f, 200f / h), Math.Max(0.6f, 1f - 160f / h), 1f } };
                    g.FillRectangle(b, rc);
                }
            }
            else if (Theme.Aero) PaintSky(g, w, h);
            else if (Theme.Dbz) PaintDbz(g, w, h);
            else if (Theme.Jnb) PaintJnb(g, w, h);
            else if (Theme.Zach) PaintZach(g, w, h);
            else
            {
                using (var b = new LinearGradientBrush(rc, Theme.Lerp(Theme.Bg, Theme.Accent, 0.20f), Theme.Bg, 62f)) g.FillRectangle(b, rc);
                Glow(g, w * 0.27f, h * 0.30f, Math.Max(w, h) * 0.55f, Theme.Accent, 70);
                Glow(g, w * 0.78f, h * 0.72f, Math.Max(w, h) * 0.50f, Theme.Lerp(Theme.Accent, Color.FromArgb(56, 189, 248), 0.6f), 46);
            }
            if (!Theme.Aero) using (var path = new GraphicsPath())
            {
                path.AddEllipse(-w * 0.25f, -h * 0.3f, w * 1.5f, h * 1.6f);
                using (var pg = new PathGradientBrush(path) { CenterColor = Color.FromArgb(0, 0, 0, 0), SurroundColors = new[] { Color.FromArgb(120, 0, 0, 0) } }) { pg.SetBlendTriangularShape(0.55f, 1f); g.FillRectangle(pg, rc); }
            }
        }
        if (half) { using (var g2 = Graphics.FromImage(cache)) { g2.CompositingMode = CompositingMode.SourceCopy; g2.InterpolationMode = InterpolationMode.HighQualityBilinear; g2.PixelOffsetMode = PixelOffsetMode.Half; g2.DrawImage(small, new Rectangle(0, 0, w, h), 0, 0, small.Width, small.Height, GraphicsUnit.Pixel); } small.Dispose(); }
        long nq = Stopwatch.GetTimestamp(); double paintDone = (nq - bq0) * 1000.0 / Stopwatch.Frequency; PartA += paintDone;
        // a touch of noise so the soft gradients never band
        var data = cache.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadWrite, PixelFormat.Format32bppPArgb);
        try
        {
            int bytes = Math.Abs(data.Stride) * h; var px = new byte[bytes]; Marshal.Copy(data.Scan0, px, 0, bytes); var nz = NoiseTable;
            for (int i = 0, k = 0; i < bytes; i += 4, k = (k + 1) & 65535) { int n = nz[k]; int v = px[i] + n; px[i] = (byte)(v < 0 ? 0 : v > 255 ? 255 : v); v = px[i + 1] + n; px[i + 1] = (byte)(v < 0 ? 0 : v > 255 ? 255 : v); v = px[i + 2] + n; px[i + 2] = (byte)(v < 0 ? 0 : v > 255 ? 255 : v); }
            Marshal.Copy(px, 0, data.Scan0, bytes);
        }
        finally { cache.UnlockBits(data); }
        PartB += (Stopwatch.GetTimestamp() - nq) * 1000.0 / Stopwatch.Frequency;
        sharedList.Add(new SharedEntry { Key = key, Size = ClientSize, Bmp = cache });
        while (sharedList.Count > 4) { var ev = sharedList[0]; sharedList.RemoveAt(0); if (ev.Bmp != cache) ev.Bmp.Dispose(); }
    }
    // Frutiger Aero sky: blue to white, a sun glow, soft rays, clouds, bokeh, and two rolling green hills
    static void PaintSky(Graphics g, int w, int h)
    {
        var rc = new Rectangle(0, 0, w, h);
        using (var b = new LinearGradientBrush(rc, Color.Black, Color.Black, 90f))
        {
            b.InterpolationColors = new ColorBlend(4) { Colors = new[] { Color.FromArgb(54, 156, 236), Color.FromArgb(124, 204, 248), Color.FromArgb(206, 238, 252), Color.FromArgb(232, 247, 254) }, Positions = new[] { 0f, 0.36f, 0.68f, 1f } };
            g.FillRectangle(b, rc);
        }
        Glow(g, w * 0.2f, 0f, Math.Max(w, h) * 0.6f, Color.White, 170);
        Glow(g, w * 0.2f, 0f, Math.Max(w, h) * 0.16f, Color.FromArgb(255, 252, 220), 200);                                                 // the sun
        float[][] fl = { new[] { 0.32f, 0.20f, 0.05f }, new[] { 0.44f, 0.31f, 0.09f }, new[] { 0.56f, 0.42f, 0.04f }, new[] { 0.70f, 0.55f, 0.07f }, new[] { 0.84f, 0.67f, 0.12f } };   // a lens flare running away from the sun
        for (int i = 0; i < fl.Length; i++) Glow(g, w * fl[i][0], h * fl[i][1], Math.Max(w, h) * fl[i][2], i % 2 == 0 ? Color.FromArgb(150, 236, 255) : Color.FromArgb(255, 236, 170), 44);
        Glow(g, w * 0.5f, h * 0.80f, w * 0.55f, Color.White, 110);                                                                            // haze on the horizon
        for (int i = 0; i < 6; i++)
        {
            float a0 = 0.12f + i * 0.17f; var pts = new[] { new PointF(w * 0.2f, -20), new PointF(w * a0, h), new PointF(w * (a0 + 0.07f), h) };
            using (var b = new SolidBrush(Color.FromArgb(i % 2 == 0 ? 24 : 12, 255, 255, 255))) g.FillPolygon(b, pts);
        }
        float[][] cl = { new[] { 0.62f, 0.13f, 0.26f }, new[] { 0.34f, 0.22f, 0.20f }, new[] { 0.86f, 0.28f, 0.18f }, new[] { 0.12f, 0.34f, 0.16f } };
        foreach (var c in cl) for (int k = 0; k < 4; k++) Glow(g, w * (c[0] + (k - 1.5f) * c[2] * 0.35f), h * (c[1] + (k % 2 == 0 ? 0.01f : -0.012f)), w * c[2] * 0.55f, Color.White, 130);
        var rn = new Random(5);
        for (int i = 0; i < 16; i++) { float x = (float)rn.NextDouble() * w, y = (float)rn.NextDouble() * h * 0.8f, r = 12 + (float)rn.NextDouble() * 46; using (var br = new SolidBrush(Color.FromArgb(14 + rn.Next(22), 255, 255, 255))) g.FillEllipse(br, x - r, y - r, r * 2, r * 2); }
        DrawHill(g, w, h, 0.77f, 0.055f, 1.1f, Color.FromArgb(170, 234, 142), Color.FromArgb(106, 208, 94), 0.3f);
        DrawHill(g, w, h, 0.87f, 0.045f, 2.2f, Color.FromArgb(112, 210, 82), Color.FromArgb(34, 146, 60), 1.1f);
    }
    // Dragon Ball: a night sky going to a blazing orange horizon, ki rays fanning from a hidden power-up, stars and dark mesas
    static void PaintDbz(Graphics g, int w, int h)
    {
        var rc = new Rectangle(0, 0, w, h);
        using (var b = new LinearGradientBrush(rc, Color.Black, Color.Black, 90f))
        {
            b.InterpolationColors = new ColorBlend(5) { Colors = new[] { Color.FromArgb(4, 6, 28), Color.FromArgb(16, 22, 78), Color.FromArgb(64, 44, 120), Color.FromArgb(226, 100, 36), Color.FromArgb(255, 176, 52) }, Positions = new[] { 0f, 0.34f, 0.62f, 0.86f, 1f } };
            g.FillRectangle(b, rc);
        }
        float cx = w * 0.74f, cy = h * 0.80f; var rn = new Random(9);
        for (int i = 0; i < 90; i++) { float x = (float)rn.NextDouble() * w, y = (float)rn.NextDouble() * h * 0.62f, r = 0.6f + (float)rn.NextDouble() * 1.5f; using (var br = new SolidBrush(Color.FromArgb(70 + rn.Next(150), 255, 248, 224))) g.FillEllipse(br, x, y, r, r); }
        Glow(g, cx, cy, Math.Max(w, h) * 0.75f, Color.FromArgb(255, 150, 20), 150);
        for (int i = 0; i < 26; i++)
        {
            double a0 = Math.PI + i * (Math.PI / 26.0), a1 = a0 + Math.PI / 52.0; float L = Math.Max(w, h) * 1.4f;
            var pts = new[] { new PointF(cx, cy), new PointF(cx + (float)Math.Cos(a0) * L, cy + (float)Math.Sin(a0) * L), new PointF(cx + (float)Math.Cos(a1) * L, cy + (float)Math.Sin(a1) * L) };
            using (var br = new SolidBrush(Color.FromArgb(i % 2 == 0 ? 30 : 14, 255, 216, 96))) g.FillPolygon(br, pts);
        }
        Glow(g, cx, cy, Math.Max(w, h) * 0.22f, Color.FromArgb(255, 244, 190), 190);
        float[][] mesa = { new[] { 0.02f, 0.18f, 0.74f }, new[] { 0.22f, 0.12f, 0.80f }, new[] { 0.46f, 0.20f, 0.77f }, new[] { 0.80f, 0.16f, 0.72f }, new[] { 0.64f, 0.11f, 0.82f } };
        foreach (var m in mesa)
        {
            float x0 = w * m[0], mw = w * m[1], top = h * m[2], bw = mw * 1.35f;
            var pts = new[] { new PointF(x0 - (bw - mw) / 2, h), new PointF(x0, top + mw * 0.10f), new PointF(x0 + mw * 0.08f, top), new PointF(x0 + mw * 0.92f, top), new PointF(x0 + mw, top + mw * 0.10f), new PointF(x0 + mw + (bw - mw) / 2, h) };
            using (var br = new LinearGradientBrush(new RectangleF(x0, top, mw, h - top + 1), Color.FromArgb(46, 26, 40), Color.FromArgb(12, 10, 28), 90f)) g.FillPolygon(br, pts);
            using (var p = new Pen(Color.FromArgb(120, 255, 150, 50), 1.6f)) g.DrawLine(p, x0 + mw * 0.08f, top, x0 + mw * 0.92f, top);
        }
        using (var br = new LinearGradientBrush(new RectangleF(0, h * 0.90f, w, h * 0.10f + 1), Color.FromArgb(40, 22, 30), Color.FromArgb(8, 8, 20), 90f)) g.FillRectangle(br, 0, h * 0.90f, w, h * 0.10f + 1);
    }
    // a dragon ball: an amber glass sphere with deep-red stars in it, cached per size and star count
    Bitmap DragonBallSprite(int rad, int stars)
    {
        return Sprite("db" + rad + "_" + stars, rad * 2, rad * 2, delegate (Graphics g, Rectangle r)
        {
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(r);
                using (var pg = new PathGradientBrush(path) { CenterColor = Color.FromArgb(255, 255, 214, 88), SurroundColors = new[] { Color.FromArgb(255, 214, 94, 0) }, CenterPoint = new PointF(r.X + r.Width * 0.38f, r.Y + r.Height * 0.32f) }) g.FillPath(pg, path);
            }
            float cx = r.X + r.Width / 2f, cy = r.Y + r.Height / 2f, sr = rad * (stars == 1 ? 0.34f : 0.20f), ring = rad * 0.44f;
            for (int s = 0; s < stars; s++)
            {
                float px = cx, py = cy;
                if (stars > 1 && !(stars == 7 && s == 6)) { double a = -Math.PI / 2 + s * Math.PI * 2 / (stars == 7 ? 6 : stars); px = cx + (float)Math.Cos(a) * ring; py = cy + (float)Math.Sin(a) * ring; }
                var pts = new PointF[10];
                for (int k = 0; k < 10; k++) { double an = -Math.PI / 2 + k * Math.PI / 5; float rr = k % 2 == 0 ? sr : sr * 0.42f; pts[k] = new PointF(px + (float)Math.Cos(an) * rr, py + (float)Math.Sin(an) * rr); }
                using (var br = new SolidBrush(Color.FromArgb(255, 196, 18, 18))) g.FillPolygon(br, pts);
            }
            using (var p = new Pen(Color.FromArgb(170, 150, 50, 0), 1.2f)) g.DrawEllipse(p, Rectangle.Inflate(r, -1, -1));
            var hl = new RectangleF(r.X + r.Width * 0.18f, r.Y + r.Height * 0.10f, r.Width * 0.42f, r.Height * 0.26f);
            using (var b = new LinearGradientBrush(new RectangleF(hl.X, hl.Y - 1, hl.Width, hl.Height + 2), Color.FromArgb(230, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f)) g.FillEllipse(b, hl);
        });
    }
    // Janemba: the blood-red Other World sky with swirling lighter currents, jagged maroon crags, a pink-lavender cracked plain
    // the Zachery theme: his green striped turtleneck as the wallpaper, a band of zebra print pants and pink boots along the bottom
    static void PaintZach(Graphics g, int w, int h)
    {
        var rc = new Rectangle(0, 0, w, h);
        using (var b = new LinearGradientBrush(rc, Color.FromArgb(16, 66, 36), Color.FromArgb(4, 20, 11), 90f)) g.FillRectangle(b, rc);
        int band = Math.Max(26, h / 20);
        for (int y = 0, i = 0; y < h; y += band, i++) if (i % 2 == 0) using (var b = new SolidBrush(Color.FromArgb(44, 70, 196, 112))) g.FillRectangle(b, 0, y, w, band / 2 + 4);
        using (var p = new Pen(Color.FromArgb(14, 0, 0, 0), 1f)) for (int x = 0; x < w; x += 5) g.DrawLine(p, x, 0, x, h);      // the knit ribs
        Glow(g, w * 0.2f, h * 0.18f, Math.Max(w, h) * 0.5f, Color.FromArgb(70, 220, 120), 54);
        Glow(g, w * 0.82f, h * 0.7f, Math.Max(w, h) * 0.5f, Color.FromArgb(255, 90, 170), 56);
        float top = h * 0.835f, boots = h * 0.955f; var rn = new Random(11);
        var edge = new List<PointF>(); for (int k = 0; k <= 24; k++) edge.Add(new PointF(w * k / 24f, top + (float)Math.Sin(k * 1.3) * h * 0.004f));
        var pants = new List<PointF>(edge); pants.Add(new PointF(w, boots)); pants.Add(new PointF(0, boots));
        using (var b = new LinearGradientBrush(new RectangleF(0, top - 2, w, boots - top + 4), Color.FromArgb(250, 252, 250), Color.FromArgb(196, 204, 198), 90f)) g.FillPolygon(b, pants.ToArray());
        float sh = boots - top;
        for (int k = 0; k < w / 24 + 2; k++)                                         // the zebra stripes: tapered black ribbons that lean and sway
        {
            float x0 = k * 24f + (float)rn.NextDouble() * 10f, lean = (float)(rn.NextDouble() - 0.5) * 36f, bw = 7f + (float)rn.NextDouble() * 9f, ph = (float)rn.NextDouble() * 6f;
            var left = new List<PointF>(); var right = new List<PointF>();
            for (int j = 0; j <= 8; j++)
            {
                float u = j / 8f, cx = x0 + lean * u + (float)Math.Sin(u * 3.2 + ph) * 7f, cy = top + u * sh, ww = bw * (float)Math.Pow(Math.Sin(Math.PI * u), 0.6) * 0.5f + 0.3f;
                left.Add(new PointF(cx - ww, cy)); right.Add(new PointF(cx + ww, cy));
            }
            right.Reverse(); left.AddRange(right);
            using (var b = new SolidBrush(Color.FromArgb(240, 14, 14, 18))) g.FillPolygon(b, left.ToArray());
        }
        using (var b = new LinearGradientBrush(new RectangleF(0, top - 6, w, 26), Color.FromArgb(150, 4, 20, 11), Color.FromArgb(0, 4, 20, 11), 90f)) g.FillRectangle(b, 0, top - 6, w, 26);
        var bootRc = new RectangleF(0, boots, w, h - boots + 1);
        using (var b = new LinearGradientBrush(bootRc, Color.FromArgb(255, 126, 190), Color.FromArgb(206, 40, 120), 90f)) g.FillRectangle(b, bootRc);
        using (var p = new Pen(Color.FromArgb(140, 255, 255, 255), 2f)) g.DrawLine(p, 0, boots + 3, w, boots + 3);
        using (var p = new Pen(Color.FromArgb(120, 120, 10, 70), 1.4f)) for (int x = 40; x < w; x += 130) g.DrawLine(p, x, boots + 4, x + 18, h);
        using (var b = new SolidBrush(Color.FromArgb(240, 250, 248))) g.FillRectangle(b, 0, h - Math.Max(3, h * 0.012f), w, Math.Max(3, h * 0.012f) + 1);
    }
    // a little pink boot drifting up through the green, cached per size
    Bitmap BootSprite(int q)
    {
        return Sprite("zboot" + q, q * 2, q * 2, delegate (Graphics g, Rectangle r)
        {
            Func<float, float, PointF> P = (fx, fy) => new PointF(r.X + r.Width * fx, r.Y + r.Height * fy);
            var boot = new[] { P(0.26f, 0.04f), P(0.60f, 0.04f), P(0.62f, 0.56f), P(0.90f, 0.64f), P(0.98f, 0.78f), P(0.97f, 0.88f), P(0.10f, 0.88f), P(0.10f, 0.68f), P(0.26f, 0.60f) };
            using (var b = new LinearGradientBrush(r, Color.FromArgb(255, 150, 208), Color.FromArgb(214, 44, 128), 70f)) g.FillPolygon(b, boot);
            using (var p = new Pen(Color.FromArgb(160, 110, 10, 66), 1.2f) { LineJoin = LineJoin.Round }) g.DrawPolygon(p, boot);
            using (var b = new SolidBrush(Color.FromArgb(246, 250, 250))) g.FillRectangle(b, r.X + r.Width * 0.08f, r.Y + r.Height * 0.86f, r.Width * 0.90f, r.Height * 0.10f);
            using (var p = new Pen(Color.FromArgb(170, 255, 255, 255), 1.2f)) g.DrawLine(p, P(0.32f, 0.12f), P(0.34f, 0.46f));
        });
    }
    static void PaintJnb(Graphics g, int w, int h)
    {
        var rc = new Rectangle(0, 0, w, h);
        using (var b = new LinearGradientBrush(rc, Color.Black, Color.Black, 90f))
        {
            b.InterpolationColors = new ColorBlend(5) { Colors = new[] { Color.FromArgb(120, 6, 22), Color.FromArgb(214, 24, 40), Color.FromArgb(236, 44, 48), Color.FromArgb(176, 24, 84), Color.FromArgb(116, 26, 122) }, Positions = new[] { 0f, 0.34f, 0.58f, 0.80f, 1f } };
            g.FillRectangle(b, rc);
        }
        var rn = new Random(21);
        for (int i = 0; i < 9; i++)                                   // slow currents in the sky
        {
            float y0 = h * (0.04f + i * 0.075f); var pts = new PointF[7];
            for (int k = 0; k < 7; k++) pts[k] = new PointF(w * k / 6f, y0 + (float)Math.Sin(k * 0.9 + i * 1.7) * h * 0.07f + k * h * 0.012f);
            using (var p = new Pen(Color.FromArgb(i % 2 == 0 ? 34 : 22, 255, 120 + rn.Next(80), 120), h * (0.03f + 0.012f * (i % 3)))) { p.StartCap = LineCap.Round; p.EndCap = LineCap.Round; g.DrawCurve(p, pts, 0.5f); }
        }
        Glow(g, w * 0.5f, h * 0.42f, Math.Max(w, h) * 0.6f, Color.FromArgb(255, 70, 60), 80);
        // far then near crags
        for (int layer = 0; layer < 2; layer++)
        {
            float baseY = h * (layer == 0 ? 0.80f : 0.86f); int n = layer == 0 ? 11 : 7; var pts = new List<PointF>(); pts.Add(new PointF(-10, h));
            var rr = new Random(33 + layer * 7);
            for (int k = 0; k <= n; k++)
            {
                float x = w * k / (float)n; float peak = (float)(rr.NextDouble() * 0.5 + (k % 3 == 1 ? 0.7 : 0.15)) * h * (layer == 0 ? 0.30f : 0.26f);
                pts.Add(new PointF(x - w * 0.02f, baseY)); pts.Add(new PointF(x + w * 0.012f, baseY - peak * 0.55f)); pts.Add(new PointF(x + w * 0.02f, baseY - peak)); pts.Add(new PointF(x + w * 0.032f, baseY - peak * 0.4f));
            }
            pts.Add(new PointF(w + 10, baseY)); pts.Add(new PointF(w + 10, h));
            using (var br = new LinearGradientBrush(new RectangleF(0, h * 0.5f, w, h * 0.5f + 1), layer == 0 ? Color.FromArgb(120, 20, 60) : Color.FromArgb(70, 12, 40), layer == 0 ? Color.FromArgb(90, 22, 80) : Color.FromArgb(54, 12, 70), 90f)) g.FillPolygon(br, pts.ToArray());
            using (var p = new Pen(Color.FromArgb(layer == 0 ? 70 : 90, 255, 130, 150), 1.4f)) g.DrawLines(p, pts.GetRange(1, pts.Count - 3).ToArray());
        }
        var plain = new RectangleF(0, h * 0.92f, w, h * 0.08f + 1);
        using (var br = new LinearGradientBrush(plain, Color.FromArgb(214, 120, 222), Color.FromArgb(150, 70, 190), 90f)) g.FillRectangle(br, plain);
        using (var p = new Pen(Color.FromArgb(70, 70, 10, 90), 1.2f)) for (int i = 0; i < 14; i++) { float x = w * (i + (float)rn.NextDouble()) / 14f; g.DrawLine(p, x, plain.Y, x + (float)(rn.NextDouble() - 0.5) * 60f, plain.Bottom); }
    }
    // a glossy jelly orb in one of Janemba's sweet-and-sinister colours, cached per size and colour
    Bitmap JellySprite(int rad, int colour)
    {
        return Sprite("jl" + rad + "_" + colour, rad * 2 + rad / 2, rad * 2, delegate (Graphics g, Rectangle r)
        {
            Color[] c = { Color.FromArgb(255, 96, 176), Color.FromArgb(255, 204, 60), Color.FromArgb(96, 150, 255), Color.FromArgb(255, 150, 60), Color.FromArgb(176, 176, 200) };
            var col = c[colour % c.Length];
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(r);
                using (var pg = new PathGradientBrush(path) { CenterColor = Color.FromArgb(214, Theme.Lerp(col, Color.White, 0.55f)), SurroundColors = new[] { Color.FromArgb(190, col) }, CenterPoint = new PointF(r.X + r.Width * 0.36f, r.Y + r.Height * 0.32f) }) g.FillPath(pg, path);
            }
            using (var p = new Pen(Color.FromArgb(200, Theme.Lerp(col, Color.White, 0.7f)), 1.4f)) g.DrawEllipse(p, Rectangle.Inflate(r, -1, -1));
            var hl = new RectangleF(r.X + r.Width * 0.18f, r.Y + r.Height * 0.14f, r.Width * 0.36f, r.Height * 0.22f);
            using (var b = new LinearGradientBrush(new RectangleF(hl.X, hl.Y - 1, hl.Width, hl.Height + 2), Color.FromArgb(230, 255, 255, 255), Color.FromArgb(10, 255, 255, 255), 90f)) g.FillEllipse(b, hl);
        });
    }
    static void DrawHill(Graphics g, int w, int h, float baseY, float amp, float freq, Color top, Color bot, float phase)
    {
        var pts = new List<PointF>(); for (int x = 0; x <= w + 24; x += 24) pts.Add(new PointF(x, h * baseY - amp * h * (float)Math.Sin(x / (float)w * Math.PI * freq + phase)));
        using (var path = new GraphicsPath())
        {
            path.AddCurve(pts.ToArray(), 0.5f); path.AddLine(w + 24, h, 0, h); path.CloseFigure();
            using (var b = new LinearGradientBrush(new RectangleF(0, h * (baseY - amp) - 1, w, h * (1f - baseY + amp) + 2), top, bot, 90f)) g.FillPath(b, path);
            using (var p = new Pen(Color.FromArgb(110, 255, 255, 255), 2f)) g.DrawCurve(p, pts.ToArray(), 0.5f);
        }
    }
    static void Glow(Graphics g, float cx, float cy, float r, Color c, int alpha)
    {
        using (var path = new GraphicsPath())
        {
            path.AddEllipse(cx - r, cy - r, r * 2, r * 2);
            using (var pg = new PathGradientBrush(path) { CenterColor = Color.FromArgb(alpha, c), SurroundColors = new[] { Color.FromArgb(0, c) } }) g.FillPath(pg, path);
        }
    }

    protected void DrawBackdrop(Graphics g)
    {
        EnsureCache(); if (cache == null) return;
        int w = Width, h = Height; bool pic = Backdrop.Source != null;
        int dx = (int)Math.Round((pic ? 14 : 26) * Math.Sin(t * 0.30)), dy = (int)Math.Round((pic ? 10 : 18) * Math.Cos(t * 0.23));     // a slow drift of the whole picture
        g.CompositingMode = CompositingMode.SourceCopy; g.InterpolationMode = InterpolationMode.NearestNeighbor; g.PixelOffsetMode = PixelOffsetMode.Half;
        g.DrawImage(cache, new Rectangle(-M + dx, -M + dy, cache.Width, cache.Height), 0, 0, cache.Width, cache.Height, GraphicsUnit.Pixel);
        g.CompositingMode = CompositingMode.SourceOver; g.SmoothingMode = SmoothingMode.AntiAlias;
        // a slow diagonal light streak every ~10 s
        float u = (t % 10f) / 10f;
        if (u < 0.45f)
        {
            float k = u / 0.45f, x = -300 + k * (w + 600), a = (float)Math.Sin(k * Math.PI);
            var band = new PointF[] { new PointF(x, 0), new PointF(x + 90, 0), new PointF(x - 140, h), new PointF(x - 230, h) };
            using (var b = new SolidBrush(Theme.Aero ? Color.FromArgb((int)(34 * a), 255, 255, 255) : Color.FromArgb((int)(16 * a), Theme.AccentSoft))) g.FillPolygon(b, band);
        }
        for (int i = 0; i < sx.Length; i++)
        {
            float y = (sy[i] - sv[i] * t * 0.35f) % 1f; if (y < 0) y += 1f;
            float x = sx[i] * w + (float)Math.Sin(t * 0.7f + sp[i]) * 8f, yy = y * h, tw = 0.25f + 0.75f * (float)Math.Abs(Math.Sin(t * 1.3f + sp[i]));
            if (Theme.Aero)                                           // soap bubbles drifting up: a faint body, a bright rim, a little reflection
            {
                int q = Math.Max(5, Math.Min(15, (int)Math.Round(ss[i] * 7f + 5f)));
                var bs = BubbleSprite(q); g.CompositingMode = CompositingMode.SourceOver; g.DrawImage(bs, (int)Math.Round(x) - q - Pad, (int)Math.Round(yy) - q - Pad, bs.Width, bs.Height);
                continue;
            }
            if (Theme.Zach && i % 3 == 0)                              // pink boots drifting up through the green
            {
                int q = Math.Max(8, Math.Min(20, (int)Math.Round(ss[i] * 8f + 8f))); var zs = BootSprite(q);
                g.CompositingMode = CompositingMode.SourceOver; g.DrawImage(zs, (int)Math.Round(x) - q - Pad, (int)Math.Round(yy) - q - Pad, zs.Width, zs.Height); continue;
            }
            if (Theme.Jnb && i % 2 == 0)                               // jelly orbs drifting up through the red sky
            {
                int q = Math.Max(6, Math.Min(22, (int)Math.Round(ss[i] * 9f + 6f))); var js = JellySprite(q, i / 2);
                g.CompositingMode = CompositingMode.SourceOver; g.DrawImage(js, (int)Math.Round(x) - q - q / 4 - Pad, (int)Math.Round(yy) - q - Pad, js.Width, js.Height); continue;
            }
            if (Theme.Dbz && i % 4 == 0)                               // dragon balls drifting up through the sky
            {
                int q = Math.Max(7, Math.Min(20, (int)Math.Round(ss[i] * 8f + 7f))), st = i / 4 % 7 + 1; var ds = DragonBallSprite(q, st);
                g.CompositingMode = CompositingMode.SourceOver; g.DrawImage(ds, (int)Math.Round(x) - q - Pad, (int)Math.Round(yy) - q - Pad, ds.Width, ds.Height); continue;
            }
            using (var br = new SolidBrush(Color.FromArgb((int)(170 * tw), i % 5 == 0 ? Color.White : Theme.AccentSoft))) g.FillEllipse(br, x - ss[i], yy - ss[i], ss[i] * 2, ss[i] * 2);
        }
    }

    public void PaintBackdropFor(Graphics g, Control c)
    {
        var st = g.Save(); g.TranslateTransform(-c.Left, -c.Top); g.SetClip(new Rectangle(c.Left, c.Top, c.Width, c.Height));
        DrawBackdrop(g); DrawCards(g); g.Restore(st);
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        long p0 = Stopwatch.GetTimestamp();
        var g = e.Graphics; g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit; g.CompositingQuality = CompositingQuality.HighSpeed;
        long q0 = Stopwatch.GetTimestamp(); if (!SkipBackdrop) DrawBackdrop(g); long q1 = Stopwatch.GetTimestamp(); DrawCards(g); long q2 = Stopwatch.GetTimestamp(); DrawContent(g); long q3 = Stopwatch.GetTimestamp(); BDs[0] += (q1 - q0) * 1000.0 / Stopwatch.Frequency; BDs[1] += (q2 - q1) * 1000.0 / Stopwatch.Frequency; BDs[2] += (q3 - q2) * 1000.0 / Stopwatch.Frequency; if ((q3 - q0) * 1000.0 / Stopwatch.Frequency > 30) Breakdown += ((q1 - q0) * 1000 / Stopwatch.Frequency) + "/" + ((q2 - q1) * 1000 / Stopwatch.Frequency) + "/" + ((q3 - q2) * 1000 / Stopwatch.Frequency) + "ms ";
        { double ms = (Stopwatch.GetTimestamp() - p0) * 1000.0 / Stopwatch.Frequency; PaintedFrames++; PaintMs += ms; if (FrameLog != null) FrameLog.Add(ms); }
    }

    // frosted-glass card with a soft shadow; hv (0..1) makes it brighten and glow
    protected static void Glass(Graphics g, Rectangle r, float hv)
    {
        if (Theme.Zach)                                                  // a knit card: green stripes, a zebra tab, a pink edge
        {
            for (int i = 3; i >= 1; i--) using (var gp = Theme.Round(new Rectangle(r.X - i * 2, r.Y - i * 2 + 5, r.Width + i * 4, r.Height + i * 4), 22 + i * 2)) using (var b = new SolidBrush(Color.FromArgb(14 + (4 - i) * 3, 0, 12, 4))) g.FillPath(b, gp);
            using (var path = Theme.Round(r, 22))
            {
                bool pic = Backdrop.Source != null;
                using (var b = new LinearGradientBrush(r, Color.FromArgb(pic ? 226 : 216, Theme.Lerp(Theme.Card, Theme.CardHover, 0.35f * hv)), Color.FromArgb(pic ? 232 : 224, Theme.Lerp(Theme.Panel, Theme.Card, 0.3f)), 90f)) g.FillPath(b, path);
                var st = g.Save(); g.SetClip(path);
                using (var b = new SolidBrush(Color.FromArgb(22, 120, 230, 160))) for (int y = r.Y + 12; y < r.Bottom; y += 16) g.FillRectangle(b, r.X, y, r.Width, 7);
                int tw = Math.Min(150, r.Width / 3);
                using (var b = new SolidBrush(Color.FromArgb(240, 246, 244))) g.FillRectangle(b, r.X, r.Y, tw, 6);
                var st2 = g.Save(); g.SetClip(new Rectangle(r.X, r.Y, tw, 6), CombineMode.Intersect);
                using (var b = new SolidBrush(Color.FromArgb(12, 12, 16))) for (int x = r.X - 6; x < r.X + tw; x += 11) g.FillPolygon(b, new[] { new Point(x, r.Y + 6), new Point(x + 5, r.Y + 6), new Point(x + 9, r.Y), new Point(x + 4, r.Y) });
                g.Restore(st2);
                using (var b = new SolidBrush(Color.FromArgb(255, 110, 184))) g.FillRectangle(b, r.X + tw, r.Y, Math.Min(40, r.Width / 8), 6);
                g.Restore(st);
                if (hv > 0.02f) using (var p = new Pen(Color.FromArgb((int)(130 * hv), 255, 110, 184), 6f)) g.DrawPath(p, path);
                using (var p = new Pen(Color.FromArgb(230, 2, 14, 6), 3.4f)) g.DrawPath(p, path);
                using (var p = new Pen(Theme.Lerp(Color.FromArgb(255, 100, 176), Color.FromArgb(255, 176, 214), hv), 2f)) g.DrawPath(p, path);
            }
            return;
        }
        if (Theme.Dbz)                                                   // a comic panel: hard offset shadow, thick gold ink border, halftone corner, orange tab
        {
            using (var sp = Theme.Round(new Rectangle(r.X + 5, r.Y + 6, r.Width, r.Height), 22)) using (var b = new SolidBrush(Color.FromArgb(150, 2, 3, 14))) g.FillPath(b, sp);
            using (var path = Theme.Round(r, 22))
            {
                bool pic = Backdrop.Source != null;
                using (var b = new LinearGradientBrush(r, Color.FromArgb(pic ? 226 : 214, Theme.Lerp(Theme.Card, Theme.CardHover, 0.35f * hv)), Color.FromArgb(pic ? 232 : 222, Theme.Lerp(Theme.Panel, Color.Black, 0.2f)), 90f)) g.FillPath(b, path);
                var st = g.Save(); g.SetClip(path);
                using (var b = new SolidBrush(Color.FromArgb(34, 255, 190, 70))) for (int row = 0; row < 7; row++) for (int col = 0; col < 12; col++) { float dd = 1.2f + (6 - row) * 0.35f - col * 0.05f; if (dd < 0.5f) continue; g.FillEllipse(b, r.Right - 14 - col * 8 - (row % 2) * 4, r.Y + 8 + row * 7, dd * 2, dd * 2); }
                using (var b = new SolidBrush(Color.FromArgb(220, 255, 150, 0))) g.FillRectangle(b, r.X, r.Y, Math.Min(120, r.Width / 3), 5);
                using (var b = new SolidBrush(Color.FromArgb(235, 255, 216, 80))) g.FillRectangle(b, r.X, r.Y, Math.Min(34, r.Width / 8), 5);
                g.Restore(st);
                if (hv > 0.02f) using (var p = new Pen(Color.FromArgb((int)(150 * hv), 255, 200, 60), 7f)) g.DrawPath(p, path);
                using (var p = new Pen(Color.FromArgb(240, 2, 3, 16), 4.5f)) g.DrawPath(p, path);
                using (var p = new Pen(Theme.Lerp(Color.FromArgb(255, 150, 20), Color.FromArgb(255, 222, 100), hv), 2.4f)) g.DrawPath(p, path);
            }
            return;
        }
        if (Theme.Jnb)                                                   // a crystal shard: glowing magenta edge, light and dark facets, thin yellow rim on the long cuts
        {
            for (int i = 3; i >= 1; i--) using (var gp = Theme.Round(new Rectangle(r.X - i * 3, r.Y - i * 3, r.Width + i * 6, r.Height + i * 6), 22 + i * 4)) using (var p = new Pen(Color.FromArgb(14 + (int)(10 * hv), 255, 40, 120), 3f)) g.DrawPath(p, gp);
            using (var path = Theme.Round(r, 22))
            {
                bool pic = Backdrop.Source != null;
                using (var b = new LinearGradientBrush(r, Color.FromArgb(pic ? 214 : 200, Theme.Lerp(Theme.CardHover, Theme.Card, 0.45f - 0.3f * hv)), Color.FromArgb(pic ? 228 : 214, Theme.Lerp(Theme.Panel, Color.Black, 0.25f)), 35f)) g.FillPath(b, path);
                var st = g.Save(); g.SetClip(path);
                using (var b = new SolidBrush(Color.FromArgb(26, 255, 190, 230))) g.FillPolygon(b, new[] { new PointF(r.X + r.Width * 0.30f, r.Y), new PointF(r.X + r.Width * 0.46f, r.Y), new PointF(r.X + r.Width * 0.16f, r.Bottom), new PointF(r.X, r.Bottom), new PointF(r.X, r.Bottom - 40), });
                using (var b = new SolidBrush(Color.FromArgb(36, 0, 0, 0))) g.FillPolygon(b, new[] { new PointF(r.Right, r.Y + r.Height * 0.45f), new PointF(r.Right, r.Bottom), new PointF(r.Right - r.Width * 0.35f, r.Bottom) });
                g.Restore(st);
                using (var p = new Pen(Theme.Lerp(Color.FromArgb(214, 84, 150), Color.FromArgb(255, 222, 80), hv), 1.6f)) g.DrawPath(p, path);
                float cut = Math.Min(Math.Min(r.Width, r.Height) / 2f, 33f);
                using (var p = new Pen(Color.FromArgb(230, 255, 218, 70), 2.2f)) { g.DrawLine(p, r.X + 1, r.Y + cut, r.X + cut, r.Y + 1); g.DrawLine(p, r.Right - 1, r.Bottom - cut, r.Right - cut, r.Bottom - 1); }
            }
            return;
        }
        if (Theme.Aero)
        {
            for (int i = 4; i >= 1; i--) using (var path = Theme.Round(new Rectangle(r.X - i * 2, r.Y - i * 2 + 5, r.Width + i * 4, r.Height + i * 4), 22 + i * 2)) using (var b = new SolidBrush(Color.FromArgb(10, 30, 90, 140))) g.FillPath(b, path);
            using (var path = Theme.Round(r, 20))
            {
                bool pic = Backdrop.Source != null;
                using (var b = new LinearGradientBrush(r, Color.FromArgb(pic ? 214 : 176, 232, 248, 255), Color.FromArgb(pic ? 196 : 150, 196, 232, 252), 90f)) g.FillPath(b, path);
                Theme.Gloss(g, path, r, 150, 18);
                if (hv > 0.02f) using (var p = new Pen(Color.FromArgb((int)(120 * hv), 60, 200, 255), 5f)) g.DrawPath(p, path);
                using (var p = new Pen(Theme.Lerp(Color.FromArgb(120, 176, 212), Color.FromArgb(24, 150, 232), hv))) g.DrawPath(p, path);
                using (var inner = Theme.Round(Rectangle.Inflate(r, -1, -1), 18)) using (var p = new Pen(Color.FromArgb(235, 255, 255, 255), 1.6f)) g.DrawPath(p, inner);
            }
            return;
        }
        for (int i = 4; i >= 1; i--) using (var path = Theme.Round(new Rectangle(r.X - i * 2, r.Y - i * 2 + 5, r.Width + i * 4, r.Height + i * 4), 22 + i * 2)) using (var b = new SolidBrush(Color.FromArgb(9, 0, 0, 0))) g.FillPath(b, path);
        using (var path = Theme.Round(r, 20))
        {
            using (var b = new LinearGradientBrush(r, Color.FromArgb(Backdrop.Source != null ? 196 : 176, Theme.Lerp(Theme.Card, Theme.Accent, 0.10f + 0.16f * hv)), Color.FromArgb(Backdrop.Source != null ? 214 : 196, Theme.Lerp(Theme.Panel, Color.Black, 0.18f)), 70f)) g.FillPath(b, path);
            if (hv > 0.02f) using (var p = new Pen(Color.FromArgb((int)(60 * hv), Theme.Accent), 5f)) g.DrawPath(p, path);
            using (var p = new Pen(Theme.Lerp(Theme.Border, Theme.Accent, 0.15f + 0.85f * hv))) g.DrawPath(p, path);
        }
        using (var p = new Pen(Color.FromArgb(34, 255, 255, 255))) g.DrawLine(p, r.X + 22, r.Y + 1, r.Right - 22, r.Y + 1);
    }
    protected static void Str(Graphics g, string s, Font f, Color c, RectangleF r, bool wrap)
    {
        using (var br = new SolidBrush(c)) using (var sf = new StringFormat(wrap ? StringFormat.GenericDefault : StringFormat.GenericTypographic) { Trimming = StringTrimming.EllipsisCharacter }) g.DrawString(s, f, br, r, sf);
    }
    protected static int ChipS(Graphics g, int x, int y, string text, Color tone, bool filled)
    {
        Size sz = TextRenderer.MeasureText(text, Theme.SmallB, Size.Empty, TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        var r = new Rectangle(x, y, sz.Width + 14, 19);
        using (var path = Theme.Round(r, 10))
        {
            using (var b = new SolidBrush(filled ? Theme.Lerp(Theme.Card, tone, 0.28f) : Theme.Lerp(Theme.Card, tone, 0.1f))) g.FillPath(b, path);
            using (var p = new Pen(Theme.Lerp(Theme.Card, tone, 0.55f))) g.DrawPath(p, path);
        }
        using (var br = new SolidBrush(filled ? Theme.Emph(tone, 0.35f) : tone)) using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center }) g.DrawString(text, Theme.SmallB, br, new RectangleF(r.X, r.Y, r.Width, r.Height), sf);
        return r.Width + 6;
    }
}

// the wordmark and a soft animated backdrop at the top of the rail (the gradient and the lettering are baked; only sparkles and the shine move)
class BrandPanel : Panel
{
    readonly float[] sx = new float[18], sy = new float[18], sv = new float[18], ss = new float[18], sp = new float[18];
    float t; bool hooked; Bitmap bgSpr, txtSpr; GraphicsPath textPath; Size sprSize; int sprKey;
    public BrandPanel()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        var r = new Random(11);
        for (int i = 0; i < sx.Length; i++) { sx[i] = (float)r.NextDouble(); sy[i] = (float)r.NextDouble(); sv[i] = 0.02f + (float)r.NextDouble() * 0.04f; ss[i] = 0.8f + (float)r.NextDouble() * 1.5f; sp[i] = (float)r.NextDouble() * 6.28f; }
        VisibleChanged += delegate { Hook(); }; HandleCreated += delegate { Hook(); };
    }
    void Hook()
    {
        bool want = Visible && IsHandleCreated;
        if (want && !hooked) { hooked = true; Ticker.Frame += OnFrame; } else if (!want && hooked) { hooked = false; Ticker.Frame -= OnFrame; }
    }
    void OnFrame(float dt) { if (HubState.IntroPlaying) return; var f = FindForm(); if (f == null || f.WindowState == FormWindowState.Minimized) return; t += dt; Invalidate(); }
    protected override void Dispose(bool d) { if (d) { if (hooked) { hooked = false; Ticker.Frame -= OnFrame; } if (bgSpr != null) bgSpr.Dispose(); if (txtSpr != null) txtSpr.Dispose(); if (textPath != null) textPath.Dispose(); } base.Dispose(d); }
    void Bake()
    {
        int key = Theme.Accent.ToArgb();
        if (bgSpr != null && sprSize == Size && sprKey == key) return;
        if (Width < 2 || Height < 2) return;
        if (bgSpr != null) bgSpr.Dispose(); if (txtSpr != null) txtSpr.Dispose(); if (textPath != null) textPath.Dispose();
        sprSize = Size; sprKey = key;
        bgSpr = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(bgSpr))
        {
            var rc = new Rectangle(0, 0, Width, Height);
            if (Theme.Aero)
            {
                using (var b = new LinearGradientBrush(rc, Color.FromArgb(104, 188, 246), Color.FromArgb(222, 242, 253), 90f)) g.FillRectangle(b, rc);
                using (var path = new GraphicsPath()) { path.AddRectangle(rc); Theme.Gloss(g, path, rc, 110, 14); }
                using (var p = new Pen(Color.FromArgb(150, 90, 150, 196))) g.DrawLine(p, 0, Height - 1, Width, Height - 1);
                using (var p = new Pen(Color.FromArgb(210, 255, 255, 255))) g.DrawLine(p, 0, Height - 2, Width, Height - 2);
            }
            else
            {
                using (var b = new LinearGradientBrush(rc, Theme.Lerp(Theme.Panel, Theme.Accent, 0.38f), Theme.Panel, 90f)) g.FillRectangle(b, rc);
                using (var p = new Pen(Theme.Lerp(Theme.Border, Theme.Panel, 0.4f))) g.DrawLine(p, 0, Height - 1, Width, Height - 1);
            }
        }
        txtSpr = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
        textPath = new GraphicsPath();
        textPath.AddString("CENOHWARE", new FontFamily("Segoe UI Black"), 0, 27f, new PointF(0, 0), StringFormat.GenericTypographic);
        var bb = textPath.GetBounds();
        using (var m = new Matrix()) { m.Translate((Width - bb.Width) / 2f - bb.X, 46f - bb.Y); textPath.Transform(m); }
        using (var g = Graphics.FromImage(txtSpr))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            for (int i = 4; i >= 1; i--) using (var p = new Pen(Color.FromArgb(Theme.Aero ? 30 : 22, Theme.Aero ? Color.FromArgb(40, 190, 255) : Theme.Accent), i * 4f) { LineJoin = LineJoin.Round }) g.DrawPath(p, textPath);
            using (var p = new Pen(Theme.Aero ? Color.FromArgb(0, 98, 172) : Theme.AccentSoft, 2.4f) { LineJoin = LineJoin.Round }) g.DrawPath(p, textPath);
            using (var b = new SolidBrush(Color.White)) g.FillPath(b, textPath);
            if (Theme.Aero) using (var b = new LinearGradientBrush(textPath.GetBounds(), Color.FromArgb(0, 255, 255, 255), Color.FromArgb(120, 120, 205, 255), 90f)) g.FillPath(b, textPath);     // a little sky in the lower half of the letters
            using (var br = new SolidBrush(Theme.Aero ? Color.FromArgb(24, 70, 108) : Theme.Lerp(Theme.Dim, Color.White, 0.25f))) using (var sf = new StringFormat { Alignment = StringAlignment.Center }) g.DrawString("by Cenoh", Theme.SmallB, br, new RectangleF(0, 82, Width, 20), sf);
        }
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; Bake(); if (bgSpr == null) return;
        g.CompositingMode = CompositingMode.SourceCopy; g.DrawImage(bgSpr, new Rectangle(0, 0, Width, Height), 0, 0, Width, Height, GraphicsUnit.Pixel); g.CompositingMode = CompositingMode.SourceOver;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        for (int i = 0; i < sx.Length; i++)
        {
            float y = (sy[i] - sv[i] * t * 0.35f) % 1f; if (y < 0) y += 1f;
            float x = sx[i] * Width + (float)Math.Sin(t * 0.8f + sp[i]) * 5f, yy = y * Height, tw = 0.3f + 0.7f * (float)Math.Abs(Math.Sin(t * 1.4f + sp[i]));
            if (Theme.Aero)
            {
                float rad = ss[i] * 4f + 2.5f;
                using (var br = new SolidBrush(Color.FromArgb((int)(40 * tw), 255, 255, 255))) g.FillEllipse(br, x - rad, yy - rad, rad * 2, rad * 2);
                using (var p = new Pen(Color.FromArgb((int)(170 * tw), 255, 255, 255), 1f)) g.DrawEllipse(p, x - rad, yy - rad, rad * 2, rad * 2);
                continue;
            }
            using (var br = new SolidBrush(Color.FromArgb((int)(160 * tw), Theme.AccentSoft))) g.FillEllipse(br, x - ss[i], yy - ss[i], ss[i] * 2, ss[i] * 2);
        }
        g.DrawImage(txtSpr, new Rectangle(0, 0, Width, Height), 0, 0, Width, Height, GraphicsUnit.Pixel);
        var gb = textPath.GetBounds(); float sh = ((t * 0.22f) % 1.5f - 0.25f) * (gb.Width + 80f) + gb.X - 40f;
        if (sh > gb.X - 60f && sh < gb.Right + 60f)
        {
            var st = g.Save(); g.SetClip(textPath);
            var band = new RectangleF(sh - 36, gb.Y - 4, 72, gb.Height + 8);
            using (var lb = new LinearGradientBrush(band, Color.Transparent, Color.Transparent, 0f))
            {
                lb.InterpolationColors = new ColorBlend(3) { Colors = Theme.Aero ? new[] { Color.FromArgb(0, 120, 215, 255), Color.FromArgb(235, 130, 220, 255), Color.FromArgb(0, 120, 215, 255) } : new[] { Color.FromArgb(0, Theme.AccentSoft), Color.FromArgb(235, Theme.AccentSoft), Color.FromArgb(0, Theme.AccentSoft) }, Positions = new[] { 0f, 0.5f, 1f } };
                g.FillRectangle(lb, band);
            }
            g.Restore(st);
        }
    }
}

// the mouse wheel goes to the focused control, and the tab list is never focused: so while the pointer is over the list, the wheel scrolls it
class NavWheelFilter : IMessageFilter
{
    readonly NavList nav; public NavWheelFilter(NavList n) { nav = n; }
    public bool PreFilterMessage(ref Message m)
    {
        if (m.Msg != 0x20A || nav.IsDisposed || !nav.IsHandleCreated) return false;
        if (!nav.RectangleToScreen(nav.ClientRectangle).Contains(Cursor.Position)) return false;
        nav.WheelBy((short)((long)m.WParam >> 16)); return true;
    }
}

class NavList : Control
{
    public event Action<int> Picked;
    static readonly string[] AllNames = { "Home", "Hold Click", "", "", "", "", "", "", "", "", "Cacenoh", "Shotgun Keys", "Disk Cleaner", "Minecraft Server", "", "Humanizer" };
    static readonly string[] AllSubs = { "Everything in one place", "Hold or auto-click a button", "", "", "", "", "", "", "", "", "Pretend coins, real fun", "Every key goes bang", "Free up drive space", "Run it from this PC", "", "Make AI text sound like you" };
    // the tabs that are shown, as page numbers: all of them, or in the public build Home, the Cacenoh, Hold Click, Shotgun Keys, Disk Cleaner, Minecraft Server and Humanizer
    static readonly int[] DefaultReal = { 0, 10, 1, 11, 12, 13, 15 };
    public static int[] Real = (int[])DefaultReal.Clone();       // the page shown in each row, in the order the user chose
    static int[] Seq(int n) { var r = new int[n]; for (int i = 0; i < n; i++) r[i] = i; return r; }
    static string[] Pick(string[] a) { var r = new string[Real.Length]; for (int i = 0; i < r.Length; i++) r[i] = a[Real[i]]; return r; }
    public static string[] Names = Pick(AllNames), Subs = Pick(AllSubs);
    // a saved or dragged order: pages it does not mention (a tab added later) go on the end, ones that no longer exist are dropped
    public static void SetOrder(int[] want)
    {
        var res = new List<int>(); foreach (int p in want) if (Array.IndexOf(DefaultReal, p) >= 0 && !res.Contains(p)) res.Add(p);
        foreach (int p in DefaultReal) if (!res.Contains(p)) res.Add(p);
        Real = res.ToArray(); Names = Pick(AllNames); Subs = Pick(AllSubs);
    }
    public static int RowOf(int page) { return Array.IndexOf(Real, page); }
    public int Selected;
    const int Pad = 10, ItemH = 58;
    float scroll, scrollTarget; int MaxScroll { get { return Math.Max(0, Pad * 2 + Names.Length * ItemH - Height); } }     // more tabs than fit: the list scrolls (mouse wheel, or drag near the edge in edit mode)
    float selY, glowT; readonly float[] hv = new float[Names.Length], rowAnim = new float[Names.Length]; int hot = -1; bool hooked;
    public bool Editing; public event Action Reordered; int dragRow = -1, dragTarget, selPage; float dragY, dragOff;   // edit mode: drag a tab up or down to move it
    float RowTop(int i) { return dragRow < 0 ? Pad + i * ItemH - scroll : i == dragRow ? dragY : rowAnim[i]; }
    float RowTargetTop(int i) { int shift = 0; if (dragRow < dragTarget && i > dragRow && i <= dragTarget) shift = -1; else if (dragRow > dragTarget && i >= dragTarget && i < dragRow) shift = 1; return Pad + (i + shift) * ItemH - scroll; }
    int DrawOrder(int q) { return dragRow < 0 ? q : q < Names.Length - 1 ? (q < dragRow ? q : q + 1) : dragRow; }
    float SelDrawY() { return dragRow < 0 ? selY - scroll : Selected == dragRow ? dragY : rowAnim[Selected]; }
    public void SetEditing(bool on) { Editing = on; dragRow = -1; Cursor = on ? Cursors.SizeNS : Cursors.Hand; Kick(); Invalidate(); }
    public NavList() { SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true); Cursor = Cursors.Hand; selY = Pad; }
    float TargetY { get { return Pad + Selected * ItemH; } }
    int At(Point p) { int i = (int)Math.Floor((p.Y - Pad + scroll) / ItemH); return p.Y >= 0 && i >= 0 && i < Names.Length ? i : -1; }
    void OnFrame(float dt)
    {
        bool moving = false;
        selY = Ticker.Ease(selY, TargetY, 16f, dt); if (selY != TargetY) moving = true;
        if (dragRow >= 0) { if (dragY < 36) scrollTarget -= 700f * dt; else if (dragY > Height - ItemH - 36) scrollTarget += 700f * dt; scrollTarget = Math.Max(0, Math.Min(MaxScroll, scrollTarget)); scroll = scrollTarget; dragTarget = Math.Max(0, Math.Min(Names.Length - 1, (int)((dragY + scroll + ItemH / 2f - Pad) / ItemH))); }
        else { scrollTarget = Math.Max(0, Math.Min(MaxScroll, scrollTarget)); scroll = Ticker.Ease(scroll, scrollTarget, 16f, dt); if (Math.Abs(scroll - scrollTarget) > 0.4f) moving = true; else scroll = scrollTarget; }
        for (int i = 0; i < Names.Length; i++) { float t = hot == i ? 1f : 0f; hv[i] = Ticker.Ease(hv[i], t, 16f, dt); if (hv[i] != t) moving = true; }
        glowT += dt; if (glowT < 1.2f) moving = true;
        if (dragRow >= 0) { moving = true; for (int i = 0; i < rowAnim.Length; i++) rowAnim[i] = Ticker.Ease(rowAnim[i], RowTargetTop(i), 20f, dt); }
        Invalidate(); if (!moving && hooked) { Ticker.Frame -= OnFrame; hooked = false; }
    }
    void Kick() { if (!hooked) { hooked = true; Ticker.Frame += OnFrame; } }
    public void Select(int i, bool animate)
    {
        Selected = i; if (!animate) selY = TargetY; glowT = 0;
        float top = Pad + i * ItemH; if (top - scrollTarget < 0) scrollTarget = Math.Max(0, top - Pad); else if (top + ItemH - scrollTarget > Height - Pad) scrollTarget = Math.Min(MaxScroll, top + ItemH - Height + Pad);      // keep the chosen tab in view
        if (!animate) scroll = scrollTarget; Kick(); Invalidate();
    }
    protected override void Dispose(bool d) { if (d && hooked) { Ticker.Frame -= OnFrame; hooked = false; } base.Dispose(d); }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (dragRow >= 0)
        {
            dragY = Math.Max(0, Math.Min(Height - ItemH + 6, e.Y - dragOff)); dragTarget = Math.Max(0, Math.Min(Names.Length - 1, (int)((dragY + scroll + ItemH / 2f - Pad) / ItemH))); Kick(); Invalidate(); return;
        }
        int h = At(e.Location); if (h != hot) { hot = h; Kick(); }
        base.OnMouseMove(e);
    }
    protected override void OnMouseLeave(EventArgs e) { hot = -1; Kick(); base.OnMouseLeave(e); }
    public void WheelBy(int delta) { if (MaxScroll > 0 && dragRow < 0) { scrollTarget = Math.Max(0, Math.Min(MaxScroll, scrollTarget - delta * 0.6f)); Kick(); Invalidate(); } }
    protected override void OnMouseWheel(MouseEventArgs e) { WheelBy(e.Delta); base.OnMouseWheel(e); }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        int i = At(e.Location);
        if (Editing)
        {
            if (i >= 0 && e.Button == MouseButtons.Left) { dragRow = dragTarget = i; dragOff = e.Y - (Pad + i * ItemH - scroll); dragY = Pad + i * ItemH - scroll; for (int k = 0; k < rowAnim.Length; k++) rowAnim[k] = Pad + k * ItemH - scroll; selPage = Real[Selected]; Kick(); Invalidate(); }
            return;
        }
        if (i >= 0 && Picked != null) Picked(Real[i]);
        base.OnMouseDown(e);
    }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        if (dragRow >= 0)
        {
            int from = dragRow, to = dragTarget; dragRow = -1;
            if (from != to) { var list = new List<int>(Real); int pg = list[from]; list.RemoveAt(from); list.Insert(to, pg); SetOrder(list.ToArray()); Selected = Math.Max(0, RowOf(selPage)); selY = TargetY; if (Reordered != null) Reordered(); }
            Kick(); Invalidate();
        }
        base.OnMouseUp(e);
    }

    public static void Icon(Graphics g, int kind, Rectangle r, Color c)
    {
        using (var p = new Pen(c, 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
        {
            float x = r.X, y = r.Y, w = r.Width, h = r.Height;
            switch (kind)
            {
                case 0: g.DrawLines(p, new[] { new PointF(x + 2, y + h * 0.5f), new PointF(x + w / 2, y + 2), new PointF(x + w - 2, y + h * 0.5f) }); g.DrawRectangle(p, x + 5, y + h * 0.5f, w - 10, h * 0.4f); break;
                case 1: g.DrawPath(p, Theme.Round(new Rectangle((int)x + 5, (int)y + 2, (int)w - 10, (int)h - 4), 12)); g.DrawLine(p, x + w / 2, y + 3, x + w / 2, y + h * 0.42f); g.DrawLine(p, x + 5, y + h * 0.42f, x + w - 5, y + h * 0.42f); break;
                case 2: g.DrawPath(p, Theme.Round(new Rectangle((int)x + 4, (int)y + 3, (int)w - 8, (int)h - 4), 5)); g.DrawLines(p, new[] { new PointF(x + 8, y + h * 0.55f), new PointF(x + w * 0.42f, y + h * 0.75f), new PointF(x + w - 8, y + h * 0.35f) }); break;
                case 3: g.DrawPath(p, Theme.Round(new Rectangle((int)(x + w / 2 - 4), (int)y + 1, 8, (int)(h * 0.55f)), 8)); g.DrawArc(p, x + 4, y + h * 0.2f, w - 8, h * 0.55f, 0, 180); g.DrawLine(p, x + w / 2, y + h * 0.75f, x + w / 2, y + h - 2); g.DrawLine(p, x + w / 2 - 5, y + h - 2, x + w / 2 + 5, y + h - 2); break;
                case 5: g.DrawPath(p, Theme.Round(new Rectangle((int)x + 3, (int)y + 4, (int)w - 6, (int)h - 8), 5)); g.DrawLines(p, new[] { new PointF(x + 6, y + h - 7), new PointF(x + w * 0.42f, y + h * 0.5f), new PointF(x + w * 0.62f, y + h * 0.7f), new PointF(x + w - 6, y + h * 0.4f) }); g.DrawEllipse(p, x + w * 0.64f, y + h * 0.22f, 5, 5); break;
                case 6: { var bub = new Rectangle((int)x + 2, (int)y + 3, (int)w - 4, (int)(h * 0.64f)); using (var path = Theme.Round(bub, 9)) { using (var fb = new SolidBrush(Color.FromArgb(46, c))) g.FillPath(fb, path); g.DrawPath(p, path); } g.DrawLines(p, new[] { new PointF(x + w * 0.3f, y + h * 0.67f), new PointF(x + w * 0.24f, y + h - 3), new PointF(x + w * 0.52f, y + h * 0.67f) }); g.DrawLine(p, x + w / 2, y + h * 0.2f, x + w / 2, y + h * 0.43f); using (var db = new SolidBrush(c)) g.FillEllipse(db, x + w / 2 - 1.6f, y + h * 0.5f - 0.5f, 3.2f, 3.2f); } break;
                case 7: { var top = new[] { new PointF(x + w / 2, y + 2), new PointF(x + w - 3, y + h * 0.27f), new PointF(x + w / 2, y + h * 0.5f), new PointF(x + 3, y + h * 0.27f) }; using (var fb = new SolidBrush(Color.FromArgb(46, c))) g.FillPolygon(fb, top); g.DrawLines(p, new[] { new PointF(x + w / 2, y + 2), new PointF(x + w - 3, y + h * 0.27f), new PointF(x + w - 3, y + h * 0.73f), new PointF(x + w / 2, y + h - 2), new PointF(x + 3, y + h * 0.73f), new PointF(x + 3, y + h * 0.27f), new PointF(x + w / 2, y + 2) }); g.DrawLine(p, x + 3, y + h * 0.27f, x + w / 2, y + h * 0.5f); g.DrawLine(p, x + w - 3, y + h * 0.27f, x + w / 2, y + h * 0.5f); g.DrawLine(p, x + w / 2, y + h * 0.5f, x + w / 2, y + h - 2); } break;
                case 8: { var st = g.Save(); g.TranslateTransform(x + w * 0.31f, y + h * 0.54f); g.RotateTransform(-14f); using (var path = Theme.Round(new Rectangle((int)(-w * 0.2f), (int)(-h * 0.34f), (int)(w * 0.4f), (int)(h * 0.68f)), 4)) { using (var fb = new SolidBrush(Color.FromArgb(40, c))) g.FillPath(fb, path); g.DrawPath(p, path); } g.Restore(st); st = g.Save(); g.TranslateTransform(x + w * 0.67f, y + h * 0.5f); g.RotateTransform(11f); using (var path = Theme.Round(new Rectangle((int)(-w * 0.2f), (int)(-h * 0.34f), (int)(w * 0.4f), (int)(h * 0.68f)), 4)) { using (var fb = new SolidBrush(Color.FromArgb(70, c))) g.FillPath(fb, path); g.DrawPath(p, path); } using (var db = new SolidBrush(c)) { var star = new PointF[10]; for (int k = 0; k < 10; k++) { double an = -Math.PI / 2 + k * Math.PI / 5; float rr = k % 2 == 0 ? w * 0.16f : w * 0.07f; star[k] = new PointF((float)Math.Cos(an) * rr, (float)Math.Sin(an) * rr); } g.FillPolygon(db, star); } g.Restore(st); } break;
                case 9: { using (var path = Theme.Round(new Rectangle((int)x + 2, (int)y + 3, (int)w - 4, (int)h - 6), 5)) { using (var fb = new SolidBrush(Color.FromArgb(40, c))) g.FillPath(fb, path); g.DrawPath(p, path); } g.DrawLine(p, x + w * 0.37f, y + 4, x + w * 0.37f, y + h - 4); g.DrawLine(p, x + w * 0.65f, y + 4, x + w * 0.65f, y + h - 4); using (var db = new SolidBrush(c)) { g.FillRectangle(db, x + w * 0.1f, y + h * 0.26f, w * 0.17f, h * 0.14f); g.FillRectangle(db, x + w * 0.1f, y + h * 0.5f, w * 0.17f, h * 0.14f); g.FillRectangle(db, x + w * 0.45f, y + h * 0.26f, w * 0.17f, h * 0.14f); g.FillRectangle(db, x + w * 0.73f, y + h * 0.26f, w * 0.17f, h * 0.14f); g.FillRectangle(db, x + w * 0.73f, y + h * 0.5f, w * 0.17f, h * 0.14f); g.FillRectangle(db, x + w * 0.73f, y + h * 0.74f - 2, w * 0.17f, h * 0.14f); } } break;
                case 10: { var d = new RectangleF(x + 2, y + 2, w - 4, h - 4); g.DrawEllipse(p, d); g.DrawEllipse(p, d.X + d.Width * 0.2f, d.Y + d.Height * 0.2f, d.Width * 0.6f, d.Height * 0.6f); for (int k = 0; k < 8; k++) { double an = k * Math.PI / 4 + Math.PI / 8; g.DrawLine(p, d.X + d.Width / 2 + (float)Math.Cos(an) * d.Width * 0.42f, d.Y + d.Height / 2 + (float)Math.Sin(an) * d.Height * 0.42f, d.X + d.Width / 2 + (float)Math.Cos(an) * d.Width * 0.5f, d.Y + d.Height / 2 + (float)Math.Sin(an) * d.Height * 0.5f); } g.DrawLines(p, new[] { new PointF(x + w * 0.36f, y + h * 0.36f), new PointF(x + w * 0.64f, y + h * 0.36f), new PointF(x + w * 0.36f, y + h * 0.64f), new PointF(x + w * 0.64f, y + h * 0.64f) }); } break;
                case 11: { var kc = new Rectangle((int)x + 3, (int)y + 4, (int)w - 6, (int)h - 10); using (var path = Theme.Round(kc, 6)) { using (var fb = new SolidBrush(Color.FromArgb(40, c))) g.FillPath(fb, path); g.DrawPath(p, path); } g.DrawLine(p, x + w * 0.3f, y + h * 0.44f, x + w * 0.7f, y + h * 0.44f); g.DrawLine(p, x + w * 0.3f, y + h * 0.62f, x + w * 0.7f, y + h * 0.62f); g.DrawLine(p, x + w * 0.5f, y + 1, x + w * 0.5f, y + 4); g.DrawLine(p, x + w * 0.2f, y + 3, x + w * 0.27f, y + 6); g.DrawLine(p, x + w * 0.8f, y + 3, x + w * 0.73f, y + 6); } break;
                case 12: { var dr = new Rectangle((int)x + 2, (int)y + 6, (int)w - 4, (int)h - 12); using (var path = Theme.Round(dr, 6)) { using (var fb = new SolidBrush(Color.FromArgb(40, c))) g.FillPath(fb, path); g.DrawPath(p, path); } g.DrawLine(p, x + 5, y + h * 0.62f, x + w - 5, y + h * 0.62f); g.FillEllipse(new SolidBrush(c), x + w - 10, y + h * 0.5f - 1, 3.5f, 3.5f); g.DrawLine(p, x + w * 0.5f, y + 1, x + w * 0.5f, y + 5); g.DrawLine(p, x + w * 0.5f - 4, y + 3, x + w * 0.5f + 4, y + 3); } break;
                case 13: { var cx = x + w / 2; var hex = new[] { new PointF(cx, y + 1), new PointF(x + w - 2, y + h * 0.27f), new PointF(x + w - 2, y + h * 0.73f), new PointF(cx, y + h - 1), new PointF(x + 2, y + h * 0.73f), new PointF(x + 2, y + h * 0.27f) }; using (var fb = new SolidBrush(Color.FromArgb(40, c))) g.FillPolygon(fb, hex); g.DrawPolygon(p, hex); g.DrawLines(p, new[] { new PointF(x + 2, y + h * 0.27f), new PointF(cx, y + h * 0.5f), new PointF(x + w - 2, y + h * 0.27f) }); g.DrawLine(p, cx, y + h * 0.5f, cx, y + h - 1); } break;
                case 14: { var cb = new Rectangle((int)x + 2, (int)y + 6, (int)w - 4, (int)h - 9); using (var path = Theme.Round(cb, 6)) { using (var fb = new SolidBrush(Color.FromArgb(40, c))) g.FillPath(fb, path); g.DrawPath(p, path); } g.DrawEllipse(p, x + w / 2 - 5, y + h * 0.58f - 5, 10, 10); g.DrawLines(p, new[] { new PointF(x + w * 0.3f, y + 6), new PointF(x + w * 0.38f, y + 2), new PointF(x + w * 0.62f, y + 2), new PointF(x + w * 0.7f, y + 6) }); } break;
                case 15: { var pg = new Rectangle((int)x + 3, (int)y + 2, (int)w - 6, (int)h - 4); using (var path = Theme.Round(pg, 5)) { using (var fb = new SolidBrush(Color.FromArgb(40, c))) g.FillPath(fb, path); g.DrawPath(p, path); } g.DrawLine(p, x + 8, y + h * 0.3f, x + w - 8, y + h * 0.3f); g.DrawLine(p, x + 8, y + h * 0.5f, x + w - 11, y + h * 0.5f); g.DrawBezier(p, x + 8, y + h * 0.72f, x + w * 0.35f, y + h * 0.58f, x + w * 0.5f, y + h * 0.86f, x + w - 8, y + h * 0.7f); } break;
                default: g.DrawRectangle(p, x + 4, y + h * 0.4f, w - 8, h * 0.5f); g.DrawLine(p, x + w / 2, y + h * 0.4f, x + w / 2, y + 2); g.DrawLines(p, new[] { new PointF(x + w / 2 - 4, y + 6), new PointF(x + w / 2, y + 2), new PointF(x + w / 2 + 4, y + 6) }); break;
            }
        }
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit; g.Clear(Theme.Panel);
        if (Theme.Aero) using (var b = new LinearGradientBrush(new Rectangle(0, 0, Width, Height + 1), Color.FromArgb(232, 246, 254), Color.FromArgb(196, 228, 248), 90f)) g.FillRectangle(b, 0, 0, Width, Height);
        var sel = new Rectangle(8, (int)SelDrawY(), Width - 16, ItemH - 6);
        float flash = Math.Max(0f, 1f - glowT / 1.2f);
        if (flash > 0.01f) using (var path = Theme.Round(Rectangle.Inflate(sel, 3, 3), 16)) using (var p = new Pen(Color.FromArgb((int)(90 * flash), Theme.AccentSoft), 5f)) g.DrawPath(p, path);
        using (var path = Theme.Round(sel, 14))
        {
            if (Theme.Aero)
            {
                using (var b = new LinearGradientBrush(sel, Color.FromArgb(78, 184, 250), Color.FromArgb(4, 112, 204), 90f)) g.FillPath(b, path);
                Theme.Gloss(g, path, sel, 150, 30);
                using (var p = new Pen(Color.FromArgb(0, 92, 160))) g.DrawPath(p, path);
                using (var inner = Theme.Round(Rectangle.Inflate(sel, -1, -1), 12)) using (var p = new Pen(Color.FromArgb(150, 255, 255, 255))) g.DrawPath(p, inner);
            }
            else
            {
                using (var b = new LinearGradientBrush(sel, Theme.Lerp(Theme.Card, Theme.Accent, 0.42f), Theme.Lerp(Theme.Card, Theme.Accent, 0.16f), 0f)) g.FillPath(b, path);
                using (var p = new Pen(Theme.Lerp(Theme.Border, Theme.Accent, 0.75f))) g.DrawPath(p, path);
            }
        }
        if (!Theme.Aero) using (var b = new SolidBrush(Theme.AccentSoft)) g.FillPath(b, Theme.Round(new Rectangle(8, sel.Y + 12, 4, ItemH - 30), 4));
        if (MaxScroll > 0) { float th = Math.Max(30, Height * (float)Height / (Pad * 2 + Names.Length * ItemH)), ty = (Height - th) * scroll / MaxScroll; using (var sb = Theme.Round(new Rectangle(Width - 6, (int)ty + 2, 4, (int)th - 4), 4)) using (var b = new SolidBrush(Color.FromArgb(120, Theme.AccentSoft))) g.FillPath(b, sb); }
        for (int q = 0; q < Names.Length; q++)
        {
            int i = DrawOrder(q); int y = (int)RowTop(i); bool on = i == Selected;
            if (Editing)                                       // grip dots on every tab; the one being dragged is lit
            {
                if (i == dragRow) using (var path = Theme.Round(new Rectangle(8, y, Width - 16, ItemH - 6), 14)) { using (var b = new SolidBrush(Color.FromArgb(70, Theme.Accent))) g.FillPath(b, path); using (var p = new Pen(Theme.AccentSoft, 2f)) g.DrawPath(p, path); }
                using (var b = new SolidBrush(Color.FromArgb(i == dragRow ? 255 : 150, Theme.AccentSoft))) for (int gy = 0; gy < 3; gy++) for (int gx = 0; gx < 2; gx++) g.FillEllipse(b, Width - 34 + gx * 7, y + 12 + gy * 8, 3.5f, 3.5f);
            }
            if (!on && hv[i] > 0.02f) using (var path = Theme.Round(new Rectangle(8, y, Width - 16, ItemH - 6), 14)) { using (var b = new SolidBrush(Color.FromArgb((int)((Theme.Aero ? 190 : 255) * hv[i]), Theme.Lerp(Theme.Panel, Theme.CardHover, 0.9f)))) g.FillPath(b, path); if (Theme.Aero) using (var p = new Pen(Color.FromArgb((int)(220 * hv[i]), 150, 205, 238))) g.DrawPath(p, path); }
            Color ic = on ? Color.White : Theme.Lerp(Theme.Dim, Theme.AccentSoft, hv[i]);
            Icon(g, Real[i], new Rectangle(24 + (int)(3 * hv[i]), y + (ItemH - 6 - 24) / 2, 24, 24), ic);
            TextRenderer.DrawText(g, Names[i], Theme.UIB, new Rectangle(62 + (int)(3 * hv[i]), y + 8, Width - 70 - (Editing ? 28 : 0), 20), on ? Color.White : Theme.Text, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            TextRenderer.DrawText(g, Subs[i], Theme.Small, new Rectangle(62 + (int)(3 * hv[i]), y + 28, Width - 70 - (Editing ? 28 : 0), 18), on ? (Theme.Aero ? Color.White : Theme.Lerp(Theme.Dim, Color.White, 0.5f)) : Theme.Dim, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        }
    }
}


class HomePage : BackdropPage
{
    readonly HubForm hub; readonly Btn[] open = new Btn[N]; readonly Btn bgBtn, resetBtn, replayBtn, introBtn;
    readonly float[] hv = new float[N]; int hot = -1;
    const int N = 4; static readonly int[] Target = { 10, 1, 12, 15 };
    static readonly string[] Titles = { "Cacenoh", "Hold Click", "Disk Cleaner", "Humanizer" };
    static readonly string[] Desc =
    {
        "Five casino games played with CenohCoins, which are pretend money: Rocket, Mines, Slots, Blackjack and Plinko. Use your own pictures or the built-in symbols.",
        "Hold down or auto-click a mouse button, or press two keys in turn, with a keybind. Opens as a small window that stays on top of your game.",
        "Free up space on your PC: junk and caches, old Windows updates, leftovers of uninstalled programs, old, big and duplicate files.",
        "Rewrites stiff, AI-sounding text so it reads like a person wrote it. Uses Claude with your own API key, or the offline rules."
    };
    static readonly string[][] Chips = { new[] { "pretend coins", "your own pictures" }, new[] { "always on top", "hold, click or two keys" }, new[] { "deep clean", "Recycle Bin first" }, new[] { "Claude or offline", "your own key" } };
    static readonly string[] Taglines = { "Pretend money, real fun.", "The house always wins.", "Everything in one place.", "Click less, play more.", "Free up some space." };
    const string WelcomeText = "Welcome to CENOHWARE.";
    static readonly Font FTitle = new Font("Segoe UI Semibold", 26f), FCard = new Font("Segoe UI Semibold", 15f);

    public HomePage(HubForm h)
    {
        hub = h;
        for (int i = 0; i < N; i++) { int ix = Target[i]; open[i] = new Btn(i == 0 && Target[0] == 1 ? "Open Hold Click" : "Open") { Width = i == 0 && Target[0] == 1 ? 150 : 110, Height = 32, Primary = true }; open[i].Click += delegate { hub.Go(ix); }; Controls.Add(open[i]); }
        bgBtn = new Btn("Change background…") { Width = 168, Height = 30, Font = Theme.Small }; bgBtn.Click += delegate { hub.ChooseBackground(); };
        resetBtn = new Btn("Reset") { Width = 70, Height = 30, Font = Theme.Small }; resetBtn.Click += delegate { Backdrop.Reset(); };
        replayBtn = new Btn("Replay intro") { Width = 110, Height = 30, Font = Theme.Small }; replayBtn.Click += delegate { hub.PlayIntro(); };
        introBtn = new Btn("") { Width = 150, Height = 30, Font = Theme.Small }; introBtn.Click += delegate { hub.IntroOn = !hub.IntroOn; UpdateIntroText(); };
        Controls.AddRange(new Control[] { bgBtn, resetBtn, replayBtn, introBtn }); UpdateIntroText();
        Resize += delegate { Place(); }; FeedRefresh(true);
    }
    static void FeedRefresh(bool first) {
    }
    void UpdateIntroText() { introBtn.Text = "Intro on start: " + (hub.IntroOn ? "on" : "off"); introBtn.Selected = hub.IntroOn; introBtn.Invalidate(); }
    Rectangle Card(int i) { int w = Math.Max(300, (Width - 88 - 24) / 2); return new Rectangle(44 + (i % 2) * (w + 24), 168 + (i / 2) * 214, w, 190); }
    void Place()
    {
        for (int i = 0; i < N; i++) { var c = Card(i); open[i].Location = new Point(c.X + 26, c.Bottom - 54); }
        int x = Width - 44; introBtn.Location = new Point(x - introBtn.Width, 40); replayBtn.Location = new Point(introBtn.Left - 8 - replayBtn.Width, 40);
        resetBtn.Location = new Point(x - resetBtn.Width, 80); bgBtn.Location = new Point(resetBtn.Left - 8 - bgBtn.Width, 80);
    }
    protected override void OnTick(float dt) { for (int i = 0; i < N; i++) hv[i] = Ticker.Ease(hv[i], hot == i ? 1f : 0f, 14f, dt); FeedRefresh(false); }
    protected override void OnMouseMove(MouseEventArgs e) { int h = -1; for (int i = 0; i < N; i++) if (Card(i).Contains(e.Location)) h = i; if (h != hot) { hot = h; Cursor = h >= 0 ? Cursors.Hand : Cursors.Default; } base.OnMouseMove(e); }
    protected override void OnMouseLeave(EventArgs e) { hot = -1; base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { for (int i = 0; i < N; i++) if (Card(i).Contains(e.Location)) { hub.Go(Target[i]); return; } base.OnMouseDown(e); }

    // each card (glass, icon, title, chips, text) is one cached picture per hover level; per frame it is only a copy
    void DrawCard(Graphics g, int i)
    {
        var c = Card(i); int q = (int)Math.Round(hv[i] * 12f); float k = q / 12f; int lift = (int)Math.Round(5 * hv[i]);
        var spr = Sprite("home" + i + "_" + q + "_" + c.Width, c.Width, c.Height, delegate (Graphics gg, Rectangle r)
        {
            Glass(gg, r, k);
            var disc = new Rectangle(r.X + 26, r.Y + 24, 50, 50);
            using (var b = new LinearGradientBrush(disc, Theme.Lerp(Theme.Accent, Color.White, 0.15f * k), Theme.Lerp(Theme.Accent, Theme.Bg, 0.45f), 60f)) gg.FillEllipse(b, disc);
            if (Theme.Aero) using (var path = new GraphicsPath()) { path.AddEllipse(disc); Theme.Gloss(gg, path, disc, 190, 30); }
            using (var p = new Pen(Color.FromArgb(70, 255, 255, 255))) gg.DrawEllipse(p, disc);
            NavList.Icon(gg, Target[i], new Rectangle(disc.X + 11, disc.Y + 11, 28, 28), Color.White);
            Str(gg, Titles[i], FCard, Theme.Text, new RectangleF(disc.Right + 16, r.Y + 22, r.Width - 110, 30), false);
            int cx = disc.Right + 16; foreach (string ch in Chips[i]) cx += ChipS(gg, cx, r.Y + 54, ch, Theme.AccentSoft, false);
            Str(gg, Desc[i], Theme.UI, Theme.Emph(Theme.Dim, 0.18f), new RectangleF(r.X + 26, r.Y + 88, r.Width - 52, 56), true);
        });
        Blit(g, spr, c.X - Pad, c.Y - Pad - lift);
    }
    void DrawFeed(Graphics g) { }
    protected override void DrawCards(Graphics g) { for (int i = 0; i < N; i++) DrawCard(g, i); DrawFeed(g); }
    protected override void DrawContent(Graphics g)
    {
        TextRenderer.DrawText(g, WelcomeText, FTitle, new Rectangle(44, 32, Width - 500, 52), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        float f = t % 6f, a = Math.Min(1f, Math.Min(f / 0.5f, (6f - f) / 0.5f)); int ti = (int)(t / 6f) % Taglines.Length;
        TextRenderer.DrawText(g, Taglines[ti], Theme.UIL, new Rectangle(46, 90, Width - 500, 28), Theme.Lerp(Theme.Bg, Theme.AccentSoft, Math.Max(0.05f, a)), TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "CENOHWARE  ·  made by Cenoh", Theme.SmallB, new Rectangle(46, Height - 30, Width - 80, 20), Theme.Aero ? Color.FromArgb(8, 56, 36) : Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
    }
}

class HoldPage : BackdropPage
{
    readonly HubForm hub; readonly Btn go, bgBtn, resetBtn; bool open; float openT;
    static readonly Font FTitle = new Font("Segoe UI Semibold", 26f), FOrb = new Font("Segoe UI Black", 17f);
    const string Blurb = "It opens as its own small window that stays on top of your game, so you can leave it up while you play. Your keybinds, speed and look are remembered. Close it with its own X, or it closes when you close CENOHWARE.";
    public HoldPage(HubForm h)
    {
        hub = h;
        go = new Btn("Open Hold Click") { Width = 230, Height = 48, Primary = true, Big = true };
        go.Click += delegate { HcApp.HoldClick.Launch(); };
        bgBtn = new Btn("Change background…") { Width = 168, Height = 30, Font = Theme.Small }; bgBtn.Click += delegate { hub.ChooseBackground(); };
        resetBtn = new Btn("Reset") { Width = 70, Height = 30, Font = Theme.Small }; resetBtn.Click += delegate { Backdrop.Reset(); };
        Controls.AddRange(new Control[] { go, bgBtn, resetBtn }); Resize += delegate { Place(); };
    }
    Rectangle CardRect { get { return new Rectangle(44, 150, Math.Max(380, Math.Min(Width - 88 - (Width > 1100 ? 380 : 0), 660)), 330); } }
    void Place() { var c = CardRect; go.Location = new Point(c.X + 28, c.Bottom - 108); int x = Width - 44; resetBtn.Location = new Point(x - resetBtn.Width, 40); bgBtn.Location = new Point(resetBtn.Left - 8 - bgBtn.Width, 40); }
    protected override void OnTick(float dt)
    {
        bool o = HcApp.HoldClick.IsOpen; openT = Ticker.Ease(openT, o ? 1f : 0f, 8f, dt);
        string txt = o ? "Bring it to the front" : "Open Hold Click"; if (go.Text != txt) { go.Text = txt; go.Invalidate(); } open = o;
    }
    protected override void DrawCards(Graphics g)
    {
        var c = CardRect;
        var spr = Sprite("hold_" + c.Width, c.Width, c.Height, delegate (Graphics gg, Rectangle r)
        {
            Glass(gg, r, 0.15f);
            int cx = r.X + 28; foreach (string ch in new[] { "hold", "auto-click", "any mouse button", "your own keybind", "remembers settings" }) { if (cx + 150 > r.Right - 20) break; cx += ChipS(gg, cx, r.Y + 26, ch, Theme.AccentSoft, true); }
            Str(gg, Blurb, Theme.UI, Theme.Emph(Theme.Dim, 0.2f), new RectangleF(r.X + 28, r.Y + 70, r.Width - 56, 110), true);
        });
        Blit(g, spr, c.X - Pad, c.Y - Pad);
    }
    protected override void DrawContent(Graphics g)
    {
        TextRenderer.DrawText(g, "Hold Click", FTitle, new Rectangle(44, 32, Width - 480, 52), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "Hold down or auto-click any mouse button with a keybind.", Theme.UIL, new Rectangle(46, 90, Width - 480, 28), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        var c = CardRect;
        var dot = new Rectangle(c.X + 30, c.Bottom - 42, 10, 10);
        if (open) using (var b = new SolidBrush(Color.FromArgb((int)(60 + 40 * Math.Sin(t * 4)), Theme.Green))) g.FillEllipse(b, Rectangle.Inflate(dot, 5, 5));
        using (var b = new SolidBrush(open ? Theme.Green : Theme.Border)) g.FillEllipse(b, dot);
        TextRenderer.DrawText(g, open ? "Hold Click is open" : "Hold Click is closed", Theme.UI, new Rectangle(dot.Right + 10, dot.Y - 6, 300, 22), open ? Theme.Green : Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        // the orb, like the one in the app
        if (Width > 1100)
        {
            float ox = c.Right + (Width - c.Right) / 2f, oy = c.Y + c.Height / 2f, r = 88f; g.SmoothingMode = SmoothingMode.AntiAlias;
            for (int k = 0; k < 3; k++) { float u = ((t * 0.5f) + k / 3f) % 1f, rr = r + 14 + u * 90; using (var p = new Pen(Color.FromArgb((int)(120 * (1f - u) * (0.4f + 0.6f * openT)), Theme.AccentSoft), 2f)) g.DrawEllipse(p, ox - rr, oy - rr, rr * 2, rr * 2); }
            var o = new RectangleF(ox - r, oy - r, r * 2, r * 2);
            using (var b = new LinearGradientBrush(o, Theme.Lerp(Theme.Accent, Color.White, 0.2f), Theme.Lerp(Theme.Accent, Theme.Bg, 0.65f), 90f)) g.FillEllipse(b, o);
            if (Theme.Aero) using (var path = new GraphicsPath()) { path.AddEllipse(o); Theme.Gloss(g, path, o, 190, 40); }                                  // glossy glass orb
            using (var p = new Pen(Color.FromArgb(160, 255, 255, 255), 2.5f)) g.DrawEllipse(p, o);
            TextRenderer.DrawText(g, open ? "HOLDING" : "IDLE", FOrb, Rectangle.Round(o), Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
    }
}

// the old page, frozen for a moment and fading away, so switching tools glides instead of snapping
// A cross-fade done by the compositor: a borderless click-through window holding a picture of the OLD look sits on top of the app, the app changes
// underneath, and the window's opacity is faded to nothing. DWM does the blending on the GPU, so there is no per-frame drawing at all and the app only
// has to take one picture (not two) before it can start changing.

class GhostForm : Form
{
    Bitmap bmp; float t, dur = 0.28f; bool hooked, running; System.Windows.Forms.Timer safety;
    public static int Ticks; public static float MaxDt;
    public GhostForm()
    {
        FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; StartPosition = FormStartPosition.Manual; BackColor = Color.Black; Opacity = 0.999;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.Opaque, true);
        safety = new System.Windows.Forms.Timer { Interval = 900 }; safety.Tick += delegate { safety.Stop(); if (!running) End(); };
    }
    protected override bool ShowWithoutActivation { get { return true; } }
    protected override CreateParams CreateParams { get { var cp = base.CreateParams; cp.ExStyle |= 0x08000000 | 0x80 | 0x80000; return cp; } }   // no-activate, tool window, layered
    protected override void WndProc(ref Message m) { if (m.Msg == 0x84) { m.Result = (IntPtr)(-1); return; } base.WndProc(ref m); }                         // clicks fall through to the app
    bool held; static readonly Point Parked = new Point(-32000, -32000);
    public bool Active { get { return held; } }
    // the window is created once and kept shown far off-screen, so holding a picture is only a move (showing a window each time cost ~17 ms)
    public void Park(Form owner) { Opacity = 0.999; Bounds = new Rectangle(Parked, owner.ClientSize); if (!Visible) Show(owner); Invalidate(); Update(); }
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
    public string Describe() { return "visible=" + Visible + " bounds=" + Bounds + " opacity=" + Opacity.ToString("0.00") + " owner=" + (Owner != null) + " handle=" + IsHandleCreated + " layered=" + ((GetWindowLong(Handle, -20) & 0x80000) != 0); }
    // show the old picture exactly over the app's client area; whatever changes underneath stays hidden until Begin
    public void Hold(Bitmap old, Rectangle screenBounds, Form owner)
    {
        if (bmp != null) bmp.Dispose(); bmp = old; running = false; t = 0; HubState.Transitioning = true; held = true; Opacity = 0.999;
        if (!Visible) { Bounds = new Rectangle(Parked, screenBounds.Size); Show(owner); }
        if (Size != screenBounds.Size) Size = screenBounds.Size; Invalidate(); Update();                                  // paint it while it is still off-screen
        Location = screenBounds.Location; safety.Stop(); safety.Start();
    }
    public void Begin(float seconds) { safety.Stop(); if (!held) return; dur = seconds; t = 0; running = true; Ticks = 0; MaxDt = 0; if (!hooked) { hooked = true; Ticker.Frame += OnFrame; } }
    public Action Ended;
    public void End() { safety.Stop(); running = false; HubState.Transitioning = false; held = false; if (Ended != null) Ended(); if (Visible) Location = Parked; if (bmp != null) { bmp.Dispose(); bmp = null; } if (hooked) { hooked = false; Ticker.Frame -= OnFrame; } }
    void OnFrame(float dt)
    {
        if (!running) return; Ticks++; if (dt > MaxDt) MaxDt = dt; t += Math.Min(dt, 0.025f) / dur;
        if (t >= 1f) { End(); return; }
        float k = t * t * (3f - 2f * t); Opacity = Math.Max(0.002, 0.999 * (1.0 - k));
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        if (bmp == null) return; var g = e.Graphics; g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy; g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor; g.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height);
    }
    protected override void Dispose(bool d) { if (d) { if (hooked) Ticker.Frame -= OnFrame; safety.Dispose(); if (bmp != null) bmp.Dispose(); } base.Dispose(d); }
}

class FadeOverlay : Control
{
    Bitmap bmp; float a; bool hooked;
    public FadeOverlay() { SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.Opaque, true); Visible = false; }
    public void Start(Bitmap b) { if (bmp != null) bmp.Dispose(); bmp = b; a = 1f; Visible = true; BringToFront(); if (!hooked) { hooked = true; Ticker.Frame += OnFrame; } Invalidate(); }
    void OnFrame(float dt)
    {
        a -= dt / 0.17f;
        if (a <= 0.02f) { Visible = false; if (bmp != null) { bmp.Dispose(); bmp = null; } Ticker.Frame -= OnFrame; hooked = false; return; }
        Invalidate();
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        if (bmp == null) return;
        var cm = new ColorMatrix { Matrix33 = Math.Max(0f, a) };
        using (var ia = new ImageAttributes()) { ia.SetColorMatrix(cm); e.Graphics.DrawImage(bmp, new Rectangle(0, 0, Width, Height), 0, 0, bmp.Width, bmp.Height, GraphicsUnit.Pixel, ia); }
    }
    protected override void Dispose(bool d) { if (d) { if (hooked) Ticker.Frame -= OnFrame; if (bmp != null) bmp.Dispose(); } base.Dispose(d); }
}

// the placeholder CENOHWARE logo: a neon "C" ring that can draw itself. Used by the intro and the icon; swap it for a real logo later.
static class Logo
{
    public static readonly Color Cyan = Color.FromArgb(56, 189, 248);
    // The C is an arc open to the right: it starts at the lower-right (40 degrees), runs clockwise round the left and ends at the upper-right (320).
    public static void DrawC(Graphics g, float cx, float cy, float r, float thick, float progress, float glow, float alpha, Color a, Color b)
    {
        if (progress <= 0.001f || alpha <= 0.001f) return;
        const float start = 40f, span = 280f; float sweep = span * Math.Min(1f, progress);
        var rect = new RectangleF(cx - r, cy - r, r * 2, r * 2);
        int segs = Math.Max(6, (int)(44 * Math.Min(1f, progress)));
        float step = sweep / segs;
        // soft halo, then the coloured stroke, then a white-hot core
        for (int pass = 0; pass < 3; pass++)
        {
            if (pass == 0)
            {
                float hw = thick * (2.2f + glow * 1.2f);
                for (int h = 2; h >= 0; h--) using (var p = new Pen(Color.FromArgb((int)(255 * alpha * (0.05f + 0.05f * glow) * (3 - h) / 3f), Theme.Lerp(a, b, 0.45f)), hw * (1f + h * 0.45f)) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(p, rect, start, sweep);
                continue;
            }
            float w = pass == 0 ? thick * (2.4f + glow * 1.2f) : pass == 1 ? thick : thick * 0.36f;
            int al = (int)(255 * alpha);
            for (int i = 0; i < segs; i++)
            {
                float u = (i + 0.5f) / (span / step);
                Color c = pass == 2 ? Color.FromArgb(al, Theme.Lerp(Theme.Lerp(a, b, u), Color.White, 0.75f)) : Color.FromArgb(al, Theme.Lerp(a, b, Math.Max(0f, Math.Min(1f, u))));
                using (var p = new Pen(c, w) { StartCap = pass == 0 ? LineCap.Round : LineCap.Flat, EndCap = pass == 0 ? LineCap.Round : LineCap.Flat })
                    g.DrawArc(p, rect, start + i * step - 0.4f, step + 0.8f);
            }
            double sa = start * Math.PI / 180.0; float sx0 = cx + r * (float)Math.Cos(sa), sy0 = cy + r * (float)Math.Sin(sa);   // round start cap
            using (var br = new SolidBrush(pass == 2 ? Color.FromArgb(al, Color.White) : Color.FromArgb(al, a))) g.FillEllipse(br, sx0 - w / 2f, sy0 - w / 2f, w, w);
        }
        // the glowing head while it is still being drawn
        if (progress < 0.999f)
        {
            double ang = (start + sweep) * Math.PI / 180.0; float hx = cx + r * (float)Math.Cos(ang), hy = cy + r * (float)Math.Sin(ang);
            using (var gp = new GraphicsPath()) { float hr = thick * 2.6f; gp.AddEllipse(hx - hr, hy - hr, hr * 2, hr * 2); using (var pg = new PathGradientBrush(gp) { CenterColor = Color.FromArgb((int)(190 * alpha), Color.White), SurroundColors = new[] { Color.FromArgb(0, Color.White) } }) g.FillPath(pg, gp); }
            using (var br = new SolidBrush(Color.FromArgb((int)(255 * alpha), Color.White))) g.FillEllipse(br, hx - thick * 0.5f, hy - thick * 0.5f, thick, thick);
        }
        else
        {
            // finished: a small node sits in the opening, like the hub in the icon
            using (var br = new SolidBrush(Color.FromArgb((int)(255 * alpha), Color.White))) g.FillEllipse(br, cx + r * 0.42f - thick * 0.42f, cy - thick * 0.42f, thick * 0.84f, thick * 0.84f);
            using (var p = new Pen(Color.FromArgb((int)(220 * alpha), b), thick * 0.2f)) g.DrawEllipse(p, cx + r * 0.42f - thick * 0.42f, cy - thick * 0.42f, thick * 0.84f, thick * 0.84f);
        }
    }
}

// the CENOHWARE intro over the whole hub window: a neon C draws itself, the wordmark lands letter by letter, the four tools
// pop in. Everything is placed from the window size, so it fits any window. Frames are paced to the monitor's refresh rate
// (DwmFlush), so it runs as smoothly as the screen allows (60, 144 Hz...).
class IntroForm : Form
{
    [DllImport("dwmapi.dll")] static extern int DwmFlush();
    readonly HubForm hub; float t, endT; bool ending, done, running; int pending; Thread pacer; long lastTicks; int frames; float worstDt; double paintMs;
    Bitmap bg; Size bgSize; int bgKey;
    // the word, cached per scale
    float wordScale = -1; readonly List<GraphicsPath> letters = new List<GraphicsPath>(); readonly List<float> letterX = new List<float>(); GraphicsPath wordPath; float wordW, wordH;
    const string Word = "CENOHWARE";
    static readonly float[] pa = new float[80], pr = new float[80], ps = new float[80], pph = new float[80], psp = new float[80];
    public const float Total = 3.7f, FadeOut = 0.55f;

    static IntroForm()
    {
        var r = new Random(9);
        for (int i = 0; i < pa.Length; i++) { pa[i] = (float)(r.NextDouble() * Math.PI * 2); pr[i] = 0.18f + (float)Math.Pow(r.NextDouble(), 0.7) * 0.9f; ps[i] = 0.9f + (float)r.NextDouble() * 2.1f; pph[i] = (float)r.NextDouble() * 6.28f; psp[i] = 0.25f + (float)r.NextDouble() * 0.5f; }
    }
    public IntroForm(HubForm h)
    {
        hub = h; FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; StartPosition = FormStartPosition.Manual; KeyPreview = true; BackColor = Color.Black;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.Opaque, true);
        MouseDown += delegate { Skip(); }; KeyDown += delegate { Skip(); };
    }
    void Fit() { if (!done) Bounds = hub.RectangleToScreen(hub.ClientRectangle); }
    public void Begin()
    {
        Fit(); hub.LocationChanged += OnHubMoved; hub.SizeChanged += OnHubMoved;
        try { using (var wb = new Bitmap(Math.Max(64, ClientSize.Width), Math.Max(64, ClientSize.Height), PixelFormat.Format32bppPArgb)) { RenderTo(wb, 0.6f); RenderTo(wb, 3.1f); RenderTo(wb, 0f); } } catch { }     // builds every cache and warms the code, so the first real frame is as fast as the rest
        t = 0f; HubState.IntroPlaying = true; Show(hub); Activate();
        running = true; lastTicks = Stopwatch.GetTimestamp();
        pacer = new Thread(delegate ()
        {
            while (running)
            {
                try { DwmFlush(); } catch { Thread.Sleep(8); }
                if (Interlocked.Exchange(ref pending, 1) == 0) { try { BeginInvoke(new Action(Frame)); } catch { running = false; } }
            }
        }) { IsBackground = true, Name = "intro-pacer" };
        pacer.Start();
    }
    void OnHubMoved(object s, EventArgs e) { Fit(); }
    void Skip() { if (!ending) { ending = true; t = Math.Max(t, Total - 0.2f); } }
    static float Sm(float v) { v = v < 0f ? 0f : v > 1f ? 1f : v; return v * v * (3f - 2f * v); }
    static float C01(float v) { return v < 0f ? 0f : v > 1f ? 1f : v; }
    static float OutBack(float x) { x = C01(x); const float c1 = 1.70158f, c3 = c1 + 1f; float u = x - 1f; return 1f + c3 * u * u * u + c1 * u * u; }
    static float OutCubic(float x) { x = C01(x); float u = 1f - x; return 1f - u * u * u; }
    static float Lerp(float a, float b, float k) { return a + (b - a) * k; }

    void Frame()
    {
        Interlocked.Exchange(ref pending, 0);
        if (done) return;
        long now = Stopwatch.GetTimestamp(); float dt = (float)((now - lastTicks) / (double)Stopwatch.Frequency); lastTicks = now; if (dt > 0.1f) dt = 0.1f;
        t += dt; frames++; if (dt > worstDt) worstDt = dt;
        if (!ending && t >= Total) ending = true;
        if (ending) { endT += dt; Opacity = 1.0 - Sm(endT / FadeOut); if (endT >= FadeOut) { Finish(); return; } }
        long p0 = Stopwatch.GetTimestamp(); Invalidate(); Update(); paintMs += (Stopwatch.GetTimestamp() - p0) * 1000.0 / Stopwatch.Frequency;
    }
    void Finish()
    {
        if (done) return; done = true; running = false; HubState.IntroPlaying = false; hub.LocationChanged -= OnHubMoved; hub.SizeChanged -= OnHubMoved; Hide();
        if (Program.FpsOut != null) { try { File.WriteAllText(Program.FpsOut, "frames=" + frames + " seconds=" + (t + endT).ToString("0.00") + " avg_fps=" + (frames / Math.Max(0.01f, t)).ToString("0.0") + " prof_ms_per_frame[bg,fade+particles,rings,shock,C,word,shine+tagline,pills]=" + string.Join(",", Array.ConvertAll(prof, v => (v / Math.Max(1, frames)).ToString("0.00"))) + " avg_paint_ms=" + (paintMs / Math.Max(1, frames)).ToString("0.0") + " worst_frame_ms=" + (worstDt * 1000).ToString("0.0") + " size=" + ClientSize); } catch { } Environment.Exit(0); }
        hub.IntroFinished(); Close();
    }

    Bitmap cSprite, wordSprite; float spriteScale = -1; int spriteKey;
    void EnsureSprites(float s, Graphics g)
    {
        int key = Theme.Accent.ToArgb();
        if (cSprite != null && Math.Abs(spriteScale - s) < 0.001f && spriteKey == key) return;
        if (cSprite != null) cSprite.Dispose(); if (wordSprite != null) wordSprite.Dispose();
        spriteScale = s; spriteKey = key; Color A = Theme.Accent, B = Logo.Cyan;
        float cr = 96f * s, th = 21f * s; int cd = (int)Math.Ceiling((cr + th * 5f) * 2f);
        cSprite = new Bitmap(cd, cd, PixelFormat.Format32bppPArgb);
        using (var gg = Graphics.FromImage(cSprite)) { gg.SmoothingMode = SmoothingMode.AntiAlias; Logo.DrawC(gg, cd / 2f, cd / 2f, cr, th, 1f, 0.5f, 1f, A, B); }
        int pad = (int)(26 * s), ww = (int)Math.Ceiling(wordW) + pad * 2, wh = (int)Math.Ceiling(wordH * 1.15f) + pad * 2;
        wordSprite = new Bitmap(ww, wh, PixelFormat.Format32bppPArgb);
        using (var gg = Graphics.FromImage(wordSprite))
        {
            gg.SmoothingMode = SmoothingMode.AntiAlias; gg.TranslateTransform(pad, pad);
            foreach (var lp in letters)
            {
                for (int gl = 3; gl >= 1; gl--) using (var p = new Pen(Color.FromArgb(20, A), gl * 5f * s) { LineJoin = LineJoin.Round }) gg.DrawPath(p, lp);
                using (var p = new Pen(Theme.AccentSoft, 2.4f * s) { LineJoin = LineJoin.Round }) gg.DrawPath(p, lp);
                using (var br = new SolidBrush(Color.White)) gg.FillPath(br, lp);
            }
        }
    }
    static Bitmap grain;
    static void EnsureGrain()
    {
        if (grain != null) return;
        grain = new Bitmap(192, 192, PixelFormat.Format32bppArgb); var r = new Random(77);
        for (int y = 0; y < 192; y++) for (int x = 0; x < 192; x++) { int v = r.Next(2) == 0 ? 0 : 255; grain.SetPixel(x, y, Color.FromArgb(r.Next(0, 3), v, v, v)); }
    }
    void EnsureBg(int W, int H)
    {
        int key = Theme.Accent.ToArgb();
        if (bg != null && bgSize.Width == W && bgSize.Height == H && bgKey == key) return;
        if (bg != null) bg.Dispose();
        bgSize = new Size(W, H); bgKey = key; bg = new Bitmap(W, H, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(bg))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias; var rc = new Rectangle(0, 0, W, H);
            using (var b = new LinearGradientBrush(rc, Theme.Lerp(Color.FromArgb(8, 7, 18), Theme.Accent, 0.16f), Color.FromArgb(7, 6, 14), 62f)) g.FillRectangle(b, rc);
            using (var b = new SolidBrush(Color.FromArgb(16, Theme.AccentSoft))) for (int x = 24; x < W; x += 40) for (int y = 24; y < H; y += 40) g.FillEllipse(b, x - 1, y - 1, 2, 2);
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(-W * 0.2f, -H * 0.25f, W * 1.4f, H * 1.5f);
                using (var pg = new PathGradientBrush(path) { CenterColor = Color.FromArgb(0, 0, 0, 0), SurroundColors = new[] { Color.FromArgb(170, 0, 0, 0) } }) { pg.SetBlendTriangularShape(0.5f, 1f); g.FillRectangle(pg, rc); }
            }
            // the big soft glow behind the C, baked once (a live gradient this size is far too slow per frame)
            float s0 = Math.Max(0.45f, Math.Min(2.6f, Math.Min(W / 1500f, H / 900f))), gx = W / 2f, gy = H / 2f - 18f * s0, gr = 540f * s0;
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(gx - gr, gy - gr, gr * 2, gr * 2);
                using (var pg = new PathGradientBrush(path) { CenterColor = Color.FromArgb(120, Theme.Accent), SurroundColors = new[] { Color.FromArgb(0, Theme.Accent) } }) g.FillPath(pg, path);
            }
        }
        // dither: a little noise so the soft gradients do not band
        var data = bg.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadWrite, PixelFormat.Format32bppPArgb);
        try
        {
            int bytes = Math.Abs(data.Stride) * H; var px = new byte[bytes]; Marshal.Copy(data.Scan0, px, 0, bytes); var rn = new Random(31);
            for (int i = 0; i < bytes; i += 4) { int n = rn.Next(-2, 3); for (int c = 0; c < 3; c++) { int v = px[i + c] + n; px[i + c] = (byte)(v < 0 ? 0 : v > 255 ? 255 : v); } }
            Marshal.Copy(px, 0, data.Scan0, bytes);
        }
        finally { bg.UnlockBits(data); }
    }
    void EnsureWord(float s, Graphics g)
    {
        if (Math.Abs(wordScale - s) < 0.001f) return;
        wordScale = s; foreach (var p in letters) p.Dispose(); letters.Clear(); letterX.Clear(); if (wordPath != null) wordPath.Dispose(); wordPath = new GraphicsPath();
        float em = 70f * s; var ff = new FontFamily("Segoe UI Black"); var sf = StringFormat.GenericTypographic;
        for (int i = 0; i < Word.Length; i++)
        {
            float x = i == 0 ? 0f : g.MeasureString(Word.Substring(0, i), new Font(ff, em, FontStyle.Regular, GraphicsUnit.Pixel), PointF.Empty, sf).Width;
            var gp = new GraphicsPath(); gp.AddString(Word[i].ToString(), ff, 0, em, new PointF(x, 0), sf);
            letters.Add(gp); letterX.Add(x); wordPath.AddString(Word[i].ToString(), ff, 0, em, new PointF(x, 0), sf);
        }
        var bb = wordPath.GetBounds(); wordW = bb.Right; wordH = em * 1.0f;
    }

    public event Action FirstPainted; bool firstDone;
    protected override void OnPaint(PaintEventArgs e)
    {
        Render(e.Graphics, ClientSize.Width, ClientSize.Height);
        if (!firstDone) { firstDone = true; var fp = FirstPainted; if (fp != null) { try { BeginInvoke(new Action(delegate { try { DwmFlush(); } catch { } fp(); })); } catch { fp(); } } }       // the app may only appear once the intro is really on screen
    }

    /// <summary>Draws one frame at time `time` into a bitmap of any size (used by the check switch; nothing is shown on screen).</summary>
    public void RenderTo(Bitmap bmp, float time) { t = time; using (var g = Graphics.FromImage(bmp)) Render(g, bmp.Width, bmp.Height); }

    static readonly double[] prof = new double[10]; long pl;
    void Mark(int i) { long n = Stopwatch.GetTimestamp(); prof[i] += (n - pl) * 1000.0 / Stopwatch.Frequency; pl = n; }
    void Render(Graphics g, int W, int H)
    {
        pl = Stopwatch.GetTimestamp();
        if (W < 50 || H < 50) return;
        EnsureBg(W, H);
        g.CompositingMode = CompositingMode.SourceCopy; g.InterpolationMode = InterpolationMode.NearestNeighbor; g.PixelOffsetMode = PixelOffsetMode.Half;
        g.DrawImage(bg, new Rectangle(0, 0, W, H), 0, 0, W, H, GraphicsUnit.Pixel);
        g.CompositingMode = CompositingMode.SourceOver;
        g.SmoothingMode = SmoothingMode.AntiAlias; g.CompositingQuality = CompositingQuality.HighSpeed; g.InterpolationMode = InterpolationMode.HighQualityBilinear; g.PixelOffsetMode = PixelOffsetMode.Half; g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        float s = Math.Max(0.45f, Math.Min(2.6f, Math.Min(W / 1500f, H / 900f)));
        Color A = Theme.Accent, B = Logo.Cyan;
        EnsureWord(s, g);

        // the layout (every size is a multiple of s, so it scales as one piece)
        float blockH = 462f * s, top = (H - blockH) / 2f;
        float cFinalY = top + 112f * s, wordY = top + 256f * s, subY = top + 362f * s, pillY = top + 402f * s;
        float eMove = Sm((t - 1.5f) / 0.7f);
        float cx = W / 2f, cy = Lerp(H / 2f, cFinalY, eMove), cr = Lerp(118f, 96f, eMove) * s, thick = Lerp(26f, 21f, eMove) * s;
        float prog = Sm((t - 0.2f) / 1.15f);
        float pulse = Math.Max(0f, 1f - Math.Abs(t - 1.4f) / 0.35f);

        Mark(0);
        // fade up from black (the glow itself is part of the baked background)
        float dark = 1f - Sm(t / 0.9f);
        if (dark > 0.003f) using (var br = new SolidBrush(Color.FromArgb((int)(255 * dark), 7, 6, 14))) { var st0 = g.Save(); g.ResetTransform(); g.FillRectangle(br, 0, 0, W, H); g.Restore(st0); }
        Mark(1);
        // swirling particles, drawn in towards the C and then drifting
        float pin = Sm(t / 0.7f);
        for (int i = 0; i < pa.Length; i++)
        {
            float rad = pr[i] * 640f * s * (1f + 0.05f * (float)Math.Sin(t * 0.9f + pph[i])) * Lerp(1.5f, 1f, Sm(t / 1.6f)), ang = pa[i] + t * psp[i] / (0.4f + pr[i]);
            float x = cx + rad * (float)Math.Cos(ang), y = cy + rad * 0.62f * (float)Math.Sin(ang), tw = 0.3f + 0.7f * (float)Math.Abs(Math.Sin(t * 2f + pph[i]));
            Color pc = i % 3 == 0 ? B : i % 3 == 1 ? Theme.AccentSoft : Color.White;
            using (var br = new SolidBrush(Color.FromArgb((int)(200 * tw * pin), pc))) g.FillEllipse(br, x - ps[i] * s, y - ps[i] * s, ps[i] * 2 * s, ps[i] * 2 * s);
        }
        Mark(2);
        // two slowly turning dashed rings round the C
        float ring = Sm((t - 0.9f) / 0.8f);
        if (ring > 0.01f)
            for (int rr = 0; rr < 2; rr++)
            {
                float R = (rr == 0 ? 168f : 206f) * s * (1f + 0.02f * pulse), dir = rr == 0 ? 1f : -1f; var rc2 = new RectangleF(cx - R, cy - R, R * 2, R * 2);
                using (var p = new Pen(Color.FromArgb((int)((rr == 0 ? 110 : 70) * ring), rr == 0 ? A : B), 2f * s))
                    for (int d = 0; d < 14; d++) g.DrawArc(p, rc2, dir * t * (rr == 0 ? 22f : 14f) + d * (360f / 14), 14f);
            }
        // shockwaves when the C closes
        for (int w = 0; w < 3; w++)
        {
            float u = (t - 1.38f - w * 0.22f) / 1.5f; if (u <= 0f || u >= 1f) continue;
            float R = 110f * s + OutCubic(u) * Math.Max(W, H) * 0.7f;
            using (var p = new Pen(Color.FromArgb((int)(150 * (1f - u)), w % 2 == 0 ? A : B), 3f * s * (1f - u * 0.5f))) g.DrawEllipse(p, cx - R, cy - R, R * 2, R * 2);
        }
        Mark(3);
        // the C
        EnsureSprites(s, g);
        if (t >= 2.3f) g.DrawImage(cSprite, new Rectangle((int)Math.Round(cx - cSprite.Width / 2f), (int)Math.Round(cy - cSprite.Height / 2f), cSprite.Width, cSprite.Height), 0, 0, cSprite.Width, cSprite.Height, GraphicsUnit.Pixel);
        else { float cs = 1f + 0.05f * pulse; Logo.DrawC(g, cx, cy, cr * cs, thick, prog, Math.Max(pulse, Sm((t - 1.3f) / 0.6f) * 0.5f), Sm(t / 0.25f), A, B); }

        Mark(4);
        // the wordmark, letter by letter
        float wx = cx - wordW / 2f;
        bool wordDone = t >= 1.85f + (letters.Count - 1) * 0.055f + 0.5f;
        if (wordDone) g.DrawImage(wordSprite, new Rectangle((int)Math.Round(wx - 26f * s), (int)Math.Round(wordY - 26f * s), wordSprite.Width, wordSprite.Height), 0, 0, wordSprite.Width, wordSprite.Height, GraphicsUnit.Pixel);
        else for (int i = 0; i < letters.Count; i++)
        {
            float u = (t - 1.85f - i * 0.055f) / 0.5f; if (u <= 0f) continue;
            float al = Sm(u), dy = (1f - OutBack(u)) * 46f * s;
            var st = g.Save(); g.TranslateTransform(wx, wordY + dy);
            for (int gl = 3; gl >= 1; gl--) using (var p = new Pen(Color.FromArgb((int)(20 * al), A), gl * 5f * s) { LineJoin = LineJoin.Round }) g.DrawPath(p, letters[i]);
            using (var p = new Pen(Color.FromArgb((int)(255 * al), Theme.AccentSoft), 2.4f * s) { LineJoin = LineJoin.Round }) g.DrawPath(p, letters[i]);
            using (var br = new SolidBrush(Color.FromArgb((int)(255 * al), Color.White))) g.FillPath(br, letters[i]);
            g.Restore(st);
        }
        // a shine sweeping across the finished word
        float sh = (t - 2.7f) / 0.7f;
        if (sh > 0f && sh < 1f)
        {
            var st = g.Save(); g.TranslateTransform(wx, wordY); g.SetClip(wordPath);
            float bx = Lerp(-100f * s, wordW + 100f * s, Sm(sh)); var band = new RectangleF(bx - 46f * s, -10f * s, 92f * s, wordH + 20f * s);
            using (var lb = new LinearGradientBrush(band, Color.Transparent, Color.Transparent, 0f))
            {
                lb.InterpolationColors = new ColorBlend(3) { Colors = new[] { Color.FromArgb(0, B), Color.FromArgb(235, Color.White), Color.FromArgb(0, B) }, Positions = new[] { 0f, 0.5f, 1f } };
                g.FillRectangle(lb, band);
            }
            g.Restore(st);
        }
        Mark(5);
        // tagline
        float ta = Sm((t - 2.5f) / 0.5f);
        if (ta > 0.01f)
        {
            using (var f = new Font("Segoe UI Semibold", Math.Max(9f, 13f * s), GraphicsUnit.Point)) using (var br = new SolidBrush(Color.FromArgb((int)(230 * ta), Theme.Lerp(Theme.AccentSoft, Color.White, 0.35f)))) using (var sf = new StringFormat { Alignment = StringAlignment.Center })
                g.DrawString("ONE WINDOW   ·   ALL YOUR TOOLS   ·   BY CENOH", f, br, new RectangleF(0, subY, W, 40f * s), sf);
        }
        Mark(6);
        // the four tools pop in
        string[] names = NavList.Names; int cnt = Math.Min(4, names.Length - 1); float pw = 188f * s, ph = 50f * s, gap = 14f * s, rowW = cnt * pw + (cnt - 1) * gap, rx = cx - rowW / 2f;
        for (int i = 1; i <= cnt; i++)
        {
            float u = (t - 2.6f - (i - 1) * 0.12f) / 0.45f; if (u <= 0f) continue;
            float al = Sm(u), sc = 0.85f + 0.15f * OutBack(u); float px = rx + (i - 1) * (pw + gap), py = pillY + (1f - OutCubic(u)) * 22f * s;
            var pill = new RectangleF(px + pw * (1 - sc) / 2f, py + ph * (1 - sc) / 2f, pw * sc, ph * sc);
            using (var path = Theme.Round(Rectangle.Round(pill), (int)(16 * s)))
            {
                using (var br = new SolidBrush(Color.FromArgb((int)(170 * al), 16, 12, 34))) g.FillPath(br, path);
                using (var p = new Pen(Color.FromArgb((int)(190 * al), i % 2 == 0 ? B : A), 1.6f)) g.DrawPath(p, path);
            }
            NavList.Icon(g, NavList.Real[i], new Rectangle((int)(pill.X + 12 * s), (int)(pill.Y + (pill.Height - 26 * s) / 2f), (int)(26 * s), (int)(26 * s)), Color.FromArgb((int)(255 * al), 232, 224, 255));
            using (var f = new Font("Segoe UI Semibold", Math.Max(8f, 11f * s), GraphicsUnit.Point)) using (var br = new SolidBrush(Color.FromArgb((int)(255 * al), 240, 236, 255))) using (var sf = new StringFormat { LineAlignment = StringAlignment.Center })
                g.DrawString(names[i], f, br, new RectangleF(pill.X + 46f * s, pill.Y, pill.Width - 50f * s, pill.Height), sf);
        }
        Mark(7); g.ResetTransform();
        using (var f = new Font("Segoe UI", 9f)) using (var br = new SolidBrush(Color.FromArgb((int)(110 * Sm((t - 0.9f) / 0.6f)), 190, 180, 230))) using (var sf = new StringFormat { Alignment = StringAlignment.Center })
            g.DrawString("click or press any key to skip", f, br, new RectangleF(0, H - 34, W, 24), sf);
    }
    protected override void Dispose(bool d) { if (d) { running = false; if (cSprite != null) cSprite.Dispose(); if (wordSprite != null) wordSprite.Dispose(); if (bg != null) bg.Dispose(); foreach (var p in letters) p.Dispose(); if (wordPath != null) wordPath.Dispose(); } base.Dispose(d); }
}

// holds an embedded tool: painted into one off-screen picture and put on screen in one go, so a page never shows up in pieces (the dark box)
class Composited : Panel
{
    public Composited() { SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true); }
    protected override CreateParams CreateParams { get { var cp = base.CreateParams; cp.ExStyle |= 0x02000000; return cp; } }       // WS_EX_COMPOSITED
}

class Surface : Panel
{
    public Surface() { SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true); }
}

class HubForm : Form
{
    [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr hwnd, IntPtr hdc, uint flags);
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int v, int size);
    [DllImport("user32.dll", CharSet = CharSet.Auto)] static extern uint PrivateExtractIcons(string file, int index, int cx, int cy, IntPtr[] icons, int[] ids, uint n, uint flags);

    public static readonly string SettingsDirPublic = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CENOHWARE");
    static readonly string SettingsDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CENOHWARE");
    static readonly string SettingsFile = Path.Combine(SettingsDir, "settings.txt");

    Panel rail, content; BrandPanel brand; NavList nav; Btn themeBtn; ThemePopup popup; PopupCloser closer; System.Windows.Forms.Timer clock; FadeOverlay fade;
    const int PageCount = 16, MatchIdx = 8, RoadIdx = 9, GateIdx = 99, CasinoIdx = 10, ShotIdx = 11, DiskIdx = 12, McIdx = 13, BugIdx = 14, HzIdx = 15;
    readonly Control[] pages = new Control[PageCount]; readonly string[] pageAccent = new string[PageCount]; int cur = -1, startPage; string seenAccent; string snapshotPath;
    public bool IntroOn = true; IntroForm intro; bool introDone;

    public HubForm(string snapshot, int page)
    {
        snapshotPath = snapshot;
        Text = "CENOHWARE"; ForeColor = Theme.Text; Font = Theme.UI; DoubleBuffered = true;
        var wa = Screen.PrimaryScreen.WorkingArea;
        ClientSize = Program.W > 0 && Program.H > 0 ? new Size(Program.W, Program.H) : new Size(Math.Min(1500, wa.Width - 40), Math.Min(900, wa.Height - 70)); MinimumSize = new Size(Math.Min(1340, wa.Width - 20), Math.Min(760, wa.Height - 40));
        if (Program.Testing) { StartPosition = FormStartPosition.Manual; Location = new Point(-32000, -32000); ShowInTaskbar = false; }   // check runs open out of sight and never take the focus
        else StartPosition = FormStartPosition.CenterScreen;
        LoadIcon(); LoadSettings();
        if (Program.ThemeHex != null) { Color c; if (Theme.TryHex(Program.ThemeHex, out c)) Theme.Apply(c); }
        if (page >= 0) startPage = page;
        if (NavList.RowOf(startPage) < 0) startPage = 0;
        Backdrop.Load(Program.Testing ? Program.BgPath : null);
        BackColor = Theme.Bg; seenAccent = Theme.Hex(Theme.Accent);
        Build();
        bool playIntro = IntroOn && (!Program.Testing || Program.Intro);
        if (playIntro) Opacity = 0;                              // invisible until the intro covers it, so the app never flashes before the intro
        Shown += delegate { Go(startPage);
            if (playIntro) { var fb = new System.Windows.Forms.Timer { Interval = 2500 }; fb.Tick += delegate { fb.Stop(); fb.Dispose(); Opacity = 1; }; fb.Start(); try { intro = new IntroForm(this); intro.FirstPainted += delegate { Opacity = 1; }; intro.Begin(); } catch { Opacity = 1; intro = null; } } else { introDone = true; StartPrewarm(); PostStart(); } if (snapshotPath != null) Snapshot(snapshotPath); if (Program.PageFpsOut != null) MeasurePage(); if (Program.SwitchOut != null) SwitchTest(); if (Program.FadeTestOut != null) FadeTest(); if (Program.TreeOut != null) { var w2 = new System.Windows.Forms.Timer { Interval = 3500 }; w2.Tick += delegate { w2.Stop(); Go(2); Pump(800); var sb = new StringBuilder(); DumpTree(content, 0, sb); File.WriteAllText(Program.TreeOut, sb.ToString()); Environment.Exit(0); }; w2.Start(); } if (Program.BoxOut != null) { var w1 = new System.Windows.Forms.Timer { Interval = 5000 }; w1.Tick += delegate { w1.Stop(); BoxHunt(); }; w1.Start(); } if (Program.InnerOut != null) { var w0 = new System.Windows.Forms.Timer { Interval = 2500 }; w0.Tick += delegate { w0.Stop(); InnerTabTest(); }; w0.Start(); } };
        FormClosing += OnClosing;
        clock = new System.Windows.Forms.Timer { Interval = 250 };
        clock.Tick += delegate { CheckAccent(); };
        clock.Start();
    }

    void LoadIcon()
    {
        try { var h = new IntPtr[1]; var id = new int[1]; if (PrivateExtractIcons(Application.ExecutablePath, 0, 48, 48, h, id, 1, 0) > 0 && h[0] != IntPtr.Zero) Icon = Icon.FromHandle(h[0]); } catch { }
    }
    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        SetTitleBar();
    }
    void SetTitleBar() { try { int dark = Theme.Light ? 0 : 1; if (DwmSetWindowAttribute(Handle, 20, ref dark, 4) != 0) DwmSetWindowAttribute(Handle, 19, ref dark, 4); } catch { } }
    void LoadSettings()
    {
        try
        {
            if (File.Exists(SettingsFile))
                foreach (string line in File.ReadAllLines(SettingsFile))
                {
                    int i = line.IndexOf('='); if (i < 0) continue;
                    string k = line.Substring(0, i).Trim(), v = line.Substring(i + 1).Trim(); int n;
                    if (k == "accent") { Color c; if (Theme.TryHex(v, out c)) Theme.Apply(c); }
                    else if (k == "page" && int.TryParse(v, out n) && n >= 0 && n < PageCount) startPage = n;
                    else if (k == "intro") IntroOn = v != "0";
                    else if (k == "order") { var want = new List<int>(); foreach (string part in v.Split(',')) { int pg; if (int.TryParse(part, out pg)) want.Add(pg); } NavList.SetOrder(want.ToArray()); }
                }
        }
        catch { }
    }
    void SaveSettings()
    {
        if (Program.Testing) return;
        try { Directory.CreateDirectory(SettingsDir); File.WriteAllText(SettingsFile, "accent=" + Theme.Hex(Theme.Accent) + "\r\npage=" + Math.Max(0, cur) + "\r\nintro=" + (IntroOn ? 1 : 0) + "\r\norder=" + string.Join(",", Array.ConvertAll(NavList.Real, x => x.ToString())) + "\r\n"); } catch { }
    }

    void Build()
    {
        rail = new Panel { Dock = DockStyle.Left, Width = 232, BackColor = Theme.Panel };
        brand = new BrandPanel { Dock = DockStyle.Top, Height = 112 };
        nav = new NavList { Dock = DockStyle.Fill };
        nav.Picked += delegate (int i) { Go(i); };
        Application.AddMessageFilter(new NavWheelFilter(nav));
        var foot = new Panel { Dock = DockStyle.Bottom, Height = 106, BackColor = Theme.Panel };
        var editBtn = new Btn("Edit tab order") { Width = 196, Height = 30, Font = Theme.Small, Location = new Point(18, 12) };
        editBtn.Click += delegate { nav.SetEditing(!nav.Editing); editBtn.Text = nav.Editing ? "Done  (drag the tabs)" : "Edit tab order"; editBtn.Selected = nav.Editing; editBtn.Invalidate(); };
        foot.Controls.Add(editBtn);
        nav.Reordered += delegate { SaveSettings(); };
        themeBtn = new Btn("Theme") { Width = 196, Height = 34, Font = Theme.Small, Location = new Point(18, 56) };
        themeBtn.Click += delegate { ToggleTheme(); };
        foot.Controls.Add(themeBtn);
        rail.Controls.Add(nav); rail.Controls.Add(foot); rail.Controls.Add(brand);
        content = new Surface { Dock = DockStyle.Fill, BackColor = Theme.Bg };
        fade = new FadeOverlay { Dock = DockStyle.Fill };
        Controls.Add(content); Controls.Add(rail); content.BringToFront();
        content.Controls.Add(fade);
        trans = new GhostForm(); trans.Ended = delegate { tracking = false; }; Theme.BeforeApply += OnBeforeTheme;      // its window exists (hidden) before the first click
        popup = new ThemePopup();
        popup.Picked += delegate (Color c) { Theme.Apply(c); popup.Visible = false; };
        popup.CustomClicked += delegate { popup.Visible = false; { Color pc; if (ColorPicker.Show(this, Theme.Accent, out pc)) Theme.Apply(pc); } };
        Controls.Add(popup); popup.BringToFront();
        closer = new PopupCloser { Popup = popup, KeepOpenOn = new Control[] { themeBtn } };
        Application.AddMessageFilter(closer);
    }

    public void ChooseBackground() { string err = Backdrop.Choose(this); if (err.Length > 0) MessageBox.Show(this, err, "CENOHWARE"); }
    public void PlayIntro() { if (intro != null) return; try { intro = new IntroForm(this); intro.Begin(); } catch { intro = null; } }
    public void IntroFinished() { intro = null; introDone = true; Activate(); StartPrewarm(); PostStart(); }

    // once the intro is over, quietly build the pages nobody has opened yet (one every so often), so the first click on each is instant
    System.Windows.Forms.Timer prewarm;
    protected override bool ShowWithoutActivation { get { return Program.Testing; } }
    // the Minecraft tab connects by itself and keeps its schedules and join alerts going when they are switched on, even before you open it
    void McAuto() { try { if (!McPage.Wants()) return; if (pages[McIdx] == null) { pages[McIdx] = MakePage(McIdx); pageAccent[McIdx] = Theme.Hex(Theme.Accent); pages[McIdx].Visible = false; var bp = pages[McIdx] as BackdropPage; if (bp != null) bp.Bounds = content.ClientRectangle; if (cur >= 0 && pages[cur] != null) pages[cur].BringToFront(); popup.BringToFront(); } var mc = pages[McIdx] as McPage; if (mc != null) mc.AutoStart(); } catch { } }
    // the background services (key sounds, screenshot hotkey, Minecraft keep-alive) start one by one after the window is up and the intro is over,
    // so none of their set-up work lands as a hitch in the opening
    bool postStarted;
    void PostStart()
    {
        if (postStarted || Program.Testing) return; postStarted = true;
        var steps = new Action[] { delegate { KeyBang.Init(); }, McAuto }; int n = 0;
        var tm = new System.Windows.Forms.Timer { Interval = 400 };
        tm.Tick += delegate { if (n < steps.Length) { try { steps[n++](); } catch { } } if (n >= steps.Length) { tm.Stop(); tm.Dispose(); } };
        tm.Start();
    }
    [StructLayout(LayoutKind.Sequential)] struct LASTINPUTINFO { public uint cbSize, dwTime; }
    [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO p);
    static int IdleMs() { var li = new LASTINPUTINFO { cbSize = 8 }; if (!GetLastInputInfo(ref li)) return 9999; return (int)((uint)Environment.TickCount - li.dwTime); }
    void ParkGhost() { try { if (trans != null && !trans.Visible) trans.Park(this); } catch { } }
    void StartPrewarm()
    {
        BeginInvoke(new Action(ParkGhost));
        if ((Program.Testing && Program.SwitchOut == null && Program.BoxOut == null) || prewarm != null) return;
        int[] order = { 10, 1, 12 }; int next = 0;
        prewarm = new System.Windows.Forms.Timer { Interval = 1800 };
        prewarm.Tick += delegate
        {
            prewarm.Interval = 600;
            if (!Program.Testing && IdleMs() < 400) return;        // the mouse or keyboard was just used: wait for a quiet moment
            while (next < order.Length && pages[order[next]] != null) next++;
            if (next >= order.Length) { prewarm.Stop(); return; }
            if (HubState.IntroPlaying) return;
            int i = order[next++];
            try { pages[i] = MakePage(i); pageAccent[i] = Theme.Hex(Theme.Accent); pages[i].Visible = false; var bp = pages[i] as BackdropPage; if (bp != null) { bp.Bounds = content.ClientRectangle; bp.Warm(); } var hp = (embedded[i] ?? pages[i]) as IHubPage; if (hp != null) hp.HubPrewarm(); var cur0 = cur >= 0 ? pages[cur] : null; if (cur0 != null) cur0.BringToFront(); popup.BringToFront(); }
            catch { }
        };
        prewarm.Start();
    }
    public bool InIntro { get { return intro != null; } }

    // ---- cross-fades: the window is photographed before and after a change, and the two are blended ----
    GhostForm trans; bool tracking;
    [DllImport("user32.dll")] static extern IntPtr GetWindowDC(IntPtr hwnd);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hwnd, IntPtr dc);
    [DllImport("gdi32.dll")] static extern bool BitBlt(IntPtr dst, int x, int y, int w, int h, IntPtr src, int sx, int sy, int rop);
    // the old look is what is on screen right now: copy it straight from the window surface (a few ms) instead of asking every control to paint again (PrintWindow, ~25 ms)
    Bitmap CaptureFast()
    {
        var b = new Bitmap(Math.Max(1, ClientSize.Width), Math.Max(1, ClientSize.Height), PixelFormat.Format32bppRgb);
        var origin = RectangleToScreen(ClientRectangle).Location; var wr = Bounds; int ox = origin.X - wr.X, oy = origin.Y - wr.Y;
        IntPtr wdc = GetWindowDC(Handle);
        try { using (var g = Graphics.FromImage(b)) { IntPtr dc = g.GetHdc(); try { BitBlt(dc, 0, 0, b.Width, b.Height, wdc, ox, oy, 0x00CC0020); } finally { g.ReleaseHdc(dc); } } }
        finally { ReleaseDC(Handle, wdc); }
        return b;
    }
    Bitmap Capture()
    {
        var b = new Bitmap(Math.Max(1, ClientSize.Width), Math.Max(1, ClientSize.Height), PixelFormat.Format32bppRgb);
        using (var g = Graphics.FromImage(b)) { IntPtr hdc = g.GetHdc(); try { PrintWindow(Handle, hdc, 3); } finally { g.ReleaseHdc(hdc); } }
        return b;
    }
    bool CanFade { get { return IsHandleCreated && Visible && WindowState != FormWindowState.Minimized && intro == null && (!Program.Testing || Program.FadeTestOut != null) && !InIntro && trans != null; } }
    void CheckAccent() { string a = Theme.Hex(Theme.Accent); if (a != seenAccent) { seenAccent = a; Recolor(); SaveSettings(); } }
    void OnBeforeTheme(Color c)
    {
        if (!trans.Active) tracking = false;                    // a fade that ended or was cut short must never block the next one
        if (!CanFade || trans.Active || tracking || Theme.Hex(c) == seenAccent) return;
        try { tApply = Stopwatch.GetTimestamp(); var old = CaptureFast(); tracking = true; trans.Hold(old, RectangleToScreen(ClientRectangle), this); BeginInvoke(new Action(CheckAccent)); } catch { tracking = false; }       // start the fade as soon as the caller has finished changing things, not at the next 250 ms poll
    }
    public static double LastLag; public static string LastParts = ""; long tApply;
    void FinishThemeFade()
    {
        if (!tracking) return; tracking = false;
        try { long q = Stopwatch.GetTimestamp(); Update(); long q1 = Stopwatch.GetTimestamp(); long q2 = q1; trans.Begin(0.28f); LastLag = (Stopwatch.GetTimestamp() - tApply) * 1000.0 / Stopwatch.Frequency; LastParts = "recolor+paint " + ((q1 - q) * 1000.0 / Stopwatch.Frequency).ToString("0") + " ms, capture " + ((q2 - q1) * 1000.0 / Stopwatch.Frequency).ToString("0") + " ms"; } catch { trans.End(); }
    }
    void FadeThrough(Action change, float seconds)
    {
        if (!CanFade || trans.Active) { change(); return; }
        long t0 = Stopwatch.GetTimestamp(); Func<double> ms = delegate { long n = Stopwatch.GetTimestamp(); double r = (n - t0) * 1000.0 / Stopwatch.Frequency; t0 = n; return r; };
        Bitmap old = null; try { old = CaptureFast(); } catch { }
        if (old == null) { change(); return; }
        double a = ms(); trans.Hold(old, RectangleToScreen(ClientRectangle), this); double b = ms();
        change(); double c = ms(); Update(); double d = ms();
        try { trans.Begin(seconds); } catch { trans.End(); }
        PageParts = "capture " + a.ToString("0") + ", show ghost " + b.ToString("0") + ", switch page " + c.ToString("0") + ", paint " + d.ToString("0");
    }
    public static string PageParts = "";
    void ToggleTheme()
    {
        if (popup.Visible) { popup.Visible = false; return; }
        var p = PointToClient(themeBtn.PointToScreen(new Point(0, -popup.Height - 8)));
        popup.Location = new Point(Math.Max(10, p.X), Math.Max(10, p.Y)); popup.BringToFront(); popup.Visible = true; popup.Invalidate();
    }

    // the accent changed (here or inside a tool): repaint the hub and the page in front; the other pages catch up when opened
    void Recolor()
    {
        try { Recolor2(); } catch (Exception ex) { try { File.AppendAllText(Path.Combine(SettingsDir, "error.log"), DateTime.Now + " Recolor: " + ex + Environment.NewLine); } catch { } }
        FinishThemeFade();
    }
    void Recolor2()
    {
        BackColor = Theme.Bg; rail.BackColor = Theme.Panel; content.BackColor = Theme.Bg; foreach (Control c in rail.Controls) c.BackColor = Theme.Panel; SetTitleBar();
        rail.Invalidate(true);
        if (cur >= 0) CatchUp(cur);
        Invalidate(true);
    }
    void CatchUp(int i)
    {
        string hex = Theme.Hex(Theme.Accent);
        if (pageAccent[i] == hex) return;
        pageAccent[i] = hex;
        var p = (embedded[i] ?? pages[i]) as IHubPage; if (p != null) p.HubTheme(); else if (pages[i] != null) pages[i].Invalidate(true);
    }

    // ---- pages ----
    readonly Form[] embedded = new Form[PageCount];
    Control Embed(Form f, int slot)
    {
        var wrap = new Composited { Dock = DockStyle.Fill, BackColor = Theme.Bg, Bounds = content.ClientRectangle, Visible = false };
        content.Controls.Add(wrap);
        f.TopLevel = false; f.FormBorderStyle = FormBorderStyle.None; f.MinimumSize = Size.Empty; f.ShowInTaskbar = false;
        f.Bounds = wrap.ClientRectangle;               // right size BEFORE it is shown, so no part of it ever paints at its default size in a corner
        f.Dock = DockStyle.Fill; wrap.Controls.Add(f); wrap.Visible = true; wrap.PerformLayout(); f.Show(); f.PerformLayout();
        embedded[slot] = f; return wrap;
    }
    Control MakePage(int i)
    {
        string hex = Theme.Hex(Theme.Accent); bool t = Program.Testing;
        switch (i)
        {
            case 0: { var p = new HomePage(this) { Dock = DockStyle.Fill }; content.Controls.Add(p); return p; }
            case 1: { var p = new HoldPage(this) { Dock = DockStyle.Fill }; content.Controls.Add(p); return p; }
            case 10: { var p = new CasinoPage(this) { Dock = DockStyle.Fill }; content.Controls.Add(p); return p; }
            case 11: { var p = new ShotgunKeysPage(this) { Dock = DockStyle.Fill }; content.Controls.Add(p); return p; }
            case 12: { var p = new DiskPage(this) { Dock = DockStyle.Fill }; content.Controls.Add(p); return p; }
            case 13: { var p = new McPage(this) { Dock = DockStyle.Fill }; content.Controls.Add(p); return p; }
            case 15: { var p = new HumanizerPage(this) { Dock = DockStyle.Fill }; content.Controls.Add(p); return p; }
            default: return null;
        }
    }
    public void Go(int i)
    {
        if (!Program.Testing && introDone) KeyBang.Init();
        if (i < 0 || i >= PageCount || i == cur) return;
        if (cur >= 0 && CanFade && !trans.Active) { FadeThrough(delegate { GoNow(i); }, 0.18f); return; }
        GoNow(i);
    }
    void GoNow(int i)
    {
        if (cur >= 0 && pages[cur] != null) { pages[cur].Visible = false; var old = (embedded[cur] ?? pages[cur]) as IHubPage; if (old != null) old.HubHidden(); }
        if (pages[i] == null) { pages[i] = MakePage(i); pageAccent[i] = Theme.Hex(Theme.Accent); }
        cur = i; nav.Select(Math.Max(0, NavList.RowOf(i)), cur >= 0);
        pages[i].Visible = true; pages[i].BringToFront(); pages[i].PerformLayout();
        CatchUp(i);
        var np = (embedded[i] ?? pages[i]) as IHubPage; if (np != null) np.HubShown();
        popup.BringToFront();
        Text = "CENOHWARE · " + NavList.Names[Math.Max(0, NavList.RowOf(i))]; SaveSettings();
    }

    void OnClosing(object s, FormClosingEventArgs e)
    {
        if (intro != null) { try { intro.Close(); } catch { } intro = null; }
        // Hold Click saves its settings and lets go of its hotkeys in its own closing step: let it finish first
        if (HcApp.HoldClick.IsOpen)
        {
            e.Cancel = true; var hc = HcApp.HoldClick.Current;
            hc.FormClosed += delegate { try { BeginInvoke(new Action(delegate { Close(); })); } catch { } };
            hc.Close(); return;
        }
        KeyBang.Shutdown();
        for (int i = 2; i <= 4; i++)
        {
            var f = embedded[i]; if (f == null) continue;
            f.Close();
            if (!f.IsDisposed) { e.Cancel = true; return; }       // a tool asked to keep going (for example a release is being made)
        }
        SaveSettings();
    }

    // check switch: go through the pages the way a person does, timing each switch until the UI is idle and photographing it a moment later
    void SwitchTest()
    {
        int[] order = { 2, 0, 3, 4, 2, 1, 0, 4, 3, 2 }; int idx = 0; var log = new StringBuilder(); var start = new System.Windows.Forms.Timer { Interval = 4500 };
        start.Tick += delegate
        {
            start.Stop();
            var step = new System.Windows.Forms.Timer { Interval = 700 };
            step.Tick += delegate
            {
                if (idx >= order.Length) { step.Stop(); File.WriteAllText(Program.SwitchOut, log.ToString()); Environment.Exit(0); return; }
                int target = order[idx++]; var sw = Stopwatch.StartNew(); bool first = pages[target] == null;
                EventHandler idle = null; idle = delegate { Application.Idle -= idle; log.AppendLine("switch -> " + NavList.Names[Math.Max(0, NavList.RowOf(target))] + (first ? " (first open)" : "") + ": " + sw.ElapsedMilliseconds + " ms until idle"); };
                Application.Idle += idle; Go(target); long goMs = sw.ElapsedMilliseconds; log.AppendLine("   Go() itself took " + goMs + " ms");
                var shot = new System.Windows.Forms.Timer { Interval = 25 }; int n = idx;
                shot.Tick += delegate { shot.Stop(); try { using (var b = new Bitmap(Width, Height)) using (var g = Graphics.FromImage(b)) { g.CopyFromScreen(Location, Point.Empty, b.Size); b.Save(Program.SwitchOut + "_" + n + ".png", ImageFormat.Png); } } catch { } };
                shot.Start();
            };
            step.Start();
        };
        start.Start();
    }
    // check switch: try the situations where a dark box might flash (just opened, maximised, restored, recoloured) and flag any frame whose header differs from the settled picture
    Bitmap Grab() { var b = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb); using (var g = Graphics.FromImage(b)) g.CopyFromScreen(Location, Point.Empty, b.Size); return b; }
    static int Diff(Bitmap a, Bitmap b)
    {
        int n = 0, w = Math.Min(a.Width, b.Width), h = Math.Min(a.Height, b.Height);
        for (int y = 36; y < Math.Min(h, 230); y += 2) for (int x = 244; x < Math.Min(w, 1100); x += 2) { Color p = a.GetPixel(x, y), q = b.GetPixel(x, y); if (Math.Abs(p.R - q.R) + Math.Abs(p.G - q.G) + Math.Abs(p.B - q.B) > 150) n++; }
        return n * 4;
    }
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }
    static string Native(Control c)
    {
        if (!c.IsHandleCreated) return "nohandle"; RECT r; GetWindowRect(c.Handle, out r);
        var tl = c.Parent != null ? c.Parent.PointToClient(new Point(r.L, r.T)) : new Point(r.L, r.T);
        return "native=" + tl.X + "," + tl.Y + " " + (r.R - r.L) + "x" + (r.B - r.T) + (IsWindowVisible(c.Handle) ? " NATIVE-VISIBLE" : "");
    }
    static void DumpTree(Control c, int depth, StringBuilder sb)
    {
        sb.AppendLine(new string(' ', depth * 2) + c.GetType().Name + " vis=" + c.Visible + " bounds=" + c.Bounds + " dock=" + c.Dock + " back=" + c.BackColor.Name + " " + Native(c));
        if (depth < 4) foreach (Control k in c.Controls) DumpTree(k, depth + 1, sb);
    }
    // check switch: change theme and switch pages like a person and report what the cross-fades cost
    void FadeTest()
    {
        var t0 = new System.Windows.Forms.Timer { Interval = 1500 };
        t0.Tick += delegate
        {
            t0.Stop(); var sb = new StringBuilder(); Action<string, Action> step = delegate (string name, Action a)
            {
                GhostForm.Ticks = 0; GhostForm.MaxDt = 0; BackdropPage.CacheMs = 0; BackdropPage.PartA = BackdropPage.PartB = 0; var sw = Stopwatch.StartNew(); a(); double call = sw.Elapsed.TotalMilliseconds; string gd = trans.Describe(); sw.Restart(); Pump(120); gd += " | later: " + trans.Describe(); if (name.StartsWith("theme -> Aero") && !File.Exists(Program.FadeTestOut + ".ghost.png")) { try { using (var gb = new Bitmap(trans.Width, trans.Height)) { using (var gg = Graphics.FromImage(gb)) { IntPtr gdc = gg.GetHdc(); try { PrintWindow(trans.Handle, gdc, 2); } finally { gg.ReleaseHdc(gdc); } } gb.Save(Program.FadeTestOut + ".ghost.png", ImageFormat.Png); } } catch (Exception ex) { gd += " ghostshot failed " + ex.Message; } } sw.Restart(); while (sw.ElapsedMilliseconds < 700) { Application.DoEvents(); Thread.Sleep(1); }
                sb.AppendLine("   ghost: " + gd.Substring(0, Math.Min(gd.Length, 0)) + " page parts: " + PageParts); sb.AppendLine(name + " [click to fade start " + HubForm.LastLag.ToString("0") + " ms: " + HubForm.LastParts + "]: call took " + call.ToString("0") + " ms; backdrop cache builds " + BackdropPage.CacheMs.ToString("0") + " ms (drawing " + BackdropPage.PartA.ToString("0") + ", noise " + BackdropPage.PartB.ToString("0") + "); fade ticker frames " + GhostForm.Ticks + ", longest frame " + (GhostForm.MaxDt * 1000).ToString("0") + " ms");
            };
            step("theme -> Aero", delegate { Theme.Apply(Theme.AeroKey); });
            step("theme -> Dragon Ball", delegate { Theme.Apply(Theme.DbzKey); });
            step("theme -> Janemba", delegate { Theme.Apply(Theme.JnbKey); });
            step("theme -> Aero again (cached)", delegate { Theme.Apply(Theme.AeroKey); });
            step("theme -> Dragon Ball again (cached)", delegate { Theme.Apply(Theme.DbzKey); });
            step("theme -> orange preset", delegate { Theme.Apply(Theme.PresetColors[3]); });
            step("theme -> Aero 3rd (maybe evicted)", delegate { Theme.Apply(Theme.AeroKey); });
            step("page -> Test Picker", delegate { Go(2); });
            step("page -> Home", delegate { Go(0); });
            step("theme -> Aero (end state)", delegate { Theme.Apply(Theme.AeroKey); }); using (var cb = Capture()) cb.Save(Program.FadeTestOut + ".png", ImageFormat.Png);
            File.WriteAllText(Program.FadeTestOut, sb.ToString()); Environment.Exit(0);
        };
        t0.Start();
    }
    void Pump(int ms) { var sw = Stopwatch.StartNew(); while (sw.ElapsedMilliseconds < ms) { Application.DoEvents(); Thread.Sleep(1); } }
    void BoxHunt()
    {
        var log = new StringBuilder(); int flagged = 0;
        Action<string, Action> scenario = delegate (string name, Action prep)
        {
            Go(0); Pump(300); if (prep != null) { prep(); Pump(500); }
            Go(2); Pump(900); var reference = Grab();           // settled picture of the page
            Go(0); Pump(300); if (prep != null) { prep(); Pump(300); }
            var frames = new List<Bitmap>(); var sw = Stopwatch.StartNew(); Go(2);
            while (sw.ElapsedMilliseconds < 160) { frames.Add(Grab()); Application.DoEvents(); }
            int worst = 0, wi = -1; for (int i = 1; i < frames.Count; i++) { int d = Diff(frames[i], reference); if (d > worst) { worst = d; wi = i; } }
            log.AppendLine(name + ": " + frames.Count + " frames, worst header difference " + worst + " px" + (wi >= 0 ? " (frame " + wi + ")" : ""));
            if (worst > 6000) { flagged++; frames[wi].Save(Program.BoxOut + "_" + name.Replace(' ', '_') + ".png", ImageFormat.Png); }
            foreach (var f in frames) f.Dispose(); reference.Dispose();
        };
        scenario("plain", null);
        scenario("after resize smaller", delegate { WindowState = FormWindowState.Normal; Size = new Size(Width - 120, Height - 60); });
        scenario("after maximise", delegate { WindowState = FormWindowState.Maximized; });
        scenario("after restore", delegate { WindowState = FormWindowState.Normal; });
        scenario("after recolour", delegate { Theme.Apply(Color.FromArgb(249, 115, 22)); });
        scenario("after recolour 2", delegate { Theme.Apply(Color.FromArgb(52, 211, 153)); });
        scenario("after minimise and back", delegate { WindowState = FormWindowState.Minimized; Pump(300); WindowState = FormWindowState.Normal; });
        log.AppendLine(flagged == 0 ? "no box seen" : flagged + " scenario(s) flagged");
        File.WriteAllText(Program.BoxOut, log.ToString()); Environment.Exit(0);
    }
    // check switch: click through the Test Picker's own tabs and views and photograph each change a few ms later (looking for flashes)
    void InnerTabTest()
    {
        Go(2); var tp = embedded[2]; var t = tp.GetType(); var bf = System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance;
        var seq = new[] { "t1", "t2", "t0", "m1", "m2", "m0", "t1", "t0" }; int idx = 0; var log = new StringBuilder();
        var st = new System.Windows.Forms.Timer { Interval = 900 };
        st.Tick += delegate
        {
            if (idx >= seq.Length) { st.Stop(); File.WriteAllText(Program.InnerOut, log.ToString()); Environment.Exit(0); return; }
            string a = seq[idx++]; var sw = Stopwatch.StartNew();
            t.GetMethod(a[0] == 't' ? "SwitchTab" : "SetMode", bf).Invoke(tp, new object[] { a[1] - '0' });
            log.AppendLine(a + ": call returned after " + sw.ElapsedMilliseconds + " ms"); int n = idx;
            foreach (int delay in new[] { 1, 12, 40 }) { int d = delay; var sh = new System.Windows.Forms.Timer { Interval = d }; sh.Tick += delegate { sh.Stop(); try { using (var b = new Bitmap(Width, Height)) using (var g = Graphics.FromImage(b)) { g.CopyFromScreen(Location, Point.Empty, b.Size); b.Save(Program.InnerOut + "_" + n + "_" + d + ".png", ImageFormat.Png); } } catch { } }; sh.Start(); }
        };
        st.Start();
    }
    // check switch: sit on the current page for a few seconds and report how many frames it painted and what each cost
    void MeasurePage()
    {
        var t0 = new System.Windows.Forms.Timer { Interval = 1500 };
        t0.Tick += delegate
        {
            t0.Stop(); BackdropPage.PaintedFrames = 0; BackdropPage.PaintMs = 0; BackdropPage.BDs = new double[3]; var sw = Stopwatch.StartNew();
            var t1 = new System.Windows.Forms.Timer { Interval = 4000 };
            t1.Tick += delegate { t1.Stop(); double s = sw.Elapsed.TotalSeconds; File.WriteAllText(Program.PageFpsOut, "parts[backdrop,cards,content]=" + (BackdropPage.BDs[0] / Math.Max(1, BackdropPage.PaintedFrames)).ToString("0.00") + "," + (BackdropPage.BDs[1] / Math.Max(1, BackdropPage.PaintedFrames)).ToString("0.00") + "," + (BackdropPage.BDs[2] / Math.Max(1, BackdropPage.PaintedFrames)).ToString("0.00") + " page=" + cur + " frames=" + BackdropPage.PaintedFrames + " fps=" + (BackdropPage.PaintedFrames / s).ToString("0.0") + " avg_paint_ms=" + (BackdropPage.PaintMs / Math.Max(1, BackdropPage.PaintedFrames)).ToString("0.00") + " size=" + ClientSize); Environment.Exit(0); };
            t1.Start();
        };
        t0.Start();
    }
    void Snapshot(string path)
    {
        var t = new System.Windows.Forms.Timer { Interval = Program.Delay };
        t.Tick += delegate
        {
            t.Stop();
            if (Program.NavScroll) { nav.WheelBy(-3000); Pump(1500); }
            if (Program.NavEdit) { nav.SetEditing(true); NavList.SetOrder(new[] { 10, 5, 0 }); nav.Select(Math.Max(0, NavList.RowOf(cur)), false); Pump(500); File.WriteAllText(path + ".nav.txt", "editing=" + nav.Editing + " order=" + string.Join(",", Array.ConvertAll(NavList.Real, x => x.ToString()))); }
            if (Program.CasinoTest >= 0) { var cp = pages[CasinoIdx] as CasinoPage; if (cp != null) { Pump(2500); File.WriteAllText(path + ".casino.txt", cp.TestShow(Program.CasinoTest)); Pump(900); } }
            if (Program.Popup) { ToggleTheme(); Application.DoEvents(); Thread.Sleep(400); Application.DoEvents(); }
            try { var pg = pages[cur] as BackdropPage; if (pg != null) { var fi = typeof(BackdropPage).GetField("cache", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance); var cb = (Bitmap)fi.GetValue(pg); if (cb != null) cb.Save(path + ".cache.png", ImageFormat.Png); } } catch { }
            try { var tsb = new StringBuilder(); DumpTree(content, 0, tsb); File.WriteAllText(path + ".tree.txt", tsb.ToString()); } catch { }
            try { File.WriteAllText(path + ".info.txt", "client " + ClientSize + "\r\npage " + cur + "\r\ntitle " + Text + "\r\nintro " + (intro != null)); } catch { }
            try
            {
                Application.DoEvents(); Thread.Sleep(200);
                if (intro == null)
                {
                    using (var b = new Bitmap(Width, Height)) { using (var g = Graphics.FromImage(b)) { IntPtr hdc = g.GetHdc(); try { PrintWindow(Handle, hdc, 2); } finally { g.ReleaseHdc(hdc); } } b.Save(path, ImageFormat.Png); }
                }
                else using (var b = new Bitmap(Width, Height)) using (var g = Graphics.FromImage(b)) { g.CopyFromScreen(Location, Point.Empty, b.Size); b.Save(path, ImageFormat.Png); }
            }
            catch (Exception ex) { File.WriteAllText(path + ".err.txt", ex.ToString()); }
            Environment.Exit(0);
        };
        t.Start();
    }
}

static class HubProgram
{
    [STAThread]
    static void Main(string[] args)
    {
        string snap = null, introOut = null; int page = -1;
        for (int i = 0; i < args.Length - 1; i++)
        {
            if (args[i] == "--snapshot") snap = args[i + 1];
            else if (args[i] == "--page") int.TryParse(args[i + 1], out page);
            else if (args[i] == "--theme") Program.ThemeHex = args[i + 1];
            else if (args[i] == "--bg") Program.BgPath = args[i + 1];
            else if (args[i] == "--delay") int.TryParse(args[i + 1], out Program.Delay);
            else if (args[i] == "--size") { var p = args[i + 1].Split('x'); if (p.Length == 2) { int.TryParse(p[0], out Program.W); int.TryParse(p[1], out Program.H); } }
            else if (args[i] == "--introframes") introOut = args[i + 1];
            else if (args[i] == "--introfps") Program.FpsOut = args[i + 1];
            else if (args[i] == "--picker") { ColorPicker.TestShot(args[i + 1]); Environment.Exit(0); }
            else if (args[i] == "--fadetest") Program.FadeTestOut = args[i + 1];
            else if (args[i] == "--clip") { var cp = args[i + 1].Split('|'); Program.ClipArgs = cp; }
            else if (args[i] == "--fbscroll") { var fp = args[i + 1].Split(','); Program.FbScroll = new[] { float.Parse(fp[0]), fp.Length > 1 ? float.Parse(fp[1]) : 0f }; }
            else if (args[i] == "--matchtest") Program.MatchTest = true;
            else if (args[i] == "--roadtest") Program.RoadTest = true;
            else if (args[i] == "--gatefake") Program.FakeGate = args[i + 1];
            else if (args[i] == "--gatetest") Program.GateTest = args[i + 1];
            else if (args[i] == "--casino") Program.CasinoTest = int.Parse(args[i + 1]);
            else if (args[i] == "--editnav") Program.NavEdit = true;
            else if (args[i] == "--keytest") Program.KeyTest = true;
            else if (args[i] == "--navscroll") Program.NavScroll = true;
            else if (args[i] == "--disk") Program.DiskTest = int.Parse(args[i + 1]);
            else if (args[i] == "--mc") Program.McView = int.Parse(args[i + 1]);
            else if (args[i] == "--bug") Program.BugTest = true;
            else if (args[i] == "--mview") Program.ModelView = int.Parse(args[i + 1]);
            else if (args[i] == "--mzoom") Program.ModelZoom = float.Parse(args[i + 1], System.Globalization.CultureInfo.InvariantCulture);
            else if (args[i] == "--pagefps") Program.PageFpsOut = args[i + 1];
            else if (args[i] == "--switchtest") Program.SwitchOut = args[i + 1];
            else if (args[i] == "--innertabs") Program.InnerOut = args[i + 1];
            else if (args[i] == "--boxhunt") Program.BoxOut = args[i + 1];
            else if (args[i] == "--dumptree") Program.TreeOut = args[i + 1];
            else if (args[i] == "--zopen") { var zp = args[i + 1].Split(':'); Program.ZOpen = zp[0]; if (zp.Length > 1) float.TryParse(zp[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out Program.ZZoom); }
            else if (args[i] == "--zscript") Program.ZScript = args[i + 1];
            else if (args[i] == "--tptab") int.TryParse(args[i + 1], out Program.TpTab);
        }
        Program.Popup = Array.IndexOf(args, "--popup") >= 0; Program.LaunchHold = Array.IndexOf(args, "--hold") >= 0; Program.Intro = Array.IndexOf(args, "--intro") >= 0;
        Program.Testing = snap != null || introOut != null || Program.FpsOut != null || Program.PageFpsOut != null || Program.FadeTestOut != null || Program.SwitchOut != null || Program.InnerOut != null || Program.BoxOut != null || Program.TreeOut != null; if (Program.FpsOut != null) Program.Intro = true;
        Application.EnableVisualStyles();
        if (introOut != null)
        {
            int w = Program.W > 0 ? Program.W : 1500, h = Program.H > 0 ? Program.H : 900;
            try
            {
            using (var f = new IntroForm(null)) foreach (float tt in new[] { 0.5f, 1.0f, 1.45f, 1.9f, 2.4f, 3.1f })
                using (var b = new Bitmap(w, h, PixelFormat.Format32bppPArgb)) { f.RenderTo(b, tt); b.Save(introOut + "_" + tt.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".png", ImageFormat.Png); }
            }
            catch (Exception ex) { File.WriteAllText(introOut + ".err.txt", ex.ToString()); }
            return;
        }
        if (!Program.Testing) { try { Directory.CreateDirectory(HubForm.SettingsDirPublic); System.Runtime.ProfileOptimization.SetProfileRoot(HubForm.SettingsDirPublic); System.Runtime.ProfileOptimization.StartProfile("hub.jit"); } catch { } }
        Application.Run(new HubForm(snap, page));
    }
}

// the hub's own switches (the tools' own Program classes live inside their namespaces)
static class Program { public static bool Testing, Popup, LaunchHold, Intro; public static bool MatchTest, RoadTest; public static string FakeGate, GateTest; public static int CasinoTest = -1; public static bool NavEdit, KeyTest, NavScroll; public static int DiskTest = -1; public static int McView = -1; public static bool BugTest; public static int ModelView = -1; public static float ModelZoom; public static string[] ClipArgs; public static float[] FbScroll; public static string FadeTestOut, ThemeHex, BgPath, FpsOut, PageFpsOut, SwitchOut, InnerOut, BoxOut, TreeOut, ZOpen, ZScript; public static float ZZoom = 1f; public static int Delay = 5000, W, H, TpTab = -1; }
