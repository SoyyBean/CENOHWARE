// Disk Cleaner: free up drive space without guessing. Eight views:
//   Overview   every drive, how full it is, and what has been freed so far
//   Junk       temp files, caches and the Recycle Bin (known throw-away places only; you tick what to clear)
//   Deep clean the system places that need administrator rights: old Windows updates (DISM), update downloads, Delivery
//              Optimization, logs, Windows.old, the hibernation file, old restore points. One permission prompt runs them all.
//   Leftovers  unused files: old installers in Downloads, and AppData/ProgramData folders that no installed program owns
//              and nothing has touched in 6 months (to the Recycle Bin)
//   Old files  files nobody has opened or changed in 6 / 12 / 24 months, in a folder you pick, biggest first
//   Big files  the biggest files in a folder
//   Duplicates identical files (same size, then same content), so you can keep one
//   Folders    what is taking the space inside a folder, drill down with a double click
// Safety: nothing is touched until you press the action button and confirm. Old, big and duplicate files go to the Recycle Bin
// (so you can get them back); only the Junk view deletes for good, and only inside its fixed throw-away folders. Files that are
// online-only in OneDrive are skipped (they take no space on this PC), and system folders are never walked.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

class DcRow
{
    public string Path = "", Name = "", Dir = "", Tag = "", Note = "", Key = ""; public long Size; public DateTime Used; public bool Check, Header, IsDir; public int Group; public float Frac;
}

// the scans (no UI in here, so they can be run and checked by themselves)
static class DcScan
{
    public static readonly string[] SkipDirs = { "$RECYCLE.BIN", "System Volume Information", ".git", "node_modules", "$WINDOWS.~BT", "WindowsApps" };
    const FileAttributes Placeholder = (FileAttributes)(0x1000 | 0x400000 | 0x40000);       // offline, recall on data access, recall on open: online-only OneDrive files
    public static string Fmt(long b)
    {
        double v = b; string[] u = { "B", "KB", "MB", "GB", "TB" }; int i = 0; while (v >= 1024 && i < u.Length - 1) { v /= 1024; i++; }
        return i == 0 ? b + " B" : v.ToString(v >= 100 ? "0" : "0.0", CultureInfo.InvariantCulture) + " " + u[i];
    }
    public static string AgeText(DateTime used)
    {
        double days = (DateTime.Now - used).TotalDays; if (days < 60) return (int)days + " days";
        int months = (int)(days / 30.44); if (months < 24) return months + " months"; return (months / 12).ToString(CultureInfo.InvariantCulture) + " years";
    }
    // every file under root, skipping links, system folders and the places Windows keeps for itself
    public static IEnumerable<FileInfo> Walk(string root, Func<bool> stop)
    {
        var stack = new Stack<DirectoryInfo>(); try { stack.Push(new DirectoryInfo(root)); } catch { yield break; }
        while (stack.Count > 0)
        {
            if (stop != null && stop()) yield break;
            var d = stack.Pop(); FileInfo[] files = null; DirectoryInfo[] subs = null;
            try { files = d.GetFiles(); } catch { }
            try { subs = d.GetDirectories(); } catch { }
            if (files != null) foreach (var f in files) yield return f;
            if (subs != null) foreach (var s in subs)
            {
                try { if ((s.Attributes & FileAttributes.ReparsePoint) != 0) continue; if ((s.Attributes & FileAttributes.System) != 0 && Array.IndexOf(SkipDirs, s.Name) >= 0) continue; } catch { continue; }
                if (Array.IndexOf(SkipDirs, s.Name) >= 0) continue; stack.Push(s);
            }
        }
    }
    public static bool OnlineOnly(FileInfo f) { try { return (f.Attributes & Placeholder) != 0; } catch { return true; } }
    public static DateTime LastUsed(FileInfo f) { DateTime a = f.LastAccessTime, w = f.LastWriteTime; return a > w ? a : w; }
    public static long Size(string dir, Func<bool> stop, out int count) { long t = 0; int n = 0; foreach (var f in Walk(dir, stop)) { try { t += f.Length; n++; } catch { } } count = n; return t; }

    public static List<DcRow> Old(string root, int months, long minBytes, Func<bool> stop, Action<int, long> progress)
    {
        var res = new List<DcRow>(); var cutoff = DateTime.Now.AddMonths(-months); int seen = 0; long total = 0;
        foreach (var f in Walk(root, stop))
        {
            try
            {
                if (f.Length < minBytes || OnlineOnly(f)) continue; var used = LastUsed(f); seen++;
                if (used < cutoff) { res.Add(new DcRow { Path = f.FullName, Name = f.Name, Dir = f.DirectoryName, Size = f.Length, Used = used, Tag = "not used in " + AgeText(used) }); total += f.Length; }
                if (progress != null && seen % 200 == 0) progress(res.Count, total);
            }
            catch { }
        }
        res.Sort((a, b) => b.Size.CompareTo(a.Size)); if (res.Count > 3000) res.RemoveRange(3000, res.Count - 3000); return res;
    }
    public static List<DcRow> Big(string root, int top, Func<bool> stop, Action<int, long> progress)
    {
        var all = new List<DcRow>(); int seen = 0; long total = 0; long floor = 0;
        foreach (var f in Walk(root, stop))
        {
            try
            {
                if (OnlineOnly(f)) continue; long len = f.Length; seen++; total += len;
                if (len > floor || all.Count < top * 2) { var used = LastUsed(f); all.Add(new DcRow { Path = f.FullName, Name = f.Name, Dir = f.DirectoryName, Size = len, Used = used, Tag = "last used " + AgeText(used) + " ago" }); if (all.Count > top * 4) { all.Sort((a, b) => b.Size.CompareTo(a.Size)); all.RemoveRange(top, all.Count - top); floor = all[all.Count - 1].Size; } }
                if (progress != null && seen % 300 == 0) progress(seen, total);
            }
            catch { }
        }
        all.Sort((a, b) => b.Size.CompareTo(a.Size)); if (all.Count > top) all.RemoveRange(top, all.Count - top); return all;
    }
    static string Hash(string path, long maxBytes)
    {
        using (var md5 = MD5.Create()) using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, 1 << 16))
        {
            var buf = new byte[1 << 20]; long left = maxBytes; int n;
            while (left > 0 && (n = fs.Read(buf, 0, (int)Math.Min(buf.Length, left))) > 0) { md5.TransformBlock(buf, 0, n, null, 0); left -= n; }
            md5.TransformFinalBlock(new byte[0], 0, 0); return BitConverter.ToString(md5.Hash);
        }
    }
    // identical files: same size, then the same first 64 KB, then the same whole content
    public static List<DcRow> Duplicates(string root, long minBytes, Func<bool> stop, Action<string> status)
    {
        var bySize = new Dictionary<long, List<FileInfo>>(); int seen = 0;
        foreach (var f in Walk(root, stop)) { try { if (f.Length < minBytes || OnlineOnly(f)) continue; List<FileInfo> l; if (!bySize.TryGetValue(f.Length, out l)) { l = new List<FileInfo>(); bySize[f.Length] = l; } l.Add(f); seen++; if (status != null && seen % 400 == 0) status("Looking through " + seen.ToString("N0", CultureInfo.InvariantCulture) + " files\u2026"); } catch { } }
        var groups = new List<List<FileInfo>>(); int checkedN = 0, cand = 0; foreach (var l in bySize.Values) if (l.Count > 1) cand += l.Count;
        foreach (var l in bySize.Values)
        {
            if (l.Count < 2) continue; if (stop != null && stop()) break;
            var quick = new Dictionary<string, List<FileInfo>>();
            foreach (var f in l) { try { string h = Hash(f.FullName, 65536); List<FileInfo> q; if (!quick.TryGetValue(h, out q)) { q = new List<FileInfo>(); quick[h] = q; } q.Add(f); } catch { } checkedN++; if (status != null && checkedN % 20 == 0) status("Comparing " + checkedN + " of " + cand + " files that look alike\u2026"); }
            foreach (var q in quick.Values)
            {
                if (q.Count < 2) continue; var full = new Dictionary<string, List<FileInfo>>();
                foreach (var f in q) { try { string h = Hash(f.FullName, long.MaxValue); List<FileInfo> g; if (!full.TryGetValue(h, out g)) { g = new List<FileInfo>(); full[h] = g; } g.Add(f); } catch { } }
                foreach (var g in full.Values) if (g.Count > 1) groups.Add(g);
            }
        }
        groups.Sort((a, b) => (b[0].Length * (b.Count - 1)).CompareTo(a[0].Length * (a.Count - 1)));
        var res = new List<DcRow>(); int gi = 0;
        foreach (var g in groups)
        {
            gi++; g.Sort((a, b) => LastUsed(a).CompareTo(LastUsed(b))); long each = g[0].Length;
            res.Add(new DcRow { Header = true, Group = gi, Name = g.Count + " identical copies of " + g[0].Name, Size = each * (g.Count - 1), Note = "frees " + Fmt(each * (g.Count - 1)) + " if you keep one" });
            for (int i = 0; i < g.Count; i++) res.Add(new DcRow { Group = gi, Path = g[i].FullName, Name = g[i].Name, Dir = g[i].DirectoryName, Size = each, Used = LastUsed(g[i]), Tag = i == g.Count - 1 ? "newest" : i == 0 ? "oldest" : "" });
        }
        return res;
    }
    // what is inside a folder: each subfolder's size (the loose files together as one row), biggest first
    public static List<DcRow> Folders(string root, Func<bool> stop)
    {
        var res = new List<DcRow>(); DirectoryInfo[] subs = null; FileInfo[] loose = null; var di = new DirectoryInfo(root);
        try { subs = di.GetDirectories(); } catch { } try { loose = di.GetFiles(); } catch { }
        var lock0 = new object();
        if (subs != null) Parallel.ForEach(subs, new ParallelOptions { MaxDegreeOfParallelism = 4 }, s =>
        {
            try { if ((s.Attributes & FileAttributes.ReparsePoint) != 0) return; } catch { return; }
            int n; long sz = Size(s.FullName, stop, out n); lock (lock0) res.Add(new DcRow { Path = s.FullName, Name = s.Name, Dir = root, Size = sz, IsDir = true, Tag = n.ToString("N0", CultureInfo.InvariantCulture) + " files" });
        });
        if (loose != null) { long t = 0; foreach (var f in loose) { try { if (!OnlineOnly(f)) t += f.Length; } catch { } } if (t > 0) res.Add(new DcRow { Name = "(files directly in this folder)", Dir = root, Size = t, Tag = loose.Length + " files" }); }
        res.Sort((a, b) => b.Size.CompareTo(a.Size)); long max = res.Count > 0 ? Math.Max(1, res[0].Size) : 1; foreach (var r in res) r.Frac = r.Size / (float)max; return res;
    }
}

class DiskPage : BackdropPage, IHubPage
{
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, Pack = 4)] struct SHQUERYRBINFO { public int cbSize; public long i64Size, i64NumItems; }
    [System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)] static extern int SHQueryRecycleBin(string root, ref SHQUERYRBINFO info);
    [System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)] static extern int SHEmptyRecycleBin(IntPtr h, string root, uint flags);

    static readonly Font FTitle = new Font("Segoe UI Semibold", 26f), FRow = new Font("Segoe UI Semibold", 10.5f), FBig = new Font("Segoe UI Semibold", 15f);
    static readonly string[] TabNames = { "Overview", "Junk", "Old files", "Big files", "Duplicates", "Folders", "Deep clean", "Leftovers" };
    static readonly int[] TabOrder = { 0, 1, 6, 7, 2, 3, 4, 5 };          // the order the tab buttons are shown in (the numbers are what the code uses)
    readonly HubForm hub; readonly Btn[] tabBtns = new Btn[8], rootBtns = new Btn[6], ageBtns = new Btn[3], sizeBtns = new Btn[3];
    readonly Btn scanBtn, selAllBtn, selNoneBtn, actBtn, showBtn, upBtn, keepBtn;
    int tab; string root; int ageMonths = 12; long minBytes = 1L << 20; List<DcRow> rows = new List<DcRow>(); readonly Dictionary<int, List<DcRow>> store = new Dictionary<int, List<DcRow>>();
    int first, selRow = -1, hotRow = -1; volatile bool busy; volatile string status = ""; volatile bool cancel; string note = "", folderStack = ""; long freedTotal; readonly List<string> stack = new List<string>();
    static string SaveFile { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CENOHWARE", "diskclean.txt"); } }
    static readonly string[] RootNames = { "Downloads", "Desktop", "Documents", "Videos", "Pictures", "Choose\u2026" };

    public DiskPage(HubForm h)
    {
        hub = h; root = Known(0); try { long v; if (long.TryParse(File.ReadAllText(SaveFile).Trim(), out v)) freedTotal = v; } catch { }
        for (int i = 0; i < 8; i++) { int k = i; tabBtns[i] = new Btn(TabNames[i]) { Height = 32, Width = 116, Font = Theme.UIB }; tabBtns[i].Click += delegate { SetTab(k); }; }
        for (int i = 0; i < 6; i++) { int k = i; rootBtns[i] = new Btn(RootNames[i]) { Height = 28, Width = i == 5 ? 100 : 96, Font = Theme.Small }; rootBtns[i].Click += delegate { PickRoot(k); }; }
        string[] ages = { "6 months", "1 year", "2 years" }; int[] am = { 6, 12, 24 }; for (int i = 0; i < 3; i++) { int k = i; ageBtns[i] = new Btn(ages[i]) { Height = 28, Width = 84, Font = Theme.Small }; ageBtns[i].Click += delegate { ageMonths = am[k]; SyncUi(); }; }
        string[] sizes = { "1 MB+", "10 MB+", "100 MB+" }; long[] sm = { 1L << 20, 10L << 20, 100L << 20 }; for (int i = 0; i < 3; i++) { int k = i; sizeBtns[i] = new Btn(sizes[i]) { Height = 28, Width = 84, Font = Theme.Small }; sizeBtns[i].Click += delegate { minBytes = sm[k]; SyncUi(); }; }
        scanBtn = new Btn("Scan") { Width = 110, Height = 32, Primary = true }; scanBtn.Click += delegate { if (busy) cancel = true; else StartScan(); };
        selAllBtn = new Btn("Select all") { Width = 100, Height = 30, Font = Theme.Small }; selAllBtn.Click += delegate { foreach (var r in rows) if (!r.Header && !r.IsDir) r.Check = true; Invalidate(); };
        selNoneBtn = new Btn("Select none") { Width = 100, Height = 30, Font = Theme.Small }; selNoneBtn.Click += delegate { foreach (var r in rows) r.Check = false; Invalidate(); };
        keepBtn = new Btn("Keep the newest") { Width = 140, Height = 30, Font = Theme.Small }; keepBtn.Click += delegate { KeepNewest(); };
        showBtn = new Btn("Show in Explorer") { Width = 140, Height = 30, Font = Theme.Small }; showBtn.Click += delegate { ShowSel(); };
        upBtn = new Btn("Up one folder") { Width = 120, Height = 28, Font = Theme.Small }; upBtn.Click += delegate { Up(); };
        actBtn = new Btn("") { Width = 230, Height = 36, Primary = true }; actBtn.Click += delegate { DoAction(); };
        var all = new List<Control>(); all.AddRange(tabBtns); all.AddRange(rootBtns); all.AddRange(ageBtns); all.AddRange(sizeBtns); all.AddRange(new Control[] { scanBtn, selAllBtn, selNoneBtn, keepBtn, showBtn, upBtn, actBtn });
        Controls.AddRange(all.ToArray()); Resize += delegate { Place(); }; Place(); SyncUi();
    }
    static string Known(int i)
    {
        string u = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        switch (i) { case 0: return Path.Combine(u, "Downloads"); case 1: return Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory); case 2: return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments); case 3: return Environment.GetFolderPath(Environment.SpecialFolder.MyVideos); default: return Environment.GetFolderPath(Environment.SpecialFolder.MyPictures); }
    }
    Rectangle Card { get { return new Rectangle(44, 170, Math.Max(600, Width - 88), Math.Max(400, Height - 170 - 24)); } }
    Rectangle ListRect { get { var c = Card; return new Rectangle(c.X + 18, c.Y + 104, c.Width - 36, Math.Max(100, c.Height - 104 - 74)); } }
    const int RowH = 46;
    int Visible { get { return Math.Max(1, ListRect.Height / RowH); } }
    void Place()
    {
        var c = Card; for (int i = 0; i < 8; i++) tabBtns[TabOrder[i]].Location = new Point(44 + i * 122, 124);
        int x = c.X + 18, y = c.Y + 16;
        for (int i = 0; i < 6; i++) { rootBtns[i].Location = new Point(x, y); x += rootBtns[i].Width + 6; }
        PlaceTools();
        scanBtn.Location = new Point(c.Right - 18 - scanBtn.Width, c.Y + 14); upBtn.Location = new Point(scanBtn.Left - 10 - upBtn.Width, c.Y + 16);
        int by = c.Bottom - 56; selAllBtn.Location = new Point(c.X + 18, by + 3); selNoneBtn.Location = new Point(selAllBtn.Right + 8, by + 3); keepBtn.Location = new Point(selNoneBtn.Right + 8, by + 3); showBtn.Location = new Point(keepBtn.Right + 8, by + 3);
        actBtn.Location = new Point(c.Right - 18 - actBtn.Width, by);
    }
    // the second toolbar row: how old, and how big (Old files has both, Duplicates only the size)
    int ToolsWidth { get { return tab == 2 ? 3 * 90 + 8 + 3 * 90 + 14 : tab == 4 ? 3 * 90 + 14 : 0; } }
    void PlaceTools()
    {
        var c = Card; int x = c.X + 18, y = c.Y + 48;
        if (tab == 2) { for (int i = 0; i < 3; i++) { ageBtns[i].Location = new Point(x, y); x += 90; } x += 8; }
        for (int i = 0; i < 3; i++) { sizeBtns[i].Location = new Point(x, y); x += 90; }
    }
    void SyncUi()
    {
        PlaceTools();
        for (int i = 0; i < 8; i++) { tabBtns[i].Selected = i == tab; tabBtns[i].Invalidate(); }
        bool pick = tab >= 2 && tab <= 5, old = tab == 2, size = tab == 2 || tab == 4;
        for (int i = 0; i < 6; i++) rootBtns[i].Visible = pick;
        for (int i = 0; i < 3; i++) { ageBtns[i].Visible = old; ageBtns[i].Selected = ageMonths == new[] { 6, 12, 24 }[i]; ageBtns[i].Invalidate(); sizeBtns[i].Visible = size; sizeBtns[i].Selected = minBytes == new[] { 1L << 20, 10L << 20, 100L << 20 }[i]; sizeBtns[i].Invalidate(); }
        scanBtn.Visible = tab != 0; scanBtn.Text = busy ? "Stop" : tab == 1 ? "Scan junk" : tab == 5 ? "Analyze" : tab == 7 ? "Find leftovers" : "Scan"; scanBtn.Invalidate();
        upBtn.Visible = tab == 5 && stack.Count > 0; bool lst = tab != 0 && tab != 5;
        selAllBtn.Visible = selNoneBtn.Visible = lst; keepBtn.Visible = tab == 4; showBtn.Visible = (tab >= 2 && tab <= 5) || tab == 7;
        actBtn.Visible = lst; actBtn.Text = tab == 1 || tab == 6 ? "Clean the ticked ones" : "Move ticked to Recycle Bin"; actBtn.Enabled = !busy && rows.Exists(r => r.Check);
        Invalidate();
    }
    void SetTab(int t)
    {
        if (busy) return; store[tab] = rows; tab = t; List<DcRow> r; rows = store.TryGetValue(t, out r) ? r : new List<DcRow>(); first = 0; selRow = -1; note = ""; if (t != 5) stack.Clear(); SyncUi();
        if ((t == 1 || t == 6 || t == 7) && rows.Count == 0) StartScan();
    }
    void PickRoot(int k)
    {
        if (busy) return;
        if (k == 5) { using (var d = new FolderBrowserDialog { Description = "Pick a folder to look through", SelectedPath = root }) { if (d.ShowDialog(FindForm()) != DialogResult.OK) return; root = d.SelectedPath; } }
        else root = Known(k);
        stack.Clear(); rows = new List<DcRow>(); store.Remove(tab); first = 0; note = ""; SyncUi(); StartScan();
    }
    void Up() { if (stack.Count == 0 || busy) return; root = stack[stack.Count - 1]; stack.RemoveAt(stack.Count - 1); StartScan(); }

    // ------------------------------------------------------------------ scanning (always on a worker thread)
    void StartScan()
    {
        if (busy) return; busy = true; cancel = false; status = "Starting\u2026"; note = ""; var t = tab; string r = root; int months = ageMonths; long min = minBytes; SyncUi();
        ThreadPool.QueueUserWorkItem(delegate
        {
            List<DcRow> res = null; string done = "";
            try
            {
                Func<bool> stop = delegate { return cancel; };
                if (t == 1) res = JunkScan(stop);
                else if (t == 6) { res = DeepScan(stop); done = "Tick what to clean. Windows asks for administrator permission once, then every ticked step runs."; }
                else if (t == 7) { res = LeftoverScan(stop); long tot = 0; int n = 0; foreach (var x in res) if (!x.Header) { tot += x.Size; n++; } done = n == 0 ? "No leftovers found." : n + " unused items, " + DcScan.Fmt(tot) + " in all. Check them over before ticking: they go to the Recycle Bin."; }
                else if (t == 2) { res = DcScan.Old(r, months, min, stop, (n, b) => status = "Found " + n.ToString("N0", CultureInfo.InvariantCulture) + " old files, " + DcScan.Fmt(b) + " so far\u2026"); long tot = 0; foreach (var x in res) tot += x.Size; done = res.Count.ToString("N0", CultureInfo.InvariantCulture) + " files not used in " + (months == 12 ? "a year" : months + " months") + ", " + DcScan.Fmt(tot) + " in all"; }
                else if (t == 3) { res = DcScan.Big(r, 150, stop, (n, b) => status = "Looked at " + n.ToString("N0", CultureInfo.InvariantCulture) + " files (" + DcScan.Fmt(b) + ")\u2026"); done = "the " + res.Count + " biggest files"; }
                else if (t == 4) { res = DcScan.Duplicates(r, min, stop, s => status = s); long tot = 0; int g = 0; foreach (var x in res) if (x.Header) { tot += x.Size; g++; } done = g + " sets of identical files, up to " + DcScan.Fmt(tot) + " to free"; }
                else if (t == 5) { status = "Measuring the folders\u2026"; res = DcScan.Folders(r, stop); long tot = 0; foreach (var x in res) tot += x.Size; done = DcScan.Fmt(tot) + " in " + r; }
            }
            catch (Exception ex) { done = "The scan stopped: " + ex.Message; }
            try { BeginInvoke(new Action(delegate { busy = false; if (res != null && tab == t) { rows = res; first = 0; selRow = -1; } else if (res != null) store[t] = res; if (cancel) done = "Stopped. " + done; note = done; var pa = pendingAfter; pendingAfter = null; if (pa != null) pa(); SyncUi(); })); } catch { }
        });
    }

    // junk: the fixed throw-away places. Each row is one place; Size is what is in it now.
    class JunkSpot { public string Key, Title, Note, Proc = ""; public string[] Dirs; public string Pattern = "*"; public bool Default, Admin, KeepFolders; }      // Proc: the program that must be closed first; KeepFolders: only the files go, the folder layout stays (browsers expect it)
    static bool Running(string proc) { if (proc.Length == 0) return false; try { var l = Process.GetProcessesByName(proc); bool any = l.Length > 0; foreach (var p in l) p.Dispose(); return any; } catch { return false; } }
    static List<JunkSpot> Spots()
    {
        string local = Environment.GetEnvironmentVariable("LOCALAPPDATA") ?? "", app = Environment.GetEnvironmentVariable("APPDATA") ?? "", win = Environment.GetEnvironmentVariable("WINDIR") ?? @"C:\Windows";
        var l = new List<JunkSpot>();
        l.Add(new JunkSpot { Key = "temp", Title = "Temporary files", Note = "Your temp folder: leftovers from installers and apps", Dirs = new[] { Path.GetTempPath() }, Default = true });
        l.Add(new JunkSpot { Key = "wintemp", Title = "Windows temp folder", Note = "Some files need administrator rights and are skipped", Dirs = new[] { Path.Combine(win, "Temp") }, Default = true, Admin = true });
        l.Add(new JunkSpot { Key = "thumbs", Title = "Thumbnail cache", Note = "Explorer rebuilds the picture previews when it needs them", Dirs = new[] { Path.Combine(local, @"Microsoft\Windows\Explorer") }, Pattern = "thumbcache_*.db", Default = true });
        l.Add(new JunkSpot { Key = "dumps", Title = "Crash dumps and error reports", Note = "Memory dumps and Windows error reports of crashed programs", Dirs = new[] { Path.Combine(local, "CrashDumps"), Path.Combine(local, @"Microsoft\Windows\WER") }, Default = true });
        l.Add(new JunkSpot { Key = "chrome", Proc = "chrome", KeepFolders = true, Title = "Chrome cache", Note = "Saved web page pieces (not your history, logins or bookmarks); close Chrome first", Dirs = new[] { Path.Combine(local, @"Google\Chrome\User Data\Default\Cache"), Path.Combine(local, @"Google\Chrome\User Data\Default\Code Cache"), Path.Combine(local, @"Google\Chrome\User Data\Default\GPUCache") }, Default = true });
        l.Add(new JunkSpot { Key = "edge", Proc = "msedge", KeepFolders = true, Title = "Edge cache", Note = "Saved web page pieces (not your history, logins or favorites); close Edge first", Dirs = new[] { Path.Combine(local, @"Microsoft\Edge\User Data\Default\Cache"), Path.Combine(local, @"Microsoft\Edge\User Data\Default\Code Cache"), Path.Combine(local, @"Microsoft\Edge\User Data\Default\GPUCache") }, Default = true });
        l.Add(new JunkSpot { Key = "inet", Title = "Internet cache", Note = "Old Internet Explorer / Windows web cache, used by some apps", Dirs = new[] { Path.Combine(local, @"Microsoft\Windows\INetCache") }, KeepFolders = true });
        l.Add(new JunkSpot { Key = "shader", KeepFolders = true, Title = "Graphics shader caches", Note = "DirectX, NVIDIA, AMD and Intel shader caches: games rebuild them, so the first match afterwards may stutter a little", Dirs = new[] { Path.Combine(local, "D3DSCache"), Path.Combine(local, @"NVIDIA\DXCache"), Path.Combine(local, @"NVIDIA\GLCache"), Path.Combine(local, @"AMD\DxCache"), Path.Combine(local, @"AMD\GLCache"), Path.Combine(local, @"Intel\ShaderCache") } });
        string steam = SteamDir(); if (steam.Length > 0) l.Add(new JunkSpot { Key = "steam", Proc = "steam", KeepFolders = true, Title = "Steam logs and web cache", Note = "Steam's logs, crash dumps and store page cache (not your games); close Steam first", Dirs = new[] { Path.Combine(steam, "logs"), Path.Combine(steam, "dumps"), Path.Combine(steam, @"appcache\httpcache") } });
        var epic = new List<string>(); string saved = Path.Combine(local, @"EpicGamesLauncher\Saved"); try { if (Directory.Exists(saved)) { epic.AddRange(Directory.GetDirectories(saved, "webcache*")); epic.Add(Path.Combine(saved, "Logs")); } } catch { }
        if (epic.Count > 0) l.Add(new JunkSpot { Key = "epic", Proc = "EpicGamesLauncher", KeepFolders = true, Title = "Epic Games Launcher cache", Note = "The launcher's web cache and logs (not your games); close the launcher first", Dirs = epic.ToArray() });
        l.Add(new JunkSpot { Key = "discord", Proc = "Discord", KeepFolders = true, Title = "Discord cache", Note = "Saved images and app pieces (not your messages); close Discord first", Dirs = new[] { Path.Combine(app, @"discord\Cache"), Path.Combine(app, @"discord\Code Cache"), Path.Combine(app, @"discord\GPUCache") } });
        l.Add(new JunkSpot { Key = "devcache", KeepFolders = true, Title = "Developer caches", Note = "NuGet, pip and Unity package caches: they download again when a project needs them", Dirs = new[] { Path.Combine(local, @"NuGet\v3-cache"), Path.Combine(local, @"pip\cache"), Path.Combine(local, @"Unity\cache") } });
        return l;
    }
    static string SteamDir() { try { using (var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")) { var v = k == null ? null : k.GetValue("SteamPath") as string; return v != null && Directory.Exists(v) ? v.Replace('/', '\\') : ""; } } catch { return ""; } }

    // ------------------------------------------------------------------ deep clean: the system places, run with administrator rights in one go
    class DeepItem { public string Key, Title, Note, Script = ""; public string[] Dirs = new string[0]; public bool Default; public long Fixed = -2; }      // Fixed: a size known another way (-2: measure the folders, -1: not known before it runs)
    static string Q(string p) { return p.Replace("'", "''"); }
    static string ClearDirs(string[] dirs) { var sb = new StringBuilder(); foreach (string d in dirs) sb.Append("if (Test-Path -LiteralPath '" + Q(d) + "') { Get-ChildItem -LiteralPath '" + Q(d) + "' -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue }; "); return sb.ToString(); }
    static List<DeepItem> DeepItems()
    {
        string win = Environment.GetEnvironmentVariable("WINDIR") ?? @"C:\Windows", sys = Path.GetPathRoot(win) ?? @"C:\", pd = Environment.GetEnvironmentVariable("ProgramData") ?? @"C:\ProgramData";
        var l = new List<DeepItem>();
        l.Add(new DeepItem { Key = "comp", Title = "Old Windows updates", Note = "Older versions of updates that newer ones replaced (Windows' own DISM cleanup); can take 5 to 15 minutes", Default = true, Fixed = -1, Script = "Dism.exe /Online /Cleanup-Image /StartComponentCleanup /NoRestart | Out-Null" });
        l.Add(new DeepItem { Key = "reset", Title = "Lock in installed updates", Note = "Also removes the backups of installed updates (DISM /ResetBase): frees more, but no installed update can be uninstalled afterwards", Fixed = -1, Script = "Dism.exe /Online /Cleanup-Image /StartComponentCleanup /ResetBase /NoRestart | Out-Null" });
        var upd = new[] { Path.Combine(win, @"SoftwareDistribution\Download") };
        l.Add(new DeepItem { Key = "updl", Title = "Windows Update downloads", Note = "Update files that are already installed; Windows downloads again anything it still needs", Default = true, Dirs = upd, Script = "Stop-Service wuauserv,bits -Force -ErrorAction SilentlyContinue; " + ClearDirs(upd) + "Start-Service wuauserv,bits -ErrorAction SilentlyContinue" });
        l.Add(new DeepItem { Key = "dopt", Title = "Delivery Optimization files", Note = "Update pieces Windows keeps to share with other PCs", Default = true, Dirs = new[] { Path.Combine(win, @"ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache") }, Script = "Delete-DeliveryOptimizationCache -Force -ErrorAction SilentlyContinue" });
        var logs = new[] { Path.Combine(win, @"Logs\CBS"), Path.Combine(win, @"Logs\DISM"), Path.Combine(pd, @"Microsoft\Windows\WER\ReportArchive"), Path.Combine(pd, @"Microsoft\Windows\WER\ReportQueue") };
        l.Add(new DeepItem { Key = "logs", Title = "Windows logs and system error reports", Note = "Update and setup logs (CBS, DISM) and error reports from every user on this PC", Default = true, Dirs = logs, Script = ClearDirs(logs) });
        var wt = new[] { Path.Combine(win, "Temp") };
        l.Add(new DeepItem { Key = "systemp", Title = "Windows temp folder (all of it)", Note = "The files the Junk view has to skip without administrator rights", Default = true, Dirs = wt, Script = ClearDirs(wt) });
        var old = new List<string>(); foreach (string n in new[] { "Windows.old", "$Windows.~BT", "$Windows.~WS" }) { string p = Path.Combine(sys, n); if (Directory.Exists(p)) old.Add(p); }
        if (old.Count > 0) { var sb = new StringBuilder(); foreach (string p in old) sb.Append("takeown /F '" + Q(p) + "' /R /A /D Y | Out-Null; icacls '" + Q(p) + "' /grant '*S-1-5-32-544:F' /T /C /Q | Out-Null; Remove-Item -LiteralPath '" + Q(p) + "' -Recurse -Force -ErrorAction SilentlyContinue; "); l.Add(new DeepItem { Key = "winold", Title = "Previous Windows installation", Note = "Windows.old and upgrade leftovers: afterwards you can no longer go back to your earlier version of Windows", Dirs = old.ToArray(), Script = sb.ToString() }); }
        long hib = -1; try { var hf = new FileInfo(Path.Combine(sys, "hiberfil.sys")); if (hf.Exists) hib = hf.Length; else hib = -3; } catch { }
        if (hib != -3) l.Add(new DeepItem { Key = "hiber", Title = "Hibernation file", Note = "Turns hibernation and Fast Startup off (powercfg /h off). Turn them back on any time with powercfg /h on", Fixed = hib, Script = "powercfg.exe /hibernate off" });
        l.Add(new DeepItem { Key = "restore", Title = "Old restore points", Note = "Deletes every System Restore point except the newest one", Fixed = -1, Script = "$s = @(Get-CimInstance Win32_ShadowCopy | Sort-Object InstallDate); if ($s.Count -gt 1) { $s[0..($s.Count - 2)] | Remove-CimInstance }" });
        return l;
    }
    List<DcRow> DeepScan(Func<bool> stop)
    {
        var res = new List<DcRow>();
        foreach (var it in DeepItems())
        {
            if (stop()) break; status = "Measuring " + it.Title + "\u2026"; long t = it.Fixed; int n = 0;
            if (t == -2)
            {
                t = 0; bool blind = false;
                foreach (string d in it.Dirs) { if (!Directory.Exists(d)) continue; try { Directory.GetFileSystemEntries(d); } catch { blind = true; continue; } foreach (var f in DcScan.Walk(d, stop)) { try { t += f.Length; n++; } catch { } } }
                if (blind && t == 0) t = -1;
            }
            res.Add(new DcRow { Key = it.Key, Name = it.Title, Note = it.Note, Size = t, Tag = t < 0 ? "needs admin, size shown after" : "needs admin" + (n > 0 ? ", " + n.ToString("N0", CultureInfo.InvariantCulture) + " files" : ""), Check = it.Default && t != 0 });
        }
        long max = 1; foreach (var r in res) if (r.Size > max) max = r.Size; foreach (var r in res) r.Frac = Math.Max(0, r.Size) / (float)max; return res;
    }
    static long FreeOn(string drive) { try { return new DriveInfo(drive).AvailableFreeSpace; } catch { return 0; } }
    void DoDeep(List<DcRow> chosen)
    {
        string list = string.Join("\r\n", chosen.ConvertAll(r => "   \u2022 " + r.Name).ToArray());
        if (MessageBox.Show(FindForm(), "Clean these with administrator rights?\r\n\r\n" + list + "\r\n\r\nWindows will ask for permission once. This is permanent. Old Windows updates can take several minutes; CENOHWARE stays usable meanwhile.", "Disk Cleaner", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
        var items = DeepItems(); string id = Guid.NewGuid().ToString("N").Substring(0, 8);
        string log = Path.Combine(Path.GetTempPath(), "cenoh_deep_" + id + ".log"), ps1 = Path.Combine(Path.GetTempPath(), "cenoh_deep_" + id + ".ps1");
        var sb = new StringBuilder(); sb.AppendLine("$log = '" + Q(log) + "'");
        sb.AppendLine("function Step($k, [scriptblock]$b) { Add-Content -LiteralPath $log ('START ' + $k); try { & $b; Add-Content -LiteralPath $log ('OK ' + $k) } catch { Add-Content -LiteralPath $log ('ERR ' + $k + ' ' + $_.Exception.Message) } }");
        var titles = new Dictionary<string, string>();
        foreach (var r in chosen) { var it = items.Find(x => x.Key == r.Key); if (it == null) continue; titles[it.Key] = it.Title; sb.AppendLine("Step '" + it.Key + "' { " + it.Script + " }"); }
        sb.AppendLine("Add-Content -LiteralPath $log 'DONE'");
        try { File.WriteAllText(ps1, sb.ToString(), new UTF8Encoding(true)); } catch (Exception ex) { note = "Could not write the clean-up script: " + ex.Message; Invalidate(); return; }
        busy = true; cancel = false; status = "Waiting for administrator permission\u2026"; SyncUi();
        ThreadPool.QueueUserWorkItem(delegate
        {
            string drive = Path.GetPathRoot(Environment.GetEnvironmentVariable("WINDIR") ?? @"C:\"); long before = FreeOn(drive); string err = ""; bool declined = false; int ok = 0, bad = 0;
            try
            {
                var psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + ps1 + "\"") { Verb = "runas", UseShellExecute = true, WindowStyle = ProcessWindowStyle.Hidden };
                using (var p = Process.Start(psi))
                    while (!p.WaitForExit(700))
                    {
                        try { string last = ""; foreach (string ln in File.ReadAllLines(log)) if (ln.StartsWith("START ")) last = ln.Substring(6); string tt; if (last.Length > 0 && titles.TryGetValue(last, out tt)) status = "Cleaning: " + tt + "\u2026  (this runs as administrator and can not be stopped halfway)"; } catch { }
                    }
            }
            catch (System.ComponentModel.Win32Exception ex) { if (ex.NativeErrorCode == 1223) declined = true; else err = ex.Message; }
            catch (Exception ex) { err = ex.Message; }
            try { foreach (string ln in File.ReadAllLines(log)) { if (ln.StartsWith("OK ")) ok++; else if (ln.StartsWith("ERR ")) bad++; } } catch { }
            try { File.Delete(ps1); File.Delete(log); } catch { }
            long freed = Math.Max(0, FreeOn(drive) - before);
            try
            {
                BeginInvoke(new Action(delegate
                {
                    busy = false;
                    if (declined) note = "Nothing was cleaned: Windows asked for administrator permission and it was not given.";
                    else if (err.Length > 0) note = "Could not start the clean-up: " + err;
                    else { freedTotal += freed; try { Directory.CreateDirectory(Path.GetDirectoryName(SaveFile)); File.WriteAllText(SaveFile, freedTotal.ToString(CultureInfo.InvariantCulture)); } catch { } note = "Freed " + DcScan.Fmt(freed) + " on " + drive.TrimEnd('\\') + " (" + ok + " step" + (ok == 1 ? "" : "s") + " done" + (bad > 0 ? ", " + bad + " failed" : "") + ")"; }
                    SyncUi(); if (!declined && err.Length == 0) { string keep = note; StartScanThen(() => note = keep); }
                }));
            }
            catch { }
        });
    }
    // rescan the current view, then put back the message about what was just done
    void StartScanThen(Action after) { StartScan(); pendingAfter = after; }
    Action pendingAfter;

    // ------------------------------------------------------------------ leftovers: unused files
    static readonly string[] KeepNames = { "microsoft", "packages", "temp", "programs", "comms", "connecteddevicesplatform", "crashdumps", "d3dscache", "history", "publishers", "virtualstore", "google", "mozilla", "nvidia", "nvidiacorporation", "intel", "amd", "ati", "apple", "applecomputer", "adobe", "packagecache", "cenohware", "holdclick", "steam", "epicgameslauncher", "unity", "unitytechnologies", "jetbrains", "pip", "nuget", "npm", "npmcache", "nodegyp", "python", "ssh", "gnupg", "windows", "windowsapps", "ssl", "usoshared", "usoprivate", "softwaredistribution", "desktop", "documents", "startmenu", "templates", "applicationdata", "sun", "java", "oracle", "realtek", "identities", "mediacenterprograms", "chocolatey", "fontcache", "peripheral", "tiledatalayer", "regid19910" };
    static string Norm(string v) { var sb = new StringBuilder(); foreach (char c in v.ToLowerInvariant()) if (char.IsLetterOrDigit(c)) sb.Append(c); return sb.ToString(); }
    // every name that says a program is still on this PC: the uninstall list, the Program Files folders, the Start menu, what is running
    static List<string> InstalledNames()
    {
        var set = new HashSet<string>();
        Action<string> add = v => { if (string.IsNullOrEmpty(v)) return; string n = Norm(v); if (n.Length >= 3) set.Add(n); };
        Action<string> addPath = p => { try { if (string.IsNullOrEmpty(p)) return; p = p.Trim('"', ' '); int c = p.IndexOf(','); if (c > 0) p = p.Substring(0, c); var d = new DirectoryInfo(Path.HasExtension(p) ? Path.GetDirectoryName(p) : p); for (int i = 0; i < 2 && d != null && d.Parent != null; i++) { add(d.Name); d = d.Parent; } } catch { } };
        foreach (var hive in new[] { Microsoft.Win32.RegistryHive.LocalMachine, Microsoft.Win32.RegistryHive.CurrentUser })
            foreach (var view in new[] { Microsoft.Win32.RegistryView.Registry64, Microsoft.Win32.RegistryView.Registry32 })
                try
                {
                    using (var b = Microsoft.Win32.RegistryKey.OpenBaseKey(hive, view)) using (var u = b.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"))
                        if (u != null) foreach (string sub in u.GetSubKeyNames()) try { using (var k = u.OpenSubKey(sub)) { if (k == null) continue; add(k.GetValue("DisplayName") as string); add(k.GetValue("Publisher") as string); addPath(k.GetValue("InstallLocation") as string); addPath(k.GetValue("DisplayIcon") as string); } } catch { }
                }
                catch { }
        string local = Environment.GetEnvironmentVariable("LOCALAPPDATA") ?? "";
        foreach (string root in new[] { Environment.GetEnvironmentVariable("ProgramFiles"), Environment.GetEnvironmentVariable("ProgramFiles(x86)"), Path.Combine(local, "Programs"), Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms), Environment.GetFolderPath(Environment.SpecialFolder.Programs) })
        {
            if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) continue;
            try { foreach (string d in Directory.GetDirectories(root)) { add(Path.GetFileName(d)); try { foreach (string d2 in Directory.GetDirectories(d)) add(Path.GetFileName(d2)); foreach (string f in Directory.GetFiles(d, "*.lnk")) add(Path.GetFileNameWithoutExtension(f)); } catch { } } foreach (string f in Directory.GetFiles(root, "*.lnk")) add(Path.GetFileNameWithoutExtension(f)); } catch { }
        }
        try { foreach (var p in Process.GetProcesses()) { try { add(p.ProcessName); } catch { } p.Dispose(); } } catch { }
        return new List<string>(set);
    }
    static bool Owned(string folder, List<string> known)
    {
        string n = Norm(folder); if (n.Length < 3) return true;
        foreach (string k in KeepNames) if (n.StartsWith(k)) return true;
        foreach (string k in known) { if (k.Contains(n)) return true; if (k.Length >= 4 && n.Contains(k)) return true; }
        return false;
    }
    List<DcRow> LeftoverScan(Func<bool> stop)
    {
        var res = new List<DcRow>();
        // 1. setup files downloaded over a month ago
        status = "Looking for old installers in Downloads\u2026"; string dl = Known(0); var inst = new List<DcRow>(); long ti = 0;
        if (Directory.Exists(dl)) foreach (var f in DcScan.Walk(dl, stop))
            {
                try { string ext = f.Extension.ToLowerInvariant(); if (ext != ".exe" && ext != ".msi" && ext != ".msix" && ext != ".msixbundle" && ext != ".appx") continue; if (DcScan.OnlineOnly(f)) continue; var used = DcScan.LastUsed(f); if ((DateTime.Now - used).TotalDays < 30) continue; inst.Add(new DcRow { Group = 1, Path = f.FullName, Name = f.Name, Dir = f.DirectoryName, Size = f.Length, Used = used, Tag = "downloaded " + DcScan.AgeText(used) + " ago" }); ti += f.Length; } catch { }
            }
        inst.Sort((a, b) => b.Size.CompareTo(a.Size));
        if (inst.Count > 0) { res.Add(new DcRow { Header = true, Group = 1, Name = inst.Count + " old installers in Downloads", Size = ti, Note = "Setup files from over a month ago: running them again is the only thing they are for. " + DcScan.Fmt(ti) }); res.AddRange(inst); }
        // 2. folders programs leave behind in AppData and ProgramData after they are uninstalled
        if (stop()) return res; status = "Reading the list of installed programs\u2026"; var known = InstalledNames();
        string up = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile); var cutoff = DateTime.Now.AddMonths(-6); var lefts = new List<DcRow>(); long tl = 0;
        foreach (string root in new[] { Environment.GetEnvironmentVariable("APPDATA"), Environment.GetEnvironmentVariable("LOCALAPPDATA"), Path.Combine(up, @"AppData\LocalLow"), Environment.GetEnvironmentVariable("ProgramData") })
        {
            if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) continue; DirectoryInfo[] subs; try { subs = new DirectoryInfo(root).GetDirectories(); } catch { continue; }
            foreach (var d in subs)
            {
                if (stop()) break;
                try { if ((d.Attributes & (FileAttributes.ReparsePoint | FileAttributes.System)) != 0) continue; } catch { continue; }
                if (d.Name.StartsWith(".") || d.Name.StartsWith("{") || Owned(d.Name, known)) continue;
                status = "Checking " + Path.GetFileName(root) + "\\" + d.Name + "\u2026"; long sz = 0; DateTime newest = d.LastWriteTime; bool fresh = false;
                foreach (var f in DcScan.Walk(d.FullName, stop)) { try { sz += f.Length; if (f.LastWriteTime > newest) newest = f.LastWriteTime; if (newest > cutoff) { fresh = true; break; } } catch { } }
                if (fresh || newest > cutoff || sz < (1L << 20)) continue;
                lefts.Add(new DcRow { Group = 2, Key = "folder", Path = d.FullName, Name = d.Name, Dir = root, Size = sz, Used = newest, Tag = "not touched in " + DcScan.AgeText(newest) }); tl += sz;
            }
        }
        lefts.Sort((a, b) => b.Size.CompareTo(a.Size));
        if (lefts.Count > 0) { res.Add(new DcRow { Header = true, Group = 2, Name = lefts.Count + " folders left by programs that are not installed any more", Size = tl, Note = "No installed program has these names and nothing touched them in 6 months. Check each one (Show in Explorer) before ticking. " + DcScan.Fmt(tl) }); res.AddRange(lefts); }
        return res;
    }

    static long BinSize() { try { var i = new SHQUERYRBINFO(); i.cbSize = System.Runtime.InteropServices.Marshal.SizeOf(typeof(SHQUERYRBINFO)); return SHQueryRecycleBin(null, ref i) == 0 ? i.i64Size : 0; } catch { return 0; } }
    static IEnumerable<FileInfo> SpotFiles(JunkSpot s, Func<bool> stop) { foreach (string d in s.Dirs) { if (!Directory.Exists(d)) continue; foreach (var f in DcScan.Walk(d, stop)) { if (s.Pattern != "*") { if (!Wild(f.Name, s.Pattern)) continue; } yield return f; } } }
    static bool Wild(string name, string pat) { string p = pat.Replace("*", ""); return name.StartsWith(p.Substring(0, p.IndexOf('_') + 1), StringComparison.OrdinalIgnoreCase) && name.EndsWith(".db", StringComparison.OrdinalIgnoreCase); }
    List<DcRow> JunkScan(Func<bool> stop)
    {
        var res = new List<DcRow>();
        foreach (var s in Spots())
        {
            if (stop()) break; status = "Measuring " + s.Title + "\u2026"; long t = 0; int n = 0; foreach (var f in SpotFiles(s, stop)) { try { t += f.Length; n++; } catch { } }
            bool open = Running(s.Proc);
            res.Add(new DcRow { Key = s.Key, Name = s.Title, Note = open ? "Close it first (all of its windows, and in the tray): clearing the cache of a running browser leaves it unable to load pages until it restarts" : s.Note, Size = t, Tag = open ? s.Title.Split(' ')[0] + " is open" : n.ToString("N0", CultureInfo.InvariantCulture) + " files", Check = s.Default && t > 0 && !open });
        }
        long bin = BinSize(); res.Add(new DcRow { Key = "bin", Name = "Recycle Bin", Note = "Everything you have deleted so far; emptying it is permanent", Size = bin, Tag = "", Check = false });
        long max = 1; foreach (var r in res) if (r.Size > max) max = r.Size; foreach (var r in res) r.Frac = r.Size / (float)max; res.Sort((a, b) => b.Size.CompareTo(a.Size)); return res;
    }

    // ------------------------------------------------------------------ actions
    void KeepNewest() { foreach (var r in rows) { if (r.Header) continue; r.Check = r.Tag != "newest"; } Invalidate(); SyncUi(); }
    void ShowSel() { var r = selRow >= 0 && selRow < rows.Count ? rows[selRow] : null; if (r == null || r.Path.Length == 0) { note = "Click a file first, then Show in Explorer."; Invalidate(); return; } try { Process.Start("explorer.exe", "/select,\"" + r.Path + "\""); } catch { } }
    void DoAction()
    {
        if (busy) return; var chosen = rows.FindAll(r => r.Check && !r.Header); if (chosen.Count == 0) return; long total = 0; foreach (var r in chosen) total += Math.Max(0, r.Size);
        if (tab == 6) { DoDeep(chosen); return; }
        bool junk = tab == 1;
        string msg = junk ? "Clear " + chosen.Count + " place" + (chosen.Count == 1 ? "" : "s") + " (" + DcScan.Fmt(total) + ")?\r\n\r\nThese are temp and cache files; they are deleted for good. Files that are in use are skipped." : "Move " + chosen.Count.ToString("N0", CultureInfo.InvariantCulture) + " file" + (chosen.Count == 1 ? "" : "s") + " (" + DcScan.Fmt(total) + ") to the Recycle Bin?\r\n\r\nYou can still get them back from there.";
        if (MessageBox.Show(FindForm(), msg, "Disk Cleaner", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
        busy = true; cancel = false; status = "Working\u2026"; SyncUi();
        ThreadPool.QueueUserWorkItem(delegate
        {
            long freed = 0; int ok = 0, fail = 0, skipped = 0; var removed = new HashSet<DcRow>();
            try
            {
                if (junk) foreach (var r in chosen)
                    {
                        status = "Clearing " + r.Name + "\u2026";
                        if (r.Key == "bin") { long before = BinSize(); SHEmptyRecycleBin(IntPtr.Zero, null, 0x7); long after = BinSize(); freed += Math.Max(0, before - after); ok++; continue; }
                        var sp = Spots().Find(s => s.Key == r.Key); if (sp == null) continue;
                        if (Running(sp.Proc)) { skipped++; continue; }
                        foreach (var f in new List<FileInfo>(SpotFiles(sp, null))) { try { long len = f.Length; f.Attributes = FileAttributes.Normal; f.Delete(); freed += len; ok++; } catch { fail++; } }
                        if (!sp.KeepFolders) foreach (string d in sp.Dirs) { if (sp.Pattern == "*") TryPruneEmpty(d); }
                    }
                else foreach (var r in chosen)
                    {
                        status = "Moving " + r.Name + "\u2026";
                        try { if (r.Key == "folder") Microsoft.VisualBasic.FileIO.FileSystem.DeleteDirectory(r.Path, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin); else Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(r.Path, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin); freed += r.Size; ok++; removed.Add(r); } catch { fail++; }
                    }
            }
            catch (Exception ex) { status = ex.Message; }
            try { BeginInvoke(new Action(delegate { busy = false; freedTotal += freed; try { Directory.CreateDirectory(Path.GetDirectoryName(SaveFile)); File.WriteAllText(SaveFile, freedTotal.ToString(CultureInfo.InvariantCulture)); } catch { } if (!junk) { rows.RemoveAll(r => removed.Contains(r)); rows.RemoveAll(r => r.Header && !rows.Exists(x => !x.Header && x.Group == r.Group)); } note = "Freed " + DcScan.Fmt(freed) + (skipped > 0 ? "  (skipped " + skipped + " because the browser is open: close it and clean again)" : "") + (fail > 0 ? "  (" + fail + " could not be removed: in use or no permission)" : ""); SyncUi(); if (junk) StartScan(); })); } catch { }
        });
    }
    static void TryPruneEmpty(string dir) { try { foreach (var d in Directory.GetDirectories(dir)) { TryPruneEmpty(d); try { if ((File.GetAttributes(d) & FileAttributes.ReparsePoint) == 0 && Directory.GetFileSystemEntries(d).Length == 0) Directory.Delete(d); } catch { } } } catch { } }

    // ------------------------------------------------------------------ IHubPage
    public void HubShown() { SyncUi(); }
    public void HubHidden() { }
    public void HubTheme() { Invalidate(true); }
    public void HubPrewarm() { }

    // ------------------------------------------------------------------ drawing
    protected override void DrawCards(Graphics g)
    {
        var c = Card; var sp = Sprite("dccard_" + c.Width + "x" + c.Height, c.Width, c.Height, delegate (Graphics gg, Rectangle r) { Glass(gg, r, 0.06f); }); Blit(g, sp, c.X - Pad, c.Y - Pad);
    }
    protected override void DrawContent(Graphics g)
    {
        TextRenderer.DrawText(g, "Disk Cleaner", FTitle, new Rectangle(44, 32, Width - 100, 52), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "Find what is eating your drive. Nothing is touched until you tick it and press the button.", Theme.UIL, new Rectangle(46, 90, Width - 100, 28), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        g.SmoothingMode = SmoothingMode.AntiAlias; var c = Card;
        if (tab == 0) { DrawOverview(g, c); return; }
        if (tab >= 2 && tab <= 5) TextRenderer.DrawText(g, "In: " + root, Theme.Small, new Rectangle(c.X + 18 + ToolsWidth, c.Y + 54, c.Width - 36 - ToolsWidth, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.PathEllipsis);
        string line = busy ? status : note; if (line.Length > 0) TextRenderer.DrawText(g, line, Theme.UIB, new Rectangle(c.X + 18, c.Y + 80, c.Width - 36, 22), busy ? Theme.AccentSoft : Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        else if (rows.Count == 0 && tab >= 2 && tab <= 5) TextRenderer.DrawText(g, tab == 5 ? "Pick a folder and press Analyze." : "Pick a folder and press Scan.", Theme.UIB, new Rectangle(c.X + 18, c.Y + 80, c.Width - 36, 22), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        var lr = ListRect; int vis = Visible; if (first > Math.Max(0, rows.Count - vis)) first = Math.Max(0, rows.Count - vis);
        for (int i = 0; i < vis && first + i < rows.Count; i++) DrawRow(g, rows[first + i], first + i, new Rectangle(lr.X, lr.Y + i * RowH, lr.Width - 14, RowH - 4));
        if (rows.Count > vis) { float th = Math.Max(30, lr.Height * vis / (float)rows.Count), ty = lr.Y + (lr.Height - th) * first / Math.Max(1, rows.Count - vis); using (var p = Theme.Round(new Rectangle(lr.Right - 7, (int)ty, 5, (int)th), 5)) using (var b = new SolidBrush(Color.FromArgb(150, Theme.AccentSoft))) g.FillPath(b, p); }
        // the bottom line
        long sel = 0; int n = 0; foreach (var r in rows) if (r.Check && !r.Header) { sel += Math.Max(0, r.Size); n++; }
        string sum = tab == 5 ? "" : n + " ticked  \u00b7  " + DcScan.Fmt(sel); if (tab != 5 && tab != 1 && rows.Count > 0) sum += "   (" + rows.FindAll(r => !r.Header).Count.ToString("N0", CultureInfo.InvariantCulture) + " listed)";
        if (tab >= 2 && tab != 5) TextRenderer.DrawText(g, sum, Theme.UIB, new Rectangle(c.X + 18, c.Bottom - 84, c.Width / 2, 22), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        else if (tab == 1) TextRenderer.DrawText(g, sum, Theme.UIB, new Rectangle(c.X + 18, c.Bottom - 84, c.Width / 2, 22), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
    }
    void DrawRow(Graphics g, DcRow r, int idx, Rectangle rc)
    {
        if (r.Header)
        {
            using (var path = Theme.Round(rc, 10)) using (var b = new SolidBrush(Color.FromArgb(70, Theme.Accent))) g.FillPath(b, path);
            TextRenderer.DrawText(g, r.Name, Theme.UIB, new Rectangle(rc.X + 14, rc.Y + 4, rc.Width - 250, 20), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
            TextRenderer.DrawText(g, r.Note, Theme.Small, new Rectangle(rc.X + 14, rc.Y + 23, rc.Width - 28, 16), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix); return;
        }
        bool sel = idx == selRow, hot = idx == hotRow;
        using (var path = Theme.Round(rc, 10)) { using (var b = new SolidBrush(Color.FromArgb(sel ? 90 : hot ? 56 : 30, sel ? Theme.Accent : Theme.CardHover))) g.FillPath(b, path); if (r.Frac > 0) { var bar = new Rectangle(rc.X + 6, rc.Bottom - 3, (int)((rc.Width - 12) * r.Frac), 2); using (var b = new SolidBrush(Color.FromArgb(150, Theme.Accent))) g.FillRectangle(b, bar); } }
        int tx = rc.X + 12;
        if (!r.IsDir && (tab != 5)) { var cb = new Rectangle(rc.X + 12, rc.Y + (rc.Height - 20) / 2, 20, 20); using (var path = Theme.Round(cb, 6)) { using (var b = new SolidBrush(r.Check ? Theme.Accent : Color.FromArgb(40, Theme.Border))) g.FillPath(b, path); using (var p = new Pen(r.Check ? Theme.AccentSoft : Theme.Border, 1.4f)) g.DrawPath(p, path); } if (r.Check) using (var p = new Pen(Theme.OnAccent, 2.4f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawLines(p, new[] { new Point(cb.X + 5, cb.Y + 10), new Point(cb.X + 9, cb.Y + 14), new Point(cb.X + 15, cb.Y + 6) }); tx = rc.X + 44; }
        int sizeW = 90, tagW = r.Tag.Length > 0 ? 220 : 0;
        TextRenderer.DrawText(g, r.Name, FRow, new Rectangle(tx, rc.Y + 4, rc.Width - (tx - rc.X) - sizeW - tagW - 20, 20), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        string sub = r.Note.Length > 0 ? r.Note : r.Dir; TextRenderer.DrawText(g, sub, Theme.Small, new Rectangle(tx, rc.Y + 22, rc.Width - (tx - rc.X) - sizeW - tagW - 20, 16), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.PathEllipsis);
        TextRenderer.DrawText(g, r.Size < 0 ? "?" : DcScan.Fmt(r.Size), FRow, new Rectangle(rc.Right - sizeW - 10, rc.Y + 4, sizeW, 20), Theme.Amber, TextFormatFlags.Right | TextFormatFlags.NoPrefix);
        if (tagW > 0) TextRenderer.DrawText(g, r.Tag, Theme.Small, new Rectangle(rc.Right - sizeW - tagW - 16, rc.Y + 6, tagW, 18), r.Tag.StartsWith("not used") || r.Tag.StartsWith("not touched") ? Theme.Red : Theme.Dim, TextFormatFlags.Right | TextFormatFlags.NoPrefix);
    }
    void DrawOverview(Graphics g, Rectangle c)
    {
        int y = c.Y + 24; var drives = new List<DriveInfo>(); foreach (var d in DriveInfo.GetDrives()) { try { if (d.IsReady && (d.DriveType == DriveType.Fixed || d.DriveType == DriveType.Removable)) drives.Add(d); } catch { } }
        TextRenderer.DrawText(g, "YOUR DRIVES", Theme.SmallB, new Rectangle(c.X + 24, y, 300, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix); y += 28;
        foreach (var d in drives)
        {
            long total = d.TotalSize, free = d.AvailableFreeSpace, used = total - free; float f = total > 0 ? used / (float)total : 0f;
            var rc = new Rectangle(c.X + 24, y, Math.Min(c.Width - 48, 900), 74);
            using (var path = Theme.Round(rc, 14)) using (var b = new SolidBrush(Color.FromArgb(50, Theme.CardHover))) g.FillPath(b, path);
            string label = d.Name.TrimEnd('\\') + (string.IsNullOrEmpty(d.VolumeLabel) ? "" : "  " + d.VolumeLabel);
            TextRenderer.DrawText(g, label, FBig, new Rectangle(rc.X + 18, rc.Y + 8, 360, 28), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
            TextRenderer.DrawText(g, DcScan.Fmt(free) + " free of " + DcScan.Fmt(total), Theme.UIB, new Rectangle(rc.Right - 320, rc.Y + 12, 300, 22), f > 0.9f ? Theme.Red : f > 0.75f ? Theme.Amber : Theme.Text, TextFormatFlags.Right | TextFormatFlags.NoPrefix);
            var bar = new Rectangle(rc.X + 18, rc.Y + 46, rc.Width - 36, 12); using (var path = Theme.Round(bar, 12)) using (var b = new SolidBrush(Color.FromArgb(90, Theme.Border))) g.FillPath(b, path);
            var fill = new Rectangle(bar.X, bar.Y, Math.Max(10, (int)(bar.Width * f)), bar.Height); using (var path = Theme.Round(fill, 12)) using (var b = new SolidBrush(f > 0.9f ? Theme.Red : f > 0.75f ? Theme.Amber : Theme.Accent)) g.FillPath(b, path);
            y += 86; if (y > c.Bottom - 190) break;
        }
        TextRenderer.DrawText(g, "FREED SO FAR WITH THIS TAB", Theme.SmallB, new Rectangle(c.X + 24, y + 6, 360, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, DcScan.Fmt(freedTotal), FBig, new Rectangle(c.X + 24, y + 26, 300, 28), Theme.Green, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        string tips = "Start with Junk (safe, known throw-away places). Deep clean goes further with administrator rights: old Windows updates, update downloads, logs, Windows.old, the hibernation file and old restore points. Leftovers finds old installers and folders left by uninstalled programs. Then look at Old files and Big files in your Downloads, Desktop and Videos; Duplicates finds identical copies, and Folders shows what is using the space inside any folder.\r\nOld, big, duplicate and leftover files go to the Recycle Bin, so nothing is lost until you empty it.";
        TextRenderer.DrawText(g, tips, Theme.UI, new Rectangle(c.X + 24, y + 70, Math.Min(c.Width - 48, 900), 130), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
    }

    // ------------------------------------------------------------------ mouse
    int RowAt(Point p) { var lr = ListRect; if (!lr.Contains(p)) return -1; int i = first + (p.Y - lr.Y) / RowH; return i >= 0 && i < rows.Count ? i : -1; }
    protected override void OnMouseMove(MouseEventArgs e) { int h = RowAt(e.Location); if (h != hotRow) { hotRow = h; Cursor = h >= 0 && !rows[h].Header ? Cursors.Hand : Cursors.Default; } base.OnMouseMove(e); }
    protected override void OnMouseLeave(EventArgs e) { hotRow = -1; base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        Focus(); int i = RowAt(e.Location);
        if (i >= 0 && !rows[i].Header && !busy)
        {
            var r = rows[i]; selRow = i; var lr = ListRect;
            if (e.Clicks == 1) { if (!r.IsDir && tab != 5 && e.X < lr.X + 44) r.Check = !r.Check; }
            else if (tab == 5 && r.IsDir) { stack.Add(root); root = r.Path; StartScan(); return; }          // double click: go into the folder
            else if (!r.IsDir && tab != 1 && tab != 6 && e.X >= lr.X + 44) ShowSel();                                  // double click: show the file
            SyncUi();
        }
        base.OnMouseDown(e);
    }
    protected override void OnMouseWheel(MouseEventArgs e) { if (ListRect.Contains(e.Location)) { first = Math.Max(0, Math.Min(Math.Max(0, rows.Count - Visible), first - Math.Sign(e.Delta) * 2)); Invalidate(); } base.OnMouseWheel(e); }

    // check switch: build a throwaway folder with old, big and duplicate files, run the real scans on it, put the results on screen, delete only that folder
    public string TestRun(int which)
    {
        string dir = Path.Combine(Path.GetTempPath(), "dc_test_" + Guid.NewGuid().ToString("N").Substring(0, 8)); var sb = new StringBuilder();
        try
        {
            Directory.CreateDirectory(Path.Combine(dir, "Videos")); Directory.CreateDirectory(Path.Combine(dir, "Old stuff")); var rnd = new Random(5);
            Action<string, int, int> mk = (rel, kb, daysOld) => { var b = new byte[kb * 1024]; rnd.NextBytes(b); string p = Path.Combine(dir, rel); File.WriteAllBytes(p, b); var stamp = DateTime.Now.AddDays(-daysOld); File.SetLastWriteTime(p, stamp); File.SetLastAccessTime(p, stamp); };
            mk(@"Videos\holiday.mp4", 9000, 900); mk(@"Videos\clip.mov", 4000, 20); mk(@"Old stuff\setup.exe", 6000, 500); mk(@"Old stuff\notes.txt", 2000, 800); mk(@"readme.txt", 1500, 3);
            File.Copy(Path.Combine(dir, @"Videos\holiday.mp4"), Path.Combine(dir, @"Old stuff\holiday copy.mp4")); File.Copy(Path.Combine(dir, @"Old stuff\setup.exe"), Path.Combine(dir, @"Videos\setup (1).exe"));
            root = dir; ageMonths = 12; minBytes = 1L << 20; Func<bool> never = () => false;
            var old = DcScan.Old(dir, 12, 1L << 20, never, null); var big = DcScan.Big(dir, 3, never, null); var dups = DcScan.Duplicates(dir, 1L << 20, never, null); var fold = DcScan.Folders(dir, never);
            sb.AppendLine("old: " + old.Count + " (" + string.Join(", ", old.ConvertAll(r => r.Name + " " + r.Tag).ToArray()) + ")");
            sb.AppendLine("big: " + string.Join(", ", big.ConvertAll(r => r.Name + " " + DcScan.Fmt(r.Size)).ToArray()));
            sb.AppendLine("dups: " + dups.FindAll(r => r.Header).Count + " sets, rows " + dups.Count + " (" + string.Join("; ", dups.FindAll(r => r.Header).ConvertAll(r => r.Name + " frees " + DcScan.Fmt(r.Size)).ToArray()) + ")");
            sb.AppendLine("folders: " + string.Join(", ", fold.ConvertAll(r => r.Name + " " + DcScan.Fmt(r.Size)).ToArray()));
            var sp = Spots(); sb.AppendLine("junk spots: " + sp.Count + " bin=" + DcScan.Fmt(BinSize()));
            int t = which; store[tab] = rows; tab = t; stack.Clear();
            rows = t == 2 ? old : t == 3 ? big : t == 4 ? dups : t == 5 ? fold : t == 1 ? JunkScan(() => false) : new List<DcRow>();
            foreach (var r in rows) if (t == 2 || t == 3) r.Check = r.Size > 5000 * 1024; note = "test data in a throwaway folder"; SyncUi();
            // a real delete on the throwaway data only: tick the old setup.exe and remove it for good
            var gone = Path.Combine(dir, @"Old stuff\notes.txt"); File.Delete(gone); sb.AppendLine("deleted test file: " + !File.Exists(gone));
        }
        catch (Exception ex) { sb.AppendLine("ERROR " + ex); }
        try { Directory.Delete(dir, true); } catch { }
        return sb.ToString();
    }
}
