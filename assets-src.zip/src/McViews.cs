// The sections of the Minecraft Server tab. Each one builds its own controls once, lays them out only when it is on screen, and does
// nothing while it is hidden.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

// ---------------------------------------------------------------------------------------------------- Overview
class McOverview : McView
{
    readonly TextBox sayBox; readonly Btn sayBtn, saveBtn, backupBtn, dayBtn, nightBtn, clearBtn, wlOnBtn, wlOffBtn, listBtn, restartBtn, stopBtn, startBtn; readonly McList feed = new McList { Widths = new[] { 0.2f, 0.8f }, Heads = new[] { "WHEN", "WHAT HAPPENED" }, Empty = "Nothing yet. Joins, leaves, backups and restarts show up here." };
    readonly List<KeyValuePair<Rectangle, string>> chips = new List<KeyValuePair<Rectangle, string>>();
    public McOverview(McPage p) : base(p)
    {
        Name = "Overview"; sayBox = Field("Message to everyone", 300); sayBtn = Button("Say it", 80, delegate { string m = sayBox.Text.Trim(); if (m.Length > 0) { P.Run("say " + m); sayBox.Text = ""; } });
        saveBtn = Button("Save now", 100, delegate { P.Run("save-all flush"); }); backupBtn = Button("Back up the world", 150, delegate { P.BackupNow(false); }, true);
        dayBtn = Button("Day", 70, delegate { P.Run("time set day"); }); nightBtn = Button("Night", 70, delegate { P.Run("time set night"); }); clearBtn = Button("Clear weather", 110, delegate { P.Run("weather clear"); });
        wlOnBtn = Button("Whitelist on", 100, delegate { P.Run("whitelist on"); }); wlOffBtn = Button("Whitelist off", 100, delegate { P.Run("whitelist off"); }); listBtn = Button("Who is online", 110, delegate { P.Run("list"); });
        restartBtn = Button("Restart (60 s warning)", 170, delegate { P.RestartServer(60, false); }); stopBtn = Button("Save and stop", 130, delegate { P.StopServer(); }); stopBtn.Danger = true;
        startBtn = Button("Start the server", 140, delegate { P.HelperAsync("START", (r, e) => { P.Say(e.Length > 0 ? "Helper: " + e : "Helper: " + r); P.Event("Start requested"); }); });
        Ctl.Add(feed); P.StateChanged += delegate { feed.SetRows(P.events); };
    }
    public override void Shown() { feed.SetRows(P.events); }
    public override void Place(Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 190;
        backupBtn.Location = new Point(x, y); saveBtn.Location = new Point(backupBtn.Right + 8, y); restartBtn.Location = new Point(saveBtn.Right + 8, y);
        startBtn.Location = new Point(x, y + 38); stopBtn.Location = new Point(startBtn.Right + 8, y + 38);
        dayBtn.Location = new Point(x, y + 100); nightBtn.Location = new Point(dayBtn.Right + 8, y + 100); clearBtn.Location = new Point(nightBtn.Right + 8, y + 100);
        wlOnBtn.Location = new Point(x, y + 164); wlOffBtn.Location = new Point(wlOnBtn.Right + 8, y + 164); listBtn.Location = new Point(wlOffBtn.Right + 8, y + 164);
        sayBox.Location = new Point(x, y + 232); sayBox.Width = 300; sayBtn.Location = new Point(sayBox.Right + 22, y + 226);
        feed.SetBounds(a.X + 520, a.Y + 44, a.Width - 520 - 22, a.Height - 44 - 22);
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        int x = a.X + 22; Head(g, "ONLINE NOW", x, a.Y + 18); chips.Clear(); int cx = x, cy = a.Y + 44, w; var names = P.players.Count > 0 ? P.players : P.status.Sample;
        foreach (string n in names) { w = global::Draw.Chip(g, cx, cy, n, n == P.selPlayer ? Theme.Accent : Theme.Green, n == P.selPlayer); chips.Add(new KeyValuePair<Rectangle, string>(new Rectangle(cx, cy, w - 6, 19), n)); cx += w; if (cx > a.X + 480) { cx = x; cy += 26; if (cy > a.Y + 120) break; } }
        if (names.Count == 0) TextRenderer.DrawText(g, "nobody right now", Theme.UI, new Rectangle(x, cy, 300, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "Click a name to pick them, then use the Players section.", Theme.Small, new Rectangle(x, a.Y + 142, 460, 16), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        Head(g, "THE WORLD AND THE SERVER", x, a.Y + 168); Head(g, "TIME AND WEATHER", x, a.Y + 272); Head(g, "WHITELIST AND PLAYERS", x, a.Y + 336); Head(g, "SAY SOMETHING IN THE GAME", x, a.Y + 404);
        Head(g, "RECENT", a.X + 520, a.Y + 18);
        bool hs = P.HelperSet; startBtn.Enabled = hs; stopBtn.Enabled = P.Connected || hs; restartBtn.Enabled = (P.Connected || hs) && !P.working; backupBtn.Enabled = P.Connected && !P.working;
        foreach (var b in new Btn[] { sayBtn, saveBtn, dayBtn, nightBtn, clearBtn, wlOnBtn, wlOffBtn, listBtn }) b.Enabled = P.Connected;
    }
    public override bool Click(Point p) { foreach (var kv in chips) if (kv.Key.Contains(p)) { P.selPlayer = kv.Value; P.Changed(); return true; } return false; }
}

// ---------------------------------------------------------------------------------------------------- Players
class McPlayers : McView
{
    readonly McList online = new McList { Widths = new[] { 0.6f, 0.4f }, Heads = new[] { "ONLINE NOW", "FOR" }, Empty = "Nobody is online." }, lists = new McList { Widths = new[] { 0.5f, 0.3f, 0.2f }, Empty = "" };
    readonly TextBox playerBox, countBox, itemBox, tpToBox; readonly Btn kickBtn, banBtn, unbanBtn, opBtn, deopBtn, wlAddBtn, wlRemBtn, tpMeBtn, tpGoBtn, giveBtn, refreshBtn; readonly Btn[] gm = new Btn[4], modeBtns = new Btn[3]; int mode;
    static readonly string[] Items = { "diamond", "netherite_ingot", "iron_ingot", "gold_ingot", "emerald", "coal", "redstone", "bread", "cooked_beef", "golden_apple", "enchanted_golden_apple", "diamond_sword", "diamond_pickaxe", "diamond_axe", "diamond_shovel", "netherite_sword", "netherite_pickaxe", "bow", "crossbow", "arrow", "shield", "elytra", "firework_rocket", "torch", "oak_log", "stone", "cobblestone", "dirt", "tnt", "ender_pearl", "ender_eye", "totem_of_undying", "experience_bottle", "water_bucket", "lava_bucket", "crafting_table", "furnace", "chest", "shulker_box", "beacon", "obsidian", "diamond_block", "iron_block", "slime_ball", "saddle", "name_tag", "trident", "diamond_helmet", "diamond_chestplate", "diamond_leggings", "diamond_boots", "netherite_helmet", "netherite_chestplate", "netherite_leggings", "netherite_boots", "command_block" };
    public McPlayers(McPage p) : base(p)
    {
        Name = "Players"; playerBox = Field("Player name", 200); countBox = Field("How many", 80); countBox.Text = "1"; 
        kickBtn = Button("Kick", 70, delegate { Cmd("kick {0}", true); }); banBtn = Button("Ban", 70, delegate { Cmd("ban {0}", true); }); unbanBtn = Button("Unban", 80, delegate { Cmd("pardon {0}", false); }); opBtn = Button("Make op", 90, delegate { Cmd("op {0}", false); }); deopBtn = Button("Remove op", 100, delegate { Cmd("deop {0}", false); });
        wlAddBtn = Button("Whitelist add", 110, delegate { Cmd("whitelist add {0}", false); }); wlRemBtn = Button("Whitelist remove", 130, delegate { Cmd("whitelist remove {0}", false); });
        string[] gms = { "Survival", "Creative", "Spectator", "Adventure" }; for (int i = 0; i < 4; i++) { string m = gms[i].ToLowerInvariant(); gm[i] = Button(gms[i], 96, delegate { Cmd("gamemode " + m + " {0}", false); }); }
        tpMeBtn = Button("Teleport to me", 130, delegate { string me = P.Cfg("me", "").Trim(); if (me.Length == 0) { P.Say("Type your own player name in Settings first (\"Your player name\")."); return; } Cmd("tp {0} " + me, false); });
        tpToBox = Field("Who to go to", 150); tpToBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend; tpToBox.AutoCompleteSource = AutoCompleteSource.CustomSource; tpToBox.AutoCompleteCustomSource = new AutoCompleteStringCollection();
        tpGoBtn = Button("Teleport to them", 140, delegate { string t = tpToBox.Text.Trim(); if (t.Length == 0) { P.Say("Pick who to teleport to."); return; } Cmd("tp {0} " + t, false); });
        itemBox = Field("Item, e.g. diamond", 200); itemBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend; itemBox.AutoCompleteSource = AutoCompleteSource.CustomSource; var ac = new AutoCompleteStringCollection(); ac.AddRange(Items); itemBox.AutoCompleteCustomSource = ac;
        giveBtn = Button("Give", 80, delegate { string it = itemBox.Text.Trim().Replace(' ', '_').ToLowerInvariant(); int n; if (it.Length == 0 || !int.TryParse(countBox.Text.Trim(), out n) || n < 1) { P.Say("Pick an item and how many."); return; } if (!it.Contains(":")) it = "minecraft:" + it; Cmd("give {0} " + it + " " + Math.Min(n, 6400), false); });
        refreshBtn = Button("Refresh", 80, delegate { P.Run("list", true); Load(); });
        string[] ms = { "Whitelist", "Banned", "History" }; for (int i = 0; i < 3; i++) { int k = i; modeBtns[i] = Button(ms[i], 96, delegate { mode = k; Load(); }); }
        Ctl.Add(online); Ctl.Add(lists);
        online.Picked += delegate (int i) { if (i >= 0 && i < online.Rows.Count) { P.selPlayer = online.Rows[i].Cols[0]; playerBox.Text = P.selPlayer; } };
        lists.Picked += delegate (int i) { if (mode < 2 && i >= 0 && i < lists.Rows.Count) playerBox.Text = lists.Rows[i].Cols[0]; };
        P.PlayersChanged += delegate { Fill(); };
    }
    void Cmd(string fmt, bool confirm)
    {
        string n = playerBox.Text.Trim(); if (n.Length == 0) n = P.selPlayer; if (n.Length == 0 || n.IndexOf(' ') >= 0) { P.Say("Type a player's name, or click one in the Online list, first."); return; }
        if (confirm && MessageBox.Show(P.FindForm(), (fmt.StartsWith("ban") ? "Ban " : "Kick ") + n + " from the server?", "Minecraft Server", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
        P.Run(string.Format(fmt, n), false, delegate { if (fmt.StartsWith("whitelist") || fmt.StartsWith("ban") || fmt.StartsWith("pardon")) Load(); });
    }
    void Fill()
    {
        var rows = new List<McRow>(); foreach (string n in P.players) rows.Add(new McRow { Cols = new[] { n, P.JoinedFor(n) } }); online.SetRows(rows);
        tpToBox.AutoCompleteCustomSource.Clear(); foreach (string n in P.players) tpToBox.AutoCompleteCustomSource.Add(n);
    }
    void Load()
    {
        for (int i = 0; i < 3; i++) { modeBtns[i].Selected = i == mode; modeBtns[i].Invalidate(); }
        if (mode == 2) { lists.Widths = new[] { 0.4f, 0.4f, 0.2f }; lists.Heads = new[] { "PLAYER", "JOINED", "MINUTES" }; lists.Empty = "No sessions recorded yet. They are saved as players leave while this program is open."; var rows = new List<McRow>(); foreach (var h in P.history) rows.Add(new McRow { Cols = new[] { h[0], h[1], h[2] } }); lists.SetRows(rows); return; }
        lists.Widths = new[] { 1f }; lists.Heads = new[] { mode == 0 ? "WHITELISTED (click one to pick them)" : "BANNED (click one to pick them)" }; lists.Empty = P.Connected ? "Nobody." : "Connect first."; lists.SetRows(new List<McRow>());
        if (!P.Connected) return;
        P.Run(mode == 0 ? "whitelist list" : "banlist players", true, delegate (string res)
        {
            var rows = new List<McRow>();
            if (mode == 0) { int i = res.IndexOf(':'); if (i >= 0) foreach (string n in res.Substring(i + 1).Split(',')) { string x = n.Trim(); if (x.Length > 0) rows.Add(new McRow { Cols = new[] { x } }); } }
            else foreach (string line in res.Split('\n')) { int i = line.IndexOf(" was banned by "); if (i > 0) rows.Add(new McRow { Cols = new[] { line.Substring(0, i).Trim() } }); }
            lists.SetRows(rows);
        });
    }
    public override void Shown() { Fill(); Load(); if (P.selPlayer.Length > 0) playerBox.Text = P.selPlayer; }
    public override void Place(Rectangle a)
    {
        int lw = Math.Max(300, Math.Min(420, a.Width / 3)); online.SetBounds(a.X + 22, a.Y + 22, lw, 150); refreshBtn.Location = new Point(a.X + 22 + lw - 80, a.Y + 178);
        for (int i = 0; i < 3; i++) modeBtns[i].Location = new Point(a.X + 22 + i * 100, a.Y + 218); lists.SetBounds(a.X + 22, a.Y + 256, lw, Math.Max(80, a.Height - 256 - 22));
        int x = a.X + 22 + lw + 36, y = a.Y + 50; playerBox.Location = new Point(x, y); kickBtn.Location = new Point(playerBox.Right + 22, y - 6); banBtn.Location = new Point(kickBtn.Right + 6, y - 6); unbanBtn.Location = new Point(banBtn.Right + 6, y - 6);
        opBtn.Location = new Point(x, y + 40); deopBtn.Location = new Point(opBtn.Right + 6, y + 40); wlAddBtn.Location = new Point(deopBtn.Right + 6, y + 40); wlRemBtn.Location = new Point(wlAddBtn.Right + 6, y + 40);
        for (int i = 0; i < 4; i++) gm[i].Location = new Point(x + i * 102, y + 106);
        tpMeBtn.Location = new Point(x, y + 172); tpToBox.Location = new Point(tpMeBtn.Right + 22, y + 176); tpGoBtn.Location = new Point(tpToBox.Right + 10, y + 172);
        itemBox.Location = new Point(x, y + 242); countBox.Location = new Point(itemBox.Right + 30, y + 242); giveBtn.Location = new Point(countBox.Right + 22, y + 234);
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        int lw = Math.Max(300, Math.Min(420, a.Width / 3)), x = a.X + 22 + lw + 36, y = a.Y + 50;
        Head(g, "PICK A PLAYER", x, y - 28); Head(g, "GAME MODE", x, y + 84); Head(g, "TELEPORT", x, y + 150); Head(g, "GIVE AN ITEM", x, y + 218);
        bool on = P.Connected; foreach (var c in Ctl) { if (c is Btn && c != refreshBtn) c.Enabled = on; }
    }
}

// ---------------------------------------------------------------------------------------------------- World
class McWorld : McView
{
    class Rule { public string Label; public string[] Names; public string Use = ""; public int State = -1; public Btn B; }
    readonly List<Rule> rules = new List<Rule>(); readonly Btn[] diff = new Btn[4], timeB = new Btn[4], wx = new Btn[3], dgm = new Btn[4]; readonly TextBox xBox, yBox, zBox; readonly Btn spawnBtn, rulesBtn;
    public McWorld(McPage p) : base(p)
    {
        Name = "World";
        string[] d = { "Peaceful", "Easy", "Normal", "Hard" }; for (int i = 0; i < 4; i++) { string m = d[i].ToLowerInvariant(); diff[i] = Button(d[i], 96, delegate { P.Run("difficulty " + m); }); }
        string[] t = { "Day", "Noon", "Night", "Midnight" }; for (int i = 0; i < 4; i++) { string m = t[i].ToLowerInvariant(); timeB[i] = Button(t[i], 96, delegate { P.Run("time set " + m); }); }
        string[] w = { "Clear", "Rain", "Thunder" }; for (int i = 0; i < 3; i++) { string m = w[i].ToLowerInvariant(); wx[i] = Button(w[i], 96, delegate { P.Run("weather " + m); }); }
        string[] g = { "Survival", "Creative", "Adventure", "Spectator" }; for (int i = 0; i < 4; i++) { string m = g[i].ToLowerInvariant(); dgm[i] = Button(g[i], 96, delegate { P.Run("defaultgamemode " + m); }); }
        xBox = Field("x", 70); yBox = Field("y", 70); zBox = Field("z", 70); spawnBtn = Button("Set world spawn", 140, delegate { int a, b, c; if (!int.TryParse(xBox.Text, out a) || !int.TryParse(yBox.Text, out b) || !int.TryParse(zBox.Text, out c)) { P.Say("Type three whole numbers for x, y and z."); return; } P.Run("setworldspawn " + a + " " + b + " " + c); });
        rulesBtn = Button("Refresh", 80, ReadRules);
        string[][] defs = { new[] { "Keep inventory", "keepInventory", "keep_inventory" }, new[] { "Mob griefing", "mobGriefing", "mob_griefing" }, new[] { "Day/night cycle", "doDaylightCycle", "advance_time", "do_daylight_cycle" }, new[] { "Weather cycle", "doWeatherCycle", "advance_weather", "do_weather_cycle" },
            new[] { "Mob spawning", "doMobSpawning", "spawn_mobs", "do_mob_spawning" }, new[] { "Natural healing", "naturalRegeneration", "natural_health_regeneration", "natural_regeneration" }, new[] { "Phantoms", "doInsomnia", "spawn_phantoms", "do_insomnia" }, new[] { "Instant respawn", "doImmediateRespawn", "immediate_respawn", "do_immediate_respawn" },
            new[] { "Fire spreads", "doFireTick", "fire_spread_radius_around_player", "do_fire_tick" }, new[] { "Show coordinates", "reducedDebugInfo", "reduced_debug_info" }, new[] { "Command output", "sendCommandFeedback", "send_command_feedback" }, new[] { "Announce deaths", "showDeathMessages", "show_death_messages" } };
        foreach (var df in defs) { var r = new Rule { Label = df[0], Names = new string[df.Length - 1] }; Array.Copy(df, 1, r.Names, 0, r.Names.Length); var rr = r; r.B = Button(df[0], 170, delegate { Toggle(rr); }); rules.Add(r); }
    }
    void ReadRules()
    {
        if (!P.Connected) return;
        ThreadPool.QueueUserWorkItem(delegate
        {
            foreach (var r in rules)
            {
                int state = -1; string use = r.Use;
                foreach (string n in use.Length > 0 ? new[] { use } : r.Names) { string a = P.Ask("gamerule " + n); if (a == null) return; var m = Regex.Match(a, "currently set to:?\\s*(\\w+)", RegexOptions.IgnoreCase); if (m.Success) { use = n; string v = m.Groups[1].Value.ToLowerInvariant(); state = v == "true" ? 1 : v == "false" ? 0 : -1; break; } }
                var rr = r; int st = state; string u = use; P.Ui(delegate { rr.State = st; rr.Use = u; Sync(); });
            }
        });
    }
    void Toggle(Rule r)
    {
        if (!P.Connected) { P.Say("Connect with RCON first."); return; }
        if (r.Use.Length == 0 || r.State < 0) { P.Say(r.Label + ": this server does not report that rule (it may not exist in this Minecraft version)."); return; }
        P.Run("gamerule " + r.Use + " " + (r.State == 1 ? "false" : "true")); r.State = r.State == 1 ? 0 : 1; Sync();
    }
    void Sync() { foreach (var r in rules) { r.B.Enabled = P.Connected && r.State >= 0; r.B.Selected = r.State == 1; r.B.Text = r.Label + (r.State < 0 ? "" : r.State == 1 ? ": on" : ": off"); r.B.Invalidate(); } }
    public override void Shown() { Sync(); bool any = false; foreach (var r in rules) if (r.State >= 0) any = true; if (!any) ReadRules(); }
    public override void Place(Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 44;
        for (int i = 0; i < 4; i++) diff[i].Location = new Point(x + i * 102, y); for (int i = 0; i < 4; i++) timeB[i].Location = new Point(x + i * 102, y + 70); for (int i = 0; i < 3; i++) wx[i].Location = new Point(x + i * 102, y + 140);
        for (int i = 0; i < 4; i++) dgm[i].Location = new Point(x + i * 102, y + 210); xBox.Location = new Point(x, y + 286); yBox.Location = new Point(x + 94, y + 286); zBox.Location = new Point(x + 188, y + 286); spawnBtn.Location = new Point(x + 282, y + 280);
        int gx = a.X + 480, cols = Math.Max(2, Math.Min(3, (a.Right - 22 - gx) / 180)); rulesBtn.Location = new Point(a.Right - 22 - rulesBtn.Width, a.Y + 12);
        for (int i = 0; i < rules.Count; i++) rules[i].B.Location = new Point(gx + (i % cols) * 182, a.Y + 44 + (i / cols) * 38);
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 44; Head(g, "DIFFICULTY", x, y - 26); Head(g, "TIME OF DAY", x, y + 44); Head(g, "WEATHER", x, y + 114); Head(g, "GAME MODE FOR NEW PLAYERS", x, y + 184); Head(g, "WORLD SPAWN (where new players appear)", x, y + 258);
        Head(g, "GAMERULES  (click one to flip it)", a.X + 480, a.Y + 18); bool on = P.Connected;
        foreach (var b in diff) b.Enabled = on; foreach (var b in timeB) b.Enabled = on; foreach (var b in wx) b.Enabled = on; foreach (var b in dgm) b.Enabled = on; spawnBtn.Enabled = on; rulesBtn.Enabled = on;
    }
}

// ---------------------------------------------------------------------------------------------------- Console
class McConsole : McView
{
    readonly TextBox consoleBox, cmdBox; readonly Btn sendBtn, saveCmdBtn, clearBtn, logBtn; readonly List<Btn> saved = new List<Btn>(); readonly List<string[]> cmds = new List<string[]>(); readonly List<string> hist = new List<string>(); int hi; bool logOn; long logPos = -1; DateTime lastLog = DateTime.MinValue; string logSrc = "";
    static string File_ { get { return McStore.Path_("mccmds.txt"); } }
    public McConsole(McPage p) : base(p)
    {
        Name = "Console";
        consoleBox = new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BorderStyle = BorderStyle.None, BackColor = Theme.ConsoleBg, ForeColor = Theme.Text, Font = new Font("Consolas", 9.5f), WordWrap = true }; Ctl.Add(consoleBox);
        cmdBox = Field("Type a command, e.g. list  (no slash needed)", 400); sendBtn = Button("Send", 80, Send, true); saveCmdBtn = Button("Save as a button", 130, SaveButton); clearBtn = Button("Clear", 70, delegate { P.consoleText.Length = 0; consoleBox.Clear(); }); logBtn = Button("Live log: off", 110, delegate { logOn = !logOn; logPos = -1; logBtn.Text = logOn ? "Live log: on" : "Live log: off"; logBtn.Selected = logOn; logBtn.Invalidate(); });
        cmdBox.KeyDown += delegate (object s, KeyEventArgs e) { if (e.KeyCode == Keys.Enter) { Send(); e.SuppressKeyPress = true; } else if (e.KeyCode == Keys.Up && hist.Count > 0) { hi = Math.Max(0, hi - 1); cmdBox.Text = hist[hi]; cmdBox.SelectionStart = cmdBox.Text.Length; e.SuppressKeyPress = true; } else if (e.KeyCode == Keys.Down && hist.Count > 0) { hi = Math.Min(hist.Count, hi + 1); cmdBox.Text = hi < hist.Count ? hist[hi] : ""; e.SuppressKeyPress = true; } };
        try { foreach (string line in File.ReadAllLines(File_)) { int i = line.IndexOf('|'); if (i > 0) cmds.Add(new[] { line.Substring(0, i), line.Substring(i + 1) }); } } catch { }
        P.ConsoleChanged += delegate { if (consoleBox.Visible) { consoleBox.Text = P.consoleText.ToString(); consoleBox.SelectionStart = consoleBox.Text.Length; consoleBox.ScrollToCaret(); } };
        consoleBox.Text = P.consoleText.ToString(); BuildSaved();
    }
    void Send() { string c = cmdBox.Text.Trim(); if (c.StartsWith("/")) c = c.Substring(1); if (c.Length == 0) return; hist.Add(c); hi = hist.Count; cmdBox.Text = ""; P.Run(c); }
    void SaveButton()
    {
        string c = cmdBox.Text.Trim(); if (c.StartsWith("/")) c = c.Substring(1); if (c.Length == 0) { P.Say("Type the command in the box first, then press 'Save as a button'."); return; }
        string name = McAsk.Text(P.FindForm(), "Save as a button", "Name for the button that runs  " + c, c.Length > 18 ? c.Substring(0, 18) : c); if (string.IsNullOrEmpty(name)) return;
        cmds.Add(new[] { name.Replace("|", " "), c }); Persist(); BuildSaved(); P.Changed();
    }
    void Persist() { if (Program.Testing) return; try { Directory.CreateDirectory(Path.GetDirectoryName(File_)); var sb = new StringBuilder(); foreach (var c in cmds) sb.Append(c[0] + "|" + c[1] + "\r\n"); File.WriteAllText(File_, sb.ToString()); } catch { } }
    void BuildSaved()
    {
        foreach (var b in saved) { Ctl.Remove(b); if (b.Parent != null) b.Parent.Controls.Remove(b); b.Dispose(); } saved.Clear();
        foreach (var c in cmds)
        {
            var cc = c; var b = new Btn(c[0]) { Width = Math.Max(80, TextRenderer.MeasureText(c[0], Theme.Small).Width + 28), Height = 30, Font = Theme.Small }; b.Click += delegate { P.Run(cc[1]); };
            var menu = new ContextMenuStrip(); menu.Items.Add("Remove this button", null, delegate { cmds.Remove(cc); Persist(); BuildSaved(); P.Place_(); P.Changed(); }); b.ContextMenuStrip = menu; b.Visible = false; saved.Add(b); Ctl.Add(b); if (P != null) P.Controls.Add(b);
        }
    }
    public override void Place(Rectangle a)
    {
        int x = a.X + 22; cmdBox.Location = new Point(x, a.Y + 40); cmdBox.Width = Math.Max(200, a.Width - 44 - 90 - 140 - 80 - 120 - 40); sendBtn.Location = new Point(cmdBox.Right + 22, a.Y + 34); saveCmdBtn.Location = new Point(sendBtn.Right + 8, a.Y + 34); clearBtn.Location = new Point(saveCmdBtn.Right + 8, a.Y + 34); logBtn.Location = new Point(clearBtn.Right + 8, a.Y + 34);
        int px = x, py = a.Y + 86; foreach (var b in saved) { b.Visible = true; if (px + b.Width > a.Right - 22) { px = x; py += 36; } b.Location = new Point(px, py); px += b.Width + 8; }
        int top = saved.Count > 0 ? py + 42 : a.Y + 86; consoleBox.SetBounds(x, top, a.Width - 44, Math.Max(60, a.Bottom - 22 - top));
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        Head(g, "COMMAND  (up and down arrows bring back earlier ones)", a.X + 22, a.Y + 16); if (saved.Count > 0) Head(g, "YOUR BUTTONS  (right-click one to remove it)", a.X + 22, a.Y + 74);
        sendBtn.Enabled = P.Connected;
    }
    public override void Shown() { consoleBox.Text = P.consoleText.ToString(); consoleBox.SelectionStart = consoleBox.Text.Length; consoleBox.ScrollToCaret(); }
    public override void Tick()
    {
        if (!logOn || (DateTime.Now - lastLog).TotalSeconds < 2) return; lastLog = DateTime.Now; string path = P.Cfg("log", "").Trim();
        ThreadPool.QueueUserWorkItem(delegate
        {
            try
            {
                string text = ""; long pos = logPos;
                if (path.Length > 0) using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete)) { if (pos < 0 || pos > fs.Length) pos = Math.Max(0, fs.Length - 6000); fs.Seek(pos, SeekOrigin.Begin); var buf = new byte[Math.Min(200000, fs.Length - pos)]; int n = fs.Read(buf, 0, buf.Length); pos += n; text = Encoding.UTF8.GetString(buf, 0, n); }
                else if (P.HelperSet) { string err; string res = P.Helper("LOG " + pos, out err); if (err.Length > 0) throw new IOException(err); int nl = res.IndexOf('\n'); if (res.StartsWith("pos=") && nl > 0) { long.TryParse(res.Substring(4, nl - 4), out pos); text = res.Substring(nl + 1); } }
                else throw new IOException("set a log file path or the helper in Settings first");
                long np = pos; P.Ui(delegate { logPos = np; if (text.Trim().Length > 0) P.Say(text.TrimEnd()); });
            }
            catch (Exception ex) { P.Ui(delegate { logOn = false; logBtn.Text = "Live log: off"; logBtn.Selected = false; P.Say("Live log: " + ex.Message); }); }
        });
    }
    public override void Theme_() { base.Theme_(); consoleBox.BackColor = Theme.ConsoleBg; consoleBox.ForeColor = Theme.Text; }
}

// ---------------------------------------------------------------------------------------------------- Backups
class McBackups : McView
{
    readonly Btn backupBtn, saveBtn, openBtn, restoreBtn, deleteBtn, bkToggle; readonly TextBox hoursBox, keepBox; readonly McList list = new McList { Widths = new[] { 0.5f, 0.2f, 0.3f }, Heads = new[] { "BACKUP", "SIZE", "WHEN" }, Empty = "No backups yet. Press 'Back up the world'." }; readonly McGraph sizeGraph = new McGraph { Title = "World size over time", Unit = " MB", Tone = Theme.AccentSoft }; string sizeText = ""; DateTime lastSize = DateTime.MinValue;
    public McBackups(McPage p) : base(p)
    {
        Name = "Backups"; backupBtn = Button("Back up the world", 150, delegate { P.BackupNow(false); }, true); saveBtn = Button("Save now", 100, delegate { P.Run("save-all flush"); }); openBtn = Button("Open the folder", 130, delegate { try { Directory.CreateDirectory(P.BackupDir); System.Diagnostics.Process.Start("explorer.exe", "\"" + P.BackupDir + "\""); } catch { } });
        restoreBtn = Button("Restore the selected one…", 190, Restore); deleteBtn = Button("Delete the selected one", 170, Delete);
        bkToggle = Button("Automatic backups: off", 190, delegate { P.au["bkon"] = McStore.Get(P.au, "bkon", "0") == "1" ? "0" : "1"; SaveAuto(); P.RefreshKeepAlive(); Sync(); }); hoursBox = Field("hours", 60); keepBox = Field("keep", 60);
        hoursBox.Leave += delegate { SaveAuto(); }; keepBox.Leave += delegate { SaveAuto(); };
        Ctl.Add(list); Ctl.Add(sizeGraph);
    }
    void SaveAuto() { int h, k; if (int.TryParse(hoursBox.Text, out h) && h >= 1) P.au["bkhours"] = h.ToString(CultureInfo.InvariantCulture); if (int.TryParse(keepBox.Text, out k) && k >= 1) P.au["bkkeep"] = k.ToString(CultureInfo.InvariantCulture); McStore.Write("mcauto.txt", P.au); }
    void Sync() { bool on = McStore.Get(P.au, "bkon", "0") == "1"; bkToggle.Text = on ? "Automatic backups: on" : "Automatic backups: off"; bkToggle.Selected = on; bkToggle.Invalidate(); }
    void Load()
    {
        var rows = new List<McRow>(); try { if (Directory.Exists(P.BackupDir)) { var fi = new List<FileInfo>(new DirectoryInfo(P.BackupDir).GetFiles("*.zip")); fi.Sort((a, b) => b.LastWriteTime.CompareTo(a.LastWriteTime)); foreach (var f in fi) rows.Add(new McRow { Cols = new[] { f.Name, McSize(f.Length), f.LastWriteTime.ToString("MMM d, h:mm tt", CultureInfo.InvariantCulture) }, Tag = f.FullName }); } } catch { }
        list.SetRows(rows);
        string dir = P.ServerDir; if (dir.Length > 0 && Directory.Exists(dir) && (DateTime.Now - lastSize).TotalHours > 1 && !(Program.Testing))
        {
            lastSize = DateTime.Now; ThreadPool.QueueUserWorkItem(delegate
            {
                long total = 0; string lvl = McBackup.LevelName(dir); foreach (string s in new[] { "", "_nether", "_the_end" }) { string d = Path.Combine(dir, lvl + s); if (Directory.Exists(d)) foreach (var f in DcScan.Walk(d, null)) { try { total += f.Length; } catch { } } }
                P.Ui(delegate { sizeText = "The world is " + McSize(total) + " now"; var h = McStore.Read("mcsize.txt"); h[DateTime.Now.ToString("yyyyMMdd")] = (total >> 20).ToString(CultureInfo.InvariantCulture); McStore.Write("mcsize.txt", h); FillSizes(h); P.Changed(); });
            });
        }
        else FillSizes(McStore.Read("mcsize.txt"));
    }
    void FillSizes(Dictionary<string, string> h) { var keys = new List<string>(h.Keys); keys.Sort(); sizeGraph.Data.Clear(); foreach (string k in keys) { float v; if (float.TryParse(h[k], out v)) sizeGraph.Data.Add(v); } sizeGraph.Invalidate(); }
    internal static string McSize(long b) { return DcScan.Fmt(b); }
    void Restore()
    {
        if (list.Selected < 0 || list.Selected >= list.Rows.Count) { P.Say("Pick a backup in the list first."); return; } string zip = (string)list.Rows[list.Selected].Tag, dir = P.ServerDir;
        if (dir.Length == 0 || !Directory.Exists(dir)) { P.Say("Fill in the server's folder in Settings first."); return; }
        if (MessageBox.Show(P.FindForm(), "Restore " + Path.GetFileName(zip) + "?\r\n\r\nThe server must be stopped. The current world is renamed (not deleted) so you can get it back, and the backup is unpacked in its place.", "Minecraft Server", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK) return;
        P.Say("Checking that the server is stopped…");
        ThreadPool.QueueUserWorkItem(delegate
        {
            var st = McNet.Ping(P.Host, P.GamePort, 2500); if (st.Online) { P.Ui(delegate { P.Say("The server is still running: stop it first (Overview > Save and stop), then restore."); }); return; }
            try { McBackup.Restore(zip, dir, s => P.Ui(delegate { P.Say(s); })); P.Ui(delegate { P.Event("Restored " + Path.GetFileName(zip)); }); }
            catch (Exception ex) { P.Ui(delegate { P.Say("Restore failed: " + ex.Message); }); }
        });
    }
    void Delete()
    {
        if (list.Selected < 0 || list.Selected >= list.Rows.Count) { P.Say("Pick a backup in the list first."); return; } string zip = (string)list.Rows[list.Selected].Tag;
        if (MessageBox.Show(P.FindForm(), "Delete " + Path.GetFileName(zip) + "?\r\n\r\nIt goes to the Recycle Bin.", "Minecraft Server", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
        try { Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(zip, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin); } catch (Exception ex) { P.Say("Could not delete it: " + ex.Message); } Load();
    }
    public override void Shown() { hoursBox.Text = McStore.Get(P.au, "bkhours", "6"); keepBox.Text = McStore.Get(P.au, "bkkeep", "10"); Sync(); Load(); }
    public override void Tick() { }
    public override void Place(Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 20; backupBtn.Location = new Point(x, y); saveBtn.Location = new Point(backupBtn.Right + 8, y); openBtn.Location = new Point(saveBtn.Right + 8, y);
        int lw = Math.Max(420, a.Width - 44 - 360); list.SetBounds(x, y + 84, lw, Math.Max(100, a.Height - 84 - 20 - 56 - 22)); restoreBtn.Location = new Point(x, list.Bottom + 12); deleteBtn.Location = new Point(restoreBtn.Right + 8, list.Bottom + 12);
        int rx = x + lw + 28, rw = a.Right - 22 - rx; sizeGraph.SetBounds(rx, y + 84, rw, 110); bkToggle.Location = new Point(rx, y + 262); hoursBox.Location = new Point(rx, y + 322); keepBox.Location = new Point(rx + 110, y + 322);
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 20, lw = Math.Max(420, a.Width - 44 - 360), rx = x + lw + 28;
        Head(g, "YOUR BACKUPS  (in Documents\\Minecraft backups)", x, y + 62); Head(g, "THE WORLD", rx, y + 62); TextRenderer.DrawText(g, sizeText.Length > 0 ? sizeText : "Fill in the server folder in Settings to measure the world.", Theme.UI, new Rectangle(rx, y + 202, a.Right - 22 - rx, 20), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        Head(g, "AUTOMATIC BACKUPS", rx, y + 240); Label(g, "every ... hours", hoursBox.Left, hoursBox.Top - 20); Label(g, "keep the last ...", keepBox.Left, keepBox.Top - 20);
        TextRenderer.DrawText(g, "Backups only run while CENOHWARE is open and connected.", Theme.Small, new Rectangle(rx, y + 372, a.Right - 22 - rx, 30), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
        backupBtn.Enabled = P.Connected && !P.working; saveBtn.Enabled = P.Connected; restoreBtn.Enabled = list.Selected >= 0; deleteBtn.Enabled = list.Selected >= 0;
    }
}

// ---------------------------------------------------------------------------------------------------- Automation
class McAutomation : McView
{
    readonly Btn restartOn, announceOn; readonly TextBox timeBox, everyBox, msgBox;
    public McAutomation(McPage p) : base(p)
    {
        Name = "Automation"; restartOn = Button("Restart every day: off", 200, delegate { Flip("rson"); }); announceOn = Button("Announcement: off", 200, delegate { Flip("anon"); });
        timeBox = Field("04:00", 80); everyBox = Field("minutes", 80); msgBox = Field("What to announce, e.g. Join our Discord!", 420);
        timeBox.Leave += delegate { Save(); }; everyBox.Leave += delegate { Save(); }; msgBox.Leave += delegate { Save(); };
    }
    void Flip(string k) { P.au[k] = McStore.Get(P.au, k, "0") == "1" ? "0" : "1"; Save(); P.RefreshKeepAlive(); Sync(); }
    void Save()
    {
        var m = Regex.Match(timeBox.Text.Trim(), "^(\\d{1,2}):(\\d{2})$"); if (m.Success) { int h = int.Parse(m.Groups[1].Value), mi = int.Parse(m.Groups[2].Value); if (h < 24 && mi < 60) P.au["rstime"] = h.ToString("00") + ":" + mi.ToString("00"); }
        int e; if (int.TryParse(everyBox.Text.Trim(), out e) && e >= 1) P.au["anmin"] = e.ToString(CultureInfo.InvariantCulture); P.au["anmsg"] = msgBox.Text.Trim().Replace("\r", " "); McStore.Write("mcauto.txt", P.au); P.RefreshKeepAlive();
    }
    void Sync() { bool r = McStore.Get(P.au, "rson", "0") == "1", a = McStore.Get(P.au, "anon", "0") == "1"; restartOn.Text = r ? "Restart every day: on" : "Restart every day: off"; restartOn.Selected = r; announceOn.Text = a ? "Announcement: on" : "Announcement: off"; announceOn.Selected = a; restartOn.Invalidate(); announceOn.Invalidate(); }
    public override void Shown() { timeBox.Text = McStore.Get(P.au, "rstime", "04:00"); everyBox.Text = McStore.Get(P.au, "anmin", "30"); msgBox.Text = McStore.Get(P.au, "anmsg", ""); Sync(); }
    public override void Place(Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 60; restartOn.Location = new Point(x, y); timeBox.Location = new Point(x + 260, y + 4);
        announceOn.Location = new Point(x, y + 150); everyBox.Location = new Point(x + 260, y + 154); msgBox.Location = new Point(x + 380, y + 154);
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 60; Head(g, "DAILY RESTART", x, y - 30); TextRenderer.DrawText(g, "Restarts the server once a day at the time shown (24 hour clock), with a 60 second warning in the game. Uses the helper if it is set up, otherwise the game's own restart command.", Theme.Small, new Rectangle(x, y + 40, 700, 36), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
        Label(g, "at (24 hour clock)", timeBox.Left, timeBox.Top - 20);
        Head(g, "ANNOUNCEMENT", x, y + 120); TextRenderer.DrawText(g, "Says the message to everyone in the game every few minutes.", Theme.Small, new Rectangle(x, y + 190, 700, 20), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        Label(g, "every ... minutes", everyBox.Left, everyBox.Top - 20); Label(g, "message", msgBox.Left, msgBox.Top - 20);
        TextRenderer.DrawText(g, "Automatic backups are in the Backups section. All schedules only run while CENOHWARE is open and connected to the server.", Theme.Small, new Rectangle(x, y + 250, 760, 36), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
    }
}

// ---------------------------------------------------------------------------------------------------- Files: server.properties and plugins / mods
class McFiles : McView
{
    static readonly string[][] Keys = {
        new[] { "motd", "Server message (MOTD)", "text" }, new[] { "max-players", "Most players", "text" }, new[] { "difficulty", "Difficulty", "peaceful,easy,normal,hard" }, new[] { "gamemode", "Default game mode", "survival,creative,adventure,spectator" },
        new[] { "pvp", "Players can hurt each other", "bool" }, new[] { "white-list", "Whitelist on", "bool" }, new[] { "enforce-whitelist", "Kick non-whitelisted at once", "bool" }, new[] { "online-mode", "Check Minecraft accounts", "bool" },
        new[] { "allow-flight", "Allow flying (mods)", "bool" }, new[] { "hardcore", "Hardcore", "bool" }, new[] { "enable-command-block", "Command blocks", "bool" }, new[] { "force-gamemode", "Force game mode on join", "bool" },
        new[] { "spawn-monsters", "Monsters spawn", "bool" }, new[] { "spawn-animals", "Animals spawn", "bool" }, new[] { "allow-nether", "Nether open", "bool" }, new[] { "view-distance", "View distance", "text" }, new[] { "simulation-distance", "Simulation distance", "text" }, new[] { "spawn-protection", "Spawn protection radius", "text" } };
    readonly Btn propsTab, modsTab, loadBtn, saveBtn, addBtn, removeBtn, folderBtn; readonly McList mods = new McList { Widths = new[] { 0.55f, 0.2f, 0.25f }, Heads = new[] { "PLUGIN OR MOD", "WHERE", "SIZE" }, Empty = "Nothing found. Set the server folder in Settings." };
    readonly Dictionary<string, Control> inputs = new Dictionary<string, Control>(); readonly Dictionary<string, string> orig = new Dictionary<string, string>(); bool showMods; string note = "";
    public McFiles(McPage p) : base(p)
    {
        Name = "Files"; propsTab = Button("Server settings", 130, delegate { showMods = false; Vis(); }); modsTab = Button("Plugins and mods", 150, delegate { showMods = true; Vis(); LoadMods(); });
        loadBtn = Button("Reload", 80, LoadProps); saveBtn = Button("Save to server.properties", 190, SaveProps, true); addBtn = Button("Add a .jar…", 110, AddJar); removeBtn = Button("Remove the selected one", 180, RemoveJar); folderBtn = Button("Open the folder", 130, delegate { OpenFolder(); });
        foreach (var k in Keys)
        {
            if (k[2] == "bool") { var b = new Btn("off") { Width = 70, Height = 28, Font = Theme.Small }; b.Click += delegate { b.Selected = !b.Selected; b.Text = b.Selected ? "on" : "off"; b.Invalidate(); }; inputs[k[0]] = b; Ctl.Add(b); }
            else if (k[2] == "text") { var t = Field("", 220); inputs[k[0]] = t; }
            else { var opts = k[2].Split(','); var c = new Btn(opts[0]) { Width = 150, Height = 28, Font = Theme.Small, Tag = opts }; c.Click += delegate { int i = Array.IndexOf(opts, c.Text); c.Text = opts[(i + 1) % opts.Length]; c.Invalidate(); }; inputs[k[0]] = c; Ctl.Add(c); }
        }
        Ctl.Add(mods);
    }
    string PropsPath { get { return Path.Combine(P.ServerDir, "server.properties"); } }
    void LoadProps()
    {
        orig.Clear(); try { foreach (string line in File.ReadAllLines(PropsPath)) { int i = line.IndexOf('='); if (i > 0 && !line.StartsWith("#")) orig[line.Substring(0, i)] = line.Substring(i + 1); } note = "Loaded from " + PropsPath; }
        catch (Exception ex) { note = P.ServerDir.Length == 0 ? "Fill in the server's folder in Settings first." : "Cannot read server.properties: " + ex.Message; }
        foreach (var k in Keys) { string v; orig.TryGetValue(k[0], out v); v = v ?? ""; var c = inputs[k[0]]; if (c is Btn && c.Tag is string[]) { var opts = (string[])c.Tag; c.Text = Array.IndexOf(opts, v) >= 0 ? v : opts[0]; c.Invalidate(); } else if (c is Btn) { var b = (Btn)c; b.Selected = v == "true"; b.Text = b.Selected ? "on" : "off"; b.Invalidate(); } else c.Text = v; }
        P.Changed();
    }
    void SaveProps()
    {
        if (!File.Exists(PropsPath)) { note = "No server.properties found: set the server folder in Settings."; P.Changed(); return; }
        if (MessageBox.Show(P.FindForm(), "Write these settings to server.properties?\r\n\r\nA copy of the old file is kept as server.properties.bak. The server needs a restart before it uses them.", "Minecraft Server", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
        try
        {
            File.Copy(PropsPath, PropsPath + ".bak", true); var lines = new List<string>(File.ReadAllLines(PropsPath)); var done = new HashSet<string>();
            for (int i = 0; i < lines.Count; i++) { int e = lines[i].IndexOf('='); if (e <= 0 || lines[i].StartsWith("#")) continue; string k = lines[i].Substring(0, e); Control c; if (inputs.TryGetValue(k, out c)) { lines[i] = k + "=" + Val(c); done.Add(k); } }
            foreach (var k in Keys) if (!done.Contains(k[0]) && Val(inputs[k[0]]).Length > 0) lines.Add(k[0] + "=" + Val(inputs[k[0]]));
            File.WriteAllLines(PropsPath, lines.ToArray()); note = "Saved. Restart the server for the changes to apply."; P.Say("server.properties saved (restart the server to apply it)."); P.Event("server.properties changed");
        }
        catch (Exception ex) { note = "Could not save: " + ex.Message; }
        P.Changed();
    }
    static string Val(Control c) { if (c is Btn && c.Tag is string[]) return c.Text; if (c is Btn) return ((Btn)c).Selected ? "true" : "false"; return c.Text.Trim(); }
    void LoadMods()
    {
        var rows = new List<McRow>(); string dir = P.ServerDir; if (dir.Length > 0) foreach (string sub in new[] { "plugins", "mods" }) { string d = Path.Combine(dir, sub); if (!Directory.Exists(d)) continue; try { foreach (var f in new DirectoryInfo(d).GetFiles("*.jar")) rows.Add(new McRow { Cols = new[] { f.Name, sub, DcScan.Fmt(f.Length) }, Tag = f.FullName }); } catch { } }
        rows.Sort((a, b) => string.Compare(a.Cols[0], b.Cols[0], StringComparison.OrdinalIgnoreCase)); mods.SetRows(rows);
    }
    string ModDir() { string dir = P.ServerDir; if (dir.Length == 0) return ""; foreach (string sub in new[] { "plugins", "mods" }) if (Directory.Exists(Path.Combine(dir, sub))) return Path.Combine(dir, sub); return ""; }
    void AddJar()
    {
        string d = ModDir(); if (d.Length == 0) { note = "No plugins or mods folder found in the server folder."; P.Changed(); return; }
        using (var o = new OpenFileDialog { Title = "Pick plugin or mod files", Filter = "Java files|*.jar", Multiselect = true }) { if (o.ShowDialog(P.FindForm()) != DialogResult.OK) return; foreach (string f in o.FileNames) { try { File.Copy(f, Path.Combine(d, Path.GetFileName(f)), false); P.Say("Added " + Path.GetFileName(f) + " (restart the server to load it)."); } catch (Exception ex) { P.Say("Could not add " + Path.GetFileName(f) + ": " + ex.Message); } } }
        LoadMods();
    }
    void RemoveJar()
    {
        if (mods.Selected < 0 || mods.Selected >= mods.Rows.Count) { note = "Pick one in the list first."; P.Changed(); return; } string f = (string)mods.Rows[mods.Selected].Tag;
        if (MessageBox.Show(P.FindForm(), "Remove " + Path.GetFileName(f) + " from the server?\r\n\r\nIt goes to the Recycle Bin. Restart the server for it to take effect.", "Minecraft Server", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
        try { Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(f, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin); } catch (Exception ex) { P.Say("Could not remove it: " + ex.Message); } LoadMods();
    }
    void OpenFolder() { string d = showMods ? ModDir() : P.ServerDir; if (d.Length > 0) try { System.Diagnostics.Process.Start("explorer.exe", "\"" + d + "\""); } catch { } }
    void Vis() { foreach (var c in inputs.Values) c.Visible = !showMods; mods.Visible = showMods; loadBtn.Visible = saveBtn.Visible = !showMods; addBtn.Visible = removeBtn.Visible = showMods; propsTab.Selected = !showMods; modsTab.Selected = showMods; propsTab.Invalidate(); modsTab.Invalidate(); P.Place_(); P.Changed(); }
    public override void Shown() { if (orig.Count == 0 && P.ServerDir.Length > 0) LoadProps(); Vis(); if (showMods) LoadMods(); }
    public override void Place(Rectangle a)
    {
        int x = a.X + 22; propsTab.Location = new Point(x, a.Y + 16); modsTab.Location = new Point(propsTab.Right + 8, a.Y + 16); folderBtn.Location = new Point(a.Right - 22 - folderBtn.Width, a.Y + 16);
        int colW = (a.Width - 44) / 2; for (int i = 0; i < Keys.Length; i++) { var c = inputs[Keys[i][0]]; int col = i % 2, row = i / 2; int cx = x + col * colW + 250; int cy = a.Y + 84 + row * 38; if (c is Btn) c.Location = new Point(cx, cy - 2); else c.Location = new Point(cx, cy + 2); if (c is TextBox) c.Width = Math.Max(120, colW - 270); }
        loadBtn.Location = new Point(x, a.Bottom - 22 - 30); saveBtn.Location = new Point(loadBtn.Right + 8, a.Bottom - 22 - 30);
        mods.SetBounds(x, a.Y + 60, a.Width - 44, Math.Max(100, a.Height - 60 - 70)); addBtn.Location = new Point(x, a.Bottom - 22 - 30); removeBtn.Location = new Point(addBtn.Right + 8, a.Bottom - 22 - 30);
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        int x = a.X + 22, colW = (a.Width - 44) / 2;
        if (!showMods) { for (int i = 0; i < Keys.Length; i++) { int col = i % 2, row = i / 2; TextRenderer.DrawText(g, Keys[i][1], Theme.UI, new Rectangle(x + col * colW, a.Y + 88 + row * 38, 240, 20), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis); } TextRenderer.DrawText(g, note, Theme.Small, new Rectangle(saveBtn.Right + 16, a.Bottom - 22 - 24, a.Width - 400, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis); }
        else TextRenderer.DrawText(g, note.Length > 0 ? note : "Changes need a server restart.", Theme.Small, new Rectangle(removeBtn.Right + 16, a.Bottom - 22 - 24, a.Width - 500, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        bool has = P.ServerDir.Length > 0; saveBtn.Enabled = loadBtn.Enabled = addBtn.Enabled = removeBtn.Enabled = has;
    }
}

// ---------------------------------------------------------------------------------------------------- Health
class McHealth : McView
{
    readonly Btn startBtn, stopBtn, restartBtn, killBtn, autoBtn, saveHelperBtn; string note = "";
    public McHealth(McPage p) : base(p)
    {
        Name = "Health"; startBtn = Button("Start", 80, delegate { Cmd("START"); }, true); stopBtn = Button("Stop (saves first)", 150, delegate { Cmd("STOP"); }); restartBtn = Button("Restart", 90, delegate { P.RestartServer(0, false); }); killBtn = Button("Force stop", 100, delegate { if (MessageBox.Show(P.FindForm(), "End the server process right now?\r\n\r\nNothing is saved first.", "Minecraft Server", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK) Cmd("KILL"); }); killBtn.Danger = true;
        autoBtn = Button("Restart it if it crashes: off", 230, delegate { string on = P.helperInfo.ContainsKey("autorestart") && P.helperInfo["autorestart"] == "1" ? "0" : "1"; Cmd("AUTORESTART " + on); });
        saveHelperBtn = Button("Save the helper program…", 190, SaveHelper);
        Ctl.Add(P.gLatency); Ctl.Add(P.gPlayers); Ctl.Add(P.gTps); Ctl.Add(P.gCpu); Ctl.Add(P.gRam);
    }
    void Cmd(string c) { note = "Working…"; P.Changed(); P.HelperAsync(c, (res, err) => { note = err.Length > 0 ? "Helper: " + err : "Helper: " + res.Replace("\r", "").Replace("\n", "  "); P.PingNow(); P.Changed(); }); }
    void SaveHelper()
    {
        using (var f = new FolderBrowserDialog { Description = "Pick a folder to save McHelper.exe into (then copy it to the server PC)" })
        {
            if (f.ShowDialog(P.FindForm()) != DialogResult.OK) return;
            try { using (var s = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("mchelper.exe")) { if (s == null) { note = "The helper is not built into this version."; P.Changed(); return; } using (var o = File.Create(Path.Combine(f.SelectedPath, "McHelper.exe"))) s.CopyTo(o); } note = "Saved McHelper.exe to " + f.SelectedPath; P.Say("Saved McHelper.exe to " + f.SelectedPath + ". Copy it to the server PC, run it once, fill in McHelper.cfg, run it again, then put its token in Settings."); }
            catch (Exception ex) { note = "Could not save it: " + ex.Message; }
            P.Changed();
        }
    }
    public override void Shown() { P.PingNow(); }
    public override void Place(Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 20, gw = (a.Width - 44 - 2 * 16) / 3, gh = 100;
        P.gLatency.SetBounds(x, y + 28, gw, gh); P.gPlayers.SetBounds(x + gw + 16, y + 28, gw, gh); P.gTps.SetBounds(x + 2 * (gw + 16), y + 28, gw, gh); P.gCpu.SetBounds(x, y + 28 + gh + 14, gw, gh); P.gRam.SetBounds(x + gw + 16, y + 28 + gh + 14, gw, gh);
        int by = y + 28 + 2 * (gh + 14) + 40; startBtn.Location = new Point(x, by); stopBtn.Location = new Point(startBtn.Right + 8, by); restartBtn.Location = new Point(stopBtn.Right + 8, by); killBtn.Location = new Point(restartBtn.Right + 8, by); autoBtn.Location = new Point(killBtn.Right + 28, by); saveHelperBtn.Location = new Point(x, by + 46);
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 20; Head(g, "HOW THE SERVER IS DOING  (refreshes while you look)", x, y);
        int gh = 100, by = y + 28 + 2 * (gh + 14); Head(g, "REMOTE CONTROL  (needs the helper on the server PC)", x, by + 14);
        bool hs = P.HelperSet; var i = P.helperInfo; string st; Color sc;
        if (!hs) { st = "The helper is not set up. It lets you start, stop and restart the server from here, and shows CPU and memory. See Settings."; sc = Theme.Dim; }
        else if (P.helperErr.Length > 0) { st = "Helper: " + P.helperErr; sc = Theme.Red; }
        else if (i.Count == 0) { st = "Asking the helper…"; sc = Theme.Dim; }
        else { st = (i.ContainsKey("running") && i["running"] == "1" ? "The server process is running" + (i.ContainsKey("uptimeSec") ? " (up " + Up(i["uptimeSec"]) + ")" : "") : "The server process is NOT running") + (i.ContainsKey("diskFreeGB") ? "   ·   disk: " + i["diskFreeGB"] + " GB free of " + i["diskTotalGB"] + " GB" : "") + (i.ContainsKey("crashes") && i["crashes"] != "0" ? "   ·   restarted after " + i["crashes"] + " crash(es)" : ""); sc = i.ContainsKey("running") && i["running"] == "1" ? Theme.Green : Theme.Red; }
        TextRenderer.DrawText(g, st, Theme.UIB, new Rectangle(x + 360, by + 12, a.Width - 400, 22), sc, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        TextRenderer.DrawText(g, note.Length > 0 ? note : (hs ? "" : "Helper and graphs need a connection (Settings). TPS needs a Paper or Spigot server."), Theme.Small, new Rectangle(x + 220, by + 54, a.Width - 260, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        foreach (var b in new Btn[] { startBtn, stopBtn, killBtn, autoBtn }) b.Enabled = hs; restartBtn.Enabled = (hs || P.Connected) && !P.working; autoBtn.Text = i.ContainsKey("autorestart") && i["autorestart"] == "1" ? "Restart it if it crashes: on" : "Restart it if it crashes: off"; autoBtn.Selected = i.ContainsKey("autorestart") && i["autorestart"] == "1";
    }
    static string Up(string sec) { int s; int.TryParse(sec, out s); if (s < 3600) return (s / 60) + " min"; if (s < 86400) return (s / 3600) + " h " + (s % 3600 / 60) + " min"; return (s / 86400) + " d " + (s % 86400 / 3600) + " h"; }
}

// ---------------------------------------------------------------------------------------------------- Settings
class McSettings : McView
{
    readonly TextBox hostBox, portBox, rconBox, passBox, hportBox, tokenBox, logBox, serverBox, meBox; readonly Btn saveBtn, autoBtn, alertBtn; string note = "";
    public McSettings(McPage p) : base(p)
    {
        Name = "Settings"; hostBox = Field("Server PC address, e.g. 192.168.1.50", 300); portBox = Field("25565", 80); rconBox = Field("25575", 80); passBox = Field("RCON password", 220, true); hportBox = Field("25580", 80); tokenBox = Field("Helper token (from the helper)", 300, true);
        logBox = Field("Optional: path to logs\\latest.log (a shared folder)", 460); serverBox = Field("Optional: the server's folder, shared, e.g. \\\\PC\\minecraft", 460); meBox = Field("Your player name", 200);
        saveBtn = Button("Save", 100, Save, true); autoBtn = Button("Connect when CENOHWARE starts: off", 280, delegate { autoBtn.Selected = !autoBtn.Selected; Txt(); }); alertBtn = Button("Notify me when players join or leave: off", 320, delegate { alertBtn.Selected = !alertBtn.Selected; Txt(); });
    }
    void Txt() { autoBtn.Text = "Connect when CENOHWARE starts: " + (autoBtn.Selected ? "on" : "off"); alertBtn.Text = "Notify me when players join or leave: " + (alertBtn.Selected ? "on" : "off"); autoBtn.Invalidate(); alertBtn.Invalidate(); }
    public override void Shown()
    {
        var c = P.cfg; hostBox.Text = McStore.Get(c, "host", ""); portBox.Text = McStore.Get(c, "port", "25565"); rconBox.Text = McStore.Get(c, "rcon", "25575"); passBox.Text = McStore.Unprotect(McStore.Get(c, "pass", "")); hportBox.Text = McStore.Get(c, "hport", "25580"); tokenBox.Text = McStore.Unprotect(McStore.Get(c, "tokenp", ""));
        logBox.Text = McStore.Get(c, "log", ""); serverBox.Text = McStore.Get(c, "server", ""); meBox.Text = McStore.Get(c, "me", ""); autoBtn.Selected = McStore.Get(c, "auto", "0") == "1"; alertBtn.Selected = McStore.Get(c, "alerts", "0") == "1"; Txt();
    }
    void Save()
    {
        var c = P.cfg; c["host"] = hostBox.Text.Trim(); c["port"] = portBox.Text.Trim(); c["rcon"] = rconBox.Text.Trim(); c["pass"] = McStore.Protect(passBox.Text); c["hport"] = hportBox.Text.Trim(); c["tokenp"] = McStore.Protect(tokenBox.Text.Trim()); c["log"] = logBox.Text.Trim(); c["server"] = serverBox.Text.Trim(); c["me"] = meBox.Text.Trim(); c["auto"] = autoBtn.Selected ? "1" : "0"; c["alerts"] = alertBtn.Selected ? "1" : "0";
        McStore.Write("mcserver.txt", c); P.RefreshKeepAlive(); note = "Saved. The passwords are stored encrypted for your Windows account only."; P.PingNow(); P.Changed();
    }
    public override void Place(Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 66; hostBox.Location = new Point(x, y); portBox.Location = new Point(x + 340, y); rconBox.Location = new Point(x + 460, y); passBox.Location = new Point(x + 580, y);
        hportBox.Location = new Point(x, y + 96); tokenBox.Location = new Point(x + 120, y + 96); meBox.Location = new Point(x + 480, y + 96);
        logBox.Location = new Point(x, y + 192); serverBox.Location = new Point(x, y + 250); autoBtn.Location = new Point(x, y + 304); alertBtn.Location = new Point(x + 296, y + 304); saveBtn.Location = new Point(x, y + 352);
    }
    public override void Draw(Graphics g, Rectangle a)
    {
        int x = a.X + 22, y = a.Y + 66; Head(g, "THE SERVER", x, a.Y + 16); Label(g, "game port", portBox.Left, portBox.Top - 20); Label(g, "RCON port", rconBox.Left, rconBox.Top - 20); Label(g, "RCON password", passBox.Left, passBox.Top - 20);
        Head(g, "THE HELPER ON THE SERVER PC  (optional: start, stop, restart, crash restart, CPU)", x, y + 54); Label(g, "helper port", hportBox.Left, hportBox.Top - 20); Label(g, "token", tokenBox.Left, tokenBox.Top - 20); Label(g, "your player name (for 'teleport to me')", meBox.Left, meBox.Top - 20);
        Head(g, "SHARED FOLDERS ON THE SERVER PC  (optional)", x, y + 150); Label(g, "log file: shows the live log in the Console", logBox.Left, logBox.Top - 20); Label(g, "server folder: used for backups, the settings editor and plugins", serverBox.Left, serverBox.Top - 20);
        TextRenderer.DrawText(g, note, Theme.Small, new Rectangle(saveBtn.Right + 16, saveBtn.Top + 6, a.Width - 200, 18), Theme.Green, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "On the server PC: server.properties needs enable-rcon=true, rcon.port=25575 and rcon.password=<something> (restart once), and the firewall must allow ports 25575 (RCON) and 25580 (helper). Use these only on your home network or Radmin VPN; never port-forward them to the internet.", Theme.Small, new Rectangle(x, y + 400, a.Width - 60, 40), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
    }
}
