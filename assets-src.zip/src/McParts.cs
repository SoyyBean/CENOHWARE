// Small building blocks for the Minecraft Server tab: saved settings, a line graph, a scrolling list, a one-line question box,
// and the client for the McHelper program that runs on the server PC.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

// plain "key=value" files in %APPDATA%\CENOHWARE, with secrets encrypted for this Windows account
static class McStore
{
    public static string Path_(string file) { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CENOHWARE", file); }
    public static Dictionary<string, string> Read(string file)
    {
        var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        try { foreach (string line in File.ReadAllLines(Path_(file))) { int i = line.IndexOf('='); if (i > 0) d[line.Substring(0, i)] = line.Substring(i + 1); } } catch { }
        return d;
    }
    public static void Write(string file, Dictionary<string, string> d)
    {
        if (Program.Testing) return;
        try { Directory.CreateDirectory(Path.GetDirectoryName(Path_(file))); var sb = new StringBuilder(); foreach (var kv in d) sb.Append(kv.Key + "=" + kv.Value.Replace("\r", " ").Replace("\n", " ") + "\r\n"); File.WriteAllText(Path_(file), sb.ToString()); } catch { }
    }
    public static string Get(Dictionary<string, string> d, string k, string dflt) { string v; return d.TryGetValue(k, out v) ? v : dflt; }
    public static int GetInt(Dictionary<string, string> d, string k, int dflt) { int n; return int.TryParse(Get(d, k, ""), out n) ? n : dflt; }
    public static string Protect(string s) { return s.Length == 0 ? "" : Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(s), null, DataProtectionScope.CurrentUser)); }
    public static string Unprotect(string v) { if (v.Length == 0) return ""; try { return Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(v), null, DataProtectionScope.CurrentUser)); } catch { return ""; } }
}

// a line graph of the last few minutes
class McGraph : Control
{
    public readonly List<float> Data = new List<float>(); public string Title = "", Unit = ""; public float Max; public Color Tone = Theme.Accent; public bool Lower;      // Max 0 = fit the data; Lower: smaller is better (colour only)
    public McGraph() { SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true); Height = 96; }
    public void Add(float v) { Data.Add(v); while (Data.Count > 180) Data.RemoveAt(0); Invalidate(); }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; var hp = Parent as IBackdropHost; if (hp != null) hp.PaintBackdropFor(g, this); else g.Clear(Theme.Bg);
        var r = new Rectangle(0, 0, Width - 1, Height - 1);
        using (var path = Theme.Round(r, 14)) { using (var b = new SolidBrush(Color.FromArgb(150, Theme.Card))) g.FillPath(b, path); using (var p = new Pen(Theme.Border)) g.DrawPath(p, path); }
        TextRenderer.DrawText(g, Title, Theme.SmallB, new Rectangle(12, 8, Width - 24, 16), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        string cur = Data.Count > 0 ? Data[Data.Count - 1].ToString(Data[Data.Count - 1] >= 100 ? "0" : "0.0", CultureInfo.InvariantCulture) + Unit : "no data yet";
        TextRenderer.DrawText(g, cur, Theme.UIL, new Rectangle(12, 24, 130, 22), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        if (Data.Count < 2) return;
        float mx = Max > 0 ? Max : 1; if (Max <= 0) foreach (float v in Data) if (v > mx) mx = v; mx *= 1.15f;
        var plot = new RectangleF(12, 50, Width - 24, Height - 50 - 10); var pts = new PointF[Data.Count];
        for (int i = 0; i < pts.Length; i++) pts[i] = new PointF(plot.Right - plot.Width * (Data.Count - 1 - i) / 179f, plot.Bottom - plot.Height * Math.Min(1f, Data[i] / mx));      // newest on the right, older ones scroll left
        var fill = new List<PointF>(pts); fill.Add(new PointF(pts[pts.Length - 1].X, plot.Bottom)); fill.Add(new PointF(pts[0].X, plot.Bottom));
        using (var b = new SolidBrush(Color.FromArgb(40, Tone))) g.FillPolygon(b, fill.ToArray());
        using (var p = new Pen(Tone, 2f) { LineJoin = LineJoin.Round }) g.DrawLines(p, pts);
    }
}

class McRow { public string[] Cols; public object Tag; public Color? Tone; }

// rows of text in columns; click to select; wheel scrolls (whole rows, so text never gets cut)
class McList : Control
{
    public readonly List<McRow> Rows = new List<McRow>(); public float[] Widths = { 1f }; public string[] Heads; public int Selected = -1, First; public int RowH = 30; public event Action<int> Picked, Activated; public string Empty = "";
    public McList() { SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true); }
    int Top { get { return Heads != null ? 28 : 0; } }
    int Visible { get { return Math.Max(1, (Height - Top - 4) / RowH); } }
    public void SetRows(List<McRow> rows) { string keep = Selected >= 0 && Selected < Rows.Count ? Rows[Selected].Cols[0] : null; Rows.Clear(); Rows.AddRange(rows); Selected = -1; if (keep != null) for (int i = 0; i < Rows.Count; i++) if (Rows[i].Cols[0] == keep) Selected = i; First = Math.Max(0, Math.Min(First, Math.Max(0, Rows.Count - Visible))); Invalidate(); }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit; var hp = Parent as IBackdropHost; if (hp != null) hp.PaintBackdropFor(g, this); else g.Clear(Theme.Bg);
        var r = new Rectangle(0, 0, Width - 1, Height - 1); using (var path = Theme.Round(r, 14)) { using (var b = new SolidBrush(Color.FromArgb(120, Theme.Card))) g.FillPath(b, path); using (var p = new Pen(Theme.Border)) g.DrawPath(p, path); }
        float tot = 0; foreach (float w in Widths) tot += w; int x0 = 12, avail = Width - 24 - 10;
        if (Heads != null) { int x = x0; for (int c = 0; c < Heads.Length; c++) { int w = (int)(avail * Widths[c] / tot); TextRenderer.DrawText(g, Heads[c], Theme.SmallB, new Rectangle(x, 6, w - 6, 16), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix); x += w; } }
        if (Rows.Count == 0 && Empty.Length > 0) TextRenderer.DrawText(g, Empty, Theme.UI, new Rectangle(14, Top + 8, Width - 28, 40), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
        int vis = Visible; for (int i = 0; i < vis && First + i < Rows.Count; i++)
        {
            var row = Rows[First + i]; var rc = new Rectangle(6, Top + 2 + i * RowH, Width - 12 - 8, RowH - 3);
            if (First + i == Selected) using (var path = Theme.Round(rc, 8)) using (var b = new SolidBrush(Color.FromArgb(90, Theme.Accent))) g.FillPath(b, path);
            int x = x0; for (int c = 0; c < row.Cols.Length && c < Widths.Length; c++) { int w = (int)(avail * Widths[c] / tot); TextRenderer.DrawText(g, row.Cols[c], c == 0 ? Theme.UIB : Theme.UI, new Rectangle(x, rc.Y + 4, w - 8, rc.Height - 6), c == 0 ? (row.Tone ?? Theme.Text) : Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis); x += w; }
        }
        if (Rows.Count > vis) { float th = Math.Max(24, (Height - Top - 8) * vis / (float)Rows.Count), ty = Top + 4 + (Height - Top - 8 - th) * First / Math.Max(1, Rows.Count - vis); using (var p = Theme.Round(new Rectangle(Width - 9, (int)ty, 4, (int)th), 4)) using (var b = new SolidBrush(Color.FromArgb(150, Theme.AccentSoft))) g.FillPath(b, p); }
    }
    int At(Point p) { int i = First + (p.Y - Top - 2) / RowH; return p.Y >= Top && i >= 0 && i < Rows.Count ? i : -1; }
    protected override void OnMouseDown(MouseEventArgs e) { int i = At(e.Location); if (i >= 0) { Selected = i; Invalidate(); if (e.Clicks >= 2 && Activated != null) Activated(i); else if (Picked != null) Picked(i); } base.OnMouseDown(e); }
    protected override void OnMouseWheel(MouseEventArgs e) { First = Math.Max(0, Math.Min(Math.Max(0, Rows.Count - Visible), First - Math.Sign(e.Delta) * 2)); Invalidate(); base.OnMouseWheel(e); }
}

// a one-line question
static class McAsk
{
    public static string Text(IWin32Window owner, string title, string prompt, string dflt)
    {
        using (var f = new Form { Text = title, FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false, ShowInTaskbar = false, ClientSize = new Size(420, 130), BackColor = Theme.Panel, ForeColor = Theme.Text, Font = Theme.UI })
        {
            var l = new Label { Text = prompt, Left = 16, Top = 14, Width = 388, Height = 36, ForeColor = Theme.Text }; var t = new TextBox { Left = 16, Top = 54, Width = 388, Text = dflt, BackColor = Theme.Card, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle };
            var ok = new Button { Text = "OK", Left = 232, Top = 90, Width = 80, DialogResult = DialogResult.OK }; var no = new Button { Text = "Cancel", Left = 324, Top = 90, Width = 80, DialogResult = DialogResult.Cancel };
            f.Controls.AddRange(new Control[] { l, t, ok, no }); f.AcceptButton = ok; f.CancelButton = no; t.SelectAll();
            return f.ShowDialog(owner) == DialogResult.OK ? t.Text.Trim() : null;
        }
    }
}

// the McHelper program on the server PC (token-protected, one short conversation per request)
static class McHelperClient
{
    public static string Call(string host, int port, string token, string cmd, int timeoutMs, out string error)
    {
        error = "";
        try
        {
            using (var c = new TcpClient())
            {
                var ar = c.BeginConnect(host, port, null, null); if (!ar.AsyncWaitHandle.WaitOne(Math.Min(timeoutMs, 3000))) { error = "the helper does not answer (is McHelper running on the server PC, and is port " + port + " open?)"; return ""; }
                c.EndConnect(ar); c.ReceiveTimeout = c.SendTimeout = timeoutMs; var ns = c.GetStream(); var wr = new StreamWriter(ns, new UTF8Encoding(false)) { NewLine = "\n", AutoFlush = true }; var rd = new StreamReader(ns, Encoding.UTF8);
                wr.WriteLine("AUTH " + token); wr.WriteLine(cmd); var sb = new StringBuilder(); string line; while ((line = rd.ReadLine()) != null && line != "END") sb.AppendLine(line);
                string res = sb.ToString().Trim(); if (res.StartsWith("error=")) { error = res.Substring(6); return ""; } return res;
            }
        }
        catch (Exception ex) { error = ex is SocketException ? "the helper refused the connection" : ex.Message; return ""; }
    }
    public static Dictionary<string, string> Parse(string res) { var d = new Dictionary<string, string>(); foreach (string line in res.Split('\n')) { int i = line.IndexOf('='); if (i > 0) d[line.Substring(0, i).Trim()] = line.Substring(i + 1).Trim(); } return d; }
}
