// Shotgun Keys: every key you press, in any program, plays the blast of a shotgun; Backspace racks it instead (the pump sound).
// The two clips are cut from a shotgun sound effect and live inside the exe (ks_blast.wav, ks_cock.wav). It listens for key
// presses with a Windows keyboard hook, but it never looks at which letter was typed beyond "Backspace or not", and it keeps
// and shows nothing about what you type: only how many shots there were.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// plays one short clip over and over, overlapping itself: a small pool of waveOut voices that are opened and loaded once, so a
// key press only has to restart the next voice (no loading, no gaps, a tail never cuts off the next shot unless all voices are busy)
class KeyAudio : IDisposable
{
    [StructLayout(LayoutKind.Sequential)] struct WAVEFORMATEX { public ushort wFormatTag, nChannels; public uint nSamplesPerSec, nAvgBytesPerSec; public ushort nBlockAlign, wBitsPerSample, cbSize; }
    [StructLayout(LayoutKind.Sequential)] struct WAVEHDR { public IntPtr lpData; public uint dwBufferLength, dwBytesRecorded; public IntPtr dwUser; public uint dwFlags, dwLoops; public IntPtr lpNext; public IntPtr reserved; }
    [DllImport("winmm.dll")] static extern int waveOutOpen(out IntPtr h, int dev, ref WAVEFORMATEX fmt, IntPtr cb, IntPtr inst, int flags);
    [DllImport("winmm.dll")] static extern int waveOutPrepareHeader(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveOutUnprepareHeader(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveOutWrite(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveOutReset(IntPtr h);
    [DllImport("winmm.dll")] static extern int waveOutClose(IntPtr h);
    [DllImport("winmm.dll")] static extern int waveOutSetVolume(IntPtr h, uint vol);

    class Voice { public IntPtr H, Hdr; public GCHandle Pin; }
    readonly List<Voice> voices = new List<Voice>(); int next, hdrSize;

    // a PCM wav from the exe's own resources, with `count` voices
    public static KeyAudio FromResource(string name, int count)
    {
        byte[] wav;
        using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
        {
            if (s == null) return null;
            using (var ms = new MemoryStream()) { s.CopyTo(ms); wav = ms.ToArray(); }
        }
        var fmt = new WAVEFORMATEX(); int dataAt = -1, dataLen = 0, p = 12;
        while (p + 8 <= wav.Length)
        {
            string id = System.Text.Encoding.ASCII.GetString(wav, p, 4); int len = BitConverter.ToInt32(wav, p + 4);
            if (id == "fmt ") { fmt.wFormatTag = BitConverter.ToUInt16(wav, p + 8); fmt.nChannels = BitConverter.ToUInt16(wav, p + 10); fmt.nSamplesPerSec = BitConverter.ToUInt32(wav, p + 12); fmt.nAvgBytesPerSec = BitConverter.ToUInt32(wav, p + 16); fmt.nBlockAlign = BitConverter.ToUInt16(wav, p + 20); fmt.wBitsPerSample = BitConverter.ToUInt16(wav, p + 22); fmt.cbSize = 0; }
            else if (id == "data") { dataAt = p + 8; dataLen = Math.Min(len, wav.Length - dataAt); break; }
            p += 8 + len + (len & 1);
        }
        if (dataAt < 0 || fmt.wFormatTag != 1) return null;
        var pcm = new byte[dataLen]; Buffer.BlockCopy(wav, dataAt, pcm, 0, dataLen);
        var a = new KeyAudio(); a.hdrSize = Marshal.SizeOf(typeof(WAVEHDR));
        for (int i = 0; i < count; i++)
        {
            var v = new Voice(); var f = fmt;
            if (waveOutOpen(out v.H, -1, ref f, IntPtr.Zero, IntPtr.Zero, 0) != 0) break;
            var data = (byte[])pcm.Clone(); v.Pin = GCHandle.Alloc(data, GCHandleType.Pinned);
            var hdr = new WAVEHDR { lpData = v.Pin.AddrOfPinnedObject(), dwBufferLength = (uint)data.Length };
            v.Hdr = Marshal.AllocHGlobal(a.hdrSize); Marshal.StructureToPtr(hdr, v.Hdr, false); waveOutPrepareHeader(v.H, v.Hdr, a.hdrSize);
            a.voices.Add(v);
        }
        return a.voices.Count > 0 ? a : null;
    }
    public void Play() { if (voices.Count == 0) return; var v = voices[next]; next = (next + 1) % voices.Count; waveOutReset(v.H); waveOutWrite(v.H, v.Hdr, hdrSize); }
    public void StopAll() { foreach (var v in voices) waveOutReset(v.H); }       // cuts off everything this clip is still playing
    public void SetVolume(int percent) { uint x = (uint)(Math.Max(0, Math.Min(100, percent)) * 65535 / 100); foreach (var v in voices) waveOutSetVolume(v.H, x | (x << 16)); }
    public void Dispose()
    {
        foreach (var v in voices) { try { waveOutReset(v.H); waveOutUnprepareHeader(v.H, v.Hdr, hdrSize); waveOutClose(v.H); Marshal.FreeHGlobal(v.Hdr); v.Pin.Free(); } catch { } }
        voices.Clear();
    }
}

// a low-level keyboard hook (it runs on the window thread that installed it, so the callback must be quick: it only starts a sound)
class KeyHook
{
    delegate IntPtr Proc(int code, IntPtr w, IntPtr l);
    [DllImport("user32.dll", SetLastError = true)] static extern IntPtr SetWindowsHookEx(int id, Proc fn, IntPtr mod, uint thread);
    [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int code, IntPtr w, IntPtr l);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
    public event Action<int> KeyDown; IntPtr hook; Proc proc; readonly bool[] down = new bool[256];
    public bool Start()
    {
        if (hook != IntPtr.Zero) return true; proc = Callback;
        using (var cur = Process.GetCurrentProcess()) using (var mod = cur.MainModule) hook = SetWindowsHookEx(13, proc, GetModuleHandle(mod.ModuleName), 0);
        return hook != IntPtr.Zero;
    }
    public void Stop() { if (hook != IntPtr.Zero) { UnhookWindowsHookEx(hook); hook = IntPtr.Zero; } }
    IntPtr Callback(int code, IntPtr w, IntPtr l)
    {
        if (code >= 0)
        {
            int msg = (int)w, vk = Marshal.ReadInt32(l) & 255;
            if (msg == 0x100 || msg == 0x104) { if (!down[vk]) { down[vk] = true; try { if (KeyDown != null) KeyDown(vk); } catch { } } }      // a held key does not repeat the shot
            else if (msg == 0x101 || msg == 0x105) down[vk] = false;
        }
        return CallNextHookEx(hook, code, w, l);
    }
}

// the whole feature, kept alive by the hub from startup (so it keeps working while you are on any other tab or in another program)
static class KeyBang
{
    public static bool Enabled, Missing, Failed, Restart; public static int Volume = 70, Bangs, Racks; public static event Action<bool> Shot;      // Restart: each new shot cuts off the sound still playing, instead of overlapping it
    static KeyAudio blast, cock; static KeyHook hook; static bool inited;
    static string SaveFile { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CENOHWARE", "keysound.txt"); } }
    public static void Init()
    {
        if (inited) return; inited = true;
        try { foreach (string line in File.ReadAllLines(SaveFile)) { int i = line.IndexOf('='); if (i < 0) continue; string k = line.Substring(0, i), v = line.Substring(i + 1); int n; if (k == "enabled") Enabled = v == "1"; else if (k == "volume" && int.TryParse(v, out n)) Volume = Math.Max(0, Math.Min(100, n)); else if (k == "mode") Restart = v == "restart"; } } catch { }
        try { blast = KeyAudio.FromResource("ks_blast.wav", 24); cock = KeyAudio.FromResource("ks_cock.wav", 8); } catch { }
        Missing = blast == null || cock == null; ApplyVolume();
        if (Enabled) Start();
    }
    static void Start() { if (Missing) return; if (hook == null) { hook = new KeyHook(); hook.KeyDown += OnKey; } Failed = !hook.Start(); if (Failed) Enabled = false; }
    static void Stop() { if (hook != null) hook.Stop(); }
    public static void SetEnabled(bool on) { Enabled = on; if (on) Start(); else Stop(); Save(); }
    public static void SetVolume(int v) { Volume = Math.Max(0, Math.Min(100, v)); ApplyVolume(); }
    public static void Save() { if (Program.Testing) return; try { Directory.CreateDirectory(Path.GetDirectoryName(SaveFile)); File.WriteAllText(SaveFile, "enabled=" + (Enabled ? 1 : 0) + "\r\nvolume=" + Volume + "\r\nmode=" + (Restart ? "restart" : "overlap") + "\r\n"); } catch { } }
    static void ApplyVolume() { if (blast != null) blast.SetVolume(Volume); if (cock != null) cock.SetVolume(Volume); }
    public static void Shutdown() { Stop(); if (blast != null) blast.Dispose(); if (cock != null) cock.Dispose(); blast = cock = null; }
    static bool IsModifier(int vk) { return vk == 0x10 || vk == 0x11 || vk == 0x12 || (vk >= 0xA0 && vk <= 0xA5) || vk == 0x5B || vk == 0x5C || vk == 0x14 || vk == 0x90 || vk == 0x91 || vk == 0x2C; }
    static void OnKey(int vk) { if (IsModifier(vk)) return; Fire(vk == 0x08); }
    public static void SetRestart(bool on) { Restart = on; Save(); }
    public static void Fire(bool rack)
    {
        if (Restart) { if (blast != null) blast.StopAll(); if (cock != null) cock.StopAll(); }
        if (rack) { Racks++; if (cock != null) cock.Play(); } else { Bangs++; if (blast != null) blast.Play(); }
        if (Shot != null) Shot(rack);
    }
}

class ShotgunKeysPage : BackdropPage, IHubPage
{
    static readonly Font FTitle = new Font("Segoe UI Semibold", 26f), FBig = new Font("Segoe UI Semibold", 22f), FStat = new Font("Segoe UI Semibold", 15f);
    readonly HubForm hub; readonly Btn toggleBtn, blastBtn, rackBtn, overlapBtn, restartBtn;
    class Flash { public float X, Y, Age, Tilt; public bool Rack; }
    readonly List<Flash> flashes = new List<Flash>(); readonly Random rnd = new Random(); bool dragVol; float kick;

    public ShotgunKeysPage(HubForm h)
    {
        hub = h;
        toggleBtn = new Btn("") { Width = 230, Height = 48, Primary = true, Big = true }; toggleBtn.Click += delegate { KeyBang.SetEnabled(!KeyBang.Enabled); Sync(); };
        blastBtn = new Btn("Test the blast") { Width = 150, Height = 32, Font = Theme.Small }; blastBtn.Click += delegate { KeyBang.Fire(false); };
        rackBtn = new Btn("Test the rack") { Width = 150, Height = 32, Font = Theme.Small }; rackBtn.Click += delegate { KeyBang.Fire(true); };
        overlapBtn = new Btn("Overlap") { Width = 150, Height = 32, Font = Theme.Small }; overlapBtn.Click += delegate { KeyBang.SetRestart(false); Sync(); };
        restartBtn = new Btn("Restart (cut off)") { Width = 150, Height = 32, Font = Theme.Small }; restartBtn.Click += delegate { KeyBang.SetRestart(true); Sync(); };
        Controls.AddRange(new Control[] { toggleBtn, blastBtn, rackBtn, overlapBtn, restartBtn }); Resize += delegate { Place(); }; Place(); Sync();
    }
    Rectangle Card { get { return new Rectangle(44, 150, Math.Max(520, Math.Min(Width - 88, 940)), 330); } }
    Rectangle VolRect { get { var c = Card; return new Rectangle(c.X + 450, c.Y + 78, Math.Min(330, c.Width - 450 - 40), 22); } }
    void Place() { var c = Card; toggleBtn.Location = new Point(c.X + 36, c.Y + 92); blastBtn.Location = new Point(c.X + 450, c.Y + 130); rackBtn.Location = new Point(blastBtn.Right + 10, c.Y + 130); overlapBtn.Location = new Point(c.X + 450, c.Y + 214); restartBtn.Location = new Point(overlapBtn.Right + 10, c.Y + 214); }
    void Sync() { toggleBtn.Text = KeyBang.Enabled ? "Turn it off" : "Turn it on"; toggleBtn.Danger = false; toggleBtn.Selected = KeyBang.Enabled; toggleBtn.Invalidate(); overlapBtn.Selected = !KeyBang.Restart; restartBtn.Selected = KeyBang.Restart; overlapBtn.Invalidate(); restartBtn.Invalidate(); }
    void OnShot(bool rack)
    {
        var c = Card; kick = 1f; flashes.Add(new Flash { Rack = rack, X = c.X + 40 + (float)rnd.NextDouble() * (c.Width - 260), Y = c.Y + 190 + (float)rnd.NextDouble() * 70, Tilt = (float)(rnd.NextDouble() - 0.5) * 24f });
        if (flashes.Count > 14) flashes.RemoveAt(0); Invalidate();
    }
    public void HubShown() { KeyBang.Shot -= OnShot; KeyBang.Shot += OnShot; Sync(); }
    public void HubHidden() { KeyBang.Shot -= OnShot; }
    public void HubTheme() { Invalidate(true); }
    public void HubPrewarm() { }
    protected override void OnTick(float dt)
    {
        kick = Math.Max(0f, kick - dt * 5f);
        for (int i = flashes.Count - 1; i >= 0; i--) { flashes[i].Age += dt; if (flashes[i].Age > 0.7f) flashes.RemoveAt(i); }
    }
    protected override void DrawCards(Graphics g)
    {
        var c = Card; var sp = Sprite("skcard_" + c.Width + "x" + c.Height, c.Width, c.Height, delegate (Graphics gg, Rectangle r) { Glass(gg, r, 0.1f); }); Blit(g, sp, c.X - Pad, c.Y - Pad);
    }
    protected override void DrawContent(Graphics g)
    {
        TextRenderer.DrawText(g, "Shotgun Keys", FTitle, new Rectangle(44, 32, Width - 100, 52), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "Every key you press, in any program, goes BANG. Backspace racks the shotgun.", Theme.UIL, new Rectangle(46, 90, Width - 100, 28), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        var c = Card; int x = c.X + 36, y = c.Y + 28;
        string state = KeyBang.Missing ? "The sound files are not in this build" : KeyBang.Failed ? "Windows would not let it listen to the keyboard" : KeyBang.Enabled ? "ON" : "OFF";
        Color sc = KeyBang.Missing || KeyBang.Failed ? Theme.Red : KeyBang.Enabled ? Theme.Green : Theme.Dim;
        TextRenderer.DrawText(g, state, FBig, new Rectangle(x, y, 400, 40), sc, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, KeyBang.Enabled ? "listening to every key, even while you are in another program" : "nothing plays until you turn it on", Theme.Small, new Rectangle(x, y + 42, 400, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "SHOTS THIS SESSION", Theme.SmallB, new Rectangle(x, c.Y + 164, 220, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, CenohCoinsFmt(KeyBang.Bangs), FStat, new Rectangle(x, c.Y + 184, 140, 28), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "RACKS (BACKSPACE)", Theme.SmallB, new Rectangle(x + 150, c.Y + 164, 220, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, CenohCoinsFmt(KeyBang.Racks), FStat, new Rectangle(x + 150, c.Y + 184, 140, 28), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "WHEN KEYS COME FAST", Theme.SmallB, new Rectangle(c.X + 450, c.Y + 190, 260, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, KeyBang.Restart ? "each new shot cuts off the old one" : "shots pile up and ring over each other", Theme.Small, new Rectangle(c.X + 450, c.Y + 252, 320, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        // the volume slider
        var vr = VolRect; TextRenderer.DrawText(g, "VOLUME  " + KeyBang.Volume + "%", Theme.SmallB, new Rectangle(vr.X, vr.Y - 26, 220, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var track = new Rectangle(vr.X, vr.Y + 8, vr.Width, 6);
        using (var path = Theme.Round(track, 6)) using (var b = new SolidBrush(Color.FromArgb(120, Theme.Border))) g.FillPath(b, path);
        var fill = new Rectangle(track.X, track.Y, Math.Max(6, track.Width * KeyBang.Volume / 100), track.Height);
        using (var path = Theme.Round(fill, 6)) using (var b = new SolidBrush(Theme.Accent)) g.FillPath(b, path);
        int kx = track.X + track.Width * KeyBang.Volume / 100;
        using (var b = new SolidBrush(Color.White)) g.FillEllipse(b, kx - 9, vr.Y + 11 - 9, 18, 18);
        using (var p = new Pen(Theme.Accent, 2.4f)) g.DrawEllipse(p, kx - 9, vr.Y + 11 - 9, 18, 18);
        TextRenderer.DrawText(g, "It listens for key presses to play the sound and does not record or keep anything you type.", Theme.Small, new Rectangle(x, c.Bottom - 42, c.Width - 72, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        // the BANGs
        foreach (var f in flashes)
        {
            float u = f.Age / 0.7f, a = 1f - u, sz = (f.Rack ? 26f : 40f) * (1f + 0.5f * (float)Math.Sin(Math.Min(1f, u * 3f) * Math.PI / 2));
            using (var font = new Font("Segoe UI Black", sz, FontStyle.Bold, GraphicsUnit.Point)) using (var br = new SolidBrush(Color.FromArgb((int)(255 * a), f.Rack ? Theme.AccentSoft : Color.FromArgb(255, 200, 60)))) using (var sh = new SolidBrush(Color.FromArgb((int)(150 * a), 0, 0, 0)))
            {
                var st = g.Save(); g.TranslateTransform(f.X, f.Y - u * 30f); g.RotateTransform(f.Tilt); g.DrawString(f.Rack ? "chk-chk" : "BANG!", font, sh, 3, 4); g.DrawString(f.Rack ? "chk-chk" : "BANG!", font, br, 0, 0); g.Restore(st);
            }
        }
    }
    static string CenohCoinsFmt(int n) { return n.ToString("N0", CultureInfo.InvariantCulture); }
    void SetVolFrom(int mx) { var vr = VolRect; KeyBang.SetVolume((int)Math.Round((mx - vr.X) * 100.0 / Math.Max(1, vr.Width))); Invalidate(); }
    protected override void OnMouseDown(MouseEventArgs e) { if (Rectangle.Inflate(VolRect, 12, 8).Contains(e.Location)) { dragVol = true; Capture = true; SetVolFrom(e.X); } base.OnMouseDown(e); }
    protected override void OnMouseMove(MouseEventArgs e) { if (dragVol) SetVolFrom(e.X); else Cursor = Rectangle.Inflate(VolRect, 12, 8).Contains(e.Location) ? Cursors.Hand : Cursors.Default; base.OnMouseMove(e); }
    protected override void OnMouseUp(MouseEventArgs e) { if (dragVol) { dragVol = false; Capture = false; KeyBang.Save(); KeyBang.Fire(false); } base.OnMouseUp(e); }
}
