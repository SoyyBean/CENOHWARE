// The Cacenoh: five casino games (Rocket, Mines, Slots, Blackjack, Plinko) played with CenohCoins, a pretend currency that only exists inside CENOHWARE (kept in %APPDATA%\CENOHWARE\coins.txt; never real money). The pictures are the player's own or built-in symbols.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;

// the pretend money: one balance shared by everything in CENOHWARE
static class CenohCoins
{
    public static bool NoSave; public static long Balance = 1000, Best, Rounds; public static event Action Changed; static bool loaded;
    static string SaveFile { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CENOHWARE", "coins.txt"); } }
    public static void Load()
    {
        if (loaded) return; loaded = true;
        try { var p = File.ReadAllText(SaveFile).Split(','); long v; if (p.Length >= 3) { if (long.TryParse(p[0], out v)) Balance = v; if (long.TryParse(p[1], out v)) Best = v; if (long.TryParse(p[2], out v)) Rounds = v; } } catch { }
    }
    static void Save() { if (!NoSave) try { Directory.CreateDirectory(Path.GetDirectoryName(SaveFile)); File.WriteAllText(SaveFile, Balance + "," + Best + "," + Rounds); } catch { } if (Changed != null) Changed(); }
    public static bool Spend(long n) { Load(); if (n <= 0 || n > Balance) return false; Balance -= n; Rounds++; Save(); return true; }
    public static void Pay(long n) { Load(); if (n <= 0) return; Balance += n; if (n > Best) Best = n; Save(); }
    public static void Refill() { Load(); Balance += 1000; Save(); }
    public static string Fmt(long n) { return n.ToString("N0", CultureInfo.InvariantCulture); }
}

class CasinoPage : BackdropPage, IHubPage
{
    static readonly Font FTitle = new Font("Segoe UI Semibold", 26f), FBig = new Font("Segoe UI Semibold", 22f), FStat = new Font("Segoe UI Semibold", 15f), FHuge = new Font("Segoe UI Black", 54f), FMult = new Font("Segoe UI Black", 20f), FCard = new Font("Segoe UI Semibold", 14f), FSuit = new Font("Segoe UI Symbol", 22f), FBanner = new Font("Segoe UI Semibold", 17f);
    static readonly string[] GameNames = { "Rocket", "Mines", "Slots", "Blackjack", "Plinko" };
    static readonly string[] Rules = {
        "Press Launch, then Cash out before the rocket blows up. The longer you wait, the more it pays, and nobody knows when it ends. Set an auto cash out if you like.",
        "25 tiles hide gems and a few bombs. Every gem you find raises your payout. Cash out any time, but a bomb loses everything. More bombs pay more.",
        "Three reels. Three the same pays 10x to 50x, two the same gives your bet back.",
        "Beat the dealer without going over 21. Blackjack pays 3 to 2, the dealer stands on 17, and you can double on your first two cards.",
        "Drop a ball from the top. It bounces down into a slot and pays that slot's number times your bet. Higher risk, bigger edges." };
    readonly HubForm hub; readonly Random rnd = new Random(); readonly Btn[] gameBtns = new Btn[5], optBtns = new Btn[4], betBtns = new Btn[5]; readonly Btn act1, act2, act3, refillBtn;
    int game; long bet = 10; bool active; string status = ""; Color statusCol; float shownBal, syncT; readonly Btn picBtn, plainBtn;
    readonly Dictionary<string, Bitmap> faces = new Dictionary<string, Bitmap>();
    string line = ""; float lineT; int linePic;
    class CPart { public float X, Y, Vx, Vy, A, Va, S, Life; public Color C; public bool Dot; }
    readonly List<CPart> parts = new List<CPart>();

    public CasinoPage(HubForm h)
    {
        hub = h; CenohCoins.Load(); shownBal = CenohCoins.Balance; statusCol = Theme.Text;
        for (int i = 0; i < 5; i++) { int k = i; gameBtns[i] = new Btn(GameNames[i]) { Height = 32, Font = Theme.UIB }; gameBtns[i].Click += delegate { SetGame(k); }; }
        string[] bt = { "−", "+", "½", "2×", "Max" };
        for (int i = 0; i < 5; i++) { int k = i; betBtns[i] = new Btn(bt[i]) { Width = 38, Height = 30, Font = Theme.Small }; betBtns[i].Click += delegate { BetStep(k); }; }
        for (int i = 0; i < 4; i++) { int k = i; optBtns[i] = new Btn("") { Width = 48, Height = 30, Font = Theme.Small }; optBtns[i].Click += delegate { Opt(k); }; }
        act1 = new Btn("") { Width = 210, Height = 44, Primary = true }; act1.Click += delegate { Act(1); };
        act2 = new Btn("") { Width = 210, Height = 36 }; act2.Click += delegate { Act(2); };
        act3 = new Btn("") { Width = 210, Height = 36 }; act3.Click += delegate { Act(3); };
        refillBtn = new Btn("Get 1,000 free CenohCoins") { Width = 210, Height = 34, Visible = false }; refillBtn.Click += delegate { CenohCoins.Refill(); ClampBet(); SyncUi(); Say("hello"); Invalidate(); };
        picBtn = new Btn("") { Width = 172, Height = 30, Font = Theme.Small }; picBtn.Click += delegate { PickPictures(); };
        plainBtn = new Btn("Use symbols") { Width = 90, Height = 30, Font = Theme.Small }; plainBtn.Click += delegate { UsePlaceholders(); };
        Controls.AddRange(new Control[] { picBtn, plainBtn });
        Controls.AddRange(gameBtns); Controls.AddRange(betBtns); Controls.AddRange(optBtns); Controls.AddRange(new Control[] { act1, act2, act3, refillBtn });
        for (int i = 0; i < 3; i++) reels[i] = new Reel();
        Resize += delegate { Place(); }; Place(); SetGame(0); Say("hello");
    }

    // ------------------------------------------------------------------ layout
    Rectangle StatsRect { get { int w = 270; return new Rectangle(Width - 44 - w, 124, w, Math.Max(520, Height - 124 - 24)); } }
    Rectangle BoardArea { get { var s = StatsRect; return new Rectangle(44, 170, Math.Max(300, s.X - 24 - 44), Math.Max(300, Height - 170 - 24 - 66)); } }
    void Place()
    {
        var s = StatsRect; var a = BoardArea; int x = s.X + 30;
        int gw = Math.Min(150, (a.Width - 4 * 8) / 5); for (int i = 0; i < 5; i++) { gameBtns[i].Width = gw; gameBtns[i].Location = new Point(a.X + i * (gw + 8), 124); }
        for (int i = 0; i < 5; i++) betBtns[i].Location = new Point(x + i * 43, s.Y + 24 + 134);
        for (int i = 0; i < 4; i++) optBtns[i].Location = new Point(x + i * 54, s.Y + 24 + 214);
        act1.Location = new Point(x, s.Y + 24 + 262); act2.Location = new Point(x, s.Y + 24 + 262 + 52); act3.Location = new Point(x, s.Y + 24 + 262 + 52 + 44);
        refillBtn.Location = new Point(x, s.Bottom - 56);
        picBtn.Location = new Point(s.X, 44); plainBtn.Location = new Point(s.Right - plainBtn.Width, 44);
    }

    // ------------------------------------------------------------------ the pictures: your own (picked once, kept in %APPDATA%/CENOHWARE/casino) or the built-in symbols
    static string PicDir { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CENOHWARE", "casino"); } }
    readonly List<Bitmap> mine = new List<Bitmap>(); bool picsLoaded;
    void RefreshPics()
    {
        if (picsLoaded) return; picsLoaded = true; foreach (var bm in mine) bm.Dispose(); mine.Clear(); ClearFaces();
        try
        {
            if (Directory.Exists(PicDir))
                foreach (string f in Directory.GetFiles(PicDir))
                {
                    string e = Path.GetExtension(f).ToLowerInvariant(); if (e != ".png" && e != ".jpg" && e != ".jpeg" && e != ".bmp" && e != ".gif") continue;
                    try { using (var fs = File.OpenRead(f)) using (var img = Image.FromStream(fs)) mine.Add(Square(img, 256)); } catch { }
                    if (mine.Count >= 60) break;
                }
        }
        catch { }
        var order = new List<int>(); for (int i = 0; i < Math.Max(mine.Count, 6); i++) order.Add(i);
        for (int i = order.Count - 1; i > 0; i--) { int j = rnd.Next(i + 1); int tmp = order[i]; order[i] = order[j]; order[j] = tmp; }
        for (int i = 0; i < 6; i++) slotPic[i] = mine.Count >= 6 ? order[i] : i < mine.Count ? i : -(i + 1);      // fewer than six pictures: the other reel symbols are built-in ones, so every symbol differs
        linePic = RandPic();
    }
    static Bitmap Square(Image img, int s)
    {
        var b = new Bitmap(s, s, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(b)) { g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.PixelOffsetMode = PixelOffsetMode.Half; float k = Math.Max(s / (float)img.Width, s / (float)img.Height), w = img.Width * k, h = img.Height * k; g.DrawImage(img, (s - w) / 2f, (s - h) / 2f, w, h); }
        return b;
    }
    void PickPictures()
    {
        string[] files;
        using (var d = new OpenFileDialog { Title = "Pick pictures for the Cacenoh (they become the rocket, the gems, the slot symbols, the face cards and the balls)", Multiselect = true, Filter = "Pictures|*.png;*.jpg;*.jpeg;*.bmp;*.gif" })
        { if (d.ShowDialog(FindForm()) != DialogResult.OK) return; files = d.FileNames; }
        try { Directory.CreateDirectory(PicDir); foreach (string f in Directory.GetFiles(PicDir)) File.Delete(f); int n = 0; foreach (string f in files) { try { File.Copy(f, Path.Combine(PicDir, (n++).ToString("000") + Path.GetExtension(f).ToLowerInvariant())); } catch { } } } catch { }
        picsLoaded = false; RefreshPics(); SyncPicBtns(); Invalidate();
    }
    void UsePlaceholders() { try { if (Directory.Exists(PicDir)) foreach (string f in Directory.GetFiles(PicDir)) File.Delete(f); } catch { } picsLoaded = false; RefreshPics(); SyncPicBtns(); Invalidate(); }
    void SyncPicBtns() { string tx = mine.Count > 0 ? "Change pictures (" + mine.Count + ")" : "Use your own pictures…"; if (picBtn.Text != tx) { picBtn.Text = tx; picBtn.Invalidate(); } plainBtn.Visible = mine.Count > 0; }
    void ClearFaces() { foreach (var b in faces.Values) b.Dispose(); faces.Clear(); }
    int RandPic() { return rnd.Next(mine.Count > 0 ? mine.Count : Signs.Length); }
    // the built-in symbols: a coloured tile with a casino sign on it
    static readonly string[] Signs = { "★", "♦", "♥", "♣", "♠", "7", "$", "♛", "☀", "♪", "⚡", "☘" };
    static readonly Color[] SignCols = { Color.FromArgb(240, 180, 40), Color.FromArgb(40, 170, 230), Color.FromArgb(220, 60, 80), Color.FromArgb(50, 170, 90), Color.FromArgb(120, 90, 220), Color.FromArgb(240, 110, 40), Color.FromArgb(30, 160, 140), Color.FromArgb(200, 70, 190), Color.FromArgb(250, 150, 30), Color.FromArgb(70, 120, 230), Color.FromArgb(230, 200, 40), Color.FromArgb(60, 190, 110) };
    // a square (or round) picture: one of yours, or a symbol (negative numbers always mean a symbol)
    Bitmap Face(int pic, int size, bool round)
    {
        size = Math.Max(10, size); string key = pic + "_" + size + (round ? "r" : "q"); Bitmap b; if (faces.TryGetValue(key, out b)) return b;
        if (faces.Count > 140) ClearFaces();
        using (var crop = new Bitmap(size, size, PixelFormat.Format32bppPArgb))
        {
            using (var g = Graphics.FromImage(crop))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.PixelOffsetMode = PixelOffsetMode.Half; g.Clear(Color.FromArgb(28, 28, 44));
                Bitmap own = pic >= 0 && mine.Count > 0 ? mine[pic % mine.Count] : null;
                if (own != null) g.DrawImage(own, new Rectangle(0, 0, size, size));
                else
                {
                    int k = (pic < 0 ? -pic - 1 : pic) % Signs.Length; Color c = SignCols[k]; g.SmoothingMode = SmoothingMode.AntiAlias; g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                    using (var lb = new LinearGradientBrush(new Rectangle(0, 0, size, size), Theme.Lerp(c, Color.White, 0.25f), Theme.Lerp(c, Color.Black, 0.45f), 60f)) g.FillRectangle(lb, 0, 0, size, size);
                    using (var f = new Font("Segoe UI Symbol", size * 0.52f, FontStyle.Bold, GraphicsUnit.Pixel)) using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                    {
                        using (var sh = new SolidBrush(Color.FromArgb(90, 0, 0, 0))) g.DrawString(Signs[k], f, sh, new RectangleF(size * 0.03f, size * 0.05f, size, size), sf);
                        g.DrawString(Signs[k], f, Brushes.White, new RectangleF(0, 0, size, size), sf);
                    }
                }
            }
            b = RoundedCopy(crop, size, size, round ? size / 2 : Math.Max(6, size / 9), Theme.AccentSoft);
        }
        faces[key] = b; return b;
    }

    // ------------------------------------------------------------------ what the house says
    static readonly string[] Ev_hello = { "n|Welcome to the Cacenoh. Everything here is pretend money.", "n|Pull up a chair. The house is feeling generous. Probably." };
    static readonly string[] Ev_win = { "n|Nice one.", "n|The house pays out. It looks surprised." };
    static readonly string[] Ev_big = { "n|Huge win! Somebody check the casino is still standing.", "n|The pit boss is sweating." };
    static readonly string[] Ev_lose = { "n|The house wins.", "n|The house takes it. Sorry, not really." };
    static readonly string[] Ev_cash = { "n|Smart. Knowing when to stop is the whole trick." };
    static readonly string[] Ev_crash = { "n|Boom. The pilot bailed out with a parachute." };
    static readonly string[] Ev_bust = { "n|Over 21. The dealer smiles." };
    static readonly string[] Ev_push = { "n|A tie. Nobody wins, the dealer is bored." };
    static readonly string[] Ev_broke = { "n|You are out of CenohCoins. They are free, so take some." };
    static readonly Dictionary<string, string[]> Ev = new Dictionary<string, string[]> { { "hello", Ev_hello }, { "win", Ev_win }, { "big", Ev_big }, { "lose", Ev_lose }, { "cash", Ev_cash }, { "crash", Ev_crash }, { "bust", Ev_bust }, { "push", Ev_push }, { "broke", Ev_broke } };
    void Say(string ev)
    {
        string[] all; if (!Ev.TryGetValue(ev, out all)) return; char m = 'n'; var ok = new List<string>();
        foreach (string s in all) if (s[0] == m) ok.Add(s.Substring(2)); if (ok.Count == 0) foreach (string s in all) if (s[0] == 'n') ok.Add(s.Substring(2));
        line = ok[rnd.Next(ok.Count)]; lineT = 9f; linePic = RandPic();
    }

    // ------------------------------------------------------------------ the bet and the buttons
    long MinBet { get { return Math.Min(10, Math.Max(1, CenohCoins.Balance)); } }
    void ClampBet() { if (active) return; long max = Math.Max(1, CenohCoins.Balance); if (bet > max) bet = max; if (bet < MinBet) bet = MinBet; }
    void BetStep(int k)
    {
        if (active) return; long step = bet < 100 ? 10 : bet < 1000 ? 50 : bet < 10000 ? 500 : 5000;
        if (k == 0) bet -= step; else if (k == 1) bet += step; else if (k == 2) bet /= 2; else if (k == 3) bet *= 2; else bet = CenohCoins.Balance;
        ClampBet(); Invalidate();
    }
    void SetGame(int g)
    {
        if (active) return; game = g; status = ""; statusCol = Theme.Text;
        for (int i = 0; i < 5; i++) { gameBtns[i].Selected = i == g; gameBtns[i].Invalidate(); }
        optSel[0] = 0; optSel[1] = 1; optSel[2] = 0; optSel[4] = 1; SyncUi(); Invalidate();
    }
    readonly int[] optSel = new int[5];       // the chosen option for each game: rocket auto cash out, mines count, plinko risk
    static readonly string[][] OptLabels = { new[] { "Manual", "1.5×", "2×", "5×" }, new[] { "1", "3", "5", "10" }, null, null, new[] { "Low", "Med", "High", "" } };
    static readonly string[] OptTitles = { "AUTO CASH OUT AT", "BOMBS", "", "", "RISK" };
    static readonly double[] AutoAt = { 0, 1.5, 2, 5 }; static readonly int[] MineCounts = { 1, 3, 5, 10 };
    void Opt(int k) { if (active) return; optSel[game] = k; SyncUi(); Invalidate(); }
    void Set(Btn b, string text, bool enabled, bool visible) { if (b.Text != text) { b.Text = text; b.Invalidate(); } if (b.Enabled != enabled) b.Enabled = enabled; if (b.Visible != visible) b.Visible = visible; }
    void SyncUi()
    {
        for (int i = 0; i < 5; i++) { bool e = !active; if (gameBtns[i].Enabled != e) gameBtns[i].Enabled = e; }
        for (int i = 0; i < 5; i++) { if (betBtns[i].Enabled == active) betBtns[i].Enabled = !active; }
        var ol = OptLabels[game];
        for (int i = 0; i < 4; i++)
        {
            bool vis = ol != null && ol[i].Length > 0; Set(optBtns[i], vis ? ol[i] : "", !active, vis); bool sel = vis && optSel[game] == i; if (optBtns[i].Selected != sel) { optBtns[i].Selected = sel; optBtns[i].Invalidate(); }
        }
        bool broke = CenohCoins.Balance < 1 && !active; if (refillBtn.Visible != broke) { refillBtn.Visible = broke; if (broke) Say("broke"); }
        bool can = CenohCoins.Balance >= bet && bet > 0;
        switch (game)
        {
            case 0:
                if (rState == 1 && !rCashed) Set(act1, "Cash out  " + CenohCoins.Fmt((long)Math.Floor(bet * rMult)), true, true);
                else if (rState == 1) Set(act1, "Flying…", false, true); else Set(act1, "Launch", can, true);
                Set(act2, "", false, false); Set(act3, "", false, false); break;
            case 1:
                if (mPlaying) Set(act1, mSafe > 0 ? "Cash out  " + CenohCoins.Fmt((long)Math.Floor(bet * MinesMult(mSafe, MineCounts[optSel[1]]))) : "Pick a tile", mSafe > 0, true); else Set(act1, "Start", can, true);
                Set(act2, "", false, false); Set(act3, "", false, false); break;
            case 2: Set(act1, sSpin ? "Spinning…" : "Spin", !sSpin && can, true); Set(act2, "", false, false); Set(act3, "", false, false); break;
            case 3:
                if (bState == 1) { Set(act1, "Hit", true, true); Set(act2, "Stand", true, true); Set(act3, "Double down", bP.Count == 2 && CenohCoins.Balance >= bBet, true); }
                else if (bState == 2) { Set(act1, "Dealer plays…", false, true); Set(act2, "", false, false); Set(act3, "", false, false); }
                else { Set(act1, "Deal", can, true); Set(act2, "", false, false); Set(act3, "", false, false); }
                break;
            default: Set(act1, "Drop a ball", can, true); Set(act2, "", false, false); Set(act3, "", false, false); break;
        }
        SyncPicBtns();
    }
    void Act(int k)
    {
        switch (game)
        {
            case 0: RocketAct(); break;
            case 1: MinesAct(); break;
            case 2: SlotsAct(); break;
            case 3: BjAct(k); break;
            default: PlinkoAct(); break;
        }
        SyncUi(); Invalidate();
    }
    bool TakeBet(long amount) { if (amount < 1 || !CenohCoins.Spend(amount)) { Say("broke"); return false; } return true; }
    // a round ended: pay out, set the banner, throw confetti for a good one, and let the house react
    void Settle(long stake, long payout, string text, string ev)
    {
        if (payout > 0) CenohCoins.Pay(payout); active = false; status = text; statusCol = payout > stake ? Theme.Green : payout == stake ? Theme.Amber : Theme.Red;
        if (payout > stake) Confetti(BoardArea, payout >= stake * 5 ? 150 : 60); ClampBet();
        Say(ev != null ? ev : payout >= stake * 5 && payout > stake ? "big" : payout > stake ? "win" : payout == stake ? "push" : "lose");
    }
    void Confetti(Rectangle a, int n)
    {
        Color[] cs = { Theme.Accent, Theme.AccentSoft, Color.White, Theme.Green, Theme.Amber, Color.FromArgb(255, 120, 200), Color.FromArgb(90, 190, 255) };
        for (int i = 0; i < n; i++) parts.Add(new CPart { X = a.X + a.Width / 2 + (float)(rnd.NextDouble() - 0.5) * a.Width * 0.5f, Y = a.Y + a.Height * 0.3f, Vx = (float)(rnd.NextDouble() - 0.5) * 800, Vy = -200 - (float)rnd.NextDouble() * 650, A = (float)rnd.NextDouble() * 6f, Va = (float)(rnd.NextDouble() - 0.5) * 14f, S = 6 + (float)rnd.NextDouble() * 8, C = cs[i % cs.Length], Life = 3.5f });
    }
    void Boom(float x, float y, int n)
    {
        Color[] cs = { Color.FromArgb(255, 220, 90), Color.FromArgb(255, 150, 40), Color.FromArgb(240, 70, 40), Color.White };
        for (int i = 0; i < n; i++) { double an = rnd.NextDouble() * Math.PI * 2, sp = 80 + rnd.NextDouble() * 420; parts.Add(new CPart { X = x, Y = y, Vx = (float)(Math.Cos(an) * sp), Vy = (float)(Math.Sin(an) * sp), S = 4 + (float)rnd.NextDouble() * 9, C = cs[i % cs.Length], Dot = true, Life = 0.5f + (float)rnd.NextDouble() * 0.7f }); }
    }

    // ------------------------------------------------------------------ ROCKET
    int rState, rPic = -1; double rT, rCrash = 2, rMult = 1; bool rCashed; readonly List<double> rHist = new List<double>(); float rFlame; 
    const double RocketRate = 0.12;
    void RocketAct()
    {
        if (rState == 1) { if (!rCashed) { rCashed = true; long w = (long)Math.Floor(bet * rMult); Settle(bet, w, "Cashed out at " + rMult.ToString("0.00", CultureInfo.InvariantCulture) + "x   +" + CenohCoins.Fmt(w - bet), "cash"); if (w > bet) Confetti(BoardArea, 40); } return; }
        if (!TakeBet(bet)) return;
        active = true; rState = 1; rPic = RandPic(); rT = 0; rMult = 1; rCashed = false; status = ""; statusCol = Theme.Text;
        double u = rnd.NextDouble(); rCrash = Math.Min(1000.0, Math.Max(1.0, Math.Floor(97.0 / (1.0 - u)) / 100.0));
    }
    void RocketTick(float dt)
    {
        rFlame += dt * 30f; if (rState != 1) return;
        rT += dt; rMult = Math.Exp(RocketRate * rT);
        if (!rCashed && AutoAt[optSel[0]] > 0 && rMult >= AutoAt[optSel[0]] && AutoAt[optSel[0]] < rCrash) { rMult = AutoAt[optSel[0]]; RocketAct(); SyncUi(); rMult = Math.Exp(RocketRate * rT); }
        if (rMult >= rCrash)
        {
            rMult = rCrash; rState = 2; rHist.Insert(0, rCrash); if (rHist.Count > 9) rHist.RemoveAt(9);
            var p = RocketTip(); Boom(p.X, p.Y, 70);
            if (!rCashed) { Settle(bet, 0, "Crashed at " + rCrash.ToString("0.00", CultureInfo.InvariantCulture) + "x", "crash"); }
            SyncUi();
        }
    }
    PointF RocketTip()
    {
        var r = Rectangle.Inflate(BoardArea, -30, -30); double mMax = Math.Max(2.0, rMult * 1.3), tMax = Math.Log(mMax) / RocketRate;
        return new PointF((float)(r.X + rT / tMax * r.Width), (float)(r.Bottom - (rMult - 1) / (mMax - 1) * (r.Height - 20)));
    }
    void DrawRocket(Graphics g, Rectangle A)
    {
        var r = Rectangle.Inflate(A, -30, -30); double mMax = Math.Max(2.0, rMult * 1.3), tMax = Math.Log(mMax) / RocketRate;
        using (var p = new Pen(Color.FromArgb(34, 255, 255, 255), 1f)) for (int i = 1; i < 5; i++) { g.DrawLine(p, r.X, r.Bottom - i * r.Height / 5, r.Right, r.Bottom - i * r.Height / 5); g.DrawLine(p, r.X + i * r.Width / 5, r.Y, r.X + i * r.Width / 5, r.Bottom); }
        for (int i = 1; i <= 4; i++) TextRenderer.DrawText(g, (1 + (mMax - 1) * i / 5).ToString("0.0", CultureInfo.InvariantCulture) + "x", Theme.Small, new Rectangle(r.X - 4, r.Bottom - i * r.Height / 5 - 16, 60, 16), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        int n = 60; var pts = new List<PointF>(); pts.Add(new PointF(r.X, r.Bottom));
        if (rState > 0) for (int i = 1; i <= n; i++) { double tt = rT * i / n; double m = Math.Exp(RocketRate * tt); pts.Add(new PointF((float)(r.X + tt / tMax * r.Width), (float)(r.Bottom - (m - 1) / (mMax - 1) * (r.Height - 20)))); }
        else pts.Add(new PointF(r.X + 30, r.Bottom - 30));
        PointF tip = pts[pts.Count - 1], prev = pts[Math.Max(0, pts.Count - 3)]; float ang = (float)(Math.Atan2(tip.Y - prev.Y, tip.X - prev.X) * 180 / Math.PI); if (rState == 0) ang = -40f;
        if (pts.Count > 2)
        {
            var poly = new List<PointF>(pts); poly.Add(new PointF(tip.X, r.Bottom));
            using (var b = new SolidBrush(Color.FromArgb(34, rState == 2 && !rCashed ? Theme.Red : Theme.Accent))) g.FillPolygon(b, poly.ToArray());
            using (var p = new Pen(rState == 2 && !rCashed ? Theme.Red : Theme.Accent, 4f) { LineJoin = LineJoin.Round }) g.DrawLines(p, pts.ToArray());
        }
        if (rState != 2) { int ps = 72; g.DrawImage(Face(rPic >= 0 ? rPic : linePic, ps, false), tip.X - ps / 2f, tip.Y - ps / 2f, ps, ps); }   // the rocket is just a picture
        string mt = rMult.ToString("0.00", CultureInfo.InvariantCulture) + "x"; Color mc = rState == 2 && !rCashed ? Theme.Red : rCashed ? Theme.Green : Color.White;
        TextRenderer.DrawText(g, mt, FHuge, new Rectangle(A.X, A.Y + A.Height / 2 - 120, A.Width, 100), mc, TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPrefix);
        int hx = A.X + 24; TextRenderer.DrawText(g, "Last rockets", Theme.SmallB, new Rectangle(hx, A.Y + 14, 110, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix); hx += 96;
        foreach (double h in rHist) hx += Draw.Chip(g, hx, A.Y + 14, h.ToString("0.00", CultureInfo.InvariantCulture) + "x", h >= 2 ? Theme.Green : Theme.Red, true);
    }

    // ------------------------------------------------------------------ MINES
    bool mPlaying; readonly bool[] mBomb = new bool[25], mUp = new bool[25], mHit = new bool[25], mOwn = new bool[25]; readonly float[] mFlip = new float[25]; readonly int[] mPic = new int[25]; int mSafe;
    public static double MinesMult(int k, int m) { double r = 0.97; for (int i = 0; i < k; i++) r *= (25.0 - i) / (25.0 - m - i); return r; }
    void MinesAct()
    {
        if (mPlaying) { if (mSafe > 0) MinesEnd(true); return; }
        if (!TakeBet(bet)) return;
        int m = MineCounts[optSel[1]]; Array.Clear(mBomb, 0, 25); Array.Clear(mUp, 0, 25); Array.Clear(mHit, 0, 25); Array.Clear(mOwn, 0, 25); Array.Clear(mFlip, 0, 25); mSafe = 0;
        int placed = 0; while (placed < m) { int i = rnd.Next(25); if (!mBomb[i]) { mBomb[i] = true; placed++; } }
        for (int i = 0; i < 25; i++) mPic[i] = RandPic(); mPlaying = true; active = true; status = ""; statusCol = Theme.Text;
    }
    void MinesEnd(bool cashed)
    {
        mPlaying = false; for (int i = 0; i < 25; i++) mUp[i] = true;
        int m = MineCounts[optSel[1]];
        if (cashed) { long w = (long)Math.Floor(bet * MinesMult(mSafe, m)); Settle(bet, w, "Cashed out at " + MinesMult(mSafe, m).ToString("0.00", CultureInfo.InvariantCulture) + "x   +" + CenohCoins.Fmt(w - bet), "cash"); if (w > bet) Confetti(BoardArea, 50); }
        else Settle(bet, 0, "Boom! You hit a bomb", "lose");
        SyncUi();
    }
    Rectangle MineCell(int i, out int cell)
    {
        var a = BoardArea; cell = Math.Max(40, Math.Min(112, Math.Min((a.Width - 40) / 5, (a.Height - 150) / 5))); int gap = 10, bw = 5 * cell + 4 * gap, bh = bw;
        int ox = a.X + (a.Width - bw) / 2, oy = a.Y + 74 + Math.Max(0, (a.Height - 74 - bh) / 2 - 10);
        return new Rectangle(ox + (i % 5) * (cell + gap), oy + (i / 5) * (cell + gap), cell, cell);
    }
    void MinesClick(Point pt)
    {
        if (!mPlaying) return; int cell;
        for (int i = 0; i < 25; i++) { var r = MineCell(i, out cell); if (r.Contains(pt) && !mUp[i]) { mUp[i] = true; mOwn[i] = true; if (mBomb[i]) { mHit[i] = true; var c = new PointF(r.X + r.Width / 2, r.Y + r.Height / 2); Boom(c.X, c.Y, 50); MinesEnd(false); } else { mSafe++; if (mSafe >= 25 - MineCounts[optSel[1]]) MinesEnd(true); else SyncUi(); } break; } }
    }
    void DrawMines(Graphics g, Rectangle A)
    {
        int m = MineCounts[optSel[1]]; double cur = MinesMult(mSafe, m), next = MinesMult(mSafe + 1, m);
        TextRenderer.DrawText(g, "CURRENT", Theme.SmallB, new Rectangle(A.X + 28, A.Y + 14, 140, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, cur.ToString("0.00", CultureInfo.InvariantCulture) + "x", FStat, new Rectangle(A.X + 28, A.Y + 32, 160, 30), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "NEXT GEM", Theme.SmallB, new Rectangle(A.X + 200, A.Y + 14, 140, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, mSafe >= 25 - m ? "-" : next.ToString("0.00", CultureInfo.InvariantCulture) + "x", FStat, new Rectangle(A.X + 200, A.Y + 32, 160, 30), Theme.Green, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "GEMS FOUND  " + mSafe + " / " + (25 - m), Theme.UIB, new Rectangle(A.Right - 260, A.Y + 32, 236, 24), Theme.Text, TextFormatFlags.Right | TextFormatFlags.NoPrefix);
        int cell; g.InterpolationMode = InterpolationMode.HighQualityBilinear; g.PixelOffsetMode = PixelOffsetMode.Half;
        for (int i = 0; i < 25; i++)
        {
            var r = MineCell(i, out cell); float f = mFlip[i]; float sx = Math.Max(0.03f, Math.Abs((float)Math.Cos(f * Math.PI))); bool up = f > 0.5f;
            float cx = r.X + r.Width / 2f, cy = r.Y + r.Height / 2f; int w = Math.Max(2, (int)(cell * sx));
            if (!up) { var back = MineBack(cell); int bw2 = Math.Max(2, (int)((cell + 2 * Pad) * sx)); g.DrawImage(back, new Rectangle((int)(cx - bw2 / 2f), (int)(cy - (cell + 2 * Pad) / 2f), bw2, cell + 2 * Pad)); continue; }
            var dest = new Rectangle((int)(cx - w / 2f), r.Y, w, cell);
            if (mBomb[i])
            {
                using (var path = Theme.Round(dest, 12)) using (var b = new LinearGradientBrush(dest, Color.FromArgb(120, 28, 30), Color.FromArgb(60, 12, 20), 90f)) g.FillPath(b, path);
                if (w > cell * 0.6f) { var star = new List<PointF>(); for (int k = 0; k < 16; k++) { double an = k * Math.PI / 8; float rr = k % 2 == 0 ? cell * 0.40f : cell * 0.22f; star.Add(new PointF(cx + (float)Math.Cos(an) * rr, cy + (float)Math.Sin(an) * rr)); } using (var b = new SolidBrush(mHit[i] ? Color.FromArgb(255, 200, 60) : Color.FromArgb(150, 255, 150, 40))) g.FillPolygon(b, star.ToArray()); g.FillEllipse(Brushes.Black, cx - cell * 0.16f, cy - cell * 0.12f, cell * 0.32f, cell * 0.32f); using (var p = new Pen(Color.FromArgb(220, 220, 220), 3f)) g.DrawLine(p, cx + cell * 0.06f, cy - cell * 0.1f, cx + cell * 0.16f, cy - cell * 0.24f); }
            }
            else { var fb = Face(mPic[i], cell, false); g.DrawImage(fb, dest); }
            if (!mPlaying && !mOwn[i]) using (var path = Theme.Round(dest, 12)) using (var b = new SolidBrush(Color.FromArgb(60, 0, 0, 0))) g.FillPath(b, path);
            using (var path = Theme.Round(Rectangle.Inflate(dest, -1, -1), 12)) using (var p = new Pen(mBomb[i] ? Theme.Red : Theme.Green, 2.2f)) g.DrawPath(p, path);
        }
    }
    Bitmap MineBack(int s)
    {
        return Sprite("cmback_" + s, s, s, delegate (Graphics g, Rectangle r)
        {
            using (var path = Theme.Round(r, 12)) { using (var b = new LinearGradientBrush(r, Theme.Lerp(Theme.Accent, Theme.Card, 0.55f), Theme.Lerp(Theme.Accent, Theme.Bg, 0.8f), 60f)) g.FillPath(b, path); using (var p = new Pen(Theme.AccentSoft, 2f)) g.DrawPath(p, path); }
            TextRenderer.DrawText(g, "?", FStat, r, Color.FromArgb(150, 255, 255, 255), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        });
    }

    // ------------------------------------------------------------------ SLOTS
    class Reel { public float Pos, Speed = 16f; public int Target; public float StopAt, Final; public bool Stopping, Done; }
    readonly Reel[] reels = new Reel[3]; readonly int[] slotPic = new int[6] { 0, 1, 2, 3, 4, 5 }; bool sSpin; float sT; static readonly int[] SlotPay = { 10, 10, 10, 10, 30, 50 };
    void SlotsAct()
    {
        if (sSpin || !TakeBet(bet)) return; active = true; sSpin = true; sT = 0; status = ""; statusCol = Theme.Text;
        for (int i = 0; i < 3; i++) reels[i] = new Reel { Pos = (float)rnd.NextDouble() * 6f, Target = rnd.Next(6), StopAt = 0.9f + 0.55f * i };
    }
    static int Mod6(int n) { return ((n % 6) + 6) % 6; }
    void SlotsTick(float dt)
    {
        if (!sSpin) return; sT += dt; bool all = true;
        foreach (var r in reels)
        {
            if (r.Done) continue; all = false;
            if (!r.Stopping) { r.Pos += r.Speed * dt; if (sT >= r.StopAt) { r.Stopping = true; int c = (int)Math.Ceiling(r.Pos); r.Final = c + Mod6(r.Target - c) + 6; } }
            else { r.Pos = Ticker.Ease(r.Pos, r.Final, 7f, dt); if (r.Final - r.Pos < 0.02f) { r.Pos = r.Final; r.Done = true; } }
        }
        if (!all) return;
        sSpin = false; int a = Mod6((int)Math.Round(reels[0].Pos)), b = Mod6((int)Math.Round(reels[1].Pos)), c2 = Mod6((int)Math.Round(reels[2].Pos));
        if (a == b && b == c2) { long w = bet * SlotPay[a]; Settle(bet, w, "THREE OF A KIND  " + SlotPay[a] + "x   +" + CenohCoins.Fmt(w - bet), null); }
        else if (a == b || b == c2 || a == c2) Settle(bet, bet, "Two the same: bet back", "push");
        else Settle(bet, 0, "No match", "lose");
        SyncUi();
    }
    void DrawSlots(Graphics g, Rectangle A)
    {
        int S = Math.Max(50, Math.Min(140, Math.Min((A.Height - 250) / 3, (A.Width - 100) / 3))); int gap = 14, mw = 3 * S + 2 * gap + 40, mh = 3 * S + 40;
        var m = new Rectangle(A.X + (A.Width - mw) / 2, A.Y + 50 + Math.Max(0, (A.Height - 50 - mh - 130) / 2), mw, mh);
        using (var path = Theme.Round(m, 24)) { using (var b = new LinearGradientBrush(m, Color.FromArgb(40, 30, 54), Color.FromArgb(14, 12, 28), 90f)) g.FillPath(b, path); using (var p = new Pen(Theme.Accent, 3f)) g.DrawPath(p, path); }
        g.InterpolationMode = InterpolationMode.HighQualityBilinear; g.PixelOffsetMode = PixelOffsetMode.Half;
        for (int i = 0; i < 3; i++)
        {
            var win = new Rectangle(m.X + 20 + i * (S + gap), m.Y + 20, S, 3 * S); var st = g.Save(); g.SetClip(win);
            using (var b = new SolidBrush(Color.FromArgb(18, 16, 30))) g.FillRectangle(b, win);
            float pos = reels[i].Pos; int n0 = (int)Math.Floor(pos) - 1;
            for (int n = n0; n <= n0 + 4; n++) { float y = win.Y + S + (n - pos) * S; g.DrawImage(Face(slotPic[Mod6(n)], S - 12, false), win.X + 6, y + 6, S - 12, S - 12); }
            using (var b = new LinearGradientBrush(win, Color.FromArgb(170, 0, 0, 0), Color.FromArgb(0, 0, 0, 0), 90f)) g.FillRectangle(b, win.X, win.Y, S, S * 0.5f);
            using (var b = new LinearGradientBrush(new RectangleF(win.X, win.Bottom - S * 0.5f, S, S * 0.5f + 1), Color.FromArgb(0, 0, 0, 0), Color.FromArgb(170, 0, 0, 0), 90f)) g.FillRectangle(b, win.X, win.Bottom - S * 0.5f, S, S * 0.5f);
            g.Restore(st);
        }
        bool won = !sSpin && statusCol == Theme.Green; float pulse = 0.5f + 0.5f * (float)Math.Sin(t * 8f);
        using (var p = new Pen(won ? Color.FromArgb((int)(140 + 100 * pulse), Theme.Green) : Color.FromArgb(150, Theme.Amber), won ? 4f : 2.2f)) g.DrawRectangle(p, m.X + 14, m.Y + 20 + S, mw - 28, S);
        // the pay table
        int tx = A.X + (A.Width - 6 * 70) / 2, ty = m.Bottom + 20;
        for (int i = 0; i < 6; i++) { g.DrawImage(Face(slotPic[i], 36, true), tx + i * 70 + 14, ty, 36, 36); TextRenderer.DrawText(g, SlotPay[i] + "×", Theme.SmallB, new Rectangle(tx + i * 70, ty + 38, 64, 16), Theme.AccentSoft, TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPrefix); }
    }

    // ------------------------------------------------------------------ BLACKJACK
    class BCard { public int Rank, Suit; public float Anim; public bool Hidden; }
    readonly List<BCard> bP = new List<BCard>(), bD = new List<BCard>(); int bState; float bTimer, bClear; long bBet;
    BCard Draw1(bool hidden) { return new BCard { Rank = rnd.Next(1, 14), Suit = rnd.Next(4), Hidden = hidden }; }
    static int Total(List<BCard> h, bool countHidden)
    {
        int t = 0, aces = 0; foreach (var c in h) { if (c.Hidden && !countHidden) continue; int v = c.Rank >= 10 ? 10 : c.Rank == 1 ? 11 : c.Rank; if (c.Rank == 1) aces++; t += v; }
        while (t > 21 && aces > 0) { t -= 10; aces--; } return t;
    }
    void BjAct(int k)
    {
        if (bState == 0 || bState == 3)
        {
            if (k != 1 || !TakeBet(bet)) return; bBet = bet; bClear = 0; bP.Clear(); bD.Clear(); active = true; status = ""; statusCol = Theme.Text; bState = 1;
            bP.Add(Draw1(false)); bD.Add(Draw1(false)); bP.Add(Draw1(false)); bD.Add(Draw1(true));
            bool pbj = Total(bP, true) == 21, dbj = Total(bD, true) == 21;
            if (pbj || dbj) { bD[1].Hidden = false; bState = 3; if (pbj && dbj) Settle(bBet, bBet, "Both have blackjack: push", "push"); else if (pbj) Settle(bBet, (long)Math.Floor(bBet * 2.5), "BLACKJACK  pays 3 to 2", "big"); else Settle(bBet, 0, "Dealer has blackjack", "lose"); }
            return;
        }
        if (bState != 1) return;
        if (k == 1) { bP.Add(Draw1(false)); CheckPlayer(); }
        else if (k == 2) Stand();
        else if (k == 3 && bP.Count == 2 && TakeBet(bBet)) { bBet *= 2; bP.Add(Draw1(false)); if (Total(bP, true) > 21) CheckPlayer(); else Stand(); }
    }
    void CheckPlayer() { int tt = Total(bP, true); if (tt > 21) { bD[1].Hidden = false; bState = 3; Settle(bBet, 0, "Bust with " + tt, "bust"); } else if (tt == 21) Stand(); }
    void Stand() { bState = 2; bD[1].Hidden = false; bTimer = 0.7f; }
    void BjTick(float dt)
    {
        foreach (var c in bP) c.Anim = Math.Min(1f, c.Anim + dt * 4f); foreach (var c in bD) c.Anim = Math.Min(1f, c.Anim + dt * 4f);
        if (bState == 3 && bP.Count > 0) { bClear += dt; if (bClear > 4.5f) { bP.Clear(); bD.Clear(); bState = 0; status = ""; SyncUi(); } }     // the table clears itself a few seconds after a round
        if (bState != 2) return; bTimer -= dt; if (bTimer > 0) return;
        int dt2 = Total(bD, true); if (dt2 < 17) { bD.Add(Draw1(false)); bTimer = 0.8f; return; }
        int pt = Total(bP, true); bState = 3; string dn = "Dealer " + dt2 + ", you " + pt;
        if (dt2 > 21) Settle(bBet, bBet * 2, "Dealer busts with " + dt2 + "   +" + CenohCoins.Fmt(bBet), null);
        else if (pt > dt2) Settle(bBet, bBet * 2, dn + "   +" + CenohCoins.Fmt(bBet), null);
        else if (pt == dt2) Settle(bBet, bBet, dn + ": push", "push"); else Settle(bBet, 0, dn, "lose");
        SyncUi();
    }
    void DrawCard(Graphics g, Rectangle r, BCard c, Rectangle origin)
    {
        float k = 1f - (1f - c.Anim) * (1f - c.Anim); var d = new Rectangle((int)(origin.X + (r.X - origin.X) * k), (int)(origin.Y + (r.Y - origin.Y) * k), r.Width, r.Height);
        using (var sp = Theme.Round(new Rectangle(d.X + 2, d.Y + 4, d.Width, d.Height), 9)) using (var b = new SolidBrush(Color.FromArgb(70, 0, 0, 0))) g.FillPath(b, sp);
        using (var path = Theme.Round(d, 9))
        {
            if (c.Hidden) { using (var b = new LinearGradientBrush(d, Theme.Lerp(Theme.Accent, Theme.Card, 0.45f), Theme.Lerp(Theme.Accent, Theme.Bg, 0.8f), 60f)) g.FillPath(b, path); using (var p = new Pen(Color.White, 2f)) g.DrawPath(p, path); TextRenderer.DrawText(g, CardBack, FStat, d, Color.FromArgb(220, 255, 255, 255), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix); return; }
            using (var b = new SolidBrush(Color.FromArgb(250, 250, 246))) g.FillPath(b, path); using (var p = new Pen(Color.FromArgb(120, 120, 130), 1.4f)) g.DrawPath(p, path);
        }
        bool red = c.Suit == 1 || c.Suit == 2; Color col = red ? Color.FromArgb(200, 40, 50) : Color.FromArgb(30, 30, 40); string rk = c.Rank == 1 ? "A" : c.Rank == 11 ? "J" : c.Rank == 12 ? "Q" : c.Rank == 13 ? "K" : c.Rank.ToString(); string su = new[] { "♠", "♥", "♦", "♣" }[c.Suit];
        TextRenderer.DrawText(g, rk, FCard, new Rectangle(d.X + 5, d.Y + 3, d.Width - 8, 26), col, TextFormatFlags.Left | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, su, Theme.UIL, new Rectangle(d.X + 5, d.Y + 26, 24, 22), col, TextFormatFlags.Left | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        if (c.Rank >= 11) { int fs = Math.Max(24, d.Width - 30); g.DrawImage(Face(c.Rank * 4 + c.Suit, fs, true), d.X + (d.Width - fs) / 2, d.Y + d.Height - fs - 12, fs, fs); }
        else TextRenderer.DrawText(g, su, FSuit, new Rectangle(d.X, d.Y + d.Height / 2 - 8, d.Width, 40), col, TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
    }
    const string CardBack = "C";
    void DrawBlackjack(Graphics g, Rectangle A)
    {
        var felt = Rectangle.Inflate(A, -18, -18); felt.Y += 10; felt.Height -= 10;
        using (var path = Theme.Round(felt, 28)) { using (var b = new LinearGradientBrush(felt, Color.FromArgb(24, 92, 62), Color.FromArgb(10, 52, 38), 90f)) g.FillPath(b, path); using (var p = new Pen(Color.FromArgb(120, 255, 255, 255), 2f)) g.DrawPath(p, path); }
        int cw = Math.Max(54, Math.Min(92, felt.Width / 9)), ch = (int)(cw * 1.42f); var deck = new Rectangle(felt.Right - cw - 20, felt.Y - ch / 2, cw, ch);
        int dy = felt.Y + 56, py = felt.Bottom - ch - 56; int step = (int)(cw * 0.82f);
        g.DrawImage(Face(linePic, 62, true), felt.X + 24, dy + (ch - 62) / 2, 62, 62);
        TextRenderer.DrawText(g, "DEALER  " + (bD.Count == 0 ? "" : Total(bD, false).ToString()), Theme.SmallB, new Rectangle(felt.X + 24, dy - 30, 220, 18), Color.White, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "YOU  " + (bP.Count == 0 ? "" : Total(bP, true).ToString()), Theme.SmallB, new Rectangle(felt.X + 24, py - 28, 220, 18), Color.White, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        int dx0 = felt.X + (felt.Width - ((bD.Count - 1) * step + cw)) / 2, px0 = felt.X + (felt.Width - ((bP.Count - 1) * step + cw)) / 2;
        for (int i = 0; i < bD.Count; i++) DrawCard(g, new Rectangle(dx0 + i * step, dy, cw, ch), bD[i], deck);
        for (int i = 0; i < bP.Count; i++) DrawCard(g, new Rectangle(px0 + i * step, py, cw, ch), bP[i], deck);
        if (bP.Count == 0) TextRenderer.DrawText(g, "Place your bet and press Deal", Theme.UIL, new Rectangle(felt.X, felt.Y + felt.Height / 2 - 14, felt.Width, 28), Color.FromArgb(200, 255, 255, 255), TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPrefix);
    }

    // ------------------------------------------------------------------ PLINKO
    const int PRows = 10;
    class Ball { public int[] Dir = new int[PRows]; public float P, LandT; public int Pic, Slot, Risk; public long Bet; public bool Landed; }
    readonly List<Ball> balls = new List<Ball>(); readonly float[] slotFlash = new float[PRows + 1]; readonly List<double> pHist = new List<double>();
    static readonly double[][] PMult = { new[] { 4.0, 2.0, 1.3, 1.1, 0.9, 0.8 }, new[] { 22.0, 5.0, 2.0, 1.4, 0.6, 0.4 }, new[] { 100.0, 12.0, 3.2, 0.7, 0.2, 0.1 } };
    double PlinkoMult(int slot) { return PMult[optSel[4]][Math.Min(slot, PRows - slot)]; }
    void PlinkoAct()
    {
        if (!TakeBet(bet)) return; var b = new Ball { Pic = RandPic(), Bet = bet, Risk = optSel[4] }; int s = 0; for (int i = 0; i < PRows; i++) { b.Dir[i] = rnd.Next(2); s += b.Dir[i]; } b.Slot = s; balls.Add(b); status = ""; ClampBet();
    }
    void PlinkoTick(float dt)
    {
        for (int i = slotFlash.Length - 1; i >= 0; i--) slotFlash[i] = Math.Max(0f, slotFlash[i] - dt * 1.4f);
        for (int i = balls.Count - 1; i >= 0; i--)
        {
            var b = balls[i];
            if (!b.Landed) { b.P += dt / 0.17f; if (b.P >= PRows) { b.P = PRows; b.Landed = true; double mu = PMult[b.Risk][Math.Min(b.Slot, PRows - b.Slot)]; long w = (long)Math.Floor(b.Bet * mu); slotFlash[b.Slot] = 1f; if (w > 0) CenohCoins.Pay(w); pHist.Insert(0, mu); if (pHist.Count > 9) pHist.RemoveAt(9); status = mu.ToString("0.0#", CultureInfo.InvariantCulture) + "x   " + (w >= b.Bet ? "+" : "-") + CenohCoins.Fmt(Math.Abs(w - b.Bet)); statusCol = w > b.Bet ? Theme.Green : w == b.Bet ? Theme.Amber : Theme.Red; if (w > b.Bet) { Say(mu >= 5 ? "big" : "win"); if (mu >= 5) Confetti(BoardArea, 80); } else Say("lose"); ClampBet(); SyncUi(); } }
            else { b.LandT += dt; if (b.LandT > 0.6f) balls.RemoveAt(i); }
        }
    }
    void DrawPlinko(Graphics g, Rectangle A)
    {
        float dx = Math.Min((A.Width - 40) / (PRows + 1.5f), (A.Height - 150) / (PRows * 0.87f + 1.3f)); dx = Math.Max(24f, Math.Min(dx, 70f)); float dy = dx * 0.87f;
        float cx = A.X + A.Width / 2f, top = A.Y + 58 + Math.Max(0, (A.Height - 58 - (PRows * dy + 70)) / 2f);
        for (int r = 0; r < PRows; r++) for (int j = 0; j <= r; j++) { float x = cx + (j - r / 2f) * dx, y = top + r * dy; using (var b = new SolidBrush(Color.FromArgb(200, 240, 240, 255))) g.FillEllipse(b, x - 4, y - 4, 8, 8); }
        for (int s = 0; s <= PRows; s++)
        {
            double mu = PlinkoMult(s); float x = cx + (s - PRows / 2f) * dx; var box = new Rectangle((int)(x - dx * 0.45f), (int)(top + PRows * dy + 4), (int)(dx * 0.9f), 34);
            Color c = mu >= 5 ? Theme.Amber : mu >= 1.2 ? Theme.Green : mu >= 0.8 ? Theme.Accent : Theme.Red; float fl = slotFlash[s];
            using (var path = Theme.Round(box, 8)) { using (var b = new SolidBrush(Color.FromArgb((int)(60 + 150 * fl), c))) g.FillPath(b, path); using (var p = new Pen(Color.FromArgb(200, c), 1.6f)) g.DrawPath(p, path); }
            TextRenderer.DrawText(g, mu.ToString(mu >= 10 ? "0" : "0.0#", CultureInfo.InvariantCulture), Theme.SmallB, box, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        }
        int bs = (int)(dx * 0.75f);
        foreach (var b in balls)
        {
            int i = Math.Min(PRows - 1, (int)b.P); float f = b.P - i; int j = 0; for (int k = 0; k < i; k++) j += b.Dir[k]; int j2 = j + b.Dir[i]; if (b.Landed) { i = PRows - 1; f = 1f; }
            float x0 = cx + (j - i / 2f) * dx, x1 = cx + (j2 - (i + 1) / 2f) * dx, y0 = top + i * dy - bs / 2f - 3, y1 = top + (i + 1) * dy - bs / 2f - 3;
            float x = x0 + (x1 - x0) * f, y = y0 + (y1 - y0) * f - 4f * f * (1f - f) * dy * 0.5f; float al = b.Landed ? Math.Max(0f, 1f - b.LandT / 0.6f) : 1f;
            using (var ia = new ImageAttributes()) { var cm = new ColorMatrix { Matrix33 = al }; ia.SetColorMatrix(cm); var fb = Face(b.Pic, bs, true); g.DrawImage(fb, new Rectangle((int)(x - bs / 2f), (int)y, bs, bs), 0, 0, fb.Width, fb.Height, GraphicsUnit.Pixel, ia); }
        }
        int hx = A.X + 24; TextRenderer.DrawText(g, "Last drops", Theme.SmallB, new Rectangle(hx, A.Y + 14, 90, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix); hx += 80;
        foreach (double h in pHist) hx += Draw.Chip(g, hx, A.Y + 14, h.ToString("0.0#", CultureInfo.InvariantCulture) + "x", h >= 1 ? Theme.Green : Theme.Red, true);
    }

    // ------------------------------------------------------------------ IHubPage + frame logic
    public void HubShown() { RefreshPics(); SyncUi(); }
    public void HubHidden() { }
    public void HubTheme() { ClearFaces(); Invalidate(true); }
    public void HubPrewarm() { }
    protected override void OnTick(float dt)
    {
        if (!picsLoaded && Visible) RefreshPics();
        shownBal = Ticker.Ease(shownBal, CenohCoins.Balance, 7f, dt); if (Math.Abs(shownBal - CenohCoins.Balance) < 0.5f) shownBal = CenohCoins.Balance;
        RocketTick(dt); SlotsTick(dt); BjTick(dt); PlinkoTick(dt);
        for (int i = 0; i < 25; i++) { float tg = mUp[i] ? 1f : 0f; mFlip[i] = Ticker.Ease(mFlip[i], tg, 14f, dt); if (Math.Abs(mFlip[i] - tg) < 0.004f) mFlip[i] = tg; }
        syncT -= dt; if (syncT <= 0) { syncT = 0.25f; ClampBet(); SyncUi(); }      // the buttons never stay stale
        if (lineT > 0) lineT -= dt;
        for (int i = parts.Count - 1; i >= 0; i--) { var p = parts[i]; p.X += p.Vx * dt; p.Y += p.Vy * dt; p.Life -= dt; if (!p.Dot) { p.Vy += 900f * dt; p.Vx *= 1f - 0.8f * dt; p.A += p.Va * dt; } else { p.Vx *= 1f - 2.5f * dt; p.Vy *= 1f - 2.5f * dt; } if (p.Life <= 0 || p.Y > Height + 20) parts.RemoveAt(i); }
    }

    // ------------------------------------------------------------------ drawing
    protected override void DrawCards(Graphics g)
    {
        var s = StatsRect; var sp = Sprite("cstats_" + s.Width + "x" + s.Height, s.Width, s.Height, delegate (Graphics gg, Rectangle r) { Glass(gg, r, 0.1f); }); Blit(g, sp, s.X - Pad, s.Y - Pad);
        var a = BoardArea; var bp = Sprite("cboard_" + a.Width + "x" + a.Height, a.Width, a.Height, delegate (Graphics gg, Rectangle r) { Glass(gg, r, 0.04f); }); Blit(g, bp, a.X - Pad, a.Y - Pad);
    }
    const string HouseName = "The house";
    protected override void DrawContent(Graphics g)
    {
        var logo = Sprite("zlogo", 420, 64, delegate (Graphics gg, Rectangle r) { CasinoLogo.Chip(gg, new RectangleF(r.X, r.Y, 64, 64)); CasinoLogo.Wordmark(gg, new RectangleF(r.X + 76, r.Y + 8, 340, 48)); });
        Blit(g, logo, 44 - Pad, 24 - Pad);
        TextRenderer.DrawText(g, "Pretend money only. CenohCoins are not real and cannot be cashed out.", Theme.UIL, new Rectangle(46, 86, Width - 400, 28), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        var A = BoardArea; g.SmoothingMode = SmoothingMode.AntiAlias; g.InterpolationMode = InterpolationMode.HighQualityBilinear; g.PixelOffsetMode = PixelOffsetMode.Half;
        var clip = g.Save(); g.SetClip(A);
        switch (game) { case 0: DrawRocket(g, A); break; case 1: DrawMines(g, A); break; case 2: DrawSlots(g, A); break; case 3: DrawBlackjack(g, A); break; default: DrawPlinko(g, A); break; }
        g.Restore(clip); g.SmoothingMode = SmoothingMode.AntiAlias;
        if (status.Length > 0) { var br = new Rectangle(A.X + A.Width / 2 - 260, A.Bottom - 50, 520, 38); using (var path = Theme.Round(br, 19)) { using (var b = new SolidBrush(Color.FromArgb(225, Theme.Card))) g.FillPath(b, path); using (var p = new Pen(statusCol, 2f)) g.DrawPath(p, path); } TextRenderer.DrawText(g, status, FBanner, br, statusCol, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis); }
        foreach (var p in parts)
        {
            int al = (int)(255 * Math.Min(1f, p.Life * 2f)); if (p.Dot) { using (var b = new SolidBrush(Color.FromArgb(al, p.C))) g.FillEllipse(b, p.X - p.S / 2, p.Y - p.S / 2, p.S, p.S); continue; }
            var st = g.Save(); g.TranslateTransform(p.X, p.Y); g.RotateTransform(p.A * 57.3f); using (var b = new SolidBrush(Color.FromArgb(al, p.C))) g.FillRectangle(b, -p.S / 2, -p.S / 4, p.S, p.S / 2); g.Restore(st);
        }
        // the house's line under the board
        var bar = new Rectangle(A.X, A.Bottom + 12, A.Width, 54);
        using (var path = Theme.Round(bar, 16)) { using (var b = new SolidBrush(Color.FromArgb(215, Theme.Card))) g.FillPath(b, path); using (var p = new Pen(Theme.Border, 1.4f)) g.DrawPath(p, path); }
        g.DrawImage(Face(linePic, 40, true), bar.X + 10, bar.Y + 7, 40, 40);
        TextRenderer.DrawText(g, HouseName, Theme.SmallB, new Rectangle(bar.X + 62, bar.Y + 7, 200, 16), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, line, Theme.UI, new Rectangle(bar.X + 62, bar.Y + 24, bar.Width - 76, 24), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        // the wallet and the bet
        var s = StatsRect; int x = s.X + 30, y = s.Y + 24;
        TextRenderer.DrawText(g, "CENOHCOINS", Theme.SmallB, new Rectangle(x, y, 210, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, CenohCoins.Fmt((long)Math.Round(shownBal)), FBig, new Rectangle(x, y + 20, 220, 38), Theme.Amber, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "Biggest win  " + CenohCoins.Fmt(CenohCoins.Best) + "   ·   " + CenohCoins.Fmt(CenohCoins.Rounds) + " rounds", Theme.Small, new Rectangle(x, y + 60, 220, 18), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, "BET", Theme.SmallB, new Rectangle(x, y + 94, 100, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g, CenohCoins.Fmt(game == 3 && bState > 0 && bState < 3 ? bBet : bet), FStat, new Rectangle(x, y + 108, 210, 26), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        if (OptTitles[game].Length > 0) TextRenderer.DrawText(g, OptTitles[game], Theme.SmallB, new Rectangle(x, y + 174, 210, 18), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        int ry = (act3.Visible ? act3.Bottom : act2.Visible ? act2.Bottom : act1.Bottom) + 18;
        TextRenderer.DrawText(g, Rules[game], Theme.Small, new Rectangle(x, ry, 210, Math.Max(40, s.Bottom - 70 - ry)), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
    }

    // ------------------------------------------------------------------ mouse
    protected override void OnMouseDown(MouseEventArgs e) { Focus(); if (game == 1) { MinesClick(e.Location); Invalidate(); } base.OnMouseDown(e); }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        bool over = false; if (game == 1 && mPlaying) { int cell; for (int i = 0; i < 25; i++) if (!mUp[i] && MineCell(i, out cell).Contains(e.Location)) over = true; }
        Cursor = over ? Cursors.Hand : Cursors.Default; base.OnMouseMove(e);
    }

    // check switches: put a game in a typical state for a picture, and add up the odds (nothing is spent in the saved wallet)
    public string TestShow(int g)
    {
        CenohCoins.NoSave = true; var sb = new StringBuilder(); RefreshPics(); SetGame(g); CenohCoins.Balance = 5000; bet = 100; var rb = new Random(7);
        switch (g)
        {
            case 0: RocketAct(); rCrash = 40; for (int i = 0; i < 170; i++) RocketTick(1 / 60f); linePic = 3; break;
            case 1: optSel[1] = 1; MinesAct(); int shown = 0; for (int i = 0; i < 25 && shown < 4; i++) if (!mBomb[i]) { mUp[i] = true; mSafe++; shown++; } break;
            case 2: SlotsAct(); for (int i = 0; i < 400 && sSpin; i++) SlotsTick(1 / 60f); break;
            case 3: BjAct(1); if (bState == 1) { } break;
            default: for (int i = 0; i < 6; i++) { PlinkoAct(); balls[balls.Count - 1].P = (float)(i * 1.6); } for (int i = 0; i < 20; i++) PlinkoTick(1 / 60f); break;
        }
        for (int i = 0; i < 40; i++) { mFlip[i % 25] = mUp[i % 25] ? 1f : 0f; } SyncUi();
        // the odds (house edge check): every game should pay back a little under 100%
        double[] rtp = new double[3]; for (int r = 0; r < 3; r++) { double tot = 0; for (int s = 0; s <= PRows; s++) { double c = 1; for (int k = 0; k < s; k++) c = c * (PRows - k) / (k + 1); tot += c / 1024.0 * PMult[r][Math.Min(s, PRows - s)]; } rtp[r] = tot; }
        double sl = 0; for (int a = 0; a < 6; a++) sl += (1.0 / 216) * SlotPay[a]; sl += 90.0 / 216;
        sb.AppendLine("plinko rtp low/med/high = " + rtp[0].ToString("0.000", CultureInfo.InvariantCulture) + " / " + rtp[1].ToString("0.000", CultureInfo.InvariantCulture) + " / " + rtp[2].ToString("0.000", CultureInfo.InvariantCulture));
        sb.AppendLine("slots rtp = " + sl.ToString("0.000", CultureInfo.InvariantCulture));
        int crashLow = 0; for (int i = 0; i < 100000; i++) { double u = rb.NextDouble(); double cp = Math.Max(1.0, Math.Floor(97.0 / (1.0 - u)) / 100.0); if (cp < 2.0) crashLow++; }
        sb.AppendLine("rocket: crashes below 2x = " + (crashLow / 1000.0).ToString("0.0", CultureInfo.InvariantCulture) + "% (should be about 51.5%)");
        sb.AppendLine("mines 3 bombs: 1 gem " + MinesMult(1, 3).ToString("0.000", CultureInfo.InvariantCulture) + "x, 5 gems " + MinesMult(5, 3).ToString("0.00", CultureInfo.InvariantCulture) + "x");
        sb.AppendLine("state: game=" + game + " balance=" + CenohCoins.Balance + " status=" + status + " rState=" + rState + " mSafe=" + mSafe + " slots=" + Mod6((int)Math.Round(reels[0].Pos)) + Mod6((int)Math.Round(reels[1].Pos)) + Mod6((int)Math.Round(reels[2].Pos)) + " bj=" + bP.Count + "/" + bD.Count + " balls=" + balls.Count);
        return sb.ToString();
    }
}
