// The Minecraft Server tab: a status strip that is always there, a row of sections (Overview, Players, World, Console, Backups,
// Automation, Files, Health, Settings) and one section on screen at a time, so nothing is crowded and only what you look at is drawn.
// This file is the shell and everything the sections share: the connection, the commands, who joined and left, the schedules,
// backups, restarts and the helper on the server PC. McViews.cs has the sections themselves.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

abstract class McView
{
    protected McPage P; public readonly List<Control> Ctl = new List<Control>(); public readonly List<TextBox> Fields = new List<TextBox>(); public string Name = "";
    protected McView(McPage p) { P = p; }
    public virtual void Place(Rectangle a) { }
    public virtual void Draw(Graphics g, Rectangle a) { }
    public virtual void Shown() { }
    public virtual bool Click(Point p) { return false; }
    public virtual void Tick() { }
    public virtual void Theme_() { foreach (var t in Fields) { t.BackColor = Theme.Card; t.ForeColor = Theme.Text; } }
    protected Btn Button(string text, int w, Action click, bool primary = false) { var b = new Btn(text) { Width = w, Height = 30, Font = Theme.Small, Primary = primary }; b.Click += delegate { click(); }; Ctl.Add(b); return b; }
    protected TextBox Field(string cue, int w, bool pass = false)
    {
        var t = new TextBox { BorderStyle = BorderStyle.None, BackColor = Theme.Card, ForeColor = Theme.Text, Font = new Font("Segoe UI", 10.5f), Width = w, UseSystemPasswordChar = pass };
        t.HandleCreated += delegate { McPage.SetCue(t, cue); }; Ctl.Add(t); Fields.Add(t); return t;
    }
    protected static void Label(Graphics g, string text, int x, int y, int w = 520) { TextRenderer.DrawText(g, text, Theme.Small, new Rectangle(x, y, w, 16), Theme.Dim, TextFormatFlags.Left | TextFormatFlags.NoPrefix); }
    protected static void Head(Graphics g, string text, int x, int y, int w = 760) { TextRenderer.DrawText(g, text, Theme.SmallB, new Rectangle(x, y, w, 16), Theme.AccentSoft, TextFormatFlags.Left | TextFormatFlags.NoPrefix); }
}

class McPage : BackdropPage, IHubPage
{
    [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)] static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, string l);
    public static void SetCue(TextBox t, string cue) { SendMessage(t.Handle, 0x1501, (IntPtr)1, cue); }
    static readonly Font FTitle = new Font("Segoe UI Semibold", 26f), FBig = new Font("Segoe UI Semibold", 18f);
    internal readonly HubForm hub;
    // ---- shared state the sections read
    internal McNet.Rcon rcon; internal McStatus status = new McStatus(); internal readonly List<string> players = new List<string>(); internal string selPlayer = ""; internal string rconMsg = "";
    internal Dictionary<string, string> cfg = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase), au = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    internal bool working, connecting, pinging; internal Dictionary<string, string> helperInfo = new Dictionary<string, string>(); internal string helperErr = "";
    internal readonly List<McRow> events = new List<McRow>(); internal readonly List<string[]> history = new List<string[]>();     // history: name, joined, minutes
    readonly Dictionary<string, DateTime> joined = new Dictionary<string, DateTime>(); readonly List<string> lastSeen = new List<string>(); bool seenOnce;
    internal readonly StringBuilder consoleText = new StringBuilder(); internal event Action ConsoleChanged; internal event Action StateChanged; internal event Action PlayersChanged;
    DateTime lastPing = DateTime.MinValue, lastList = DateTime.MinValue, lastHealth = DateTime.MinValue, lastBackup, lastAnnounce = DateTime.Now; string lastRestartDay = "";
    internal McGraph gLatency, gPlayers, gTps, gCpu, gRam;
    internal readonly System.Windows.Forms.Timer poll = new System.Windows.Forms.Timer { Interval = 1000 }; internal bool keepAlive; NotifyIcon tray; System.Windows.Forms.Timer trayHide;
    readonly List<McView> views = new List<McView>(); readonly Btn[] tabBtns; int cur; Btn connectBtn; internal bool restartSupported = true;

    public McPage(HubForm h)
    {
        hub = h; cfg = McStore.Read("mcserver.txt"); au = McStore.Read("mcauto.txt"); LoadHistory();
        gLatency = new McGraph { Title = "Ping to the server", Unit = " ms", Tone = Theme.Accent }; gPlayers = new McGraph { Title = "Players online", Max = 0, Tone = Theme.Green }; gTps = new McGraph { Title = "TPS (20 is perfect)", Max = 20, Tone = Theme.Amber };
        gCpu = new McGraph { Title = "Server CPU", Unit = " %", Max = 100, Tone = Theme.Red }; gRam = new McGraph { Title = "Server memory", Unit = " MB", Tone = Theme.AccentSoft };
        views.Add(new McOverview(this)); views.Add(new McPlayers(this)); views.Add(new McWorld(this)); views.Add(new McConsole(this)); views.Add(new McBackups(this)); views.Add(new McAutomation(this)); views.Add(new McFiles(this)); views.Add(new McHealth(this)); views.Add(new McSettings(this));
        tabBtns = new Btn[views.Count];
        for (int i = 0; i < views.Count; i++) { int k = i; tabBtns[i] = new Btn(views[i].Name) { Height = 32, Width = 112, Font = Theme.UIB }; tabBtns[i].Click += delegate { SetView(k); }; Controls.Add(tabBtns[i]); }
        connectBtn = new Btn("Connect") { Width = 130, Height = 34, Primary = true }; connectBtn.Click += delegate { ToggleConnect(); }; Controls.Add(connectBtn);
        foreach (var v in views) foreach (var c in v.Ctl) { c.Visible = false; Controls.Add(c); }
        double ticks; lastBackup = double.TryParse(McStore.Get(au, "lastbk", ""), out ticks) ? new DateTime((long)ticks) : DateTime.Now;
        poll.Tick += delegate { Tick1s(); }; Resize += delegate { Place(); }; SetView(0); Place();
        if (McStore.Get(cfg, "host", "").Length == 0) Say("Open Settings first: type the server PC's address and the RCON password, then press Connect. (On the server PC: server.properties needs enable-rcon=true, rcon.port=25575 and rcon.password=<something>, then restart the server once.)");
    }
    internal string Cfg(string k, string d) { return McStore.Get(cfg, k, d); }
    internal string Host { get { return Cfg("host", "").Trim(); } }
    internal int GamePort { get { return McStore.GetInt(cfg, "port", 25565); } }
    internal bool Connected { get { return rcon != null && rcon.Connected; } }
    internal bool HelperSet { get { return Cfg("tokenp", "").Length > 0 && Host.Length > 0; } }
    internal string ServerDir { get { return Cfg("server", "").Trim(); } }
    internal static string BackupRoot { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Minecraft backups"); } }
    internal string BackupDir { get { return Path.Combine(BackupRoot, Host.Replace(':', '_').Replace('\\', '_')); } }

    // ------------------------------------------------------------------ layout
    internal Rectangle Strip { get { return new Rectangle(44, 104, Math.Max(640, Width - 88), 58); } }
    internal Rectangle Area { get { return new Rectangle(44, 216, Math.Max(640, Width - 88), Math.Max(300, Height - 216 - 24)); } }
    void Place()
    {
        var s = Strip; connectBtn.Location = new Point(s.Right - 18 - connectBtn.Width, s.Y + 12);
        for (int i = 0; i < tabBtns.Length; i++) tabBtns[i].Location = new Point(44 + i * 118, 170);
        views[cur].Place(Area);
    }
    internal void SetView(int i)
    {
        cur = i; for (int k = 0; k < views.Count; k++) { foreach (var c in views[k].Ctl) c.Visible = k == i; tabBtns[k].Selected = k == i; tabBtns[k].Invalidate(); }
        views[i].Place(Area); views[i].Shown(); Invalidate();
    }
    // ------------------------------------------------------------------ messages
    internal void Say(string line) { consoleText.Append(line + "\r\n"); if (consoleText.Length > 60000) consoleText.Remove(0, 20000); if (ConsoleChanged != null) ConsoleChanged(); }
    internal void Event(string text) { events.Insert(0, new McRow { Cols = new[] { DateTime.Now.ToString("h:mm tt", CultureInfo.InvariantCulture), text } }); if (events.Count > 120) events.RemoveAt(events.Count - 1); if (StateChanged != null) StateChanged(); }
    internal void Ui(Action a) { try { if (IsHandleCreated) BeginInvoke(a); } catch { } }
    internal void Changed() { if (StateChanged != null) StateChanged(); Invalidate(); }
    void Toast(string title, string text)
    {
        try
        {
            if (tray == null) { tray = new NotifyIcon { Icon = FindForm() != null && FindForm().Icon != null ? FindForm().Icon : SystemIcons.Information }; trayHide = new System.Windows.Forms.Timer { Interval = 9000 }; trayHide.Tick += delegate { trayHide.Stop(); tray.Visible = false; }; }
            tray.Visible = true; tray.ShowBalloonTip(4000, title, text, ToolTipIcon.Info); trayHide.Stop(); trayHide.Start();
        }
        catch { }
    }
    // ------------------------------------------------------------------ connection
    internal void ToggleConnect()
    {
        if (Connected) { rcon.Dispose(); rcon = null; rconMsg = ""; players.Clear(); lastSeen.Clear(); seenOnce = false; Say("Disconnected from RCON."); Changed(); return; }
        Connect(false);
    }
    internal void Connect(bool quiet)
    {
        if (Host.Length == 0) { rconMsg = "Type the server's address in Settings first."; Changed(); return; }
        if (connecting) return; connecting = true; rconMsg = "Connecting…"; Changed(); string h = Host, pw = McStore.Unprotect(Cfg("pass", "")); int rp = McStore.GetInt(cfg, "rcon", 25575);
        ThreadPool.QueueUserWorkItem(delegate
        {
            var r = new McNet.Rcon(); string err = r.Connect(h, rp, pw, 4000);
            Ui(delegate
            {
                connecting = false;
                if (err.Length == 0) { rcon = r; rconMsg = "Connected"; if (!quiet) Say("Connected to " + h + " over RCON."); Event("Connected to " + h); Run("list", true); lastList = DateTime.Now; foreach (var v in views) v.Shown(); }
                else { rconMsg = err; if (!quiet) Say("Could not connect: " + err); }
                Changed(); PingNow();
            });
        });
    }
    internal void PingNow()
    {
        if (pinging || Host.Length == 0) return; pinging = true; lastPing = DateTime.Now; string h = Host; int p = GamePort;
        ThreadPool.QueueUserWorkItem(delegate { var st = McNet.Ping(h, p, 2500); Ui(delegate { pinging = false; status = st; if (st.Online) gLatency.Add(st.Latency); Changed(); }); });
    }
    // ------------------------------------------------------------------ commands
    readonly object runGate = new object();
    internal void Run(string cmd, bool quiet = false, Action<string> then = null)
    {
        var r = rcon; if (r == null || !r.Connected) { if (!quiet) Say("Not connected: press Connect first (RCON must be on in server.properties)."); return; }
        if (!quiet) Say("> " + cmd); if (cmd == "stop" || cmd.StartsWith("stop ")) HelperAsync("PAUSEWATCH 180");
        ThreadPool.QueueUserWorkItem(delegate
        {
            string res; try { lock (runGate) res = r.Command(cmd); } catch (Exception ex) { res = null; Ui(delegate { rconMsg = "Connection lost: " + ex.Message; rcon = null; Say(rconMsg); Changed(); }); }
            if (res == null) return;
            Ui(delegate { var clean = McNet.Strip(res); if (cmd == "list") ParseList(clean); if (!quiet || cmd != "list") { if (!quiet) Say(clean.Length == 0 ? "(done)" : clean); } if (then != null) then(clean); });
        });
    }
    // one command and its answer, on a worker thread; null when the connection is gone
    internal string Ask(string cmd) { var r = rcon; if (r == null || !r.Connected) return null; try { lock (runGate) return McNet.Strip(r.Command(cmd)); } catch { return null; } }
    void ParseList(string t)
    {
        lastList = DateTime.Now; var now = new List<string>(); int i = t.IndexOf(':'); if (i >= 0) foreach (string n in t.Substring(i + 1).Split(',')) { string x = n.Trim(); if (x.Length > 0) now.Add(x); }
        if (seenOnce)
        {
            foreach (string n in now) if (!lastSeen.Contains(n)) PlayerJoined(n);
            foreach (string n in lastSeen) if (!now.Contains(n)) PlayerLeft(n);
        }
        else foreach (string n in now) joined[n] = DateTime.Now;
        seenOnce = true; lastSeen.Clear(); lastSeen.AddRange(now); players.Clear(); players.AddRange(now); if (selPlayer.Length > 0 && !players.Contains(selPlayer)) selPlayer = "";
        gPlayers.Add(now.Count); if (PlayersChanged != null) PlayersChanged(); Changed();
    }
    void PlayerJoined(string n) { joined[n] = DateTime.Now; Event(n + " joined"); if (Cfg("alerts", "0") == "1") Toast("Minecraft", n + " joined the server"); }
    void PlayerLeft(string n)
    {
        DateTime j; double mins = 0; if (joined.TryGetValue(n, out j)) { mins = (DateTime.Now - j).TotalMinutes; joined.Remove(n); history.Insert(0, new[] { n, j.ToString("MMM d, h:mm tt", CultureInfo.InvariantCulture), ((int)Math.Round(mins)).ToString(CultureInfo.InvariantCulture) }); SaveHistory(n, j, DateTime.Now); }
        Event(n + " left"); if (Cfg("alerts", "0") == "1") Toast("Minecraft", n + " left the server");
    }
    static string HistFile { get { return McStore.Path_("mchistory.txt"); } }
    void LoadHistory()
    {
        try { var lines = File.ReadAllLines(HistFile); for (int i = lines.Length - 1; i >= 0 && history.Count < 300; i--) { var p = lines[i].Split('|'); long a, b; if (p.Length == 3 && long.TryParse(p[1], out a) && long.TryParse(p[2], out b)) history.Add(new[] { p[0], new DateTime(a).ToString("MMM d, h:mm tt", CultureInfo.InvariantCulture), ((int)Math.Round((new DateTime(b) - new DateTime(a)).TotalMinutes)).ToString(CultureInfo.InvariantCulture) }); } } catch { }
    }
    void SaveHistory(string n, DateTime a, DateTime b) { if (Program.Testing) return; try { Directory.CreateDirectory(Path.GetDirectoryName(HistFile)); File.AppendAllText(HistFile, n + "|" + a.Ticks + "|" + b.Ticks + "\r\n"); } catch { } }
    internal string JoinedFor(string n) { DateTime j; return joined.TryGetValue(n, out j) ? ((int)(DateTime.Now - j).TotalMinutes) + " min" : ""; }

    // ------------------------------------------------------------------ the helper on the server PC
    internal string Helper(string cmd, out string err)
    {
        err = ""; if (!HelperSet) { err = "the helper is not set up (Settings)"; return ""; }
        return McHelperClient.Call(Host, McStore.GetInt(cfg, "hport", 25580), McStore.Unprotect(Cfg("tokenp", "")), cmd, 70000, out err);
    }
    internal void HelperAsync(string cmd, Action<string, string> done = null)
    {
        if (!HelperSet) { if (done != null) done("", "the helper is not set up (Settings)"); return; }
        ThreadPool.QueueUserWorkItem(delegate { string err; string res = Helper(cmd, out err); if (done != null) Ui(delegate { done(res, err); }); });
    }
    void HealthSample()
    {
        lastHealth = DateTime.Now; bool rc = Connected, hs = HelperSet;
        ThreadPool.QueueUserWorkItem(delegate
        {
            string tps = rc ? Ask("tps") : null; float t = -1; if (tps != null) { var m = Regex.Match(tps, ":[^\\d]*(\\d+(?:\\.\\d+)?)"); if (m.Success && !tps.ToLowerInvariant().Contains("unknown") && !tps.ToLowerInvariant().Contains("incorrect")) { float.TryParse(m.Groups[1].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out t); if (t > 20) t = 20; } }
            Dictionary<string, string> inf = null; string herr = ""; if (hs) { string err; string res = Helper("STATUS", out err); if (err.Length == 0) inf = McHelperClient.Parse(res); else herr = err; }
            Ui(delegate
            {
                if (t >= 0) gTps.Add(t); if (hs) { helperErr = herr; if (inf != null) { helperInfo = inf; float v; if (inf.ContainsKey("cpu") && float.TryParse(inf["cpu"], NumberStyles.Float, CultureInfo.InvariantCulture, out v)) gCpu.Add(v); if (inf.ContainsKey("ramMB") && float.TryParse(inf["ramMB"], NumberStyles.Float, CultureInfo.InvariantCulture, out v)) gRam.Add(v); } }
                Changed();
            });
        });
    }
    // ------------------------------------------------------------------ backups
    internal void BackupNow(bool auto)
    {
        if (working) return; if (!Connected) { if (!auto) Say("Connect with RCON first."); return; }
        string dir = ServerDir; if (dir.Length == 0 || !Directory.Exists(dir)) { Say(auto ? "Automatic backup skipped: the server folder in Settings is not set or cannot be reached." : "To zip the world, fill in the server's folder in Settings (the one with server.properties, as a shared folder like \\\\PC\\minecraft). Until then 'Save now' makes the server write the world to its disk."); return; }
        working = true; Changed(); Say((auto ? "Automatic backup: " : "") + "Backing up the world… (the server keeps running; saving is paused for a moment)"); Event("Backup started"); string dest = BackupDir; int keep = McStore.GetInt(au, "bkkeep", 10);
        ThreadPool.QueueUserWorkItem(delegate
        {
            string failure = null; bool off = false; string zip = "";
            try
            {
                Ask("say [backup] Backing up the world, you may notice a short lag"); string a = Ask("save-off"); off = true; if (a == null) throw new IOException("lost the RCON connection");
                a = Ask("save-all flush"); if (a == null) throw new IOException("lost the RCON connection"); Thread.Sleep(2500);
                zip = McBackup.Zip(dir, dest, s => Ui(delegate { Say(s); })); McBackup.Prune(dest, McBackup.LevelName(dir), keep, s => Ui(delegate { Say(s); }));
            }
            catch (Exception ex) { failure = ex.Message; }
            finally { if (off) Ask("save-on"); Ask("say [backup] " + (failure == null ? "Backup finished" : "Backup failed")); }
            Ui(delegate { working = false; lastBackup = DateTime.Now; au["lastbk"] = lastBackup.Ticks.ToString(CultureInfo.InvariantCulture); McStore.Write("mcauto.txt", au); Event(failure == null ? "Backup finished" : "Backup failed: " + failure); if (failure != null) Say("Backup failed: " + failure); Changed(); });
        });
    }
    // ------------------------------------------------------------------ stop and restart (through the helper when it is set up: it can bring the server back, which the game itself cannot)
    internal void StopServer()
    {
        if (!Connected && !HelperSet) { Say("Connect with RCON first."); return; }
        if (MessageBox.Show(FindForm(), "Save the world and stop the server?\r\n\r\nEveryone is disconnected." + (HelperSet ? "" : " You will have to start it again on the server PC."), "Minecraft Server", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK) return;
        if (HelperSet) { Say("Stopping the server through the helper… (it saves first)"); HelperAsync("STOP", (res, err) => { Say(err.Length > 0 ? "Helper: " + err : "Helper: " + res); Event("Server stopped"); PingNow(); }); }
        else { Run("save-all"); Run("stop"); Event("Server stopped"); }
    }
    internal void RestartServer(int warn, bool auto)
    {
        if (working) return; if (!Connected && !HelperSet) { Say("Connect with RCON first."); return; }
        if (!auto && MessageBox.Show(FindForm(), "Restart the server" + (warn > 0 ? " in " + warn + " seconds (everyone is warned)" : " now") + "?" + (HelperSet ? "" : "\r\n\r\nWithout the helper this only works if the server starts itself again (a restart script, or a hosting panel). A plain server just stops."), "Minecraft Server", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK) return;
        working = true; Changed(); string h = Host; int gp = GamePort; bool viaHelper = HelperSet;
        ThreadPool.QueueUserWorkItem(delegate
        {
            try
            {
                if (warn > 0 && Connected) { Ask("say Server restarting in " + warn + " seconds"); for (int s = warn - 10; s > 0; s -= 10) { Thread.Sleep(10000); if (s > 10) Ask("say Server restarting in " + s + " seconds"); } Thread.Sleep(Math.Min(10, warn) * 1000); Ask("say Restarting now"); }
                if (Connected) { Ask("save-all flush"); Thread.Sleep(1500); }
                if (viaHelper)
                {
                    Ui(delegate { Say("Restarting through the helper…"); Event("Restart started"); rcon = null; players.Clear(); rconMsg = "Restarting…"; Changed(); });
                    string err; string res = Helper("RESTART", out err); if (err.Length > 0) { Ui(delegate { Say("Helper: " + err); working = false; Changed(); }); return; }
                }
                else
                {
                    string a = Ask("restart"); string al = (a ?? "").ToLowerInvariant();
                    if (al.Contains("unknown") || al.Contains("incorrect")) { Ui(delegate { Say("This server has no restart command (plain vanilla servers don't). Set up the helper in Settings, or use 'Save and stop' and start it on the server PC."); working = false; Changed(); }); return; }
                    Ui(delegate { Say("Restart sent. Waiting for the server to stop and come back…"); Event("Restart started"); rcon = null; players.Clear(); rconMsg = "Restarting…"; Changed(); });
                }
                bool wentDown = false, back = false; var t0 = DateTime.Now;
                while ((DateTime.Now - t0).TotalSeconds < 300) { Thread.Sleep(3000); var st = McNet.Ping(h, gp, 2000); if (!st.Online) wentDown = true; else if (wentDown || (DateTime.Now - t0).TotalSeconds > 60) { back = true; break; } }
                Ui(delegate
                {
                    working = false;
                    if (back) { Say("The server is back online."); Event("Server is back online"); Connect(false); }
                    else { Say(wentDown ? "The server stopped but did not come back within 5 minutes: start it again on the server PC." : "The server never went down: the restart may not have worked."); Event("Restart did not finish"); }
                    Changed();
                });
            }
            catch (Exception ex) { Ui(delegate { Say("Restart failed: " + ex.Message); working = false; Changed(); }); }
        });
    }
    // ------------------------------------------------------------------ the clock: refreshes, schedules
    void Tick1s()
    {
        bool active = Visible || keepAlive || Program.Testing; if (!active) return; var now = DateTime.Now;
        if (Host.Length > 0 && !pinging && (now - lastPing).TotalSeconds >= (Visible ? 5 : 15)) PingNow();
        if (Connected && !working && (now - lastList).TotalSeconds >= (Visible ? 10 : 20)) { lastList = now; Run("list", true); }
        if ((Connected || HelperSet) && (now - lastHealth).TotalSeconds >= (Visible && cur == 7 ? 8 : 30)) HealthSample();
        if (Visible) views[cur].Tick();
        // schedules (they only run while CENOHWARE is open and connected)
        if (McStore.Get(au, "bkon", "0") == "1" && Connected && !working && (now - lastBackup).TotalHours >= Math.Max(1, McStore.GetInt(au, "bkhours", 6))) { lastBackup = now; BackupNow(true); }
        if (McStore.Get(au, "rson", "0") == "1" && !working && (Connected || HelperSet) && now.ToString("HH:mm") == McStore.Get(au, "rstime", "04:00") && lastRestartDay != now.ToString("yyyyMMdd")) { lastRestartDay = now.ToString("yyyyMMdd"); Say("Scheduled restart."); RestartServer(60, true); }
        if (McStore.Get(au, "anon", "0") == "1" && Connected && (now - lastAnnounce).TotalMinutes >= Math.Max(1, McStore.GetInt(au, "anmin", 30))) { lastAnnounce = now; string m = McStore.Get(au, "anmsg", ""); if (m.Length > 0) Run("say " + m, true); }
    }
    // start with CENOHWARE: connect on its own, and keep watching if alerts or schedules are on
    public static bool Wants() { var c = McStore.Read("mcserver.txt"); var a = McStore.Read("mcauto.txt"); return McStore.Get(c, "auto", "0") == "1" || McStore.Get(c, "alerts", "0") == "1" || McStore.Get(a, "bkon", "0") == "1" || McStore.Get(a, "rson", "0") == "1" || McStore.Get(a, "anon", "0") == "1"; }
    public void AutoStart() { keepAlive = true; poll.Start(); if (Cfg("auto", "0") == "1" || Cfg("alerts", "0") == "1") Connect(true); }
    public void RefreshKeepAlive() { keepAlive = Wants(); if (keepAlive) poll.Start(); }
    internal void Place_() { Place(); }
    protected override void OnMouseDown(MouseEventArgs e) { Focus(); if (views[cur].Click(e.Location)) return; base.OnMouseDown(e); }
    // ------------------------------------------------------------------ IHubPage
    public void HubShown() { poll.Start(); if (Host.Length > 0) PingNow(); views[cur].Shown(); }
    public void HubHidden() { if (!keepAlive) poll.Stop(); }
    public void HubTheme() { foreach (var v in views) v.Theme_(); Invalidate(true); }
    public void HubPrewarm() { }
    protected override void Dispose(bool d) { if (d) { poll.Stop(); if (tray != null) tray.Dispose(); if (rcon != null) rcon.Dispose(); } base.Dispose(d); }
    // ------------------------------------------------------------------ drawing
    protected override void DrawCards(Graphics g)
    {
        foreach (var c in new[] { Strip, Area }) { var cc = c; var sp = Sprite("mcp_" + cc.Width + "x" + cc.Height, cc.Width, cc.Height, delegate (Graphics gg, Rectangle r) { Glass(gg, r, 0.05f); }); Blit(g, sp, cc.X - Pad, cc.Y - Pad); }
        foreach (var t in views[cur].Fields) { if (!t.Visible) continue; var rc = Rectangle.Inflate(t.Bounds, 8, 4); using (var path = Theme.Round(rc, 12)) { using (var b = new SolidBrush(Theme.Card)) g.FillPath(b, path); using (var p = new Pen(Theme.Border)) g.DrawPath(p, path); } }
    }
    protected override void DrawContent(Graphics g)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        TextRenderer.DrawText(g, "Minecraft Server", FTitle, new Rectangle(44, 32, Width - 100, 52), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        var s = Strip; string st = Host.Length == 0 ? "No address yet" : pinging && status.Version.Length == 0 && !status.Online ? "Checking…" : status.Online ? "ONLINE" : "OFFLINE"; Color sc = status.Online ? Theme.Green : Host.Length == 0 ? Theme.Dim : Theme.Red;
        using (var b = new SolidBrush(sc)) g.FillEllipse(b, s.X + 20, s.Y + 21, 14, 14);
        TextRenderer.DrawText(g, st, FBig, new Rectangle(s.X + 44, s.Y + 10, 170, 34), sc, TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        string line = status.Online ? status.Version + "   ·   " + status.Latency + " ms   ·   " + status.Online_ + " of " + status.Max + " players" + (status.Motd.Length > 0 ? "   ·   " + status.Motd : "") : status.Error;
        TextRenderer.DrawText(g, line, Theme.UIB, new Rectangle(s.X + 220, s.Y + 8, s.Width - 220 - 170 - 150, 22), Theme.Text, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        bool on = Connected; Color rc2 = on ? Theme.Green : rconMsg.Length > 0 && !rconMsg.StartsWith("Connecting") && !rconMsg.StartsWith("Restarting") ? Theme.Red : Theme.Dim;
        TextRenderer.DrawText(g, on ? "RCON connected: commands work" : rconMsg.Length > 0 ? rconMsg : "RCON not connected", Theme.Small, new Rectangle(s.X + 220, s.Y + 32, s.Width - 220 - 170 - 150, 18), rc2, TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        connectBtn.Text = connecting ? "Connecting…" : on ? "Disconnect" : "Connect"; connectBtn.Selected = on; connectBtn.Enabled = !connecting && !working;
        views[cur].Draw(g, Area);
    }

    // check switch: fake servers on this PC (game ping, RCON, helper) and a throwaway server folder, so the real client code runs without a real server
    public string TestRun(int view)
    {
        var sb = new StringBuilder(); int gp = 25591, rp = 25592, hp = 25593; McTest.StartAll(gp, rp, hp); string dir = Path.Combine(Path.GetTempPath(), "mc_test_" + Guid.NewGuid().ToString("N").Substring(0, 8));
        try
        {
            var st = McNet.Ping("127.0.0.1", gp, 3000); sb.AppendLine("ping: online=" + st.Online + " version=" + st.Version + " players=" + st.Online_ + "/" + st.Max + " sample=" + string.Join(",", st.Sample.ToArray()) + " motd=" + st.Motd + " latency=" + st.Latency + "ms");
            var bad = new McNet.Rcon(); sb.AppendLine("rcon wrong password: " + bad.Connect("127.0.0.1", rp, "nope", 3000)); var ok = new McNet.Rcon(); string err = ok.Connect("127.0.0.1", rp, "secret", 3000); sb.AppendLine("rcon right password: '" + err + "'");
            if (err.Length == 0) { sb.AppendLine("list -> " + ok.Command("list")); sb.AppendLine("tps -> " + ok.Command("tps")); sb.AppendLine("banlist -> " + ok.Command("banlist players").Replace("\n", " | ")); sb.AppendLine("long answer length " + ok.Command("biglist").Length + " (expected 9000)"); }
            ok.Dispose();
            string herr; string hres = McHelperClient.Call("127.0.0.1", hp, "tok123", "STATUS", 3000, out herr); var hi = McHelperClient.Parse(hres); sb.AppendLine("helper status: err='" + herr + "' running=" + (hi.ContainsKey("running") ? hi["running"] : "?") + " cpu=" + (hi.ContainsKey("cpu") ? hi["cpu"] : "?") + " ram=" + (hi.ContainsKey("ramMB") ? hi["ramMB"] : "?"));
            McHelperClient.Call("127.0.0.1", hp, "wrong", "STATUS", 3000, out herr); sb.AppendLine("helper wrong token: " + herr);
            Directory.CreateDirectory(Path.Combine(dir, @"world\region")); Directory.CreateDirectory(Path.Combine(dir, "world_nether")); Directory.CreateDirectory(Path.Combine(dir, "plugins"));
            File.WriteAllText(Path.Combine(dir, "server.properties"), "#Minecraft server properties\r\nmotd=A Minecraft Server\r\nmax-players=20\r\ndifficulty=normal\r\ngamemode=survival\r\npvp=true\r\nlevel-name=world\r\nview-distance=10\r\nonline-mode=true\r\nhardcore=false\r\n");
            File.WriteAllBytes(Path.Combine(dir, @"world\level.dat"), new byte[5000]); File.WriteAllBytes(Path.Combine(dir, @"world\region\r.0.0.mca"), new byte[300000]); File.WriteAllBytes(Path.Combine(dir, @"world_nether\level.dat"), new byte[100]); File.WriteAllText(Path.Combine(dir, @"world\session.lock"), "x");
            File.WriteAllBytes(Path.Combine(dir, @"plugins\EssentialsX.jar"), new byte[1200000]); File.WriteAllBytes(Path.Combine(dir, @"plugins\WorldEdit.jar"), new byte[3400000]);
            string backups = Path.Combine(dir, "backups");
            using (var held = new FileStream(Path.Combine(dir, @"world\region\r.0.0.mca"), FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                string zip = McBackup.Zip(dir, backups, s => sb.AppendLine("  " + s)); using (var za = System.IO.Compression.ZipFile.OpenRead(zip)) { var names = new List<string>(); foreach (var e in za.Entries) names.Add(e.FullName); sb.AppendLine("zip entries: " + string.Join(", ", names.ToArray())); }
                for (int i = 0; i < 3; i++) { Thread.Sleep(1100); McBackup.Zip(dir, backups, null); File.SetLastWriteTime(Directory.GetFiles(backups, "*.zip")[i], DateTime.Now.AddHours(-(10 - i))); }
                McBackup.Prune(backups, "world", 2, s => sb.AppendLine("  " + s)); sb.AppendLine("backups left: " + Directory.GetFiles(backups, "*.zip").Length);
            }
            var one = Directory.GetFiles(backups, "*.zip")[0]; File.WriteAllBytes(Path.Combine(dir, @"world\level.dat"), new byte[10]); McBackup.Restore(one, dir, s => sb.AppendLine("  " + s)); sb.AppendLine("restored level.dat bytes: " + new FileInfo(Path.Combine(dir, @"world\level.dat")).Length + ", old world kept: " + Directory.GetDirectories(dir, "world.before-restore-*").Length);
            // the page itself, filled the way a live session would
            cfg["host"] = "127.0.0.1"; cfg["port"] = gp.ToString(); cfg["rcon"] = rp.ToString(); cfg["pass"] = McStore.Protect("secret"); cfg["hport"] = hp.ToString(); cfg["tokenp"] = McStore.Protect("tok123"); cfg["server"] = dir; cfg["me"] = "Cenoh";
            status = st; rcon = new McNet.Rcon(); rcon.Connect("127.0.0.1", rp, "secret", 3000); rconMsg = "Connected"; players.Clear(); players.AddRange(new[] { "Steve", "Alex" }); selPlayer = "Alex"; helperInfo = hi; consoleText.Length = 0;
            Say("Connected to 127.0.0.1 over RCON."); Say("> list"); Say("There are 2 of a max of 20 players online: Steve, Alex"); Event("Alex joined"); Event("Backup finished"); Event("Steve joined"); history.Add(new[] { "Steve", "Oct 25, 9:12 PM", "48" }); history.Add(new[] { "Alex", "Oct 25, 7:40 PM", "95" });
            var rnd = new Random(3); for (int i = 0; i < 60; i++) { gLatency.Add(8 + rnd.Next(10)); gPlayers.Add(rnd.Next(4)); gTps.Add(19.2f + (float)rnd.NextDouble() * 0.8f); gCpu.Add(20 + rnd.Next(30)); gRam.Add(2800 + rnd.Next(500)); }
            SetView(Math.Max(0, Math.Min(views.Count - 1, view))); Changed();
        }
        catch (Exception ex) { sb.AppendLine("ERROR " + ex); }
        McTest.Stop = true; try { Directory.Delete(dir, true); } catch { }
        return sb.ToString();
    }
}
