// Humanizer: rewrites AI-sounding text so it reads like a person wrote it. Two engines:
// AI (Claude, given the rules below plus the ORIGINAL/FINAL example pairs in the examples folder) and Offline (the same rules as
// find-and-replace: instant, free, rougher). What the pipeline does was worked out from five essay pairs on 2026-10-28; the list is in
// README.md under "Humanizer" and in HzAi.Rules. Settings live in %APPDATA%\CENOHWARE\humanizer.txt (the API key encrypted for this Windows user).
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

static class HzStore
{
    static Dictionary<string, string> cfg;
    public static readonly string[] ModelIds = { "claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5" }, ModelNames = { "Sonnet 5.5", "Opus 5.5", "Haiku 5.5" };
    public static readonly string[] StrengthNames = { "Light", "Medium", "Strong" }, QuoteNames = { "mixed", "straight", "curly" };
    const string File_ = "humanizer.txt";
    public static void Load() { cfg = McStore.Read(File_); }
    public static string Cfg(string k, string d) { if (cfg == null) Load(); return McStore.Get(cfg, k, d); }
    public static void Set(string k, string v) { if (cfg == null) Load(); cfg[k] = v; McStore.Write(File_, cfg); }
    static int Int(string k, int d, int n) { int v; return int.TryParse(Cfg(k, d.ToString()), out v) && v >= 0 && v < n ? v : d; }
    public static bool Ai { get { return Cfg("mode", "ai") == "ai"; } }
    public static int Model { get { return Int("model", 0, ModelIds.Length); } }
    public static int Strength { get { return Int("strength", 1, 3); } }
    public static int Quotes { get { return Int("quotes", 0, 3); } }
    public static bool On(string k, bool d) { return Cfg(k, d ? "1" : "0") == "1"; }
    public static void Flip(string k, bool d) { Set(k, On(k, d) ? "0" : "1"); }
    public static bool British { get { return On("british", true); } }
    public static bool Contractions { get { return On("contr", true); } }
    public static bool Trim { get { return On("trim", true); } }
    public static bool Names { get { return On("names", true); } }
    public static bool Auto { get { return On("auto", false); } }
    public static bool Check { get { return On("check", true); } }           // AI: a second pass on paragraphs that still look AI-written
    public static int KeptTarget { get { return Strength == 0 ? 80 : Strength == 1 ? 60 : 45; } }     // the finals kept 43-51% of the originals' words
    public static string Exclude { get { return Cfg("exclude", ""); } }
    public static string Examples { get { string f = Cfg("examples", ""); return f.Length > 0 ? f : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Training"); } }
    public static string Key { get { string k = McStore.Unprotect(Cfg("key", "")); if (k.Length == 0) k = Environment.GetEnvironmentVariable("ANTHROPIC_API_KEY") ?? ""; return k.Trim(); } }
    public static bool KeySaved { get { return Cfg("key", "").Length > 0; } }
    // the header (name, course...) goes on top of every result as written: the humanizer never sees it
    public static bool HeaderOn { get { return On("header", true) && Header.Length > 0; } }
    public static string Header { get { return Cfg("headertext", "").Replace("\\n", "\r\n").Trim(); } }
    public static void SetHeader(string s) { Set("headertext", s.Replace("\r\n", "\n").Trim().Replace("\n", "\\n")); }
    public static string WithHeader(string body) { return HeaderOn ? Header + "\r\n\r\n" + body : body; }
    public static string StripHeader(string text)          // a pasted text that already starts with the header loses it, so it is not humanized or doubled
    {
        string h = Header.Replace("\r\n", "\n"), t = text.Replace("\r\n", "\n").TrimStart();
        return h.Length > 0 && t.StartsWith(h, StringComparison.Ordinal) ? t.Substring(h.Length).Trim().Replace("\n", "\r\n") : text;
    }
    public static List<string> ExcludeList() { var l = new List<string>(); foreach (string s in Exclude.Split(',', ';')) { string t = s.Trim(); if (t.Length > 0 && !l.Contains(t)) l.Add(t); } return l; }
    // the example pairs: every ORIGINAL* file with a FINAL* file of the same ending ("ORIGINAL - Copy (2).txt" goes with "FINAL - Copy (2).txt")
    public static List<string[]> Pairs()
    {
        var l = new List<string[]>();
        try
        {
            var files = Directory.GetFiles(Examples, "ORIGINAL*"); Array.Sort(files);
            foreach (string f in files) { string fin = Path.Combine(Examples, "FINAL" + Path.GetFileName(f).Substring(8)); if (File.Exists(fin)) l.Add(new[] { File.ReadAllText(f).Trim(), File.ReadAllText(fin).Trim() }); }
        }
        catch { }
        return l;
    }
    // words of `text` that are kept, in order, in `result` (longest common run of words), as a share of the original's words
    public static int KeptPercent(string text, string result)
    {
        var a = Regex.Split(text.ToLowerInvariant(), @"[^\w']+"); var b = Regex.Split(result.ToLowerInvariant(), @"[^\w']+");
        if (a.Length == 0 || a.Length > 4000 || b.Length > 4000) return -1;
        var prev = new int[b.Length + 1]; var cur = new int[b.Length + 1];
        for (int i = 1; i <= a.Length; i++) { for (int j = 1; j <= b.Length; j++) cur[j] = a[i - 1] == b[j - 1] ? prev[j - 1] + 1 : Math.Max(prev[j], cur[j - 1]); var t = prev; prev = cur; cur = t; }
        return (int)Math.Round(100.0 * prev[b.Length] / a.Length);
    }
    public static int Words(string s) { return Regex.Matches(s, @"[\w'’]+").Count; }
    // straight or curly apostrophes everywhere (mixed = leave them as the engine made them)
    public static string FixQuotes(string s) { s = Regex.Replace(s, @"\s*—\s*", ", ");          // em dashes are an AI tell; the pipeline never used one
        if (Quotes == 1) return s.Replace('’', '\''); if (Quotes == 2) return Regex.Replace(s, @"(?<=\w)'(?=\w)", "’"); return s; }
    public static List<string> MissingExcluded(string text, string result)
    {
        var l = new List<string>(); foreach (string w in ExcludeList()) if (text.IndexOf(w, StringComparison.OrdinalIgnoreCase) >= 0 && result.IndexOf(w, StringComparison.Ordinal) < 0) l.Add(w); return l;
    }
}

// the rules as find-and-replace. Each rule fires with a chance, so "Try again" gives a different take.
static class HzOffline
{
    static Random rnd; static int strength;
    // pattern, replacement, lowest strength (0 light, 1 medium, 2 strong), chance
    static readonly object[][] Words =
    {
        new object[] { @"\bon the other hand,\s*", "however, ", 0, 1.0 },
        new object[] { @"\b(?:in addition|additionally|furthermore|moreover),\s*", "also, ", 0, 1.0 },
        new object[] { @"\b(?:in conclusion|to sum up|to conclude|in summary),\s*", "overall, ", 0, 1.0 },
        new object[] { @"\b(?:as a result|therefore|thus|hence),\s*", "so ", 1, 0.7 },
        new object[] { @"\bit is (?:important|worth) (?:to note|noting) that\s*", "", 0, 1.0 },
        new object[] { @"\bin today's (?:world|society)\b", "nowadays", 0, 1.0 },
        new object[] { @"\bI (?:think|believe)\b", "I feel", 0, 1.0 },
        new object[] { @"\bmight\b", "may", 0, 1.0 },
        new object[] { @"\bwith one another\b", "with others", 0, 1.0 },
        new object[] { @"\b(?:people|others) all over the world\b", "others from around the world", 0, 1.0 },
        new object[] { @"\bface to face\b", "face-to-face", 0, 1.0 },
        new object[] { @"\bproblem solving\b", "problem-solving", 0, 1.0 },
        new object[] { @"\bcommunicate clearly\b", "communicate well", 0, 1.0 },
        new object[] { @", which means\b", ", meaning", 0, 1.0 },
        new object[] { @"\butili[sz](e|es|ed|ing)\b", "us$1", 0, 1.0 },
        new object[] { @"\bleverage\b", "use", 0, 1.0 },
        new object[] { @"\bdelve(s?) into\b", "look$1 at", 0, 1.0 },
        new object[] { @"\bnumerous\b", "many", 0, 1.0 },
        new object[] { @"\b(?:crucial|vital)\b", "important", 0, 0.9 },
        new object[] { @"\bhostile\b", "toxic", 0, 1.0 },
        new object[] { @"\bexpenses\b", "costs", 0, 1.0 },
        new object[] { @"\bcompletely changed\b", "dramatically changed", 1, 1.0 },
        new object[] { @"\b(?:simply|certainly|particularly|necessarily|truly)\s+", "", 1, 0.8 },
        new object[] { @"\brecogni[sz]e\b", "spot", 1, 0.8 },
        new object[] { @"\bhelpful\b", "handy", 1, 0.7 },
        new object[] { @"\bboring\b", "mundane", 1, 0.8 },
        new object[] { @"\bdivide\b", "split", 1, 0.8 },
        new object[] { @"\badjust\b", "adapt", 1, 0.8 },
        new object[] { @"\bassume\b", "think", 1, 0.8 },
        new object[] { @"\bdifficult\b", "hard", 1, 0.5 },
        new object[] { @"\bdifficult\b", "challenging", 1, 0.6 },
        new object[] { @"\badvantage(s?)\b", "upside$1", 1, 0.8 },
        new object[] { @"\b(?:disadvantage|drawback)(s?)\b", "downside$1", 1, 0.8 },
        new object[] { @"\bsignificant\b", "huge", 1, 0.7 },
        new object[] { @"\bmajor\b", "big", 1, 0.6 },
        new object[] { @"\bproblem(s?)\b(?![-\s]solv)", "issue$1", 1, 0.4 },
        new object[] { @"\bsolve\b", "fix", 1, 0.5 },
        new object[] { @"\bsomeone's\b", "your", 1, 0.8 },
    };
    static readonly object[][] BritishWords =
    {
        new object[] { @"(?<!\ba )\bwhile\b", "whilst", 0, 1.0 },
        new object[] { @"\balthough\b", "whilst", 1, 0.6 },
        new object[] { @"\b(?:trash|garbage)\b", "rubbish", 0, 1.0 },
    };
    // contractions; the samples used curly apostrophes on these and straight ones on the rest, so "mixed" does the same
    static readonly string[][] Contr =
    {
        new[] { "do not", "don't" }, new[] { "does not", "doesn't" }, new[] { "did not", "didn't" }, new[] { "is not", "isn’t" }, new[] { "are not", "aren’t" },
        new[] { "was not", "wasn't" }, new[] { "were not", "weren't" }, new[] { "will not", "won’t" }, new[] { "cannot", "can't" }, new[] { "should not", "shouldn’t" },
        new[] { "would not", "wouldn’t" }, new[] { "could not", "couldn’t" }, new[] { "have not", "haven't" }, new[] { "has not", "hasn't" },
    };
    static readonly string[][] ContrSome = { new[] { "it is", "it's" }, new[] { "that is", "that's" }, new[] { "there is", "there's" }, new[] { "you are", "you're" }, new[] { "they are", "they're" } };
    // "people can", "someone might", "players will"... become "you can", only where the word starts a clause (so "ordinary people can" stays)
    const string Who = @"(?:someone|somebody|a person|people|players|students|individuals|users|readers)";
    const string Subject = @"(?<=^|[,;:]\s|\b(?:when|if|because|so|but|and|then|where|while|whilst|unless|until|once|that)\s)" + Who + @"\s+(?=(?:can|may|might|will|should|could|need to|have to|often|still|usually|also|now)\b)";
    // "People listen to...", "Most people will..." at the start of a sentence become "You listen to...", "You will..." (plural verbs agree with "you")
    const string Opener = @"^(?:many |most )?people\s+(?!who\b|that\b|with\b|in\b|of\b|and\b)(?=[a-z]+\b)";
    // "helps people understand", "allows someone to" become "helps you understand", "allows you to"
    const string Object = @"(?<=\b(?:help|helps|helping|allow|allows|let|lets|give|gives|teach|teaches|encourage|encourages|remind|reminds)\s)(?:people|someone|a person)\b";

    static string Cap(string orig, string rep) { return orig.Length > 0 && char.IsUpper(orig[0]) && rep.Length > 0 ? char.ToUpper(rep[0]) + rep.Substring(1) : rep; }
    static string Swap(string s, string pat, string rep, double chance)
    {
        return Regex.Replace(s, pat, delegate (Match m) { return rnd.NextDouble() < chance ? Cap(m.Value, m.Result(rep)) : m.Value; }, RegexOptions.IgnoreCase);
    }
    static string Table(string s, object[][] t) { foreach (var r in t) if (strength >= (int)r[2]) s = Swap(s, (string)r[0], (string)r[1], (double)r[3]); return s; }

    public static string Run(string text, int seed)
    {
        rnd = new Random(seed); strength = HzStore.Strength; var keep = new List<string>();
        // words that must not change: the exclusions, links, and (optionally) names and ALL-CAPS words in mid-sentence
        var ex = HzStore.ExcludeList(); ex.Sort((a, b) => b.Length.CompareTo(a.Length));
        MatchEvaluator hide = delegate (Match m) { keep.Add(m.Value); return "" + (keep.Count - 1) + ""; };
        foreach (string w in ex) text = Regex.Replace(text, @"(?<!\w)" + Regex.Escape(w) + @"(?!\w)", hide, RegexOptions.IgnoreCase);
        text = Regex.Replace(text, @"\b(?:https?://|www\.)\S+|\S+@\S+\.\w+", hide);
        if (HzStore.Names) text = Regex.Replace(text, @"(?<=[a-z,;:]\s)(?!I\b)[A-Z][\w'’-]*|\b[A-Z]{2,}\b", hide);

        var lines = text.Replace("\r\n", "\n").Split('\n'); var sb = new StringBuilder();
        for (int i = 0; i < lines.Length; i++) { if (i > 0) sb.Append("\r\n"); sb.Append(Line(lines[i])); }
        string res = sb.ToString();
        res = Regex.Replace(res, "(\\d+)", delegate (Match m) { return keep[int.Parse(m.Groups[1].Value)]; });
        return HzStore.FixQuotes(res);
    }
    static string Line(string line)
    {
        if (line.Trim().Length == 0) return line;
        var hm = Regex.Match(line, @"^\s*#+\s*(.*)$");
        if (hm.Success) { string h = hm.Groups[1].Value; if (rnd.NextDouble() < 0.4) h = Regex.Replace(h, @"^([^:]{1,40}):\s+", "$1 – "); return h; }      // headings lose their # and sometimes swap the colon for a dash
        var parts = Regex.Split(line.Trim(), @"(?<=[.!?][""”’)]?)\s+(?=[A-Z""“])"); var sb = new StringBuilder(); int howevers = 0;
        foreach (string p in parts) { string s = Sentence(p, ref howevers); if (s.Length == 0) continue; if (sb.Length > 0) sb.Append(' '); sb.Append(s); }
        string outLine = Table(sb.ToString(), Words);
        if (HzStore.British) outLine = Table(outLine, BritishWords);
        if (HzStore.Contractions) outLine = Contract(outLine);
        return Tidy(outLine);
    }
    static string Sentence(string s, ref int howevers)
    {
        int words = HzStore.Words(s);
        if (HzStore.Trim && strength >= 1)
        {
            if (rnd.NextDouble() < 0.5) s = Regex.Replace(s, @"^For (?:example|instance),\s+(\w)", delegate (Match m) { return m.Groups[1].Value.ToUpper(); });
            if (words > 16 && rnd.NextDouble() < 0.6) { var m = Regex.Match(s, @",\s+(?:since|especially (?:when|if|because)|particularly when|which is why)\s[^.!?]*(?=[.!?][""”’]?$)"); if (m.Success && HzStore.Words(s.Substring(0, m.Index)) >= 6) s = s.Remove(m.Index, m.Length); }
        }
        // ", but" becomes "; however," (the pipeline's favourite), or a long sentence is split with "Still,"
        double chance = strength == 0 ? 0.3 : strength == 1 ? 0.55 : 0.75;
        var bm = Regex.Match(s, @",\s+but\s+(?!also\b)");
        if (bm.Success && howevers < 2 && rnd.NextDouble() < chance)
        {
            string after = s.Substring(bm.Index + bm.Length);
            if (strength >= 1 && words > 24 && rnd.NextDouble() < 0.4) s = s.Substring(0, bm.Index) + ". Still, " + after;
            else { s = s.Substring(0, bm.Index) + "; however, " + after; howevers++; }
        }
        // talk to the reader
        if (strength >= 1)
        {
            double youChance = strength == 2 ? 0.9 : 0.7;
            foreach (string pat in new[] { Opener, Subject, Object })
            {
                var pm = Regex.Match(s, pat, RegexOptions.IgnoreCase);
                if (!pm.Success || rnd.NextDouble() >= youChance) continue;
                s = s.Substring(0, pm.Index) + Cap(pm.Value, pat == Object ? "you" : "you ") + ToYou(s.Substring(pm.Index + pm.Length)); break;
            }
        }
        return s;
    }
    // the rest of a sentence whose subject became "you": they/their/them/themselves follow it
    static string ToYou(string rest)
    {
        rest = Regex.Replace(rest, @"\btheir\b", "your"); rest = Regex.Replace(rest, @"\bthemselves\b", "yourself"); rest = Regex.Replace(rest, @"\bthey're\b", "you're");
        rest = Regex.Replace(rest, @"\bthey\b", "you");          // not "them": that is usually the things, not the person
        rest = Regex.Replace(rest, @"\byour (life|phone|home|family|mind|job|car|friend)s?\b|\byour lives\b|\byour families\b", delegate (Match m) { return m.Value == "your lives" ? "your life" : m.Value == "your families" ? "your family" : "your " + m.Groups[1].Value; });     // one reader: "your phones" -> "your phone"
        return rest;
    }
    static string Contract(string s)
    {
        double chance = strength == 0 ? 0.5 : 0.8;
        foreach (var c in Contr) s = Swap(s, @"\b" + c[0] + @"\b", c[1], chance);
        foreach (var c in ContrSome) s = Swap(s, @"\b" + c[0] + @"(?= \w)", c[1], 0.35);
        return s;
    }
    static string Tidy(string s)
    {
        s = Regex.Replace(s, @"[ \t]{2,}", " "); s = Regex.Replace(s, @"\s+([,;.!?])", "$1"); s = Regex.Replace(s, @",\s*,", ",");
        s = Regex.Replace(s, @"(^|[.!?][""”’]?\s+)([a-z])", delegate (Match m) { return m.Groups[1].Value + m.Groups[2].Value.ToUpper(); });      // a sentence that lost its first words starts with a capital again
        return s;
    }
}

// looks for the habits AI detectors pick up, paragraph by paragraph: even sentence lengths, lists of three, stock frames,
// tidy moral closers, em dashes. A paragraph with two or more is flagged; the AI engine rewrites flagged paragraphs again.
static class HzScan
{
    static readonly string[] Frames =
    {
        "instead of", "it's not ", "it is not just", "not only", "at first,", "the key ", "what matters", "a good example", "a great example", "in other words", "the truth is",
        "that's why", "this is why", "ultimately", "plays a role", "serves as", "a reminder", "journey", "embrace", "navigate", "foster", "valuable lesson", "whether it's", "whether you're",
        "the real ", "more than just", "at the end of the day", "it's important to", "it is important to", "can be a powerful", "in today's", "delve", "crucial", "vital", "moreover", "furthermore", "additionally",
    };
    public class Hit { public int Para; public List<string> Why = new List<string>(); }
    public static List<string> Paragraphs(string text) { var l = new List<string>(); foreach (string p in Regex.Split(text.Replace("\r\n", "\n").Trim(), @"\n\s*\n")) if (p.Trim().Length > 0) l.Add(p.Trim()); return l; }
    public static List<Hit> Run(string text)
    {
        var hits = new List<Hit>(); var paras = Paragraphs(text);
        for (int i = 0; i < paras.Count; i++)
        {
            string p = paras[i]; var sents = Regex.Split(p, @"(?<=[.!?][""”’)]?)\s+(?=[A-Z""“(])"); if (sents.Length < 3) continue;
            var h = new Hit { Para = i };
            var lens = new List<int>(); foreach (string s in sents) lens.Add(HzStore.Words(s));
            double mean = 0; foreach (int n in lens) mean += n; mean /= lens.Count; double sd = 0; foreach (int n in lens) sd += (n - mean) * (n - mean); sd = Math.Sqrt(sd / lens.Count);
            if (sd / Math.Max(1, mean) < 0.38) h.Why.Add("sentences all about the same length");
            if (Regex.IsMatch(p, @"\b[\w']+(?: [\w']+){0,4}, [\w']+(?: [\w']+){0,4},? (?:and|or) [\w']+")) h.Why.Add("a list of three");
            string low = p.ToLowerInvariant(); foreach (string f in Frames) if (low.Contains(f)) h.Why.Add("\"" + f.Trim().TrimEnd(',') + "\"");
            if (p.Contains("—")) h.Why.Add("em dash");
            if (Regex.IsMatch(sents[sents.Length - 1], @"^(?:The|This|That|What|Every|Each|Sometimes|In the end)\b.*\b(?:becomes?|is what|matters|lesson|key|teaches|helps you|the point|worth it)\b", RegexOptions.IgnoreCase)) h.Why.Add("ends on a tidy moral");
            if (h.Why.Count >= 2) hits.Add(h);
        }
        return hits;
    }
    public static string Describe(List<Hit> hits)
    {
        if (hits.Count == 0) return "AI-pattern check: clean.";
        var sb = new StringBuilder("AI-pattern check: " + hits.Count + " paragraph" + (hits.Count == 1 ? " still looks" : "s still look") + " AI-written (");
        for (int i = 0; i < hits.Count && i < 2; i++) { if (i > 0) sb.Append("; "); sb.Append("#" + (hits[i].Para + 1) + ": " + string.Join(", ", hits[i].Why.ToArray())); }
        return sb.Append(hits.Count > 2 ? "; ...)." : ").").ToString();
    }
}

// the AI engine: the rules, the settings and the user's own example pairs go in the system prompt, the text in the message
static class HzAi
{
    public const string Rules =
@"You rewrite text so it reads as if a person wrote it. You copy one specific pipeline: an AI humanizer followed by Grammarly. This is what that pipeline does to text (learned from the user's own before/after pairs, which follow):

1. It talks to the reader. ""People"", ""someone"", ""a person"", ""players"", ""students"" doing things become ""you""/""your"" (""Someone might see a small monthly payment"" -> ""You may look at the low monthly payments""). ""I think"" becomes ""I feel"". Now and then ""we"".
2. Plainer, everyday words, with a few British ones: ""while""/""although"" -> ""whilst"" (often moved to the front: ""Whilst X, Y.""), ""trash"" -> ""rubbish"", ""might"" -> ""may"", ""difficult"" -> ""hard""/""challenging"", ""helpful"" -> ""handy"", ""advantages"" -> ""upsides"", ""downsides"" for drawbacks, ""recognize"" -> ""spot"", ""divide"" -> ""split"", ""hostile"" -> ""toxic"", ""boring"" -> ""mundane"", ""On the other hand"" -> ""However"". Spelling otherwise stays American (favorite, neighborhood, prioritize).
3. It joins contrasting clauses with ""; however,"" instead of "", but"" (a few times per piece) and opens sentences with ""However,"", ""Still,"", ""Whether you ..., ..."", ""Even if ..."", ""If you ..., you ..."".
4. It is a little shorter: from about the same length to about 20% fewer words (around 8% on average). It cuts examples (""For example, ...""), side explanations (""since ..."", ""especially when ...""), hedges and intensifiers (certainly, simply, completely, particularly). Long sentences are split. Some points are said more bluntly or more generally. Topic sentences become plain statements (""Another benefit of music is how it brings people together"" -> ""Music can also help connect people."").
5. Every paragraph stays, in the same order, and a one-line paragraph stays one line. The last paragraph still starts with ""Overall,"" if it did.
6. Contractions in some places (don't, won't, isn't, it's), not everywhere: ""it is important"" may stay.
7. Headings lose markdown (#) and may swap "":"" for "" – "".
8. A little less polished than the original: some repeated words, simple ""can""/""may"" hedging, an occasional exclamation mark, a slash in a short pair (""art/music""). Still correct grammar and punctuation, because Grammarly ran last.
9. It never adds new facts, numbers or ideas, and never uses AI-sounding words: delve, crucial, vital, tapestry, landscape, realm, moreover, furthermore, additionally, in conclusion, it is important to note, in today's world, navigate, foster, seamless.

The result is checked by AI detectors, which flag text whose rhythm and structure are too tidy even when the words are plain. So also break these AI writing habits, in every paragraph:
- Even sentence lengths. Mix them hard: a 4-6 word sentence next to a 25-35 word one. No paragraph where every sentence is 10-18 words.
- Lists of three (""study, ask questions, and try again"", ""practice, criticism, and a willingness""). Use two items, or four, or fold one into its own sentence.
- Set-up, pivot, lesson. A paragraph that goes example -> ""At first"" -> ""Still,""/""However,"" -> neat moral. Let some paragraphs just end on a plain fact or a small aside instead of a takeaway line.
- Aphorisms and tidy closers: ""X becomes useful when..."", ""What matters is..."", ""The key is..."", ""That is the real lesson"", ""This is why..."".
- Stock frames: ""Instead of X, you can Y"", ""It's not X, it's Y"", ""Not only... but also"", ""X is a good example"", ""Whether it's X or Y"", ""At first, ..."", ""In other words"", ""The truth is"".
- Every paragraph opening with a transition word. Start some with the subject, some with ""And""/""But""/""So"", now and then a short question.
- Em dashes (—). Never use them; use commas, full stops or brackets.
- The most expected word every time. Prefer a slightly less obvious but still plain word or phrase now and then (""a bad grade"" -> ""a rubbish mark"" or ""a grade you'd rather hide"").
A person's writing is a little uneven: one sentence runs on, one is clipped, a thought gets an aside in brackets. Do that, without spelling or grammar mistakes.

Always rewrite, even if the text already looks humanized: the reader runs text through this more than once.";

    static string Settings()
    {
        var sb = new StringBuilder(); int st = HzStore.Strength;
        sb.Append("\n\nSettings for this rewrite:\n");
        sb.Append(st == 0 ? "- Strength: light. Keep the wording close to the original; change words and joins, but keep almost every point and most sentences.\n" : st == 1 ? "- Strength: medium. Rewrite the way the examples do.\n" : "- Strength: strong. Rewrite freely, as the most changed examples do; restructure sentences and paragraphs' wording, but keep the paragraphs.\n");
        sb.Append("- Change enough: at most about " + HzStore.KeptTarget + "% of the original's words should survive in the same order.\n");
        sb.Append(HzStore.Trim ? "- You may cut examples and side details, as the pipeline does.\n" : "- Keep every point, example and detail; only change how they are said. Do not make the text much shorter.\n");
        sb.Append(HzStore.British ? "- Use \"whilst\" and \"rubbish\" as the pipeline does.\n" : "- Do not use British words like \"whilst\" or \"rubbish\"; use American ones.\n");
        sb.Append(HzStore.Contractions ? "- Use some contractions.\n" : "- Do not use contractions.\n");
        if (HzStore.Names) sb.Append("- Keep every name, title, brand and ALL-CAPS word exactly as written.\n");
        var ex = HzStore.ExcludeList(); if (ex.Count > 0) sb.Append("- Never change, replace or remove these words and phrases; keep them exactly as written, with the same spelling and capitals: " + string.Join(", ", ex.ConvertAll(w => "\"" + w + "\"").ToArray()) + ".\n");
        sb.Append("\nReply with only the rewritten text: no preface, no notes, no quotation marks around it, no markdown that was not in the original.");
        return sb.ToString();
    }
    public static string System_(out int pairs)
    {
        var sb = new StringBuilder(Rules); var ps = HzStore.Pairs(); pairs = 0; int chars = 0;
        if (ps.Count > 0) sb.Append("\n\nThe user's before/after pairs (ORIGINAL is the AI text that went in, FINAL is what came out of the pipeline):");
        foreach (var p in ps) { if (chars + p[0].Length + p[1].Length > 60000) break; chars += p[0].Length + p[1].Length; pairs++; sb.Append("\n\n<example>\n<original>\n" + p[0] + "\n</original>\n<final>\n" + p[1] + "\n</final>\n</example>"); }
        sb.Append(Settings());
        return sb.ToString();
    }
    // one Messages API call; returns the rewritten text or throws with a message fit to show
    // the rewrite, then (Double-check on) a second pass that rewrites only the paragraphs that still look AI-written or kept too much
    public static string Run(string text, out int pairs, out int passes)
    {
        string sys = System_(out pairs); passes = 1;
        var msgs = new List<object> { Msg("user", "<text>\n" + text + "\n</text>\n\nRewrite the text above.") };
        string first = Call(sys, msgs);
        if (!HzStore.Check) return first;
        var hits = HzScan.Run(first); int kept = HzStore.KeptPercent(text, first);
        if (hits.Count == 0 && kept <= HzStore.KeptTarget + 5) return first;
        var ask = new StringBuilder("A detector still reads parts of your rewrite as AI-written.");
        if (kept > HzStore.KeptTarget + 5) ask.Append(" It also kept " + kept + "% of the original's words in order; rewrite more, aiming for at most " + HzStore.KeptTarget + "%.");
        foreach (var h in hits) ask.Append("\n- Paragraph " + (h.Para + 1) + ": " + string.Join(", ", h.Why.ToArray()) + ".");
        ask.Append("\n\nRewrite those paragraphs again, much more loosely, breaking every habit listed (uneven sentence lengths, no lists of three, no tidy closing moral, none of the stock frames). Keep the same points and the other rules. Reply with the whole text (every paragraph, in order) and nothing else.");
        msgs.Add(Msg("assistant", first)); msgs.Add(Msg("user", ask.ToString()));
        try { string second = Call(sys, msgs); passes = 2; return second; } catch { return first; }       // the first rewrite is still good to show
    }
    static Dictionary<string, object> Msg(string role, string text) { return new Dictionary<string, object> { { "role", role }, { "content", text } }; }
    // one Messages API call; returns the text or throws with a message fit to show
    static string Call(string sys, List<object> msgs)
    {
        string key = HzStore.Key; if (key.Length == 0) throw new Exception("No API key.");
        int mi = HzStore.Model; string model = HzStore.ModelIds[mi]; bool fallback = mi != 2;          // Haiku has no server-side fallback
        var body = new Dictionary<string, object>
        {
            { "model", model }, { "max_tokens", 16000 },
            { "system", new object[] { new Dictionary<string, object> { { "type", "text" }, { "text", sys }, { "cache_control", new Dictionary<string, object> { { "type", "ephemeral" } } } } } },
            { "messages", msgs.ToArray() },
            { "output_config", new Dictionary<string, object> { { "effort", "medium" } } },
        };
        if (fallback) body["fallbacks"] = "default";       // a declined request is re-run on Anthropic's recommended model instead of failing
        ServicePointManager.SecurityProtocol |= (SecurityProtocolType)3072;
        var rq = (HttpWebRequest)WebRequest.Create("https://api.anthropic.com/v1/messages"); rq.Method = "POST"; rq.Timeout = 180000; rq.ReadWriteTimeout = 180000; rq.ContentType = "application/json";
        rq.Headers["x-api-key"] = key; rq.Headers["anthropic-version"] = "2023-06-01"; if (fallback) rq.Headers["anthropic-beta"] = "server-side-fallback-2026-07-01";
        var bytes = Encoding.UTF8.GetBytes(new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Serialize(body)); rq.ContentLength = bytes.Length;
        string json;
        try
        {
            using (var s = rq.GetRequestStream()) s.Write(bytes, 0, bytes.Length);
            using (var rs = (HttpWebResponse)rq.GetResponse()) using (var rd = new StreamReader(rs.GetResponseStream(), Encoding.UTF8)) json = rd.ReadToEnd();
        }
        catch (WebException we)
        {
            string msg = we.Message;
            try { using (var rd = new StreamReader(we.Response.GetResponseStream(), Encoding.UTF8)) { var d = new JavaScriptSerializer().DeserializeObject(rd.ReadToEnd()) as Dictionary<string, object>; var e = d["error"] as Dictionary<string, object>; msg = Convert.ToString(e["message"]); } } catch { }
            int code = we.Response is HttpWebResponse ? (int)((HttpWebResponse)we.Response).StatusCode : 0;
            if (code == 401) msg = "The API key was refused (" + msg + ")."; else if (code == 429) msg = "Too many requests right now; wait a moment (" + msg + ")."; else if (code == 529 || code >= 500) msg = "Claude is busy or down right now; try again (" + msg + ").";
            throw new Exception(msg);
        }
        var res = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.DeserializeObject(json) as Dictionary<string, object>;
        string stop = res.ContainsKey("stop_reason") ? Convert.ToString(res["stop_reason"]) : "";
        if (stop == "refusal") throw new Exception("Claude declined to rewrite this text.");
        var sb = new StringBuilder(); var content = res["content"] as IEnumerable;
        if (content != null) foreach (object o in content) { var b = o as Dictionary<string, object>; if (b != null && Convert.ToString(b["type"]) == "text") sb.Append(Convert.ToString(b["text"])); }
        string outText = sb.ToString().Trim(); if (outText.Length == 0) throw new Exception("Claude sent back no text (stop reason: " + stop + ").");
        if (stop == "max_tokens") outText += "\r\n\r\n[cut off: the text was too long for one go; split it in two]";
        outText = Regex.Replace(outText, @"^\s*<text>\s*|\s*</text>\s*$", "");
        return HzStore.FixQuotes(outText.Replace("\r\n", "\n").Replace("\n", "\r\n"));
    }
}

class HumanizerPage : BackdropPage, IHubPage
{
    static readonly Font FTitle = new Font("Segoe UI Semibold", 26f), FBox = new Font("Segoe UI", 10.5f);
    readonly HubForm hub; readonly Btn checkBtn, goBtn, modeBtn, modelBtn, strengthBtn, autoBtn, keyBtn, britBtn, contrBtn, trimBtn, quoteBtn, namesBtn, examplesBtn, headerBtn, pasteBtn, clearBtn, copyBtn, reuseBtn, againBtn;
    readonly TextBox input, output, exclude; readonly System.Windows.Forms.Timer autoTimer = new System.Windows.Forms.Timer { Interval = 900 };
    string status = "Paste text on the left and press Humanize.", stats = "", scan = "", body = ""; bool busy, bad, pasted, scanBad; int tries, lastLen, pairCount = -1;
    public HumanizerPage(HubForm h)
    {
        hub = h; HzStore.Load();
        goBtn = B("✦  Humanize", 170, delegate { Go(false); }, true); goBtn.Big = true; goBtn.Height = 70;
        modeBtn = B("", 150, delegate { HzStore.Set("mode", HzStore.Ai ? "offline" : "ai"); Sync(); });
        modelBtn = B("", 150, delegate { HzStore.Set("model", ((HzStore.Model + 1) % HzStore.ModelIds.Length).ToString()); Sync(); });
        strengthBtn = B("", 140, delegate { HzStore.Set("strength", ((HzStore.Strength + 1) % 3).ToString()); Sync(); });
        autoBtn = B("", 100, delegate { HzStore.Flip("auto", false); Sync(); });
        keyBtn = B("", 130, SetKey);
        britBtn = B("", 150, delegate { HzStore.Flip("british", true); Sync(); }); contrBtn = B("", 140, delegate { HzStore.Flip("contr", true); Sync(); });
        trimBtn = B("", 150, delegate { HzStore.Flip("trim", true); Sync(); }); quoteBtn = B("", 150, delegate { HzStore.Set("quotes", ((HzStore.Quotes + 1) % 3).ToString()); Sync(); });
        namesBtn = B("", 140, delegate { HzStore.Flip("names", true); Sync(); }); examplesBtn = B("", 160, PickExamples); checkBtn = B("", 150, delegate { HzStore.Flip("check", true); Sync(); });
        headerBtn = B("", 130, EditHeader);
        pasteBtn = B("Paste", 80, delegate { try { if (Clipboard.ContainsText()) { pasted = true; input.Text = Clipboard.GetText(); } } catch { } });
        clearBtn = B("Clear", 80, delegate { input.Clear(); output.Clear(); body = ""; stats = ""; scan = ""; status = ""; Invalidate(); });
        copyBtn = B("Copy result", 120, delegate { if (output.TextLength == 0) return; try { Clipboard.SetText(output.Text); Say("Copied.", false); } catch { Say("Could not copy it.", true); } });
        reuseBtn = B("Use as input", 120, delegate { if (output.TextLength == 0) return; input.Text = body; output.Clear(); stats = ""; Invalidate(); });
        againBtn = B("Try again", 110, delegate { Go(true); });
        input = Box(true); output = Box(true); exclude = Box(false); output.ReadOnly = true; output.BackColor = Theme.Card;
        exclude.Text = HzStore.Exclude; exclude.HandleCreated += delegate { McPage.SetCue(exclude, "Words and phrases to never change, separated by commas (names, game terms, quotes...)"); };
        exclude.Leave += delegate { HzStore.Set("exclude", exclude.Text.Trim()); };
        input.TextChanged += delegate { if (input.TextLength - lastLen > 40) pasted = true; lastLen = input.TextLength; if (HzStore.Auto) { autoTimer.Stop(); autoTimer.Start(); } };
        autoTimer.Tick += delegate { autoTimer.Stop(); if (!HzStore.Ai || pasted) Go(false); pasted = false; };          // AI costs money: in AI mode Auto runs on a paste, not on every pause in typing
        Resize += delegate { Place(); }; Place(); Sync();
    }
    Btn B(string text, int w, Action click, bool primary = false) { var b = new Btn(text) { Width = w, Height = 30, Font = Theme.Small, Primary = primary }; b.Click += delegate { click(); }; Controls.Add(b); return b; }
    TextBox Box(bool multi)
    {
        var t = new TextBox { BorderStyle = BorderStyle.None, BackColor = Theme.Card, ForeColor = Theme.Text, Font = FBox, Multiline = multi, ScrollBars = multi ? ScrollBars.Vertical : ScrollBars.None, AcceptsReturn = multi, WordWrap = true, MaxLength = 0 };
        t.KeyDown += delegate (object s, KeyEventArgs e) { if (e.Control && e.KeyCode == Keys.A) { t.SelectAll(); e.SuppressKeyPress = true; } else if (e.Control && e.KeyCode == Keys.Enter && t != exclude) { Go(false); e.SuppressKeyPress = true; } };
        t.GotFocus += delegate { Invalidate(); }; t.LostFocus += delegate { Invalidate(); };
        Controls.Add(t); return t;
    }
    Rectangle Card { get { return new Rectangle(44, 132, Math.Max(700, Width - 88), Math.Max(460, Height - 132 - 24)); } }
    void Row(int x, int y, params Btn[] bs) { foreach (var b in bs) { b.Location = new Point(x, y); x = b.Right + 8; } }
    void Place()
    {
        var c = Card; int x = c.X + 20, y = c.Y + 18;
        goBtn.Location = new Point(x, y); int ox = goBtn.Right + 14; Row(ox, y, modeBtn, modelBtn, strengthBtn, autoBtn, keyBtn, examplesBtn); Row(ox, y + 40, britBtn, contrBtn, trimBtn, quoteBtn, namesBtn, checkBtn);
        exclude.SetBounds(x + 10, y + 92, c.Width - 60 - 140, 22); headerBtn.Location = new Point(c.Right - 20 - headerBtn.Width, y + 88);
        int top = y + 150, bottom = c.Bottom - 20 - 32 - 16, gap = 28, w = (c.Width - 40 - gap) / 2;
        input.SetBounds(x + 10, top, w - 20, Math.Max(60, bottom - top)); output.SetBounds(x + w + gap + 10, top, w - 20, Math.Max(60, bottom - top));
        Row(x, c.Bottom - 20 - 32, pasteBtn, clearBtn); Row(x + w + gap, c.Bottom - 20 - 32, copyBtn, reuseBtn, againBtn);
    }
    void Sync()
    {
        bool ai = HzStore.Ai; modeBtn.Text = "Engine: " + (ai ? "AI (Claude)" : "Offline rules"); modeBtn.Selected = ai;
        modelBtn.Text = "Model: " + HzStore.ModelNames[HzStore.Model]; modelBtn.Enabled = ai; keyBtn.Enabled = ai;
        strengthBtn.Text = "Strength: " + HzStore.StrengthNames[HzStore.Strength]; autoBtn.Text = "Auto: " + (HzStore.Auto ? "on" : "off"); autoBtn.Selected = HzStore.Auto;
        keyBtn.Text = HzStore.Key.Length > 0 ? "API key: set" : "Set API key…";
        britBtn.Text = "Whilst / rubbish: " + (HzStore.British ? "on" : "off"); britBtn.Selected = HzStore.British;
        contrBtn.Text = "Contractions: " + (HzStore.Contractions ? "on" : "off"); contrBtn.Selected = HzStore.Contractions;
        trimBtn.Text = "Cut extra detail: " + (HzStore.Trim ? "on" : "off"); trimBtn.Selected = HzStore.Trim;
        quoteBtn.Text = "Apostrophes: " + HzStore.QuoteNames[HzStore.Quotes]; namesBtn.Text = "Protect names: " + (HzStore.Names ? "on" : "off"); namesBtn.Selected = HzStore.Names; checkBtn.Text = "Double-check: " + (HzStore.Check ? "on" : "off"); checkBtn.Selected = HzStore.Check; checkBtn.Enabled = HzStore.Ai;
        headerBtn.Text = "Header: " + (HzStore.HeaderOn ? "on" : "off") + "…"; headerBtn.Selected = HzStore.HeaderOn;
        if (pairCount < 0) pairCount = HzStore.Pairs().Count; examplesBtn.Text = "Examples: " + pairCount + " pair" + (pairCount == 1 ? "" : "s") + "…";
        foreach (Control b in Controls) if (b is Btn) b.Invalidate(); Invalidate();
    }
    void Say(string s, bool isBad) { status = s; bad = isBad; Invalidate(); }
    void SetKey()
    {
        string k = Microsoft.VisualBasic.Interaction.InputBox("Paste your Anthropic API key (from console.anthropic.com > API keys).\r\n\r\nIt is saved encrypted for your Windows account only. Type - to remove a saved key.", "Humanizer: API key", "");
        if (k == null || k.Trim().Length == 0) return; k = k.Trim();
        HzStore.Set("key", k == "-" ? "" : McStore.Protect(k)); Say(k == "-" ? "Key removed." : "Key saved.", false); Sync();
    }
    void EditHeader()
    {
        using (var f = new Form { Text = "Humanizer: header", FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, ClientSize = new Size(460, 250), MaximizeBox = false, MinimizeBox = false, ShowInTaskbar = false, BackColor = Theme.Panel, ForeColor = Theme.Text, Font = Theme.Small })
        {
            var lbl = new Label { Text = "Goes on top of every result exactly as written. The humanizer never changes it and it doesn't count toward the words or the AI-pattern check.", Location = new Point(14, 12), Size = new Size(432, 40) };
            var box = new TextBox { Multiline = true, AcceptsReturn = true, ScrollBars = ScrollBars.Vertical, Font = FBox, BackColor = Theme.Card, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Location = new Point(14, 56), Size = new Size(432, 110), Text = HzStore.Header };
            var on = new CheckBox { Text = "Add it to the top of the result", Checked = HzStore.On("header", true), Location = new Point(14, 176), AutoSize = true };
            var ok = new Button { Text = "Save", DialogResult = DialogResult.OK, Location = new Point(270, 210), Size = new Size(84, 28), FlatStyle = FlatStyle.System };
            var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Location = new Point(362, 210), Size = new Size(84, 28), FlatStyle = FlatStyle.System };
            f.Controls.AddRange(new Control[] { lbl, box, on, ok, cancel }); f.CancelButton = cancel;
            if (f.ShowDialog(FindForm()) != DialogResult.OK) return;
            HzStore.SetHeader(box.Text); HzStore.Set("header", on.Checked ? "1" : "0");
        }
        if (body.Length > 0) output.Text = HzStore.WithHeader(body);          // the result on screen follows at once
        Sync();
    }
    void PickExamples()
    {
        using (var d = new FolderBrowserDialog { Description = "The folder with your ORIGINAL / FINAL text pairs. The AI copies their style; add more pairs any time and it uses them on the next run.", SelectedPath = HzStore.Examples })
        { if (d.ShowDialog(FindForm()) != DialogResult.OK) return; HzStore.Set("examples", d.SelectedPath); }
        pairCount = -1; Sync(); Say(pairCount + " example pair" + (pairCount == 1 ? "" : "s") + " found in " + HzStore.Examples, pairCount == 0);
    }
    void Go(bool again)
    {
        if (busy) return; HzStore.Set("exclude", exclude.Text.Trim());
        string text = HzStore.StripHeader(input.Text.Trim()).Trim(); if (text.Length == 0) { Say("Paste some text on the left first.", true); return; }
        if (again) tries++; int seed = text.GetHashCode() ^ (tries * 7919);
        if (HzStore.Ai && HzStore.Key.Length == 0) { Show(text, HzOffline.Run(text, seed), "No API key yet, so this is the Offline engine. Press Set API key… to use Claude.", true); return; }
        if (!HzStore.Ai) { Show(text, HzOffline.Run(text, seed), "Done (Offline rules).", false); return; }
        busy = true; goBtn.Enabled = againBtn.Enabled = false; string name = HzStore.ModelNames[HzStore.Model]; Say("Asking " + name + "…", false); var sw = Stopwatch.StartNew();
        ThreadPool.QueueUserWorkItem(delegate
        {
            string res = null, err = null; int pairs = 0, passes = 1;
            try { res = HzAi.Run(text, out pairs, out passes); } catch (Exception ex) { err = ex.Message; }
            try
            {
                BeginInvoke((Action)delegate
                {
                    busy = false; goBtn.Enabled = againBtn.Enabled = true;
                    if (err != null) Show(text, HzOffline.Run(text, seed), "Claude failed: " + err + "  Showing the Offline version instead.", true);
                    else Show(text, res, "Done by " + name + " in " + sw.Elapsed.TotalSeconds.ToString("0.0") + " s, copying " + pairs + " example pair" + (pairs == 1 ? "" : "s") + (passes > 1 ? ", 2 passes" : "") + ".", false);
                });
            }
            catch { }
        });
    }
    void Show(string text, string res, string msg, bool isBad)
    {
        body = res; output.Text = HzStore.WithHeader(res); int a = HzStore.Words(text), b = HzStore.Words(res), kept = HzStore.KeptPercent(text, res);
        stats = a + " → " + b + " words" + (kept >= 0 ? ",  " + kept + "% of the original words kept in order" : "");
        var hits = HzScan.Run(res); scan = HzScan.Describe(hits); scanBad = hits.Count > 0;
        var miss = HzStore.MissingExcluded(text, res); if (miss.Count > 0) { msg = "Changed or dropped words you protected: " + string.Join(", ", miss.ToArray()) + ". " + msg; isBad = true; }
        Say(msg, isBad);
    }
    public void HubShown() { Sync(); }
    public void HubHidden() { HzStore.Set("exclude", exclude.Text.Trim()); }
    public void HubTheme() { foreach (var t in new[] { input, output, exclude }) { t.BackColor = Theme.Card; t.ForeColor = Theme.Text; } Invalidate(true); }
    public void HubPrewarm() { }
    protected override void DrawCards(Graphics g)
    {
        var c = Card; var sp = Sprite("hz_" + c.Width + "x" + c.Height, c.Width, c.Height, delegate (Graphics gg, Rectangle r) { Glass(gg, r, 0.05f); }); Blit(g, sp, c.X - Pad, c.Y - Pad);
        foreach (var t in new[] { input, output, exclude })
        {
            var rc = t.Multiline ? Rectangle.Inflate(t.Bounds, 10, 8) : Rectangle.Inflate(t.Bounds, 10, 5);
            using (var path = Theme.Round(rc, 12)) { using (var b = new SolidBrush(Theme.Card)) g.FillPath(b, path); using (var p = new Pen(t.Focused ? Theme.Accent : Theme.Border)) g.DrawPath(p, path); }
        }
    }
    protected override void DrawContent(Graphics g)
    {
        const TextFormatFlags L = TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis;
        TextRenderer.DrawText(g, "Humanizer", FTitle, new Rectangle(44, 32, Width - 100, 52), Theme.Text, L);
        TextRenderer.DrawText(g, "Rewrites AI text the way your humanizer + Grammarly pipeline does. Ctrl+Enter runs it.", Theme.UIL, new Rectangle(46, 90, Width - 100, 28), Theme.AccentSoft, L);
        var c = Card;
        TextRenderer.DrawText(g, "YOUR TEXT  (" + HzStore.Words(input.Text) + " words)", Theme.Head, new Rectangle(input.Left - 10, input.Top - 32, input.Width, 18), Theme.Dim, L);
        TextRenderer.DrawText(g, "HUMANIZED" + (stats.Length > 0 ? "   " + stats : ""), Theme.Head, new Rectangle(output.Left - 10, output.Top - 32, output.Width + 20, 18), Theme.Dim, L);
        TextRenderer.DrawText(g, status, Theme.UIB, new Rectangle(againBtn.Right + 16, againBtn.Top + 6, Math.Max(10, c.Right - 20 - againBtn.Right - 16), 20), bad ? Theme.Red : Theme.Text, L);
        if (scan.Length > 0) TextRenderer.DrawText(g, scan, Theme.Small, new Rectangle(clearBtn.Right + 16, clearBtn.Top + 7, Math.Max(10, output.Left - 40 - clearBtn.Right - 16), 18), scanBad ? Theme.Amber : Theme.Green, L);
        // a soft pulsing halo so the Humanize button is the first thing you see
        float pulse = busy ? 0.5f + 0.5f * (float)Math.Sin(t * 6f) : 0.5f + 0.5f * (float)Math.Sin(t * 2.2f); var oldSm = g.SmoothingMode; g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        for (int k = 3; k >= 1; k--) using (var path = Theme.Round(Rectangle.Inflate(goBtn.Bounds, 3 + k * 3, 3 + k * 3), 16 + k * 3)) using (var p = new Pen(Color.FromArgb((int)((26 + 40 * pulse) / k), Theme.Accent), 3f)) g.DrawPath(p, path);
        g.SmoothingMode = oldSm;
    }
}
