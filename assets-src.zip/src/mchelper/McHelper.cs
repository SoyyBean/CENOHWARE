// McHelper: a small tray program for the PC that runs the Minecraft server. CENOHWARE (on your other PC) talks to it to do what the
// game's own remote console cannot: start the server, stop it for good, restart it, watch it (CPU, memory, uptime), restart it if it
// crashes, and read its log. It does not touch the game itself.
//   1. Put McHelper.exe in any folder on the server PC and run it once: it writes McHelper.cfg next to itself and opens it.
//   2. Fill in dir= (the server's folder, the one with server.properties) and command= (how you start it, e.g.
//      java -Xmx4G -jar server.jar nogui), save, and run McHelper.exe again.
//   3. Copy the token it shows into CENOHWARE (Minecraft Server > Settings). Let port 25580 through the firewall (see CENOHWARE's notes).
// Only machines on private networks (192.168.x, 10.x, 172.16-31.x) and Radmin VPN (26.x) are allowed in, and every request needs the token.
// McHelper.cfg keys: token, port (default 25580), dir, command, gameport (default 25565), autorestart (0/1), radmin (0/1, default 1)
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

static class McHelper
{
    static string cfgPath, token = "", dir = "", command = "";
    static int port = 25580, gamePort = 25565; static bool autoRestart, allowRadmin = true;
    static volatile bool intentionalStop; static DateTime pausedUntil = DateTime.MinValue; static Process owned; static readonly List<DateTime> crashes = new List<DateTime>(); static int crashCount;
    static bool wasRunning; static DateTime upSince = DateTime.MinValue; static TimeSpan lastCpu; static DateTime lastCpuAt; static int lastPid; static double cpuPct; static NotifyIcon tray;
    static readonly object gate = new object();

    [STAThread]
    static void Main()
    {
        bool fresh; var mutex = new Mutex(true, "McHelperCenohware", out fresh); if (!fresh) return;
        cfgPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "McHelper.cfg"); bool first = !File.Exists(cfgPath); Load();
        if (token.Length == 0) { token = Guid.NewGuid().ToString("N").Substring(0, 20); Save(); }
        Application.EnableVisualStyles();
        bool quiet = Environment.GetEnvironmentVariable("MCHELPER_QUIET") == "1";
        tray = new NotifyIcon { Icon = SystemIcons.Shield, Visible = !quiet, Text = "Minecraft helper" };
        var menu = new ContextMenuStrip();
        menu.Items.Add("Show the token", null, delegate { MessageBox.Show("Token (copy it into CENOHWARE > Minecraft Server > Settings):\r\n\r\n" + token + "\r\n\r\nPort: " + port, "Minecraft helper"); });
        menu.Items.Add("Edit settings (McHelper.cfg)", null, delegate { try { Process.Start("notepad.exe", cfgPath); } catch { } });
        menu.Items.Add("Start the server", null, delegate { Reply(Do("START")); });
        menu.Items.Add("Stop the server", null, delegate { Reply(Do("STOP")); });
        menu.Items.Add("Quit the helper (the server keeps running)", null, delegate { tray.Visible = false; Application.Exit(); });
        tray.ContextMenuStrip = menu;
        if (first || dir.Length == 0 || command.Length == 0)
        {
            Save(); try { Process.Start("notepad.exe", cfgPath); } catch { }
            MessageBox.Show("First run: McHelper.cfg was created and opened.\r\n\r\nSet dir= to the Minecraft server folder and command= to how you start it (for example java -Xmx4G -jar server.jar nogui), save it, then run McHelper.exe again.\r\n\r\nYour token is: " + token, "Minecraft helper");
            tray.Visible = false; return;
        }
        var listener = new TcpListener(IPAddress.Any, port);
        try { listener.Start(); } catch (Exception ex) { MessageBox.Show("Cannot listen on port " + port + ": " + ex.Message, "Minecraft helper"); return; }
        new Thread(delegate () { while (true) { try { var c = listener.AcceptTcpClient(); ThreadPool.QueueUserWorkItem(delegate { try { Serve(c); } catch { } }); } catch { return; } } }) { IsBackground = true }.Start();
        new Thread(Watchdog) { IsBackground = true }.Start();
        if (tray.Visible) tray.ShowBalloonTip(3000, "Minecraft helper", "Listening on port " + port + (autoRestart ? ". Auto-restart is on." : "."), ToolTipIcon.Info);
        Application.Run();
    }
    static void Reply(string s) { try { if (!tray.Visible) return; tray.ShowBalloonTip(3000, "Minecraft helper", s.Split('\n')[0], ToolTipIcon.Info); } catch { } }

    // ---------------------------------------------------------------- settings
    static void Load()
    {
        try
        {
            foreach (string line in File.ReadAllLines(cfgPath))
            {
                int i = line.IndexOf('='); if (i < 0 || line.TrimStart().StartsWith("#")) continue; string k = line.Substring(0, i).Trim().ToLowerInvariant(), v = line.Substring(i + 1).Trim(); int n;
                if (k == "token") token = v; else if (k == "dir") dir = v; else if (k == "command") command = v; else if (k == "port" && int.TryParse(v, out n)) port = n; else if (k == "gameport" && int.TryParse(v, out n)) gamePort = n;
                else if (k == "autorestart") autoRestart = v == "1"; else if (k == "radmin") allowRadmin = v != "0";
            }
        }
        catch { }
    }
    static void Save()
    {
        try { File.WriteAllText(cfgPath, "# Minecraft helper settings. Change them, save, and run McHelper.exe again.\r\n# dir: the server's folder (the one with server.properties)\r\ndir=" + dir + "\r\n# command: how you start the server\r\ncommand=" + (command.Length == 0 ? "java -Xmx4G -jar server.jar nogui" : command) + "\r\ngameport=" + gamePort + "\r\nport=" + port + "\r\n# restart the server by itself when it stops without being asked to (0 or 1)\r\nautorestart=" + (autoRestart ? 1 : 0) + "\r\n# let Radmin VPN addresses (26.x.x.x) in (0 or 1)\r\nradmin=" + (allowRadmin ? 1 : 0) + "\r\n# the password CENOHWARE must send\r\ntoken=" + token + "\r\n"); } catch { }
    }
    static bool Allowed(IPAddress ip)
    {
        if (IPAddress.IsLoopback(ip)) return true; var b = ip.MapToIPv4().GetAddressBytes(); if (b.Length != 4) return false;
        return b[0] == 10 || (b[0] == 192 && b[1] == 168) || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (allowRadmin && b[0] == 26);
    }

    // ---------------------------------------------------------------- the conversation: "AUTH token", then one command; the answer ends with a line END
    static void Serve(TcpClient c)
    {
        using (c)
        {
            c.ReceiveTimeout = c.SendTimeout = 5000; var ep = c.Client.RemoteEndPoint as IPEndPoint; var ns = c.GetStream(); var rd = new StreamReader(ns, Encoding.UTF8); var wr = new StreamWriter(ns, new UTF8Encoding(false)) { NewLine = "\n", AutoFlush = true };
            if (ep == null || !Allowed(ep.Address)) { wr.WriteLine("error=not allowed from this address"); wr.WriteLine("END"); return; }
            string auth = rd.ReadLine() ?? ""; if (auth != "AUTH " + token) { Thread.Sleep(400); wr.WriteLine("error=wrong token"); wr.WriteLine("END"); return; }
            string cmd = (rd.ReadLine() ?? "").Trim(); string res; try { res = Do(cmd); } catch (Exception ex) { res = "error=" + ex.Message; }
            wr.WriteLine(res.TrimEnd()); wr.WriteLine("END");
        }
    }
    static string Do(string cmd)
    {
        string verb = cmd.Split(' ')[0].ToUpperInvariant(), arg = cmd.Length > verb.Length ? cmd.Substring(verb.Length + 1).Trim() : "";
        switch (verb)
        {
            case "STATUS": return Status();
            case "START": return Start();
            case "STOP": return Stop(false);
            case "KILL": return Stop(true);
            case "RESTART": { string a = Stop(false); if (a.StartsWith("error")) return a; Thread.Sleep(2000); intentionalStop = false; return Start(); }
            case "AUTORESTART": autoRestart = arg == "1" || arg.ToLowerInvariant() == "on"; Save(); return "ok autorestart=" + (autoRestart ? 1 : 0);
            case "PAUSEWATCH": { int s; int.TryParse(arg, out s); pausedUntil = DateTime.Now.AddSeconds(Math.Max(10, Math.Min(600, s == 0 ? 120 : s))); return "ok"; }
            case "LOG": return Log(arg);
            case "PING": return "pong";
            default: return "error=unknown command";
        }
    }

    // ---------------------------------------------------------------- the server process (found by what listens on the game port, so a server you started yourself is seen too)
    static int ListenerPid()
    {
        try
        {
            var p = Process.Start(new ProcessStartInfo("netstat", "-ano -p TCP") { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true }); string o = p.StandardOutput.ReadToEnd(); p.WaitForExit(3000);
            foreach (string line in o.Split('\n')) { if (!line.Contains("LISTENING")) continue; var t = line.Split(new[] { ' ', '\t', '\r' }, StringSplitOptions.RemoveEmptyEntries); if (t.Length >= 5 && t[1].EndsWith(":" + gamePort)) { int pid; if (int.TryParse(t[4], out pid)) return pid; } }
        }
        catch { }
        return 0;
    }
    static string Status()
    {
        int pid = ListenerPid(); var sb = new StringBuilder(); bool running = pid != 0; sb.AppendLine("running=" + (running ? 1 : 0)); sb.AppendLine("autorestart=" + (autoRestart ? 1 : 0)); sb.AppendLine("crashes=" + crashCount);
        if (running)
        {
            try
            {
                using (var pr = Process.GetProcessById(pid))
                {
                    var now = DateTime.Now; var cpu = pr.TotalProcessorTime; if (pid == lastPid && lastCpuAt != DateTime.MinValue && (now - lastCpuAt).TotalSeconds > 0.5) cpuPct = Math.Max(0, Math.Min(100, (cpu - lastCpu).TotalSeconds / (now - lastCpuAt).TotalSeconds / Environment.ProcessorCount * 100)); lastCpu = cpu; lastCpuAt = now; lastPid = pid;
                    sb.AppendLine("pid=" + pid); sb.AppendLine("cpu=" + cpuPct.ToString("0.0", CultureInfo.InvariantCulture)); sb.AppendLine("ramMB=" + (pr.WorkingSet64 >> 20)); sb.AppendLine("uptimeSec=" + (int)(now - pr.StartTime).TotalSeconds);
                }
            }
            catch { }
        }
        try { var d = new DriveInfo(Path.GetPathRoot(dir)); sb.AppendLine("diskFreeGB=" + (d.AvailableFreeSpace >> 30)); sb.AppendLine("diskTotalGB=" + (d.TotalSize >> 30)); } catch { }
        return sb.ToString();
    }
    static string Start()
    {
        lock (gate)
        {
            if (ListenerPid() != 0) return "error=the server is already running";
            if (!Directory.Exists(dir)) return "error=dir= in McHelper.cfg is not a folder"; intentionalStop = false;
            string file = command, args = ""; int sp = command.IndexOf(' '); if (sp > 0) { file = command.Substring(0, sp); args = command.Substring(sp + 1); }
            var psi = new ProcessStartInfo { WorkingDirectory = dir, UseShellExecute = false, CreateNoWindow = true };
            if (file.EndsWith(".bat", StringComparison.OrdinalIgnoreCase) || file.EndsWith(".cmd", StringComparison.OrdinalIgnoreCase)) { psi.FileName = "cmd.exe"; psi.Arguments = "/c \"" + command + "\""; } else { psi.FileName = file; psi.Arguments = args; }
            owned = Process.Start(psi); return "ok started";
        }
    }
    // saves and stops through the game's own remote console (read from server.properties), and ends the process if it is still there after a minute
    static string Stop(bool force)
    {
        intentionalStop = true; int pid = ListenerPid(); if (pid == 0) return "ok already stopped";
        if (!force)
        {
            try
            {
                string pw = "", rp = "25575"; bool on = false; foreach (string line in File.ReadAllLines(Path.Combine(dir, "server.properties"))) { if (line.StartsWith("rcon.password=")) pw = line.Substring(14).Trim(); else if (line.StartsWith("rcon.port=")) rp = line.Substring(10).Trim(); else if (line.StartsWith("enable-rcon=")) on = line.Substring(12).Trim() == "true"; }
                if (on) { Rcon("127.0.0.1", int.Parse(rp), pw, "save-all"); Thread.Sleep(1500); Rcon("127.0.0.1", int.Parse(rp), pw, "stop"); }
            }
            catch { }
            for (int i = 0; i < 60 && ListenerPid() != 0; i++) Thread.Sleep(1000);
            if (ListenerPid() == 0) return "ok stopped";
        }
        try { var p = Process.Start(new ProcessStartInfo("taskkill", "/PID " + ListenerPid() + " /T /F") { UseShellExecute = false, CreateNoWindow = true }); p.WaitForExit(8000); } catch { }
        Thread.Sleep(800); return ListenerPid() == 0 ? "ok stopped (it was ended by force)" : "error=could not stop it";
    }
    static void Rcon(string host, int p, string pw, string cmd)
    {
        using (var c = new TcpClient(host, p))
        {
            c.ReceiveTimeout = c.SendTimeout = 5000; var ns = c.GetStream(); Action<int, int, string> send = (id, type, body) => { var b = Encoding.UTF8.GetBytes(body); var ms = new MemoryStream(); var w = new BinaryWriter(ms); w.Write(10 + b.Length); w.Write(id); w.Write(type); w.Write(b); w.Write((byte)0); w.Write((byte)0); var o = ms.ToArray(); ns.Write(o, 0, o.Length); };
            var buf = new byte[4096]; send(1, 3, pw); ns.Read(buf, 0, buf.Length); send(2, 2, cmd); try { ns.Read(buf, 0, buf.Length); } catch { }
        }
    }
    static string Log(string arg)
    {
        string path = Path.Combine(dir, @"logs\latest.log"); long pos; if (!long.TryParse(arg, out pos)) pos = -1;
        using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
        {
            if (pos < 0 || pos > fs.Length) pos = Math.Max(0, fs.Length - 8000); fs.Seek(pos, SeekOrigin.Begin); var buf = new byte[Math.Min(200000, fs.Length - pos)]; int n = fs.Read(buf, 0, buf.Length);
            return "pos=" + (pos + n) + "\n" + Encoding.UTF8.GetString(buf, 0, n);
        }
    }
    // starts the server again when it disappears without being asked to (at most three times in ten minutes)
    static void Watchdog()
    {
        while (true)
        {
            Thread.Sleep(5000);
            try
            {
                bool running = ListenerPid() != 0;
                if (running) { wasRunning = true; intentionalStop = false; continue; }
                if (!wasRunning || intentionalStop || !autoRestart || DateTime.Now < pausedUntil) { if (!running && intentionalStop) wasRunning = false; continue; }
                crashes.RemoveAll(t => (DateTime.Now - t).TotalMinutes > 10); if (crashes.Count >= 3) { wasRunning = false; try { tray.ShowBalloonTip(5000, "Minecraft helper", "The server stopped 3 times in 10 minutes: not restarting it again.", ToolTipIcon.Warning); } catch { } continue; }
                crashes.Add(DateTime.Now); crashCount++; wasRunning = false; try { tray.ShowBalloonTip(4000, "Minecraft helper", "The server stopped by itself: starting it again.", ToolTipIcon.Warning); } catch { }
                Thread.Sleep(8000); Start();
            }
            catch { }
        }
    }
}
