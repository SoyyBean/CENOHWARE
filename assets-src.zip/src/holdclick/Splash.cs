using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Reflection;

// Start-up intro: the embedded picture in a circle with a rotating comet ring, shockwaves, a shine
// sweep and orbiting sparks, then the CENOHWARE wordmark in neon outlined letters that glow and shine.
// Everything heavy is pre-rendered once into bitmaps, so each frame is only a handful of cheap blits.
static class Splash
{
    public const float Total = 3.8f;           // seconds
    const string Word = "CENOHWARE";
    const float CX = 170f, CY = 205f, R = 92f; // portrait centre / radius
    const float TextCY = 372f;

    static readonly Color Purple = Color.FromArgb(139, 92, 246), Cyan = Color.FromArgb(56, 189, 248),
                          Dark = Color.FromArgb(18, 18, 26);

    static bool ready;
    static Bitmap face, faceFinal, ring, haze, spark, backdrop;
    static Bitmap[] glow, glyph;
    static RectangleF[] gb;                    // letter bounds, local coordinates
    static float offX, offY, textW, textH;     // local -> world offset of the wordmark
    static GraphicsPath textPath;              // every letter at its final position (clip for the shine)
    static float[] px, py, pv, ps, pph; static int[] pc;
    static Font fSub;
    static readonly ImageAttributes ia = new ImageAttributes();
    static readonly ColorMatrix cm = new ColorMatrix();

    public static void Prepare()
    {
        if (ready) return;
        ready = true;
        fSub = new Font("Segoe UI Semibold", 8.5f);

        // ---- portrait: circular, anti-aliased edge ----
        Bitmap src = null;
        try
        {
            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("splash.jpg"))
                if (s != null) using (var tmp = new Bitmap(s)) src = new Bitmap(tmp);
        }
        catch { }
        const int FS = 360;
        face = new Bitmap(FS, FS, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(face))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            if (src != null)
            {
                using (var tb = new TextureBrush(src, WrapMode.Clamp))
                {
                    tb.ScaleTransform(FS / (float)src.Width, FS / (float)src.Height);
                    g.FillEllipse(tb, 0.5f, 0.5f, FS - 1, FS - 1);
                }
                src.Dispose();
            }
            else
                using (var b = new LinearGradientBrush(new Rectangle(0, 0, FS, FS), Purple, Cyan, 45f))
                    g.FillEllipse(b, 0.5f, 0.5f, FS - 1, FS - 1);
        }

        // exact-size copy used once the pop-in has finished: a crisp 1:1 blit, no per-frame resampling
        int fd = (int)(R * 2f);
        faceFinal = new Bitmap(fd, fd, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(faceFinal))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.DrawImage(face, new Rectangle(0, 0, fd, fd));
        }

        // ---- comet ring: drawn once, rotated every frame ----
        int RS = 240; float rc = RS / 2f, rr = R + 16f;
        ring = new Bitmap(RS, RS, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(ring))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var p = new Pen(Color.FromArgb(36, Purple), 1.5f)) g.DrawEllipse(p, rc - rr, rc - rr, 2 * rr, 2 * rr);
            const int N = 120; const float span = 250f;
            for (int k = 0; k < N; k++)
            {
                float f = k / (float)(N - 1);                                  // 0 = tail, 1 = head
                int a = (int)(255 * Math.Pow(f, 2.4));
                using (var p = new Pen(Color.FromArgb(a, HoldClick.Lerp(Purple, Cyan, f)), 3.4f))
                    g.DrawArc(p, rc - rr, rc - rr, 2 * rr, 2 * rr, -span + f * span, span / (N - 1) + 1.4f);
            }
            float hx = rc + rr, hy = rc;                                       // glowing head at 3 o'clock
            for (int i = 5; i >= 1; i--)
                using (var b = new SolidBrush(Color.FromArgb(26, Cyan)))
                { float q = i * 3.6f + 3f; g.FillEllipse(b, hx - q, hy - q, q * 2, q * 2); }
            using (var b = new SolidBrush(Color.White)) g.FillEllipse(b, hx - 3.6f, hy - 3.6f, 7.2f, 7.2f);
        }

        // ---- soft purple haze behind the portrait ----
        haze = new Bitmap(440, 440, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(haze))
        using (var path = new GraphicsPath())
        {
            path.AddEllipse(0, 0, 439, 439);
            using (var pb = new PathGradientBrush(path))
            {
                pb.CenterColor = Color.FromArgb(150, Purple);
                pb.SurroundColors = new[] { Color.FromArgb(0, Purple) };
                pb.Blend = new Blend { Positions = new[] { 0f, 0.5f, 1f }, Factors = new[] { 0f, 0.3f, 1f } };
                g.FillPath(pb, path);
            }
        }

        // ---- static backdrop (gradient + haze) baked once; only a small pulse overlay is drawn per frame ----
        backdrop = new Bitmap(340, 540, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(backdrop))
        {
            using (var bg = new LinearGradientBrush(new Rectangle(0, 0, 340, 540), Color.FromArgb(38, 22, 78), Dark, 90f))
                g.FillRectangle(bg, 0, 0, 340, 540);
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            Blit(g, haze, CX, CY, 440f, 440f, 0.85f);
        }

        // ---- spark glow for the orbiting dots ----
        spark = new Bitmap(48, 48, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(spark))
        using (var path = new GraphicsPath())
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            path.AddEllipse(0, 0, 47, 47);
            using (var pb = new PathGradientBrush(path))
            {
                pb.CenterColor = Color.FromArgb(255, 210, 245, 255);
                pb.SurroundColors = new[] { Color.FromArgb(0, Cyan) };
                pb.Blend = new Blend { Positions = new[] { 0f, 0.45f, 1f }, Factors = new[] { 0f, 0.35f, 1f } };
                g.FillPath(pb, path);
            }
            using (var b = new SolidBrush(Color.White)) g.FillEllipse(b, 20, 20, 8, 8);
        }

        // ---- wordmark: one glow bitmap + one face bitmap per letter ----
        int n = Word.Length;
        glow = new Bitmap[n]; glyph = new Bitmap[n]; gb = new RectangleF[n];
        var paths = new GraphicsPath[n];
        const float em = 40f, track = 3f; const int pad = 28;
        using (var ff = new FontFamily("Segoe UI Black"))
        using (var font = new Font(ff, em, FontStyle.Regular, GraphicsUnit.Pixel))
        using (var meas = new Bitmap(1, 1))
        using (var mg = Graphics.FromImage(meas))
        {
            var sf = StringFormat.GenericTypographic;
            float minY = float.MaxValue, maxY = float.MinValue;
            for (int i = 0; i < n; i++)
            {
                float x = i == 0 ? 0f : mg.MeasureString(Word.Substring(0, i), font, new PointF(0, 0), sf).Width;
                paths[i] = new GraphicsPath();
                paths[i].AddString(Word[i].ToString(), ff, (int)FontStyle.Regular, em, new PointF(x + i * track, 0), sf);
                gb[i] = paths[i].GetBounds();
                minY = Math.Min(minY, gb[i].Y); maxY = Math.Max(maxY, gb[i].Bottom);
            }
            textW = gb[n - 1].Right - gb[0].Left; textH = maxY - minY;
            offX = CX - (gb[0].Left + textW / 2f);
            offY = TextCY - textH / 2f - minY;

            textPath = new GraphicsPath();
            for (int i = 0; i < n; i++)
            {
                var b = gb[i];
                Color gc = HoldClick.Lerp(Purple, Cyan, i / (float)(n - 1));
                int bw = (int)Math.Ceiling(b.Width) + 2 * pad, bh = (int)Math.Ceiling(b.Height) + 2 * pad;

                using (var world = (GraphicsPath)paths[i].Clone())
                {
                    var m = new Matrix(); m.Translate(offX, offY); world.Transform(m);
                    textPath.AddPath(world, false);
                }

                using (var path = (GraphicsPath)paths[i].Clone())
                {
                    var m = new Matrix(); m.Translate(pad - b.X, pad - b.Y); path.Transform(m);

                    glow[i] = new Bitmap(bw, bh, PixelFormat.Format32bppPArgb);
                    using (var g = Graphics.FromImage(glow[i]))
                    {
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        int[] ws = { 26, 17, 10, 5 }, al = { 16, 30, 58, 115 };
                        for (int k = 0; k < ws.Length; k++)
                            using (var p = new Pen(Color.FromArgb(al[k], gc), ws[k]) { LineJoin = LineJoin.Round })
                                g.DrawPath(p, path);
                    }

                    glyph[i] = new Bitmap(bw, bh, PixelFormat.Format32bppPArgb);
                    using (var g = Graphics.FromImage(glyph[i]))
                    {
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        var pb = path.GetBounds();
                        using (var lb = new LinearGradientBrush(new RectangleF(pb.X, pb.Y - 1, pb.Width, pb.Height + 2),
                                   Color.FromArgb(86, 62, 170), Color.FromArgb(32, 24, 78), 90f))
                            g.FillPath(lb, path);
                        using (var p = new Pen(HoldClick.Lerp(Color.White, gc, 0.25f), 2.2f) { LineJoin = LineJoin.Round })
                            g.DrawPath(p, path);
                    }
                }
                paths[i].Dispose();
            }
        }

        // ---- drifting sparks ----
        var rnd = new Random(11);
        int pn = 70;
        px = new float[pn]; py = new float[pn]; pv = new float[pn]; ps = new float[pn]; pph = new float[pn]; pc = new int[pn];
        for (int i = 0; i < pn; i++)
        {
            px[i] = (float)rnd.NextDouble() * 340f; py[i] = (float)rnd.NextDouble() * 540f;
            pv[i] = 12f + (float)rnd.NextDouble() * 40f; ps[i] = 0.8f + (float)rnd.NextDouble() * 1.7f;
            pph[i] = (float)rnd.NextDouble() * 6.28f; pc[i] = rnd.Next(3);
        }
    }

    static float Clamp01(float v) { return v < 0f ? 0f : v > 1f ? 1f : v; }
    static float Smooth(float v) { v = Clamp01(v); return v * v * (3f - 2f * v); }
    static float OutBack(float x)
    {
        x = Clamp01(x); const float c1 = 1.70158f, c3 = c1 + 1f; float u = x - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    // draw a bitmap centred on (cx, cy) at w x h with opacity a (sub-pixel positioning, no jitter)
    static Splash()
    {
        ia.SetWrapMode(WrapMode.TileFlipXY);
        cm.Matrix00 = cm.Matrix11 = cm.Matrix22 = cm.Matrix44 = 1f;
    }

    public static void Blit(Graphics g, Bitmap b, float cx, float cy, float w, float h, float a)
    {
        if (a <= 0.004f || w < 1f || h < 1f) return;
        var pts = new[] { new PointF(cx - w / 2, cy - h / 2), new PointF(cx + w / 2, cy - h / 2), new PointF(cx - w / 2, cy + h / 2) };
        if (a >= 0.995f) { g.DrawImage(b, pts); return; }   // fully opaque: skip the colour-matrix path (much faster)
        cm.Matrix33 = a;
        ia.SetColorMatrix(cm);
        g.DrawImage(b, pts, new RectangleF(0, 0, b.Width, b.Height), GraphicsUnit.Pixel, ia);
    }

    // soft diagonal light band moving across a clipped shape
    static void ShineBand(Graphics g, float bx, float top, float bottom, int alpha)
    {
        using (var lb = new LinearGradientBrush(new PointF(bx - 46, 0), new PointF(bx + 14, 0), Color.Transparent, Color.Transparent))
        {
            lb.InterpolationColors = new ColorBlend(3)
            {
                Colors = new[] { Color.FromArgb(0, 255, 255, 255), Color.FromArgb(alpha, 255, 255, 255), Color.FromArgb(0, 255, 255, 255) },
                Positions = new[] { 0f, 0.5f, 1f }
            };
            float slant = (bottom - top) * 0.45f;
            g.FillPolygon(lb, new[] {
                new PointF(bx - 18, top), new PointF(bx + 18, top),
                new PointF(bx + 18 - slant, bottom), new PointF(bx - 18 - slant, bottom) });
        }
    }

    public static void Paint(Graphics g, float t, int w, int h)
    {
        Prepare();
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.InterpolationMode = InterpolationMode.HighQualityBilinear;
        g.PixelOffsetMode = PixelOffsetMode.Half;

        // baked backdrop (1:1 copy), then a small breathing glow on top
        g.DrawImage(backdrop, 0, 0, 340, 540);
        float fadeIn = Smooth(t / 0.5f);
        float pulse01 = 0.5f + 0.5f * (float)Math.Sin(t * 3.2f), hs = 1f + 0.06f * (float)Math.Sin(t * 2f);
        Blit(g, haze, CX, CY, 320f * hs, 320f * hs, Smooth((t - 0.1f) / 0.8f) * 0.28f * pulse01);

        // drifting sparks
        for (int i = 0; i < px.Length; i++)
        {
            float y = (py[i] - pv[i] * t) % h; if (y < 0) y += h;
            float x = px[i] + (float)Math.Sin(t * 0.9f + pph[i]) * 7f;
            float tw = 0.35f + 0.65f * (float)Math.Abs(Math.Sin(t * 2.2f + pph[i]));
            Color c = pc[i] == 0 ? Purple : pc[i] == 1 ? Cyan : Color.White;
            using (var b = new SolidBrush(Color.FromArgb((int)(190 * tw * fadeIn), c)))
                g.FillEllipse(b, x - ps[i], y - ps[i], ps[i] * 2, ps[i] * 2);
        }

        // portrait pop-in
        float pp = (t - 0.15f) / 0.8f, s = OutBack(pp), pa = Clamp01(pp * 1.8f), r = R * s;

        // slow expanding pulse rings (after the reveal)
        for (int k = 0; k < 2; k++)
        {
            float u = (t - 1.0f - k * 0.9f) / 1.8f;
            if (u <= 0f) continue;
            u -= (float)Math.Floor(u);
            float rad = R + 8f + u * 70f;
            using (var p = new Pen(Color.FromArgb((int)(95 * (1f - u)), k == 0 ? Purple : Cyan), 2f))
                g.DrawEllipse(p, CX - rad, CY - rad, rad * 2, rad * 2);
        }

        // shockwave as the portrait lands
        float su = (t - 0.85f) / 0.75f;
        if (su > 0f && su < 1f)
        {
            float rad = R + su * 150f, inv = 1f - su;
            using (var p = new Pen(Color.FromArgb((int)(220 * inv * inv), 220, 235, 255), 1f + 3.5f * inv))
                g.DrawEllipse(p, CX - rad, CY - rad, rad * 2, rad * 2);
        }

        // rotating comet ring
        if (t > 0.25f)
        {
            var st = g.Save();
            g.TranslateTransform(CX, CY);
            g.RotateTransform(t * 230f - 20f);
            Blit(g, ring, 0, 0, ring.Width * s, ring.Height * s, Smooth((t - 0.25f) / 0.5f));
            g.Restore(st);
        }

        // the picture + rim light
        if (pp >= 1f)
            g.DrawImage(faceFinal, CX - R, CY - R, R * 2f, R * 2f);   // settled: crisp 1:1 blit
        else
        {
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            Blit(g, face, CX, CY, 2f * r, 2f * r, pa);
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
        }
        if (pa > 0.01f)
            using (var p = new Pen(Color.FromArgb((int)(160 * pa), 255, 255, 255), 2f))
                g.DrawEllipse(p, CX - r, CY - r, r * 2, r * 2);

        // shine sweeps across the portrait
        float[] sweeps = { 1.0f, 2.55f };
        for (int k = 0; k < sweeps.Length; k++)
        {
            float u = (t - sweeps[k]) / 0.75f;
            if (u <= 0f || u >= 1f) continue;
            using (var clip = new GraphicsPath())
            {
                clip.AddEllipse(CX - r + 1.5f, CY - r + 1.5f, 2f * r - 3f, 2f * r - 3f);
                var st = g.Save();
                g.SetClip(clip);
                ShineBand(g, CX + (-1.7f + 3.4f * Smooth(u)) * R, CY - R - 8, CY + R + 8, 150);
                g.Restore(st);
            }
        }

        // orbiting sparks
        if (t > 0.7f)
        {
            float oa = Smooth((t - 0.7f) / 0.5f);
            for (int k = 0; k < 6; k++)
            {
                float ang = t * 1.5f + k * 1.0472f, rad = R + 36f + 6f * (float)Math.Sin(t * 2f + k);
                Blit(g, spark, CX + (float)Math.Cos(ang) * rad, CY + (float)Math.Sin(ang) * rad * 0.94f, 30f, 30f,
                     oa * (0.65f + 0.35f * (float)Math.Sin(t * 4f + k)));
            }
        }

        // wordmark: letters pop in one by one, glow breathes
        int n = Word.Length;
        for (int i = 0; i < n; i++)
        {
            float p = Clamp01((t - (1.35f + i * 0.08f)) / 0.42f);
            if (p <= 0f) continue;
            float sc = 0.55f + 0.45f * OutBack(p), b2 = p;
            var b = gb[i];
            float cx = b.X + b.Width / 2f + offX, cy = b.Y + b.Height / 2f + offY + (1f - p) * 16f;
            float bw = glow[i].Width * sc, bh = glow[i].Height * sc;
            float breathe = 0.82f + 0.18f * (float)Math.Sin(t * 3.5f - i * 0.5f);
            Blit(g, glow[i], cx, cy, bw, bh, p * breathe * (1f + 1.2f * (1f - p)));
            Blit(g, glyph[i], cx, cy, bw, bh, b2);
        }

        // shine across the letters + twinkling glints
        float tu = (t - 2.45f) / 0.85f;
        if (tu > 0f && tu < 1f)
        {
            var st = g.Save();
            g.SetClip(textPath);
            ShineBand(g, CX - textW / 2f - 70f + (textW + 140f) * Smooth(tu), TextCY - textH / 2f - 6f, TextCY + textH / 2f + 6f, 235);
            g.Restore(st);
        }
        if (t > 2.0f)
        {
            int[] gi = { 1, 5, 8 };
            for (int k = 0; k < gi.Length; k++)
            {
                float q = (float)Math.Max(0.0, Math.Sin(t * 5f + k * 2.1f));
                float len = 4f + 10f * q, gx = gb[gi[k]].X + gb[gi[k]].Width * 0.5f + offX, gy = gb[gi[k]].Y + offY + 2f;
                using (var p = new Pen(Color.FromArgb((int)(230 * q), 255, 255, 255), 1.6f))
                {
                    g.DrawLine(p, gx - len, gy, gx + len, gy);
                    g.DrawLine(p, gx, gy - len, gx, gy + len);
                }
            }
        }

        // tagline
        float sa = Smooth((t - 2.3f) / 0.6f);
        if (sa > 0.01f)
        {
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            using (var b = new SolidBrush(Color.FromArgb((int)(190 * sa), 196, 186, 255)))
            using (var sf = new StringFormat { Alignment = StringAlignment.Center })
                g.DrawString("A U T O C L I C K E R", fSub, b, new RectangleF(0, TextCY + textH / 2f + 14f, w, 20f), sf);
        }

        // progress line
        {
            float pw = 150f, x0 = (w - pw) / 2f, y = h - 48f, u = Clamp01(t / Total);
            using (var track = new Pen(Color.FromArgb((int)(40 * fadeIn), 255, 255, 255), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                g.DrawLine(track, x0, y, x0 + pw, y);
            if (u > 0.01f)
                using (var lb = new LinearGradientBrush(new PointF(x0, 0), new PointF(x0 + pw, 0), Purple, Cyan))
                using (var glowPen = new Pen(Color.FromArgb(46, Purple), 9f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                using (var fill = new Pen(lb, 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                {
                    g.DrawLine(glowPen, x0, y, x0 + pw * u, y);
                    g.DrawLine(fill, x0, y, x0 + pw * u, y);
                }
        }

        // quick fade up from the window background at the very start
        float ov = 1f - Smooth(t / 0.35f);
        if (ov > 0.01f)
            using (var b = new SolidBrush(Color.FromArgb((int)(255 * ov), Dark))) g.FillRectangle(b, 0, 0, w, h);
    }
}
