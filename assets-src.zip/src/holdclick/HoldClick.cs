using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

// Shared animation clock + frame-rate independent easing, so motion has the same speed
// whether the timer fires at 60 fps or hiccups.
static class Anim
{
    static readonly Stopwatch clock = Stopwatch.StartNew();
    public static double Now { get { return clock.Elapsed.TotalSeconds; } }

    // one frame signal for every animated control, raised on the UI thread in step with the display
    public static event Action<float> Frame;
    public static void Raise(float dt) { var h = Frame; if (h != null) h(dt); }

    // exponential smoothing toward target; k = how fast (per second)
    public static float Ease(float cur, float target, float k, float dt)
    {
        cur += (target - cur) * (1f - (float)Math.Exp(-k * dt));
        return Math.Abs(target - cur) < 0.002f ? target : cur;
    }
}

class Pill : Control
{
    bool selected, pulse;
    public bool Selected { get { return selected; } set { if (selected != value) { selected = value; Kick(); } } }
    public bool Pulse { get { return pulse; } set { if (pulse != value) { pulse = value; Kick(); } } }
    public Color Accent = Color.FromArgb(139, 92, 246);
    bool hover, down;
    float hoverT, selT, downT, phase;
    bool active;

    public Pill()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        Cursor = Cursors.Hand;
    }

    // Subscribe to the shared frame signal only while something is moving; idle pills cost nothing.
    void Kick() { if (!active) { active = true; Anim.Frame += OnFrame; } }

    void OnFrame(float dt)
    {
        float h = hover ? 1f : 0f, sl = selected ? 1f : 0f, d = down ? 1f : 0f;
        bool changed = pulse || hoverT != h || selT != sl || downT != d;
        hoverT = Anim.Ease(hoverT, h, 18f, dt);
        selT = Anim.Ease(selT, sl, 14f, dt);
        downT = Anim.Ease(downT, d, 26f, dt);
        if (pulse) phase += 7.5f * dt;
        if (changed) Invalidate(); else { Anim.Frame -= OnFrame; active = false; }
    }

    protected override void Dispose(bool d) { if (d) Anim.Frame -= OnFrame; base.Dispose(d); }
    protected override void OnMouseEnter(EventArgs e) { hover = true; Kick(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hover = false; down = false; Kick(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { down = true; Kick(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { down = false; Kick(); base.OnMouseUp(e); }
    protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); if (selected) Kick(); }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        HoldClick.PaintBase(g, this);
        var r = new Rectangle(0, 0, Width - 1, Height - 1);
        Color fill = HoldClick.Lerp(HoldClick.Lerp(Color.FromArgb(34, 34, 48), Color.FromArgb(52, 52, 72), hoverT), Accent, selT);
        if (pulse) fill = HoldClick.Lerp(fill, Color.FromArgb(190, 150, 255), (float)(Math.Sin(phase) + 1) / 4f);
        fill = HoldClick.Lerp(fill, Color.Black, downT * 0.25f); // press = soft darken, no movement
        Color border = HoldClick.Lerp(HoldClick.Lerp(Color.FromArgb(60, 60, 82), Color.FromArgb(100, 80, 160), hoverT), Color.FromArgb(180, 150, 255), selT);
        Color txt = HoldClick.Lerp(Color.FromArgb(180, 180, 200), Color.White, Math.Max(selT, hoverT * 0.6f));
        using (var path = HoldClick.Round(r, 10))
        {
            using (var b = new SolidBrush(fill)) g.FillPath(b, path);
            using (var p = new Pen(border)) g.DrawPath(p, path);
        }
        TextRenderer.DrawText(g, Text, Font, r, txt, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
    }
}

// Logarithmic slider: 0.1 ms .. 60 s between clicks, with 0 (far left) = MAX speed, no delay at all.
// (The number box accepts even longer delays, up to 24 h.)
class Slider : Control
{
    public const double Max = 60000, Floor = 0.1;
    public event EventHandler Changed;
    public Color Accent = Color.FromArgb(139, 92, 246);
    double val = 20;
    bool drag, hover, placed;
    float dispT, radT = 8f;   // displayed thumb position (0..1) and radius, eased toward their targets
    bool active;

    public Slider()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        Cursor = Cursors.Hand;
    }

    void Kick() { if (!active) { active = true; Anim.Frame += OnFrame; } }

    void OnFrame(float dt)
    {
        float tt = TargetT(), rt = (drag || hover) ? 9.5f : 8f;
        bool changed = dispT != tt || radT != rt;
        dispT = Anim.Ease(dispT, tt, 30f, dt);   // quick enough to track a drag, soft enough to glide on +/-
        radT = Anim.Ease(radT, rt, 20f, dt);
        if (changed) Invalidate(); else { Anim.Frame -= OnFrame; active = false; }
    }

    protected override void Dispose(bool d) { if (d) Anim.Frame -= OnFrame; base.Dispose(d); }

    float TargetT()
    {
        return val <= 0 ? 0f : (float)Math.Max(0.0, Math.Min(1.0, Math.Log(val / Floor) / Math.Log(Max / Floor)));
    }

    public double Value
    {
        get { return val; }
        set
        {
            double v = Math.Round(Math.Max(0, Math.Min(Max, value)), 2);
            if (v == val) return;
            val = v;
            if (!placed || !IsHandleCreated) { dispT = TargetT(); placed = IsHandleCreated; Invalidate(); } else Kick();
            if (Changed != null) Changed(this, EventArgs.Empty);
        }
    }

    // step sizes get finer as the delay shrinks
    public static double StepUp(double v) { return v < 1 ? 0.1 : v < 20 ? 1 : v < 100 ? 5 : v < 1000 ? 25 : v < 10000 ? 250 : 1000; }
    public static double StepDown(double v) { return v <= 1 ? 0.1 : v <= 20 ? 1 : v <= 100 ? 5 : v <= 1000 ? 25 : v <= 10000 ? 250 : 1000; }

    double FromX(int x)
    {
        double t = Math.Max(0, Math.Min(1, (x - 10) / (double)(Width - 20)));
        if (t < 0.015) return 0; // snap to MAX at the far left
        double v = Floor * Math.Pow(Max / Floor, t);
        return v < 1 ? Math.Round(v, 2) : v < 10 ? Math.Round(v, 1) : v < 1000 ? Math.Round(v) : Math.Round(v / 10) * 10;
    }

    protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); dispT = TargetT(); placed = true; }
    protected override void OnMouseDown(MouseEventArgs e) { drag = true; Kick(); Value = FromX(e.X); base.OnMouseDown(e); }
    protected override void OnMouseMove(MouseEventArgs e) { if (drag) Value = FromX(e.X); base.OnMouseMove(e); }
    protected override void OnMouseUp(MouseEventArgs e) { drag = false; Kick(); base.OnMouseUp(e); }
    protected override void OnMouseEnter(EventArgs e) { hover = true; Kick(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hover = false; Kick(); base.OnMouseLeave(e); }
    protected override void OnMouseWheel(MouseEventArgs e)
    {
        Value = e.Delta > 0 ? (val <= 0 ? Floor : val + StepUp(val)) : (val <= Floor ? 0 : val - StepDown(val));
        base.OnMouseWheel(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        HoldClick.PaintBase(g, this);
        float x = 10 + dispT * (Width - 20), cy = Height / 2f;
        using (var b = new SolidBrush(Color.FromArgb(40, 40, 58)))
            g.FillRectangle(b, 10, cy - 3, Width - 20, 6);
        using (var b = new SolidBrush(Accent))
            g.FillRectangle(b, 10, cy - 3, x - 10, 6);
        float rad = radT;
        using (var b = new SolidBrush(Color.White))
            g.FillEllipse(b, x - rad, cy - rad, rad * 2, rad * 2);
        using (var p = new Pen(Accent, 3f))
            g.DrawEllipse(p, x - rad + 1.5f, cy - rad + 1.5f, rad * 2 - 3, rad * 2 - 3);
    }
}

// Settings dropdown that slides open under the gear button:
//   row 1: "Play intro on startup" toggle      row 2: "Background" [Choose] [Reset]
class SettingsPanel : Control
{
    public const int FullH = 100, Row1 = 50;
    public event EventHandler Toggled, ChooseBackground, ResetBackground;
    public bool On = true;
    public bool HasCustomBg;                       // enables the Reset button
    public bool IsOpen { get { return open; } }
    public Color Accent = Color.FromArgb(139, 92, 246);
    static readonly Rectangle ChooseR = new Rectangle(94, 61, 66, 28), ResetR = new Rectangle(166, 61, 50, 28);

    bool open, active;
    int hot;                                       // 0 none, 1 toggle row, 2 choose, 3 reset
    float openT, knobT = 1f;
    readonly float[] hv = new float[4];
    string status; double statusUntil;

    public SettingsPanel()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        Visible = false;
    }

    public void SetOpen(bool v)
    {
        open = v;
        if (v) { Visible = true; BringToFront(); }
        Kick();
    }

    public void Sync(bool on) { On = on; knobT = on ? 1f : 0f; Invalidate(); }
    public void Flash(string text) { status = text; statusUntil = Anim.Now + 2.5; Kick(); }

    void Kick() { if (!active) { active = true; Anim.Frame += OnFrame; } }

    void OnFrame(float dt)
    {
        float o = open ? 1f : 0f, k = On ? 1f : 0f;
        bool changed = openT != o || knobT != k || status != null;
        openT = Anim.Ease(openT, o, 18f, dt);
        knobT = Anim.Ease(knobT, k, 22f, dt);
        for (int i = 1; i < 4; i++)
        {
            float target = hot == i ? 1f : 0f;
            if (hv[i] != target) changed = true;
            hv[i] = Anim.Ease(hv[i], target, 18f, dt);
        }
        if (status != null && Anim.Now > statusUntil) status = null;
        int hh = (int)Math.Round(FullH * openT);
        if (Height != hh) Height = hh;
        if (!open && openT == 0f) Visible = false;
        if (changed) Invalidate(); else { Anim.Frame -= OnFrame; active = false; }
    }

    protected override void Dispose(bool d) { if (d) Anim.Frame -= OnFrame; base.Dispose(d); }

    int HitTest(Point p)
    {
        if (p.Y < Row1) return 1;
        if (ChooseR.Contains(p)) return 2;
        if (HasCustomBg && ResetR.Contains(p)) return 3;
        return 0;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        int h = HitTest(e.Location);
        if (h != hot) { hot = h; Cursor = h != 0 ? Cursors.Hand : Cursors.Default; Kick(); }
        base.OnMouseMove(e);
    }
    protected override void OnMouseLeave(EventArgs e) { hot = 0; Kick(); base.OnMouseLeave(e); }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        int h = HitTest(e.Location);
        if (h == 1) { On = !On; Kick(); if (Toggled != null) Toggled(this, EventArgs.Empty); }
        else if (h == 2 && ChooseBackground != null) ChooseBackground(this, EventArgs.Empty);
        else if (h == 3 && ResetBackground != null) ResetBackground(this, EventArgs.Empty);
        base.OnMouseDown(e);
    }

    void SmallButton(Graphics g, Rectangle r, string text, float hover, bool enabled)
    {
        using (var path = HoldClick.Round(r, 9))
        {
            Color fill = HoldClick.Lerp(Color.FromArgb(42, 42, 62), Color.FromArgb(78, 62, 140), hover);
            using (var b = new SolidBrush(enabled ? fill : Color.FromArgb(30, 30, 44))) g.FillPath(b, path);
            using (var p = new Pen(enabled ? HoldClick.Lerp(Color.FromArgb(76, 70, 120), Accent, hover) : Color.FromArgb(46, 46, 66))) g.DrawPath(p, path);
        }
        TextRenderer.DrawText(g, text, Font, r, enabled ? Color.FromArgb(230, 230, 245) : Color.FromArgb(100, 100, 124),
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        HoldClick.PaintBase(g, this);
        var r = new Rectangle(0, 0, Width - 1, FullH - 1);     // always laid out at full size; the control height reveals it
        using (var path = HoldClick.Round(r, 12))
        {
            using (var b = new SolidBrush(Color.FromArgb(28, 28, 42))) g.FillPath(b, path);
            using (var p = new Pen(Color.FromArgb(78, 66, 130))) g.DrawPath(p, path);
        }
        // hover wash on the toggle row
        if (hv[1] > 0.01f)
            using (var b = new SolidBrush(Color.FromArgb((int)(18 * hv[1]), 255, 255, 255)))
                g.FillRectangle(b, 1, 1, Width - 3, Row1 - 2);

        // row 1: intro toggle
        TextRenderer.DrawText(g, "Play intro on startup", Font, new Rectangle(14, 0, Width - 76, Row1), Color.FromArgb(225, 225, 240),
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
        var tr = new RectangleF(Width - 58, (Row1 - 22) / 2f, 42, 22);
        using (var path = HoldClick.Round(Rectangle.Round(tr), 22))
        using (var b = new SolidBrush(HoldClick.Lerp(Color.FromArgb(62, 62, 86), Accent, knobT)))
            g.FillPath(b, path);
        float kx = tr.X + 3f + knobT * (tr.Width - 16f - 6f);   // 16 px knob, 3 px inset each side
        using (var b = new SolidBrush(Color.White)) g.FillEllipse(b, kx, tr.Y + 3f, 16f, 16f);

        using (var p = new Pen(Color.FromArgb(60, 56, 96))) g.DrawLine(p, 12, Row1, Width - 13, Row1);

        // row 2: background picker
        if (status != null)
            TextRenderer.DrawText(g, status, Font, new Rectangle(14, Row1, Width - 28, FullH - Row1), Color.FromArgb(250, 150, 150),
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
        else
        {
            TextRenderer.DrawText(g, "Background", Font, new Rectangle(14, Row1, 80, FullH - Row1), Color.FromArgb(225, 225, 240),
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            SmallButton(g, ChooseR, "Choose...", hv[2], true);
            SmallButton(g, ResetR, "Reset", hv[3], HasCustomBg);
        }
    }
}

// Drops mouse messages that our own autoclicker/hold generated, so the app never clicks itself.
// Also tells the window about every click so the settings dropdown can close when you click away.
class InjectFilter : IMessageFilter
{
    public bool PreFilterMessage(ref Message m)
    {
        if (m.Msg == 0x201 && HoldClick.Current != null && HoldClick.GetMessageExtraInfo().ToInt64() != HoldClick.Marker)
            HoldClick.Current.AnyMouseDown(m.HWnd);
        return m.Msg >= 0x201 && m.Msg <= 0x20A && HoldClick.GetMessageExtraInfo().ToInt64() == HoldClick.Marker;
    }
}

class HoldClick : Form
{
    const int WM_HOTKEY = 0x0312;
    const uint MOD_ALT = 1, MOD_CONTROL = 2, MOD_SHIFT = 4, MOD_NOREPEAT = 0x4000;
    public const long Marker = 0x434C4B21; // tags our own synthetic clicks so this window can ignore them
    public static HoldClick Current;       // the one window (used by the click filter)
    static bool filterAdded;
    public static bool IsOpen { get { return Current != null && !Current.IsDisposed; } }
    /// <summary>Used by the CENOHWARE hub: opens the Hold Click window (or brings the open one forward).</summary>
    public static HoldClick Launch()
    {
        if (IsOpen) { if (Current.WindowState == FormWindowState.Minimized) Current.WindowState = FormWindowState.Normal; Current.Activate(); return Current; }
        if (!filterAdded) { Application.AddMessageFilter(new InjectFilter()); filterAdded = true; }
        var f = new HoldClick(); f.Show(); return f;
    }

    [DllImport("user32.dll")] public static extern IntPtr GetMessageExtraInfo();
    [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vKey);
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
    [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint type);
    [DllImport("user32.dll")] static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
    [DllImport("gdi32.dll")] static extern IntPtr CreateRoundRectRgn(int l, int t, int r, int b, int w, int h);
    [DllImport("dwmapi.dll")] static extern int DwmFlush();
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int val, int size);
    [DllImport("dwmapi.dll")] static extern int DwmExtendFrameIntoClientArea(IntPtr h, ref Margins m);
    [StructLayout(LayoutKind.Sequential)] struct Margins { public int L, R, T, B; }
    [DllImport("user32.dll")] static extern bool ReleaseCapture();
    [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h, int msg, int w, int l);
    [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint ms);
    [DllImport("winmm.dll")] static extern uint timeEndPeriod(uint ms);
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    static extern uint PrivateExtractIcons(string file, int index, int cx, int cy, IntPtr[] icons, int[] ids, uint n, uint flags);

    static readonly Color Bg = Color.FromArgb(18, 18, 26);
    static readonly Color Accent = Color.FromArgb(139, 92, 246);
    static readonly Color Green = Color.FromArgb(52, 211, 153);

    // name, down flag, up flag, xbutton data
    static readonly object[][] Buttons = {
        new object[]{ "Left",   0x0002u, 0x0004u, 0u },
        new object[]{ "Right",  0x0008u, 0x0010u, 0u },
        new object[]{ "Middle", 0x0020u, 0x0040u, 0u },
        new object[]{ "Side 1", 0x0080u, 0x0100u, 1u },
        new object[]{ "Side 2", 0x0080u, 0x0100u, 2u },
    };

    static readonly string SettingsFile = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HoldClick", "settings.txt");

    Pill[] pills = new Pill[5];
    Pill[] tabs = new Pill[3];
    Pill bindBtn, minus, plus, keyBtnA, keyBtnB;
    Keys keyA = Keys.Q, keyB = Keys.E;   // the two keys the third mode presses one after another
    int capKey;                          // 0 = capturing a start/stop hotkey, 1 / 2 = capturing key A / B
    Slider speed;
    TextBox box;                      // manual ms entry, kept in sync with the slider
    bool syncing, editing;
    Rectangle orb = new Rectangle(115, 376, 110, 110);

    volatile int sel;
    const double BoxMax = 86400000;   // longest delay the number box accepts (24 h)
    double interval = 20;             // ms between autoclicks; 0 = no delay (as fast as possible)
    int mode;                         // 0 = hold, 1 = autoclick, 2 = alternate two keys
    bool holding, capturing, closing;
    volatile bool clicking;
    int runId;
    Keys[] keys = new Keys[3];        // saved keybind per mode
    bool[] bound = new bool[3];
    int capSlot;

    // countdown before the autoclicker starts from the orb (so the cursor can leave the window)
    bool counting; DateTime countEnd;

    // animation state (all easing is time-based, see Anim)
    volatile bool frameRun;
    int framePending;
    float holdT, rip = 1f, bounce, phase, sweep = -160f, orbHover, intro = 1f, introP = 1f;
    bool splash = true, outroing;     // start-up intro (see Splash.cs); the normal UI waits until it ends
    float splashT, gearT;
    bool playIntro = true;           // saved setting, toggled from the gear dropdown
    SettingsPanel sp;
    readonly Rectangle gearRect = new Rectangle(228, 14, 28, 28);
    double lastTick = Anim.Now;
    bool orbHot, modern, shown;
    int hoverWin, saveIn = -1, homeY;  // hoverWin: 0 none, 1 minimize, 2 close

    // fonts are created once; building them every frame was a source of stutter
    static readonly Font FGear = new Font("Segoe UI Symbol", 13f),
        FTitle = new Font("Segoe UI Black", 15f), FSub = new Font("Segoe UI", 8.5f),
        FWin = new Font("Segoe UI", 12f), FLabel = new Font("Segoe UI Semibold", 8f),
        FOrb = new Font("Segoe UI Black", 11f), FCount = new Font("Segoe UI Black", 22f),
        FMade = new Font("Segoe UI Semibold", 8.5f);

    // Borderless window: native minimize/restore animation + taskbar click-to-minimize
    protected override CreateParams CreateParams
    {
        get { var cp = base.CreateParams; cp.Style |= 0x20000 | 0x80000; return cp; }
    }

    // Windows 11: let DWM draw smooth anti-aliased rounded corners, a hairline border and a soft shadow.
    // Older Windows: fall back to a clipped rounded region.
    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        try
        {
            int round = 2, border = 50 | (50 << 8) | (72 << 16);
            modern = DwmSetWindowAttribute(Handle, 33, ref round, 4) == 0;   // corner preference = round
            if (modern)
            {
                DwmSetWindowAttribute(Handle, 34, ref border, 4);            // border colour
                var m = new Margins { L = 1, R = 1, T = 1, B = 1 };
                DwmExtendFrameIntoClientArea(Handle, ref m);                 // shadow
            }
        }
        catch { modern = false; }
        if (!modern) Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width + 1, Height + 1, 22, 22));
    }

    public static Color Lerp(Color a, Color b, float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return Color.FromArgb((int)(a.A + (b.A - a.A) * t), (int)(a.R + (b.R - a.R) * t),
                              (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }

    public static GraphicsPath Round(Rectangle r, int d)
    {
        var p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }

    HoldClick()
    {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(340, 540);
        BackColor = Bg;
        Text = "Hold Click";
        TopMost = true;
        DoubleBuffered = true;
        Font = new Font("Segoe UI", 9f);
        LoadWindowIcon();
        timeBeginPeriod(1);

        // mode tabs
        string[] tabNames = { "Hold", "Autoclick", "Two keys" };
        for (int i = 0; i < 3; i++)
        {
            int m = i;
            tabs[i] = new Pill { Text = tabNames[i], Font = new Font("Segoe UI Semibold", 9.5f), Bounds = new Rectangle(20 + i * 102, 80, 94, 32) };
            tabs[i].Click += delegate { SetMode(m); };
            Controls.Add(tabs[i]);
        }

        // mouse button picker (3 + 2)
        int w = 96, gap = 8, x0 = 20;
        for (int i = 0; i < 5; i++)
        {
            var p = new Pill { Text = (string)Buttons[i][0], Font = new Font("Segoe UI Semibold", 9f), Height = 34, Width = w };
            int idx = i;
            p.Location = i < 3 ? new Point(x0 + i * (w + gap), 142) : new Point(x0 + (i - 3) * (w + gap), 142 + 42);
            p.Click += delegate { SelectButton(idx); };
            pills[i] = p;
            Controls.Add(p);
        }

        keyBtnA = new Pill { Font = new Font("Segoe UI Semibold", 9f), Bounds = new Rectangle(20, 142, 146, 34), Visible = false };
        keyBtnB = new Pill { Font = new Font("Segoe UI Semibold", 9f), Bounds = new Rectangle(174, 142, 146, 34), Visible = false };
        keyBtnA.Click += delegate { StartKeyCapture(1); };
        keyBtnB.Click += delegate { StartKeyCapture(2); };
        Controls.Add(keyBtnA); Controls.Add(keyBtnB);
        bindBtn = new Pill { Font = new Font("Segoe UI Semibold", 9f), Bounds = new Rectangle(20, 250, 300, 36) };
        bindBtn.Click += delegate { StartCapture(); };
        Controls.Add(bindBtn);

        // autoclick speed
        speed = new Slider { Bounds = new Rectangle(20, 314, 226, 28) };
        speed.Changed += delegate
        {
            interval = speed.Value; saveIn = 30; // (box handlers re-apply longer-than-slider values afterwards)
            if (!editing) { syncing = true; box.Text = Fmt(speed.Value); syncing = false; }
            Invalidate(new Rectangle(0, 340, Width, 40));
        };

        box = new TextBox
        {
            BorderStyle = BorderStyle.None, BackColor = Color.FromArgb(34, 34, 48), ForeColor = Color.White,
            TextAlign = HorizontalAlignment.Center, MaxLength = 10, Font = new Font("Segoe UI Semibold", 10f),
            Width = 52, Text = Fmt(interval)
        };
        box.Location = new Point(26, 344 + (28 - box.Height) / 2);
        box.KeyPress += delegate(object s, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter) { e.Handled = true; CommitBox(); }
            else if (e.KeyChar == '.' || e.KeyChar == ',') { e.KeyChar = '.'; if (box.Text.Contains(".")) e.Handled = true; }
            else if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
        };
        box.TextChanged += delegate
        {
            if (syncing) return;
            double v;
            if (!double.TryParse(box.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out v)) return;
            if (v > BoxMax) { v = BoxMax; syncing = true; box.Text = Fmt(v); box.SelectionStart = box.Text.Length; syncing = false; }
            editing = true; speed.Value = Math.Min(v, Slider.Max); editing = false;
            interval = Math.Round(v, 2); saveIn = 30; // slider tops out at 60 s; the box can go longer
            Invalidate(new Rectangle(0, 340, Width, 40));
        };
        box.Enter += delegate { box.SelectAll(); Invalidate(new Rectangle(15, 340, 80, 36)); };
        box.Leave += delegate { CommitBox(false); Invalidate(new Rectangle(15, 340, 80, 36)); };
        Controls.Add(box);
        minus = new Pill { Text = "–", Font = new Font("Segoe UI Semibold", 11f), Bounds = new Rectangle(252, 314, 32, 28) };
        plus = new Pill { Text = "+", Font = new Font("Segoe UI Semibold", 11f), Bounds = new Rectangle(288, 314, 32, 28) };
        minus.Click += delegate { SetInterval(interval <= Slider.Floor ? 0 : interval - Slider.StepDown(interval)); };
        plus.Click += delegate { SetInterval(interval <= 0 ? Slider.Floor : interval + Slider.StepUp(interval)); };
        Controls.AddRange(new Control[] { speed, minus, plus });

        // settings dropdown (added last so it sits on top of the other controls)
        sp = new SettingsPanel { Bounds = new Rectangle(112, 50, 220, 0) };
        sp.Toggled += delegate { playIntro = sp.On; SaveSettings(); };
        sp.ChooseBackground += delegate { ChooseBackground(); };
        sp.ResetBackground += delegate { ResetBackground(); };
        Controls.Add(sp);
        InitBackground();
        sp.HasCustomBg = customBg;

        LoadSettings();
        sp.Sync(playIntro);
        splash = playIntro;
        double loaded = interval;
        speed.Value = Math.Min(loaded, Slider.Max);
        interval = loaded;
        syncing = true; box.Text = Fmt(loaded); syncing = false;
        pills[sel].Selected = true;
        tabs[mode].Selected = true;
        speed.Visible = minus.Visible = plus.Visible = box.Visible = mode >= 1;
        foreach (var p in pills) p.Visible = mode < 2;
        keyBtnA.Visible = keyBtnB.Visible = mode == 2;
        RefreshKeyText();
        RefreshBindText();

        MouseDown += OnFormMouseDown;
        MouseMove += OnFormMouseMove;
        FormClosing += OnClosing;
        Shown += delegate
        {
            homeY = Top; shown = true; lastTick = Anim.Now;
            if (!splash) Top = homeY + 14;   // plain intro starts 14 px low and floats up
            StartFrames();
            for (int s = 0; s < 3; s++)
                if (keys[s] != Keys.None && !Bind(s, keys[s])) keys[s] = Keys.None;
            RefreshBindText();
        };

        Current = this;
        if (splash) { SetUiVisible(false); Splash.Prepare(); }   // controls stay hidden while the intro plays
        else { introP = 0f; intro = 0f; Opacity = 0; }            // intro disabled: the plain fade-in + float-up
    }

    // Called for every left click in the app (see InjectFilter): clicking anywhere else closes the dropdown.
    public void AnyMouseDown(IntPtr hwnd)
    {
        if (sp == null || !sp.IsOpen || choosing || (sp.IsHandleCreated && hwnd == sp.Handle)) return;
        if (hwnd == Handle && gearRect.Contains(PointToClient(Cursor.Position))) return; // the gear toggles it itself
        sp.SetOpen(false);
    }

    void SetUiVisible(bool v)
    {
        foreach (var t in tabs) t.Visible = v;
        foreach (var p in pills) p.Visible = v && mode < 2;
        keyBtnA.Visible = keyBtnB.Visible = v && mode == 2;
        bindBtn.Visible = v;
        speed.Visible = minus.Visible = plus.Visible = box.Visible = v && mode >= 1;
    }

    void SkipSplash() { if (!outroing && splashT < Splash.Total) splashT = Splash.Total; }

    // Frame pacing: a background thread sleeps until the display's next refresh (DwmFlush) and then asks
    // the UI thread for one animation frame. This follows the monitor (60/120/144 Hz) exactly, unlike
    // a WinForms timer, and never queues more than one frame if the UI thread is busy.
    void StartFrames()
    {
        frameRun = true;
        new Thread(delegate()
        {
            while (frameRun)
            {
                if (DwmFlush() != 0) Thread.Sleep(8); // no DWM available: ~120 Hz fallback
                if (Interlocked.CompareExchange(ref framePending, 1, 0) != 0) continue;
                try
                {
                    BeginInvoke((MethodInvoker)delegate { Interlocked.Exchange(ref framePending, 0); if (frameRun) Tick(null, null); });
                }
                catch { return; }
            }
        }) { IsBackground = true, Name = "frames" }.Start();
    }

    // Use the exact icon embedded in the exe so the taskbar matches the file icon.
    void LoadWindowIcon()
    {
        try
        {
            var h = new IntPtr[1]; var id = new int[1];
            if (PrivateExtractIcons(Application.ExecutablePath, 0, 48, 48, h, id, 1, 0) > 0 && h[0] != IntPtr.Zero)
                Icon = Icon.FromHandle(h[0]);
            else
                Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        }
        catch { }
    }

    // ---- saved settings ----
    void LoadSettings()
    {
        try
        {
            if (!File.Exists(SettingsFile)) return;
            foreach (var line in File.ReadAllLines(SettingsFile))
            {
                var kv = line.Split('=');
                long v;
                if (kv.Length != 2 || !long.TryParse(kv[1].Trim(), out v)) continue;
                switch (kv[0].Trim())
                {
                    case "key":
                    case "holdKey": keys[0] = (Keys)(int)v; break;
                    case "clickKey": keys[1] = (Keys)(int)v; break;
                    case "button": if (v >= 0 && v < Buttons.Length) sel = (int)v; break;
                    case "interval": interval = Math.Max(0, Math.Min(BoxMax, v)); break;          // old files: whole ms
                    case "intervalUs": interval = Math.Max(0, Math.Min(BoxMax, v / 1000.0)); break; // microseconds
                    case "mode": if (v >= 0 && v <= 2) mode = (int)v; break;
                    case "swapKey": keys[2] = (Keys)(int)v; break;
                    case "keyA": if ((Keys)(int)v != Keys.None) keyA = (Keys)(int)v; break;
                    case "keyB": if ((Keys)(int)v != Keys.None) keyB = (Keys)(int)v; break;
                    case "intro": playIntro = v != 0; break;
                }
            }
        }
        catch { }
    }

    void SaveSettings()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SettingsFile));
            File.WriteAllText(SettingsFile, "holdKey=" + (int)keys[0] + "\r\nclickKey=" + (int)keys[1] +
                "\r\nbutton=" + sel + "\r\nintervalUs=" + (long)Math.Round(interval * 1000) + "\r\nmode=" + mode +
                "\r\nintro=" + (playIntro ? 1 : 0) + "\r\nswapKey=" + (int)keys[2] + "\r\nkeyA=" + (int)keyA + "\r\nkeyB=" + (int)keyB + "\r\n");
        }
        catch { }
    }

    string KeyText(Keys k)
    {
        string s = "";
        if ((k & Keys.Control) != 0) s += "Ctrl + ";
        if ((k & Keys.Shift) != 0) s += "Shift + ";
        if ((k & Keys.Alt) != 0) s += "Alt + ";
        return s + (k & Keys.KeyCode);
    }

    void RefreshKeyText()
    {
        keyBtnA.Text = "Key 1:  " + (keyA & Keys.KeyCode); keyBtnB.Text = "Key 2:  " + (keyB & Keys.KeyCode);
        keyBtnA.Invalidate(); keyBtnB.Invalidate();
    }

    void RefreshBindText(string error = null)
    {
        string name = error ?? (keys[mode] == Keys.None ? "Not set" : KeyText(keys[mode]));
        bindBtn.Text = "Keybind:  " + name + "   (click to change)";
        bindBtn.Invalidate();
    }

    // ---- animation loop ----
    void OnClosing(object s, FormClosingEventArgs e)
    {
        SetHold(false); SetClick(false); counting = false;
        if (!closing && e.CloseReason == CloseReason.UserClosing) { closing = true; e.Cancel = true; return; }
        frameRun = false;
        for (int i = 0; i < 3; i++) if (bound[i]) { UnregisterHotKey(Handle, i + 1); bound[i] = false; }
        SaveSettings();
        timeEndPeriod(1);
    }

    void Tick(object s, EventArgs e)
    {
        double now = Anim.Now; float dt = (float)Math.Min(0.05, now - lastTick); lastTick = now;
        Anim.Raise(dt); // hover / press / slider animations on every frame
        if (closing)
        {
            if (WindowState == FormWindowState.Minimized) { Close(); return; }
            Opacity -= dt * 8; if (Opacity <= 0.02) Close();
            return;
        }
        if (splash)
        {
            if (!outroing)
            {
                splashT += dt;
                if (splashT >= Splash.Total) outroing = true;
            }
            else
            {
                // hand over to the normal UI: quick fade out, swap, then the usual fade-in + float-up
                Opacity -= dt / 0.18f;
                if (Opacity <= 0.02)
                {
                    splash = false; outroing = false;
                    SetUiVisible(true);
                    introP = 0f; intro = 0f; Opacity = 0; Top = homeY + 14;
                }
            }
        }
        else if (shown && introP < 1f)
        {
            // fixed-length ease-out (0.35 s): fade in while floating up 14px, then settle exactly
            introP = Math.Min(1f, introP + dt / 0.35f);
            intro = 1f - (float)Math.Pow(1f - introP, 3);
            Opacity = intro;
            Top = homeY + (int)Math.Round((1f - intro) * 14f);
        }

        if (counting && DateTime.UtcNow >= countEnd) { counting = false; SetClick(true); }
        if (saveIn > 0 && --saveIn == 0) SaveSettings();

        phase += 4.4f * dt;
        holdT = Anim.Ease(holdT, (holding || clicking) ? 1f : 0f, 9.4f, dt);
        if (rip < 1f) rip = Math.Min(1f, rip + 2.2f * dt);
        if (bounce > 0f) bounce = Math.Max(0f, bounce - 3.1f * dt);
        orbHover = Anim.Ease(orbHover, orbHot ? 1f : 0f, 14f, dt);
        float gt = (sp != null && sp.IsOpen) ? 1f : 0f;
        if (gearT != gt) { gearT = Anim.Ease(gearT, gt, 16f, dt); Invalidate(Rectangle.Inflate(gearRect, 6, 6)); }
        sweep += 250f * dt; if (sweep > Width + 160) sweep = -160f;

        if (WindowState == FormWindowState.Minimized) return; // nothing to draw while minimized
        if (splash) { Invalidate(); return; }                 // the intro scene covers the whole window
        // Repaint budget (the same whether or not the window has focus, so it never looks laggy behind
        // other windows): the drifting sparkles need ~30 fps for the whole window, a shooting star gets
        // every frame, and the circle repaints on every frame while it is actually animating.
        bool active = holding || clicking;
        bool orbBusy = counting || rip < 1f || bounce > 0f || holdT != (active ? 1f : 0f) || orbHover != (orbHot ? 1f : 0f) || active;
        float starU = ((float)(Anim.Now % 8.0) - 1.2f) / 0.65f;
        avgDt += (dt - avgDt) * 0.05f;
        float hz = 1f / Math.Max(0.004f, avgDt);
        float want = starU > 0f && starU < 1f ? hz : 30f;           // frames/second for the whole window
        int every = (int)Math.Max(1, Math.Round(hz / want));
        if (++skipFrames % every == 0) Invalidate();
        else if (orbBusy) Invalidate(new Rectangle(orb.X - 80, orb.Y - 80, orb.Width + 160, orb.Height + 160));
    }

    void OnFormMouseMove(object s, MouseEventArgs e)
    {
        double dx = e.X - (orb.X + orb.Width / 2), dy = e.Y - (orb.Y + orb.Height / 2);
        orbHot = dx * dx + dy * dy <= 55 * 55;
        int w = new Rectangle(262, 14, 28, 28).Contains(e.Location) ? 1 : new Rectangle(296, 14, 28, 28).Contains(e.Location) ? 2 :
                gearRect.Contains(e.Location) ? 3 : 0;
        if (w != hoverWin) { hoverWin = w; Invalidate(new Rectangle(222, 8, 116, 40)); }
        Cursor = (orbHot || w != 0) ? Cursors.Hand : Cursors.Default;
    }

    // ---- behavior ----
    static string Fmt(double v) { return v.ToString("0.##", CultureInfo.InvariantCulture); }

    // Normalise whatever was typed (empty -> keep current value; 0 = MAX speed) and optionally drop focus.
    void CommitBox(bool release = true)
    {
        double v;
        if (!double.TryParse(box.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out v)) v = interval;
        SetInterval(v);
        if (release) ActiveControl = null;
    }

    // Single place that applies a delay (ms): slider, box, live clicker and saved file all follow it.
    void SetInterval(double v)
    {
        v = Math.Round(Math.Max(0, Math.Min(v, BoxMax)), 2);
        editing = true; speed.Value = Math.Min(v, Slider.Max); editing = false; // slider tops out at 60 s
        interval = v; saveIn = 30;
        syncing = true; box.Text = Fmt(v); syncing = false;
        Invalidate(new Rectangle(0, 340, Width, 40));
    }

    static string RateText(double ms)
    {
        if (ms <= 0) return "MAX speed, no delay";
        if (ms < 1000)
        {
            double cps = 1000.0 / ms;
            return cps.ToString(cps >= 10 ? "#,0" : "0.#", CultureInfo.InvariantCulture) + " clicks/sec";
        }
        double s = ms / 1000.0;
        if (s < 120) return "1 click every " + s.ToString("0.##", CultureInfo.InvariantCulture) + " s";
        double m = s / 60.0;
        if (m < 120) return "1 click every " + m.ToString("0.#", CultureInfo.InvariantCulture) + " min";
        return "1 click every " + (m / 60.0).ToString("0.#", CultureInfo.InvariantCulture) + " h";
    }

    void SetMode(int m)
    {
        if (m == mode || capturing) return;
        SetHold(false); SetClick(false); counting = false;
        mode = m;
        for (int i = 0; i < 3; i++) tabs[i].Selected = i == m;
        speed.Visible = minus.Visible = plus.Visible = box.Visible = m >= 1;
        foreach (var p in pills) p.Visible = m < 2;
        keyBtnA.Visible = keyBtnB.Visible = m == 2;
        if (m == 0) ActiveControl = null;
        RefreshBindText();
        SaveSettings();
        Invalidate();
    }

    void SelectButton(int i)
    {
        SetHold(false); SetClick(false); counting = false;
        sel = i;
        for (int k = 0; k < 5; k++) pills[k].Selected = k == i;
        SaveSettings();
        Invalidate();
    }

    bool Bind(int slot, Keys keyData)
    {
        if (bound[slot]) { UnregisterHotKey(Handle, slot + 1); bound[slot] = false; }
        uint mod = MOD_NOREPEAT;
        if ((keyData & Keys.Control) != 0) mod |= MOD_CONTROL;
        if ((keyData & Keys.Shift) != 0) mod |= MOD_SHIFT;
        if ((keyData & Keys.Alt) != 0) mod |= MOD_ALT;
        bound[slot] = RegisterHotKey(Handle, slot + 1, mod, (uint)(keyData & Keys.KeyCode));
        return bound[slot];
    }

    void StartCapture()
    {
        capSlot = mode;
        if (bound[capSlot]) { UnregisterHotKey(Handle, capSlot + 1); bound[capSlot] = false; } // so the old key can be re-pressed
        capturing = true;
        bindBtn.Text = "Press a key...  (Esc to cancel)";
        bindBtn.Selected = true;
        bindBtn.Pulse = true;
        Focus();
    }

    void StartKeyCapture(int which)
    {
        capKey = which; capturing = true;
        var b = which == 1 ? keyBtnA : keyBtnB;
        b.Text = "Press a key...";
        b.Selected = true; b.Pulse = true;
        Focus();
    }

    void OnFormMouseDown(object s, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        ActiveControl = null; // clicking empty space leaves the number box
        if (splash) { SkipSplash(); return; }  // click anywhere skips the intro
        if (new Rectangle(296, 14, 28, 28).Contains(e.Location)) { Close(); return; }
        if (new Rectangle(262, 14, 28, 28).Contains(e.Location)) { WindowState = FormWindowState.Minimized; return; }
        if (gearRect.Contains(e.Location)) { sp.SetOpen(!sp.IsOpen); return; }
        double dx = e.X - (orb.X + orb.Width / 2), dy = e.Y - (orb.Y + orb.Height / 2);
        if (dx * dx + dy * dy <= 55 * 55) { OrbClick(); return; }
        if (e.Y < 60) { ReleaseCapture(); SendMessage(Handle, 0xA1, 2, 0); }
    }

    void OrbClick()
    {
        if (mode == 0) { SetHold(!holding); return; }
        // autoclick: stop if running / counting, otherwise start after 3s so the cursor can leave the orb
        if (clicking) SetClick(false);
        else if (counting) counting = false;
        else { counting = true; countEnd = DateTime.UtcNow.AddSeconds(3); }
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (splash) { SkipSplash(); return true; }  // any key skips the intro
        if (capturing && capKey != 0)
        {
            Keys key = keyData & Keys.KeyCode;
            if (key == Keys.ControlKey || key == Keys.ShiftKey || key == Keys.Menu) return true;
            var kb = capKey == 1 ? keyBtnA : keyBtnB;
            if (key != Keys.Escape) { if (capKey == 1) keyA = key; else keyB = key; SaveSettings(); }
            capturing = false; capKey = 0; kb.Selected = false; kb.Pulse = false;
            RefreshKeyText(); Invalidate();
            return true;
        }
        if (capturing)
        {
            Keys key = keyData & Keys.KeyCode;
            if (key == Keys.ControlKey || key == Keys.ShiftKey || key == Keys.Menu) return true;
            capturing = false;
            bindBtn.Selected = false;
            bindBtn.Pulse = false;

            string error = null;
            if (key == Keys.Escape)
            {
                if (keys[capSlot] != Keys.None) Bind(capSlot, keys[capSlot]); // restore previous
            }
            else if (Bind(capSlot, keyData)) { keys[capSlot] = keyData; SaveSettings(); }
            else
            {
                error = "In use, try another";
                if (keys[capSlot] != Keys.None) Bind(capSlot, keys[capSlot]);
            }
            RefreshBindText(error);
            Invalidate();
            return true;
        }
        return base.ProcessCmdKey(ref msg, keyData);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WM_HOTKEY)
        {
            int id = m.WParam.ToInt32();
            counting = false;
            if (id == 1) SetHold(!holding);
            else if (id == 2 || id == 3) SetClick(!clicking);
        }
        base.WndProc(ref m);
    }

    void SetHold(bool on)
    {
        if (on == holding) return;
        if (on) SetClick(false);
        holding = on;
        rip = 0f; bounce = 1f;
        var b = Buttons[sel];
        mouse_event(on ? (uint)b[1] : (uint)b[2], 0, 0, (uint)b[3], (UIntPtr)Marker);
        Invalidate();
    }

    // presses or releases a keyboard key (scan code included so games that read it see the key too)
    static void KeyEvent(Keys k, bool down)
    {
        byte vk = (byte)(k & Keys.KeyCode);
        uint fl = down ? 0u : 2u;
        bool ext = (vk >= 0x21 && vk <= 0x2E) || vk == 0x5B || vk == 0x5C || vk == 0x6F || vk == 0x90 || vk == 0xA3 || vk == 0xA5;
        if (ext) fl |= 1;
        keybd_event(vk, (byte)MapVirtualKey(vk, 0), fl, (UIntPtr)Marker);
    }

    void SetClick(bool on)
    {
        if (on == clicking) return;
        if (on) SetHold(false);
        clicking = on;
        rip = 0f; bounce = 1f;
        if (on)
        {
            int id = ++runId;
            new Thread(delegate() { ClickLoop(id); }) { IsBackground = true, Priority = ThreadPriority.AboveNormal }.Start();
        }
        else runId++;
        Invalidate();
    }

    // Runs on its own thread; timing is anchored to a stopwatch so the rate doesn't drift.
    void ClickLoop(int id)
    {
        var sw = Stopwatch.StartNew();
        double anchor = 0, lastPanic = 0;
        bool keyMode = mode == 2; int turn = 0;

        // emergency stop: Pause/Break always works, at any speed
        Func<double, bool> panic = delegate(double t)
        {
            if (t - lastPanic <= 5) return false;
            lastPanic = t;
            if ((GetAsyncKeyState(0x13) & 0x8000) == 0) return false;
            try { BeginInvoke((MethodInvoker)delegate { SetClick(false); }); } catch { }
            return true;
        };

        while (clicking && id == runId)
        {
            if (panic(sw.Elapsed.TotalMilliseconds)) return;

            var b = Buttons[sel];
            Keys pk = (turn++ % 2 == 0) ? keyA : keyB;
            if (keyMode) KeyEvent(pk, true); else mouse_event((uint)b[1], 0, 0, (uint)b[3], (UIntPtr)Marker);

            // keep the button down briefly so apps/games that poll mouse state actually see the click
            double hold = Math.Min(interval * 0.5, 6.0), t0 = sw.Elapsed.TotalMilliseconds, h;
            while ((h = sw.Elapsed.TotalMilliseconds - t0) < hold && clicking && id == runId)
            {
                if (hold - h > 2) Thread.Sleep(1); else Thread.SpinWait(40);
            }
            if (keyMode) KeyEvent(pk, false); else mouse_event((uint)b[2], 0, 0, (uint)b[3], (UIntPtr)Marker);

            // wait for the next click; the delay is re-read live so changing speed takes effect immediately
            double now, target;
            while ((now = sw.Elapsed.TotalMilliseconds) < (target = anchor + interval))
            {
                if (!clicking || id != runId) return;
                if (panic(now)) return;
                double rem = target - now;
                if (rem > 2) Thread.Sleep((int)Math.Min(rem - 1, 20)); else Thread.SpinWait(40);
            }
            anchor = (now - target > 100) ? now : target; // fell far behind (stall): resync instead of bursting
        }
    }

    // ---- background ----------------------------------------------------------------------------
    // Default: deep violet gradient with colour blooms, faint rings, drifting sparkles and an
    // occasional shooting star. Custom: the picked image, auto-cropped to the window and darkened a
    // little so the controls stay readable (sparkles stay on top, dimmer).

    // Controls copy their backdrop from this static layer, so their rounded corners blend in.
    public static Bitmap BaseBg;
    static readonly string BgFile = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HoldClick", "background.png");
    Bitmap glowA, glowB;
    bool customBg, choosing;
    int skipFrames;
    float avgDt = 1f / 60f;
    float[] bx, by, bv, bs, bph; int[] bc;

    public static void PaintBase(Graphics g, Control c)
    {
        if (BaseBg == null) { g.Clear(Bg); return; }
        g.DrawImage(BaseBg, new Rectangle(0, 0, c.Width, c.Height), c.Left, c.Top, c.Width, c.Height, GraphicsUnit.Pixel);
    }

    static Bitmap MakeGlow(int size, Color c, int centerAlpha)
    {
        var bmp = new Bitmap(size, size, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(bmp))
        using (var path = new GraphicsPath())
        {
            path.AddEllipse(0, 0, size - 1, size - 1);
            using (var pb = new PathGradientBrush(path))
            {
                pb.CenterColor = Color.FromArgb(centerAlpha, c);
                pb.SurroundColors = new[] { Color.FromArgb(0, c) };
                pb.Blend = new Blend { Positions = new[] { 0f, 0.5f, 1f }, Factors = new[] { 0f, 0.3f, 1f } };
                g.FillPath(pb, path);
            }
        }
        return bmp;
    }

    void InitBackground()
    {
        glowA = MakeGlow(400, Accent, 230);
        glowB = MakeGlow(400, Color.FromArgb(56, 189, 248), 210);
        var rnd = new Random(5);
        int n = 55;
        bx = new float[n]; by = new float[n]; bv = new float[n]; bs = new float[n]; bph = new float[n]; bc = new int[n];
        for (int i = 0; i < n; i++)
        {
            bx[i] = (float)rnd.NextDouble() * 340f; by[i] = (float)rnd.NextDouble() * 540f;
            bv[i] = 6f + (float)rnd.NextDouble() * 18f; bs[i] = 0.8f + (float)rnd.NextDouble() * 1.4f;
            bph[i] = (float)rnd.NextDouble() * 6.28f; bc[i] = rnd.Next(3);
        }
        BuildBackground();
    }

    // Rebuilds the static layer (called at start-up and whenever the picture changes).
    void BuildBackground()
    {
        var bmp = new Bitmap(340, 540, PixelFormat.Format32bppPArgb);
        Bitmap img = null;
        try
        {
            if (File.Exists(BgFile))
                using (var fs = File.OpenRead(BgFile)) using (var tmp = new Bitmap(fs)) img = new Bitmap(tmp);
        }
        catch { }
        customBg = img != null;

        using (var g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            if (customBg)
            {
                g.DrawImage(img, 0, 0, 340, 540);
                img.Dispose();
                var shade = Color.FromArgb(10, 10, 18);
                using (var b = new SolidBrush(Color.FromArgb(118, shade))) g.FillRectangle(b, 0, 0, 340, 540);
                using (var lb = new LinearGradientBrush(new Rectangle(0, 0, 340, 150), Color.FromArgb(150, shade), Color.FromArgb(0, shade), 90f))
                    g.FillRectangle(lb, 0, 0, 340, 150);
                using (var lb = new LinearGradientBrush(new Rectangle(0, 400, 340, 140), Color.FromArgb(0, shade), Color.FromArgb(165, shade), 90f))
                    g.FillRectangle(lb, 0, 400, 340, 140);
            }
            else
            {
                using (var lb = new LinearGradientBrush(new Rectangle(0, 0, 340, 540), Color.FromArgb(34, 20, 72), Color.FromArgb(14, 14, 24), 70f))
                    g.FillRectangle(lb, 0, 0, 340, 540);
                Splash.Blit(g, glowA, 300, 70, 420, 420, 0.55f);    // violet bloom, top right
                Splash.Blit(g, glowB, 20, 500, 380, 380, 0.40f);    // cyan bloom, bottom left
                Splash.Blit(g, glowA, 60, 300, 260, 260, 0.14f);
                for (int i = 1; i <= 4; i++)                        // faint rings behind the orb
                    using (var p = new Pen(Color.FromArgb(14 + 3 * (5 - i), Accent), 1f))
                    { float rr = 70 + i * 38; g.DrawEllipse(p, 170 - rr, 431 - rr, 2 * rr, 2 * rr); }
            }
        }
        var old = BaseBg; BaseBg = bmp;
        if (old != null) old.Dispose();
    }

    // Scale to cover the whole window, then centre-crop whatever overflows.
    static Bitmap CoverCrop(Image img)
    {
        const int W = 340, H = 540;
        float s = Math.Max(W / (float)img.Width, H / (float)img.Height);
        float w = img.Width * s, h = img.Height * s;
        var bmp = new Bitmap(W, H, PixelFormat.Format32bppArgb);
        using (var g = Graphics.FromImage(bmp))
        {
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.DrawImage(img, (W - w) / 2f, (H - h) / 2f, w, h);
        }
        return bmp;
    }

    void ChooseBackground()
    {
        string path;
        choosing = true;
        try
        {
            using (var dlg = new OpenFileDialog
            {
                Title = "Choose a background image", CheckFileExists = true,
                Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff|All files|*.*"
            })
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                path = dlg.FileName;
            }
        }
        finally { choosing = false; }

        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(BgFile));
            using (var img = Image.FromFile(path))
            using (var crop = CoverCrop(img))
                crop.Save(BgFile, ImageFormat.Png);
            BuildBackground();
            sp.HasCustomBg = customBg;
            RepaintAll();
        }
        catch { sp.Flash("Couldn't open that image"); }
    }

    void ResetBackground()
    {
        try { File.Delete(BgFile); } catch { }
        BuildBackground();
        sp.HasCustomBg = customBg;
        RepaintAll();
    }

    void RepaintAll() { foreach (Control c in Controls) c.Invalidate(); Invalidate(); }

    void DrawBackdrop(Graphics g, float t)
    {
        if (BaseBg != null) g.DrawImage(BaseBg, 0, 0, 340, 540); else g.Clear(Bg);

        if (!customBg)   // one slowly breathing bloom (the others are baked into the static layer; blits with alpha are the costly part)
        {
            float a = 0.5f + 0.5f * (float)Math.Sin(t * 0.7f);
            Splash.Blit(g, glowA, 280, 90, 230, 230, 0.30f * a);
        }

        // drifting, twinkling sparkles (dimmer over a custom picture)
        float k = customBg ? 0.55f : 1f;
        for (int i = 0; i < bx.Length; i++)
        {
            float y = (by[i] - bv[i] * t) % 540f; if (y < 0) y += 540f;
            float x = bx[i] + (float)Math.Sin(t * 0.6f + bph[i]) * 6f;
            float tw = 0.3f + 0.7f * (float)Math.Abs(Math.Sin(t * 1.7f + bph[i]));
            Color c = bc[i] == 0 ? Accent : bc[i] == 1 ? Color.FromArgb(56, 189, 248) : Color.White;
            int al = (int)(170 * tw * k);
            using (var br = new SolidBrush(Color.FromArgb(al, c)))
                g.FillEllipse(br, x - bs[i], y - bs[i], bs[i] * 2, bs[i] * 2);
            if (i % 9 == 0 && tw > 0.85f)   // a few glint to a little cross at their brightest
                using (var p = new Pen(Color.FromArgb(al, 255, 255, 255), 1f))
                {
                    float len = 2f + (tw - 0.85f) * 36f;
                    g.DrawLine(p, x - len, y, x + len, y); g.DrawLine(p, x, y - len, x, y + len);
                }
        }

        // an occasional shooting star
        const float cycle = 8f;
        float u = (t % cycle - 1.2f) / 0.65f;
        if (u > 0f && u < 1f)
        {
            var rr = new Random((int)(t / cycle) * 7 + 3);
            float x0 = 80 + rr.Next(240), y0 = 60 + rr.Next(150), dist = u * 240f, fade = (float)Math.Sin(u * Math.PI);
            var head = new PointF(x0 - 0.8f * dist, y0 + 0.6f * dist);
            var tail = new PointF(head.X + 0.8f * 70f * (0.4f + 0.6f * fade), head.Y - 0.6f * 70f * (0.4f + 0.6f * fade));
            using (var lb = new LinearGradientBrush(tail, head, Color.FromArgb(0, 255, 255, 255), Color.FromArgb((int)(220 * fade), 255, 255, 255)))
            using (var p = new Pen(lb, 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                g.DrawLine(p, tail, head);
        }
    }

    // Everything is drawn here every frame, so skip the default background erase (no flicker).
    protected override void OnPaintBackground(PaintEventArgs e) { }

    // ---- drawing ----
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        if (splash) { Splash.Paint(g, Math.Min(splashT, Splash.Total), ClientSize.Width, ClientSize.Height); return; }
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        const TextFormatFlags mid = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter;

        DrawBackdrop(g, (float)Anim.Now);

        // header glow
        using (var lg = new LinearGradientBrush(new Rectangle(0, 0, Width, 70), Color.FromArgb(70, Accent), Color.FromArgb(0, Bg), 90f))
            g.FillRectangle(lg, 0, 0, Width, 70);

        TextRenderer.DrawText(g, "HOLD CLICK", FTitle, new Point(18, 14), Color.White);
        TextRenderer.DrawText(g, "hold, autoclick, or swap two keys", FSub, new Point(20, 44), Color.FromArgb(150, 150, 175));

        // sweeping accent line under the header
        var sw = new Rectangle((int)sweep - 80, 66, 160, 2);
        using (var lb = new LinearGradientBrush(sw, Color.Transparent, Color.Transparent, 0f))
        {
            var cb = new ColorBlend(3);
            cb.Colors = new[] { Color.FromArgb(0, Accent), Color.FromArgb(200, Accent), Color.FromArgb(0, Accent) };
            cb.Positions = new[] { 0f, 0.5f, 1f };
            lb.InterpolationColors = cb;
            g.FillRectangle(lb, sw);
        }

        // window buttons
        Color idleC = Color.FromArgb(170, 170, 190);
        // gear: turns a quarter-turn while the dropdown is open
        {
            var st = g.Save();
            g.TranslateTransform(gearRect.X + gearRect.Width / 2f, gearRect.Y + gearRect.Height / 2f);
            g.RotateTransform(gearT * 90f);
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            using (var b = new SolidBrush(HoldClick.Lerp(hoverWin == 3 ? Color.White : idleC, Accent, gearT)))
            using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                g.DrawString("⚙", FGear, b, new PointF(0, 1), sf);
            g.Restore(st);
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        }
        TextRenderer.DrawText(g, "–", FWin, new Rectangle(262, 14, 28, 28), hoverWin == 1 ? Color.White : idleC, mid);
        TextRenderer.DrawText(g, "✕", FWin, new Rectangle(296, 14, 28, 28), hoverWin == 2 ? Color.FromArgb(248, 113, 113) : idleC, mid);

        Color grey = Color.FromArgb(130, 130, 155);
        TextRenderer.DrawText(g, mode == 0 ? "MOUSE BUTTON TO HOLD" : mode == 1 ? "MOUSE BUTTON TO CLICK" : "KEYS TO PRESS, ONE AFTER ANOTHER", FLabel, new Point(20, 124), Accent);
        TextRenderer.DrawText(g, mode == 0 ? "HOLD KEY" : mode == 1 ? "AUTOCLICK KEY" : "START / STOP KEY", FLabel, new Point(20, 232), Accent);
        if (mode == 2) TextRenderer.DrawText(g, "Key 1, Key 2, Key 1, Key 2 ...  (Pause stops it)", Font, new Rectangle(20, 182, 300, 20), grey, TextFormatFlags.Left);
        if (mode >= 1) TextRenderer.DrawText(g, mode == 2 ? "PRESS SPEED" : "CLICK SPEED", FLabel, new Point(20, 296), Accent);

        if (mode >= 1)
        {
            // rounded field behind the number box
            var fr = new Rectangle(20, 344, 64, 28);
            using (var path = Round(fr, 8))
            using (var b = new SolidBrush(Color.FromArgb(34, 34, 48)))
            using (var p = new Pen(box.Focused ? Accent : Color.FromArgb(60, 60, 82)))
            { g.FillPath(b, path); g.DrawPath(p, path); }

            TextRenderer.DrawText(g, "ms apart  •  " + (mode == 2 ? RateText(interval).Replace("clicks", "presses").Replace("click", "press") : RateText(interval)),
                Font, new Rectangle(92, 344, 235, 28), Color.White, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
        }
        else
        {
            TextRenderer.DrawText(g, "Press your key to hold the button down.\nPress it again to let go.", Font,
                new Rectangle(20, 308, 300, 40), grey, TextFormatFlags.HorizontalCenter);
        }

        // status orb
        bool active = holding || clicking;
        float pulse = 0.75f + 0.25f * (float)Math.Sin(phase * (clicking ? 3.5f : 1.2f));
        // sub-pixel (float) geometry so scaling is continuous, never snapping pixel to pixel
        float sc = 1f + 0.05f * (float)Math.Sin(bounce * Math.PI) + 0.03f * orbHover;
        float ow = orb.Width * sc, oh = orb.Height * sc;
        var o = new RectangleF(orb.X + (orb.Width - ow) / 2f, orb.Y + (orb.Height - oh) / 2f, ow, oh);

        if (holdT > 0.01f)
            for (int i = 5; i >= 1; i--)
            {
                float grow = i * 5 * (0.9f + 0.1f * pulse);
                using (var b = new SolidBrush(Color.FromArgb((int)(14 * holdT * pulse), Green)))
                    g.FillEllipse(b, RectangleF.Inflate(o, grow, grow));
            }

        if (rip < 1f)
        {
            float er = 1f - (1f - rip) * (1f - rip);
            var rr = RectangleF.Inflate(orb, er * 50f, er * 50f);
            Color rc = active ? Green : Color.FromArgb(150, 150, 180);
            using (var p = new Pen(Color.FromArgb((int)(170 * (1f - rip)), rc), 3f)) g.DrawEllipse(p, rr);
        }

        Color top = Lerp(Color.FromArgb(50, 50, 70), Color.FromArgb(110, 240, 190), holdT);
        Color bot = Lerp(Color.FromArgb(28, 28, 40), Color.FromArgb(20, 160, 110), holdT);
        using (var b = new LinearGradientBrush(o, top, bot, 90f)) g.FillEllipse(b, o);

        Color idleBorder = Lerp(Color.FromArgb(70, 70, 92), counting ? Accent : Color.FromArgb(120, 100, 190),
                                (float)(Math.Sin(phase * 0.6f) + 1) / 2f * 0.6f);
        using (var p = new Pen(Lerp(idleBorder, Green, holdT), 2.5f)) g.DrawEllipse(p, o);

        string label;
        if (counting) label = ((int)Math.Ceiling((countEnd - DateTime.UtcNow).TotalSeconds)).ToString();
        else label = holdT > 0.5f ? (clicking ? (mode == 2 ? "PRESSING" : "CLICKING") : "HOLDING") : "IDLE";
        TextRenderer.DrawText(g, label, counting ? FCount : FOrb, orb, Color.White, mid); // fixed rect: text never jitters

        string hint = mode == 0
            ? (string)Buttons[sel][0] + " button  •  click the circle or press your key"
            : (string)Buttons[sel][0] + " clicks  •  Pause/Break = emergency stop";
        TextRenderer.DrawText(g, hint, Font, new Rectangle(0, 498, Width, 18), grey, TextFormatFlags.HorizontalCenter);

        TextRenderer.DrawText(g, "Made by: Cenoh", FMade, new Rectangle(0, 516, Width, 18), Accent,
            TextFormatFlags.HorizontalCenter);

        if (!modern) // on Windows 11 DWM draws the border; this is the fallback outline for the clipped region
            using (var p = new Pen(Color.FromArgb(50, 50, 72)))
            using (var path = Round(new Rectangle(0, 0, Width - 1, Height - 1), 22))
                g.DrawPath(p, path);
    }

    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.AddMessageFilter(new InjectFilter());
        Application.Run(new HoldClick());
    }
}
