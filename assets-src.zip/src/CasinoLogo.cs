// The Cacenoh logo: a gold casino chip with a C in the middle, and the CACENOH wordmark. Drawn from shapes, sharp at any size. Also the exe icon (MakeIcon.cs).
using System;
using System.Drawing;
using System.Drawing.Drawing2D;

static class CasinoLogo
{
    public static readonly Color GoldHi = Color.FromArgb(255, 238, 160), GoldLo = Color.FromArgb(255, 168, 36), Violet = Color.FromArgb(34, 18, 74);

    // the chip, drawn in a 256 x 256 box and scaled to fit r
    public static void Chip(Graphics g, RectangleF r)
    {
        var st = g.Save(); var old = g.SmoothingMode; g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TranslateTransform(r.X, r.Y); g.ScaleTransform(r.Width / 256f, r.Height / 256f);
        var outer = new RectangleF(6, 6, 244, 244);
        using (var b = new LinearGradientBrush(outer, Color.FromArgb(255, 214, 96), Color.FromArgb(206, 112, 18), 60f)) g.FillEllipse(b, outer);
        for (int i = 0; i < 8; i++)                      // the cream stripes round the edge
        {
            var s = g.Save(); g.TranslateTransform(128, 128); g.RotateTransform(i * 45f + 22.5f);
            using (var path = Round(new RectangleF(-17, -122, 34, 36), 8)) using (var b = new SolidBrush(Color.FromArgb(252, 248, 232))) g.FillPath(b, path);
            g.Restore(s);
        }
        using (var p = new Pen(Color.FromArgb(120, 120, 60, 0), 3f)) g.DrawEllipse(p, outer);
        var ring = new RectangleF(40, 40, 176, 176);
        using (var b = new SolidBrush(Violet)) g.FillEllipse(b, ring);
        using (var p = new Pen(Color.FromArgb(255, 226, 120), 5f)) g.DrawEllipse(p, ring);
        var disc = new RectangleF(54, 54, 148, 148);
        using (var b = new LinearGradientBrush(disc, Color.FromArgb(118, 78, 214), Color.FromArgb(34, 20, 82), 70f)) g.FillEllipse(b, disc);
        // the C (for Cacenoh)
        using (var p = new Pen(Color.FromArgb(150, 10, 4, 30), 26f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(p, 95 + 3, 95 + 5, 66, 66, 45, 270);
        using (var lb = new LinearGradientBrush(new RectangleF(80, 84, 96, 90), GoldHi, GoldLo, 90f)) using (var p = new Pen(lb, 24f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(p, 95, 95, 66, 66, 45, 270);
        using (var p = new Pen(Color.FromArgb(200, 255, 255, 255), 5f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(p, 95, 91, 66, 66, 150, 110);
        // a glint
        using (var b = new SolidBrush(Color.FromArgb(150, 255, 255, 255))) g.FillEllipse(b, 62, 62, 40, 16);
        g.SmoothingMode = old; g.Restore(st);
    }

    // CACENOH in heavy gold letters with a dark outline and a drop shadow, fitted into r (left aligned, vertically centred)
    public static void Wordmark(Graphics g, RectangleF r)
    {
        var old = g.SmoothingMode; g.SmoothingMode = SmoothingMode.AntiAlias;
        using (var path = new GraphicsPath())
        {
            using (var fam = new FontFamily("Segoe UI Black")) using (var sf = new StringFormat(StringFormat.GenericTypographic)) path.AddString("CACENOH", fam, (int)FontStyle.Bold, 100f, new PointF(0, 0), sf);
            var b = path.GetBounds(); float k = Math.Min(r.Height / b.Height, r.Width / b.Width);
            using (var m = new Matrix()) { m.Translate(r.X - b.X * k, r.Y + (r.Height - b.Height * k) / 2f - b.Y * k); m.Scale(k, k, MatrixOrder.Prepend); path.Transform(m); }
            var fb = path.GetBounds();
            using (var sh = (GraphicsPath)path.Clone()) { using (var m = new Matrix()) { m.Translate(fb.Height * 0.04f, fb.Height * 0.07f); sh.Transform(m); } using (var br = new SolidBrush(Color.FromArgb(150, 8, 2, 28))) g.FillPath(br, sh); }
            using (var p = new Pen(Violet, Math.Max(2f, fb.Height * 0.14f)) { LineJoin = LineJoin.Round }) g.DrawPath(p, path);
            using (var lb = new LinearGradientBrush(new RectangleF(fb.X, fb.Y - 1, fb.Width, fb.Height + 2), GoldHi, GoldLo, 90f)) g.FillPath(lb, path);
            using (var p = new Pen(Color.FromArgb(120, 255, 255, 255), Math.Max(1f, fb.Height * 0.03f))) g.DrawPath(p, path);
        }
        g.SmoothingMode = old;
    }

    static GraphicsPath Round(RectangleF r, float d)
    {
        var p = new GraphicsPath(); p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90); p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90); p.CloseFigure(); return p;
    }
}
